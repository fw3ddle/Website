// meowzer-qnx.cpp — a SKELETON of a Meowzer 4 host on Qt WebEngine, for QNX SDP 8 with Qt for QNX (and any other
// Qt 6 platform, which is the easy way to try it first: build it on Linux with qmake && make).
// Done: the face at the top, tabs under it, the face's messages (nav/back/fwd/reload/newtab/close/select/chrome/
//       overlay/settings), blocking with the lists' domain rules, opening files in the viewer.
// To do: the vault (port MeowVault.swift's lock/open, see hosts/PROTOCOL.md), the page script's bridge, downloads,
//       cookies/history panels, meowcore (needs an fxc target for QNX). Never compiled.
#include <QApplication>
#include <QWebEngineView>
#include <QWebEnginePage>
#include <QWebEngineProfile>
#include <QWebEngineScript>
#include <QWebEngineScriptCollection>
#include <QWebEngineUrlRequestInterceptor>
#include <QWebEngineUrlScheme>
#include <QWebEngineUrlSchemeHandler>
#include <QWebEngineUrlRequestJob>
#include <QWebChannel>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QStackedWidget>
#include <QVBoxLayout>
#include <QBuffer>
#include <QFile>
#include <QDir>
#include <QSet>
#include <QStandardPaths>

static QString uiDir() { return QCoreApplication::applicationDirPath() + "/ui/"; }

// ---- meowzer://ui/ serves Meowzer's own pages from ui/ next to the program
class UiScheme : public QWebEngineUrlSchemeHandler {
public:
    void requestStarted(QWebEngineUrlRequestJob *job) override {
        QString name = job->requestUrl().fileName(); if (name.isEmpty()) name = "meowzer-ui.html";
        if (name.contains("..")) { job->fail(QWebEngineUrlRequestJob::UrlInvalid); return; }
        auto *f = new QFile(uiDir() + name, job);
        if (!f->open(QIODevice::ReadOnly)) { job->fail(QWebEngineUrlRequestJob::UrlNotFound); return; }
        QByteArray mime = name.endsWith(".html") ? "text/html" : name.endsWith(".js") ? "text/javascript" : name.endsWith(".png") ? "image/png" : "application/octet-stream";
        job->reply(mime, f);
    }
};

// ---- blocking: ||host^ / plain host rules from lists/meowlist.txt (the full Adblock syntax lives in meowcore)
class Blocker : public QWebEngineUrlRequestInterceptor {
public:
    QSet<QString> block, allow; std::function<void(QString)> onBlocked;
    void load(const QString &custom) {
        block.clear(); allow.clear(); QFile f(QCoreApplication::applicationDirPath() + "/lists/meowlist.txt"); f.open(QIODevice::ReadOnly);
        for (QString l : (QString::fromUtf8(f.readAll()) + "\n" + custom).split('\n')) {
            l = l.trimmed(); if (l.isEmpty() || l.startsWith('!') || l.startsWith('#') || l.contains("##")) continue;
            bool exc = l.startsWith("@@"); if (exc) l = l.mid(2);
            l = l.section('$', 0, 0); if (l.startsWith("||")) l = l.mid(2); if (l.endsWith('^')) l.chop(1);
            if (!l.contains('.') || l.contains('/') || l.contains('*')) continue;
            (exc ? allow : block).insert(l.toLower());
        }
    }
    void interceptRequest(QWebEngineUrlRequestInfo &info) override {
        if (info.resourceType() == QWebEngineUrlRequestInfo::ResourceTypeMainFrame) return;
        QStringList p = info.requestUrl().host().toLower().split('.');
        for (int i = 0; i + 1 < p.size(); i++) if (allow.contains(p.mid(i).join('.'))) return;
        for (int i = 0; i + 1 < p.size(); i++) if (block.contains(p.mid(i).join('.'))) { info.block(true); if (onBlocked) onBlocked(info.requestUrl().host()); return; }
    }
};

// ---- the face's side of the bridge: the face page sees it as webkit.messageHandlers.meow (see the shim below)
class Bridge : public QObject {
    Q_OBJECT
public:
    std::function<void(QJsonObject)> onMessage;
    Q_INVOKABLE void post(const QString &json) { if (onMessage) onMessage(QJsonDocument::fromJson(json.toUtf8()).object()); }
};
static const char *SHIM = R"JS(
// makes Qt's web channel look like WebKit's message handler, which the face already speaks
(function(){ var q=[]; window.webkit={messageHandlers:{meow:{postMessage:function(s){q.push(s);}}}};
  var s=document.createElement('script'); s.src='qrc:///qtwebchannel/qwebchannel.js';
  s.onload=function(){ new QWebChannel(qt.webChannelTransport,function(ch){ var b=ch.objects.meow;
    window.webkit.messageHandlers.meow.postMessage=function(x){b.post(typeof x==='string'?x:JSON.stringify(x));}; q.forEach(function(x){b.post(x);}); q=[]; }); };
  document.documentElement.appendChild(s); })();
)JS";

class Meowzer : public QWidget {
    QWebEngineView *face; QStackedWidget *pages; Blocker blocker; Bridge bridge; QWebChannel channel;
    struct Tab { int id; QWebEngineView *view; }; QList<Tab> tabs; int active = 0, nextTab = 1; bool ready = false;
    QJsonObject settings;
public:
    Meowzer() {
        auto *lay = new QVBoxLayout(this); lay->setContentsMargins(0, 0, 0, 0); lay->setSpacing(0);
        auto *prof = QWebEngineProfile::defaultProfile();
        prof->installUrlSchemeHandler("meowzer", new UiScheme);
        prof->setUrlRequestInterceptor(&blocker);
        blocker.onBlocked = [this](QString h) { QMetaObject::invokeMethod(this, [this, h] { toFace({{"t", "blocked"}, {"tab", active}, {"host", h}, {"ctx", ""}}); }); };
        face = new QWebEngineView(this); face->setFixedHeight(78); face->page()->setBackgroundColor(Qt::transparent);
        channel.registerObject("meow", &bridge); face->page()->setWebChannel(&channel);
        QWebEngineScript sh; sh.setSourceCode(SHIM); sh.setInjectionPoint(QWebEngineScript::DocumentCreation); sh.setWorldId(QWebEngineScript::MainWorld);
        face->page()->scripts().insert(sh);
        bridge.onMessage = [this](QJsonObject m) { onFace(m); };
        connect(face, &QWebEngineView::loadFinished, this, [this] {
            ready = true; toFace({{"t", "init"}, {"platform", "desktop"}, {"caption", false}, {"tiles", 1}, {"engine", "Qt WebEngine"}, {"settings", settings}, {"jar", QJsonObject()}, {"table", "# Qt: domain rules"}, {"totalBlocked", 0}});
            pushState(); });
        face->load(QUrl("meowzer://ui/meowzer-ui.html"));
        pages = new QStackedWidget(this); lay->addWidget(face); lay->addWidget(pages, 1);
        blocker.load(""); newTab("https://duckduckgo.com/");
        resize(1280, 820);
    }
    void toFace(const QJsonObject &o) { if (ready) face->page()->runJavaScript("window.meowReceive(" + QString::fromUtf8(QJsonDocument(o).toJson(QJsonDocument::Compact)) + ")"); }
    Tab *tab(int id) { for (auto &t : tabs) if (t.id == (id ? id : active)) return &t; return nullptr; }
    void newTab(const QString &url) {
        auto *v = new QWebEngineView; Tab t{nextTab++, v}; tabs << t; pages->addWidget(v);
        connect(v, &QWebEngineView::urlChanged, this, [this] { pushState(); });
        connect(v, &QWebEngineView::titleChanged, this, [this] { pushState(); });
        connect(v, &QWebEngineView::loadStarted, this, [this] { pushState(); });
        connect(v, &QWebEngineView::loadFinished, this, [this] { pushState(); });
        v->load(QUrl::fromUserInput(url.isEmpty() ? "https://duckduckgo.com/" : url));
        select(t.id);
    }
    void select(int id) { if (auto *t = tab(id)) { active = id; pages->setCurrentWidget(t->view); pushState(); } }
    void close(int id) {
        for (int i = 0; i < tabs.size(); i++) if (tabs[i].id == id) { pages->removeWidget(tabs[i].view); tabs[i].view->deleteLater(); tabs.removeAt(i);
            if (tabs.isEmpty()) { newTab(""); return; } if (active == id) select(tabs[qMin(i, tabs.size() - 1)].id); else pushState(); return; }
    }
    void pushState() {
        QJsonArray list; for (auto &t : tabs) list << QJsonObject{{"id", t.id}, {"url", t.view->url().toString()}, {"title", t.view->title()}, {"favicon", ""},
            {"loading", false}, {"canBack", t.view->history()->canGoBack()}, {"canFwd", t.view->history()->canGoForward()}};
        toFace({{"t", "state"}, {"active", active}, {"tabs", list}});
    }
    void onFace(const QJsonObject &m) {
        QString t = m["t"].toString(); Tab *tt = tab(m["tab"].toInt());
        if (t == "nav" && tt) tt->view->load(QUrl::fromUserInput(m["url"].toString()));
        else if (t == "back" && tt) tt->view->back(); else if (t == "fwd" && tt) tt->view->forward();
        else if (t == "reload" && tt) tt->view->reload(); else if (t == "stop" && tt) tt->view->stop();
        else if (t == "newtab") newTab(m["url"].toString()); else if (t == "close") close(m["tab"].toInt()); else if (t == "select") select(m["tab"].toInt());
        else if (t == "chrome" && m["h"].toDouble() > 0) face->setFixedHeight(int(m["h"].toDouble()));
        else if (t == "overlay") { bool o = m["open"].toBool(); pages->setVisible(!o); face->setMinimumHeight(o ? height() : 0); if (!o) face->setFixedHeight(78); }
        else if (t == "settings") { settings = m["settings"].toObject(); blocker.load(settings["customRules"].toString()); }
        else if (t == "vault" || t == "probe" || t == "tor" || t == "seal" || t == "route") toFace({{"t", t}, {"id", m["id"]}, {"data", QJsonObject{{"unsupported", true}}}});
        else if (t == "core") toFace({{"t", "core"}, {"id", m["id"]}, {"out", ""}});
    }
};

int main(int argc, char **argv) {
    QWebEngineUrlScheme s("meowzer"); s.setFlags(QWebEngineUrlScheme::SecureScheme | QWebEngineUrlScheme::LocalAccessAllowed | QWebEngineUrlScheme::CorsEnabled);
    QWebEngineUrlScheme::registerScheme(s);
    QApplication app(argc, argv); app.setApplicationName("Meowzer");
    Meowzer w; w.show(); return app.exec();
}
#include "meowzer-qnx.moc"
