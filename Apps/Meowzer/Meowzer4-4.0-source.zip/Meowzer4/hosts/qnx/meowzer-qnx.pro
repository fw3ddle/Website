# qmake project for the Meowzer 4 QNX skeleton (Qt 6 with WebEngine and WebChannel)
QT += widgets webenginewidgets webchannel
CONFIG += c++17
TARGET = meowzer4
SOURCES += meowzer-qnx.cpp
# ui/ and lists/ go next to the program
ui.path = $$OUT_PWD/ui
ui.files = ../../ui/*
lists.path = $$OUT_PWD/lists
lists.files = ../../core/lists/meowlist.txt
INSTALLS += ui lists
QMAKE_POST_LINK += $$quote(mkdir -p $$OUT_PWD/ui $$OUT_PWD/lists && cp ../../ui/* $$OUT_PWD/ui/ && cp ../../core/lists/meowlist.txt $$OUT_PWD/lists/)
