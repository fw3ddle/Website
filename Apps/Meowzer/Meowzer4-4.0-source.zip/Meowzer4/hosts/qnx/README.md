# Meowzer 4 for QNX — a starting point

QNX is BlackBerry's real-time OS, used in cars and devices. Building for it needs **QNX SDP 8.0** (the Software Development Platform). That means:
* a myQNX account;
* BlackBerry's licence, which you accept yourself;
* the QNX Software Center download.

None of that could be done for you here. Signing in and accepting licences is yours to do, so this folder isn't built or tested.

## The honest state of a browser on QNX
* QNX has no WebView2, WebKitGTK or GeckoView that you can just link.
* The options are:
  1. **QNX's Web Browser / Qt WebEngine for QNX.** This is a Chromium-based component in some QNX packages for cars. If your SDP has it, a Qt host like `meowzer-qnx.cpp` is the shortest path. The plan, which is what this folder sketches:
     * Meowzer's face goes in one `QWebEngineView`.
     * Tabs are more views.
     * `QWebChannel` replaces `chrome.webview`, so the face and the vault work.
     * `QWebEngineUrlRequestInterceptor` does the blocking.
  2. **Port WebKit (WPE WebKit) to QNX.** WPE is built for embedded devices, but porting it is a big project.
* meowcore would need an fxc target for QNX (`aarch64-qnx` / `x86_64-qnx`). ꟻX 0.28 has no such target. Until it does, a QNX host would use a C++ copy of the vault (the format is in `hosts/PROTOCOL.md`; `tests/vault-port.js` is a reference).

## Files
* `meowzer-qnx.cpp` — a Qt WebEngine host skeleton: face, tabs, blocking interceptor, and the message hookup. It isn't complete and has never been compiled.
* `meowzer-qnx.pro` — its qmake project.

## To try it
1. Install QNX SDP 8.0 and Qt for QNX with WebEngine.
2. `source ~/qnx800/qnxsdp-env.sh`
3. `qmake meowzer-qnx.pro && make`
