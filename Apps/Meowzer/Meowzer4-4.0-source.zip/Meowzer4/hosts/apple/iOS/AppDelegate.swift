// AppDelegate.swift (iOS / iPadOS) — one screen, MeowHost inside it, the Files app for opening and exporting.
import UIKit
import UniformTypeIdentifiers

final class HostViewController: UIViewController, UIDocumentPickerDelegate {
    var host: MeowHost!, pickDone: ((URL?) -> Void)?, pickMany: (([URL]) -> Void)?
    override func viewDidLoad() {
        super.viewDidLoad(); view.backgroundColor = .systemBackground
        host = MeowHost(container: view)
        host.openFilePicker = { [weak self] in self?.pick(types: [.item], many: true) { urls in self?.host.openFiles(urls) } }
        host.pickOpen = { [weak self] done in self?.pick(types: [UTType(filenameExtension: "meowvault") ?? .data, .data], many: false) { done($0.first) } }
        host.pickSave = { [weak self] name, done in   // write to a temporary file, then let the user choose where it goes
            guard let self else { return }
            let tmp = FileManager.default.temporaryDirectory.appendingPathComponent(name); FileManager.default.createFile(atPath: tmp.path, contents: Data())
            done(tmp)
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {   // after the export has been written
                let p = UIDocumentPickerViewController(forExporting: [tmp], asCopy: true); self.present(p, animated: true)
            }
        }
        host.start()
    }
    override func viewDidLayoutSubviews() { super.viewDidLayoutSubviews(); host.layout() }
    func pick(types: [UTType], many: Bool, done: @escaping ([URL]) -> Void) {
        let p = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: true); p.allowsMultipleSelection = many; p.delegate = self
        pickMany = done; present(p, animated: true)
    }
    func documentPicker(_ c: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) { pickMany?(urls); pickMany = nil }
    func documentPickerWasCancelled(_ c: UIDocumentPickerViewController) { pickMany?([]); pickMany = nil }
}

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    func application(_ app: UIApplication, didFinishLaunchingWithOptions o: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        window = UIWindow(frame: UIScreen.main.bounds); window?.rootViewController = HostViewController(); window?.makeKeyAndVisible(); return true
    }
    // files shared to Meowzer ("Open in…")
    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey: Any] = [:]) -> Bool {
        (window?.rootViewController as? HostViewController)?.host.openFiles([url]); return true
    }
}
