// AppDelegate.swift (macOS) — one window, MeowHost inside it, the Open and Save boxes, files from Finder.
import AppKit
import UniformTypeIdentifiers

final class HostView: NSView { var onLayout: (() -> Void)?; override func layout() { super.layout(); onLayout?() } }

@main
final class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate {
    var window: NSWindow!, host: MeowHost!, pendingFiles: [URL] = []

    static func main() { let app = NSApplication.shared; let d = AppDelegate(); app.delegate = d; app.setActivationPolicy(.regular); app.run() }

    func applicationDidFinishLaunching(_ n: Notification) {
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1280, height: 820), styleMask: [.titled, .closable, .miniaturizable, .resizable, .fullSizeContentView], backing: .buffered, defer: false)
        window.titlebarAppearsTransparent = true; window.titleVisibility = .hidden; window.center(); window.setFrameAutosaveName("Meowzer")
        let v = HostView(frame: window.contentView!.bounds); v.autoresizingMask = [.width, .height]; window.contentView = v
        host = MeowHost(container: v); v.onLayout = { [weak self] in self?.host.layout() }
        host.setTitle = { [weak self] t in self?.window.title = t }
        host.openFilePicker = { [weak self] in
            let p = NSOpenPanel(); p.allowsMultipleSelection = true; p.canChooseDirectories = false; p.title = "Open in Meowzer"
            if p.runModal() == .OK { self?.host.openFiles(p.urls) }
        }
        host.pickSave = { name, done in
            let p = NSSavePanel(); p.nameFieldStringValue = name; p.title = "Export the Meowzer vault"
            if let t = UTType(filenameExtension: "meowvault") { p.allowedContentTypes = [t] }
            done(p.runModal() == .OK ? p.url : nil)
        }
        host.pickOpen = { done in
            let p = NSOpenPanel(); p.title = "Import a Meowzer vault"; p.allowsMultipleSelection = false
            done(p.runModal() == .OK ? p.urls.first : nil)
        }
        let args = CommandLine.arguments.dropFirst().filter { !$0.hasPrefix("-") }.map { URL(fileURLWithPath: $0) }
        host.start(open: pendingFiles + args); pendingFiles = []
        window.makeKeyAndOrderFront(nil); NSApp.activate(ignoringOtherApps: true)
        buildMenu()
    }
    func application(_ app: NSApplication, open urls: [URL]) { if let host, host.faceReady { host.openFiles(urls) } else { pendingFiles += urls } }
    func applicationShouldTerminateAfterLastWindowClosed(_ s: NSApplication) -> Bool { true }

    // keyboard shortcuts go to the face, as on Windows
    @objc func newTab() { host.newTab(nil) }
    @objc func closeTab() { host.close(host.active) }
    @objc func openFile() { host.openFilePicker?() }
    @objc func focusAddress() { host.face.evaluateJavaScript("document.querySelector('#url')?.focus()", completionHandler: nil) }
    @objc func reload() { host.tab(nil)?.web.reload() }
    func buildMenu() {
        let main = NSMenu(), app = NSMenuItem(), file = NSMenuItem(), edit = NSMenuItem()
        main.addItem(app); main.addItem(file); main.addItem(edit)
        let am = NSMenu(); am.addItem(withTitle: "Quit Meowzer", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q"); app.submenu = am
        let fm = NSMenu(title: "File")
        fm.addItem(withTitle: "New Tab", action: #selector(newTab), keyEquivalent: "t"); fm.addItem(withTitle: "Open File…", action: #selector(openFile), keyEquivalent: "o")
        fm.addItem(withTitle: "Close Tab", action: #selector(closeTab), keyEquivalent: "w"); fm.addItem(withTitle: "Open Location", action: #selector(focusAddress), keyEquivalent: "l")
        fm.addItem(withTitle: "Reload", action: #selector(reload), keyEquivalent: "r"); file.submenu = fm
        let em = NSMenu(title: "Edit")
        for (t, s, k) in [("Undo", "undo:", "z"), ("Redo", "redo:", "Z"), ("Cut", "cut:", "x"), ("Copy", "copy:", "c"), ("Paste", "paste:", "v"), ("Select All", "selectAll:", "a")] { em.addItem(withTitle: t, action: Selector(s), keyEquivalent: k) }
        edit.submenu = em; NSApp.mainMenu = main
    }
}
