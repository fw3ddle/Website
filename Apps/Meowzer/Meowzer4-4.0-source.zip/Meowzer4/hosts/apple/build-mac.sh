#!/bin/sh
# The easy way on a Mac: ./build-mac.sh            → build/apple/Meowzer.app (and copies it to /Applications if you say yes)
#                        ./build-mac.sh ios        → opens the iOS project in Xcode (pick your phone and press ▶)
# Needs: Xcode 15+ (from the App Store) and its command line tools. XcodeGen is fetched with Homebrew if you have it.
# meowcore (blocking lists, the vault cipher, the costume's personas) is compiled with fxc from ꟻX 0.28
# (bin/macos-arm64 or bin/macos-x64); set FXC=/path/to/fxc, or put fxc on your PATH. Without it the Mac app still runs,
# using the Swift copy of the vault (MeowVault.swift) and WebKit's own content rules.
set -e
cd "$(dirname "$0")"
ROOT=../..
OUT=$ROOT/build/apple
say() { printf '\n\033[1;33m🐱 %s\033[0m\n' "$*"; }
mkdir -p "$OUT"

command -v xcodebuild >/dev/null || { echo "Install Xcode from the App Store first, then run: xcode-select --install"; exit 1; }
if ! command -v xcodegen >/dev/null; then
  if command -v brew >/dev/null; then say "Getting XcodeGen with Homebrew"; brew install xcodegen
  else echo "Install XcodeGen (https://github.com/yonaskolb/XcodeGen): brew install xcodegen"; exit 1; fi
fi

FXC=${FXC:-fxc}
if command -v "$FXC" >/dev/null 2>&1; then
  say "Compiling meowcore with $FXC"
  # fxc 0.28 makes Linux, Windows and UEFI programs; a macOS target is used when your fxc has one
  if "$FXC" "$ROOT/core/meowcore.fx" -o "$OUT/meowcore" --target=macos 2>/dev/null; then chmod +x "$OUT/meowcore"
  else echo "This fxc can't make macOS programs yet; the Mac app will use its built-in Swift vault instead."; rm -f "$OUT/meowcore"; fi
else
  echo "fxc not found: skipping meowcore (set FXC=/path/to/fxc to include it)."
fi

say "Making the Xcode project"
xcodegen generate --spec project.yml

if [ "$1" = "ios" ]; then open Meowzer4.xcodeproj; say "Pick Meowzer4-iOS and your iPhone/iPad at the top of Xcode, then press ▶"; exit 0; fi

say "Building Meowzer for this Mac"
xcodebuild -project Meowzer4.xcodeproj -scheme Meowzer4-mac -configuration Release -derivedDataPath "$OUT/dd" \
  CODE_SIGN_IDENTITY=- CODE_SIGNING_REQUIRED=NO build | tail -n 3
rm -rf "$OUT/Meowzer.app"; cp -R "$OUT/dd/Build/Products/Release/Meowzer.app" "$OUT/"
say "Built $OUT/Meowzer.app"

printf 'Copy it to /Applications? [y/N] '; read -r yes
if [ "$yes" = y ] || [ "$yes" = Y ]; then rm -rf /Applications/Meowzer.app; cp -R "$OUT/Meowzer.app" /Applications/; say "Installed. Open Meowzer from Launchpad."; fi
echo "Not signed by Apple: the first time, right-click Meowzer ▸ Open, then Open again."
