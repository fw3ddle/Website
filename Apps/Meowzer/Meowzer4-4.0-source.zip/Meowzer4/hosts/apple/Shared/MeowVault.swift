// MeowVault.swift — the vault lock and the generators, in Swift, for macOS and iOS.
//
// iOS doesn't let an app start another program, so meowcore can't run there. This is a port of exactly what
// meowcore's @vlock/@vopen do, so vault files move freely between every Meowzer. tests/vault-port.js checks the
// same port against meowcore byte for byte:
//   - PBKDF2-HMAC-SHA256 over (pepper ‖ password), 96 bytes;
//   - two ChaCha20 streams (RFC 8439, block counter from 1) XORed together;
//   - HMAC-SHA256 over salt ‖ nonce ‖ ciphertext with the third 32 bytes.
import Foundation
import CommonCrypto
import CryptoKit
import Security

enum MeowVault {
    static let pepper = Array("Meowzer 4 vault pepper. Only a Meowzer opens what a Meowzer seals; the cat keeps the key under its paw.".utf8)
    static let roundsWithPassword: UInt32 = 600_000

    static func random(_ n: Int) -> [UInt8] { var b = [UInt8](repeating: 0, count: n); _ = SecRandomCopyBytes(kSecRandomDefault, n, &b); return b }

    static func pbkdf2(_ password: [UInt8], salt: [UInt8], rounds: UInt32, length: Int) -> [UInt8] {
        var out = [UInt8](repeating: 0, count: length)
        password.withUnsafeBufferPointer { pw in
            _ = CCKeyDerivationPBKDF(CCPBKDFAlgorithm(kCCPBKDF2), UnsafeRawPointer(pw.baseAddress!).assumingMemoryBound(to: Int8.self), pw.count,
                                     salt, salt.count, CCPseudoRandomAlgorithm(kCCPRFHmacAlgSHA256), rounds, &out, length)
        }
        return out
    }

    /// RFC 8439 ChaCha20 keystream, from block counter `counter`
    struct ChaCha {
        var s = [UInt32](repeating: 0, count: 16), block = [UInt8](repeating: 0, count: 64), pos = 64
        init(key: ArraySlice<UInt8>, nonce: [UInt8], counter: UInt32) {
            let k = Array(key), w = { (b: [UInt8], o: Int) -> UInt32 in UInt32(b[o]) | UInt32(b[o + 1]) << 8 | UInt32(b[o + 2]) << 16 | UInt32(b[o + 3]) << 24 }
            s[0] = 0x61707865; s[1] = 0x3320646e; s[2] = 0x79622d32; s[3] = 0x6b206574
            for i in 0..<8 { s[4 + i] = w(k, 4 * i) }
            s[12] = counter; for i in 0..<3 { s[13 + i] = w(nonce, 4 * i) }
        }
        mutating func next() -> UInt8 {
            if pos == 64 {
                var x = s
                func qr(_ a: Int, _ b: Int, _ c: Int, _ d: Int) {
                    x[a] = x[a] &+ x[b]; x[d] ^= x[a]; x[d] = x[d] << 16 | x[d] >> 16
                    x[c] = x[c] &+ x[d]; x[b] ^= x[c]; x[b] = x[b] << 12 | x[b] >> 20
                    x[a] = x[a] &+ x[b]; x[d] ^= x[a]; x[d] = x[d] << 8 | x[d] >> 24
                    x[c] = x[c] &+ x[d]; x[b] ^= x[c]; x[b] = x[b] << 7 | x[b] >> 25
                }
                for _ in 0..<10 { qr(0, 4, 8, 12); qr(1, 5, 9, 13); qr(2, 6, 10, 14); qr(3, 7, 11, 15); qr(0, 5, 10, 15); qr(1, 6, 11, 12); qr(2, 7, 8, 13); qr(3, 4, 9, 14) }
                for i in 0..<16 { let v = x[i] &+ s[i]; for j in 0..<4 { block[4 * i + j] = UInt8(truncatingIfNeeded: v >> (8 * UInt32(j))) } }
                s[12] = s[12] &+ 1; pos = 0
            }
            defer { pos += 1 }
            return block[pos]
        }
    }

    /// salt(16) ‖ nonce(12) ‖ tag(32) ‖ ciphertext
    static func lock(_ plain: [UInt8], rounds: UInt32, password: [UInt8]) -> [UInt8] {
        let salt = random(16), nonce = random(12)
        let dk = pbkdf2(pepper + password, salt: salt, rounds: rounds, length: 96)
        var a = ChaCha(key: dk[0..<32], nonce: nonce, counter: 1), b = ChaCha(key: dk[32..<64], nonce: nonce, counter: 1)
        let ct = plain.map { $0 ^ a.next() ^ b.next() }
        var mac = HMAC<SHA256>(key: SymmetricKey(data: dk[64..<96])); mac.update(data: salt); mac.update(data: nonce); mac.update(data: ct)
        return salt + nonce + Array(mac.finalize()) + ct
    }
    /// nil when the password is wrong or a byte was changed
    static func open(_ d: [UInt8], rounds: UInt32, password: [UInt8]) -> [UInt8]? {
        guard d.count >= 60 else { return nil }
        let salt = Array(d[0..<16]), nonce = Array(d[16..<28]), tag = Array(d[28..<60]), ct = Array(d[60...])
        let dk = pbkdf2(pepper + password, salt: salt, rounds: rounds, length: 96)
        var mac = HMAC<SHA256>(key: SymmetricKey(data: dk[64..<96])); mac.update(data: salt); mac.update(data: nonce); mac.update(data: ct)
        guard Array(mac.finalize()).elementsEqual(tag) else { return nil }   // CryptoKit's isValidAuthenticationCode would also do
        var a = ChaCha(key: dk[0..<32], nonce: nonce, counter: 1), b = ChaCha(key: dk[32..<64], nonce: nonce, counter: 1)
        return ct.map { $0 ^ a.next() ^ b.next() }
    }

    // the local vault.dat: "MEOWVLT1" ‖ lock(…, rounds 1, password = the 32-byte key in the Keychain)
    static func fileBytes(_ plain: [UInt8], key: [UInt8]) -> [UInt8] { Array("MEOWVLT1".utf8) + lock(plain, rounds: 1, password: key) }
    static func fromFile(_ f: [UInt8], key: [UInt8]) -> [UInt8]? { f.count >= 68 && f.starts(with: Array("MEOWVLT1".utf8)) ? open(Array(f[8...]), rounds: 1, password: key) : nil }
    // an export: "MEOWVAULT", 1, flags, rounds (u32 LE), then lock(…)
    static func export(_ plain: [UInt8], password: String) -> [UInt8] {
        let pw = Array(password.utf8), rounds: UInt32 = pw.isEmpty ? 1 : roundsWithPassword
        return Array("MEOWVAULT".utf8) + [1, pw.isEmpty ? 0 : 1] + withUnsafeBytes(of: rounds.littleEndian, Array.init) + lock(plain, rounds: rounds, password: pw)
    }
    enum ImportResult { case notAVault, needsPassword, wrong, damaged, ok([UInt8]) }
    static func importFile(_ f: [UInt8], password: String) -> ImportResult {
        guard f.count >= 75, f.starts(with: Array("MEOWVAULT".utf8)), f[9] == 1 else { return .notAVault }
        let locked = f[10] & 1 == 1, rounds = UInt32(f[11]) | UInt32(f[12]) << 8 | UInt32(f[13]) << 16 | UInt32(f[14]) << 24
        if locked && password.isEmpty { return .needsPassword }
        guard let p = open(Array(f[15...]), rounds: rounds, password: locked ? Array(password.utf8) : []) else { return locked ? .wrong : .damaged }
        return .ok(p)
    }

    // ------------------------------------------------------------------ the generators (same tiers as meowcore's @gen / @user)
    static let lower = "abcdefghijklmnopqrstuvwxyz", upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ", digit = "0123456789"
    static let sym1 = "!@#$%&*-_+=?", sym2 = "!#$%&()*+,-./:;<=>?@[]^_{|}~", look = "0O1lI|"
    static let adj = "amber ancient arctic azure bashful bold brave breezy bright brisk bronze bubbly calm candid cheery chilly clever cloudy cosmic cozy crisp curly daring dapper dewy dizzy dreamy dusky eager early electric elder ember epic fancy feisty fiery fluffy foggy frosty fuzzy gentle giddy gilded glad gleaming golden grand happy hazel hidden honey humble icy indigo ivory jade jolly keen kind lavender lazy lemon lively lofty lucky lunar maple marble mellow merry minty misty modest mossy nimble noble odd olive orange pastel peachy pearl plucky polar proud quick quiet rainy rapid rosy royal ruby rustic sandy scarlet shiny silent silky silver sleepy smoky snowy solar sparkly spicy sunny swift tidal tiny tropic velvet violet vivid wandering warm wavy whimsy wild windy wise witty woolly zesty stormy starry toasty sly plush".split(separator: " ").map(String.init)
    static let noun = "acorn anchor badger bagel banjo beacon beetle biscuit bobcat breeze brook bubble button cactus canyon cat cedar cello comet cookie coral cricket crystal cub dingo dolphin dragon drum dune eagle echo falcon feather fennec ferret fig firefly fjord flute fox gecko geyser glacier gopher harbor hedgehog heron hollow iris island jaguar jasper kettle kitten koala lantern lark lemur lily lion llama lynx magpie mango meadow meteor mitten moon moose moth muffin nebula nugget oak ocelot orbit otter owl panda panther paw pebble pepper pine pixel planet plum pond puffin puma quartz quill rabbit raven reef river robin rocket saddle sage salmon sparrow spruce star stone storm sunset swan thistle thunder tiger toffee trout tulip turtle valley walrus whisker willow wombat yarn yeti zebra zephyr biscotti clover".split(separator: " ").map(String.init)
    /// an unbiased choice in 0..<n (rejection sampling over random bytes)
    static func pick(_ n: Int) -> Int { precondition(n > 0 && n <= 65536); let lim = 65536 - 65536 % n; while true { let b = random(2), v = Int(b[0]) << 8 | Int(b[1]); if v < lim { return v % n } } }
    static func password(tier: Int, length: Int, noLookAlikes: Bool) -> String {
        if tier == 5 {   // passphrase: capitalised words joined by '-', then a digit
            let words = max(3, min(8, length / 5)); let all = adj + noun
            return (0..<words).map { _ in all[pick(all.count)].capitalized }.joined(separator: "-") + "-" + String(pick(10))
        }
        let strip = { (s: String) in noLookAlikes ? s.filter { !look.contains($0) } : s }
        var classes = [strip(digit)]
        if tier >= 1 { classes = [strip(lower), strip(upper)] }
        if tier >= 2 { classes.append(strip(digit)) }
        if tier == 3 { classes.append(sym1) } else if tier >= 4 { classes.append(strip(sym2)) }
        let n = max(tier == 0 ? 4 : classes.count, min(128, length)), pool = Array(classes.joined())
        while true {   // draw until every class is present (they almost always are)
            let pw = (0..<n).map { _ in pool[pick(pool.count)] }
            if classes.allSatisfy({ c in pw.contains(where: c.contains) }) { return String(pw) }
        }
    }
    static func userName(style: Int) -> String {
        let a = adj[pick(adj.count)], n = noun[pick(noun.count)]
        switch style {
        case 0: return a + n + String(format: "%02d", pick(100))
        case 1: return a + "." + n
        case 2: return a + "_" + n + "_" + String(format: "%03d", pick(1000))
        default: let cs = Array("abcdefghijkmnpqrstuvwxyz23456789"); return String((0..<10).map { _ in cs[pick(cs.count)] })
        }
    }
}

/// The 32-byte key that locks vault.dat, kept in the Keychain (this device only, after first unlock)
enum MeowKeychain {
    static func vaultKey() -> [UInt8] {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "Meowzer vault", kSecAttrAccount as String: "vault.key", kSecReturnData as String: true]
        var out: CFTypeRef?
        if SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess, let d = out as? Data, d.count == 32 { return Array(d) }
        let k = MeowVault.random(32)
        let add: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "Meowzer vault", kSecAttrAccount as String: "vault.key",
                                  kSecValueData as String: Data(k), kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]
        SecItemDelete(add as CFDictionary); SecItemAdd(add as CFDictionary, nil)
        return k
    }
    static func newVaultKey() { let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "Meowzer vault", kSecAttrAccount as String: "vault.key"]; SecItemDelete(q as CFDictionary); _ = vaultKey() }
}
