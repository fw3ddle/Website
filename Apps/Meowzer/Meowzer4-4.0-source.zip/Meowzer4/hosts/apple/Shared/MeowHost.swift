// MeowHost.swift — Meowzer 4's host for macOS and iOS, on WKWebView (WebKit, the system engine).
// The same face (ui/meowzer-ui.html), page script (ui/inject.js) and protocol as Windows: see hosts/PROTOCOL.md.
// The platform shells (macOS/AppDelegate.swift, iOS/AppDelegate.swift) give it a container view and draw nothing else.
//
// What differs from Windows:
//   - Blocking is a WKContentRuleList built from the same lists (WebKit decides requests itself; a host can't
//     see each one), so the cat counts what it blocks less exactly.
//   - meowcore runs on macOS (bundled, as on Windows). iOS can't start programs, so there the vault and the
//     generators come from MeowVault.swift (the same bytes), and the costume's personas aren't drawn.
//   - Not done yet: tiling, the bookshelf, the cookie oven's sweep, the Mask's probes and Tor route, ghost pages.
// Status: written to the protocol, not yet compiled (this was written on a Windows PC without Xcode).
import Foundation
import WebKit
#if os(macOS)
import AppKit
typealias MeowView = NSView
#else
import UIKit
typealias MeowView = UIView
#endif

final class MeowTab { let id: Int; let web: WKWebView; var url = "", title = "New tab"; init(id: Int, web: WKWebView) { self.id = id; self.web = web } }

final class MeowHost: NSObject, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate, WKURLSchemeHandler {
    static let world = WKContentWorld.world(name: "meowzer")
    let container: MeowView
    var face: WKWebView!
    var tabs: [MeowTab] = [], active = 0, nextTab = 1, faceH: CGFloat = 78, overlay = false, faceReady = false
    var settings: [String: Any] = [:], jar: [String: Any] = [:], vault: [String: Any] = ["logins": [Any](), "never": [Any]()]
    var vaultBroken = false, files: [Int: URL] = [:], nextFile = 1, rules: WKContentRuleList?
    let key = "meow" + MeowVault.random(8).map { String(format: "%02x", $0) }.joined()
    let pool = WKProcessPool()
    lazy var data: URL = {
        if let d = ProcessInfo.processInfo.environment["MEOWZER_DATA"] { return URL(fileURLWithPath: d) }
        let u = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("Meowzer4")
        try? FileManager.default.createDirectory(at: u, withIntermediateDirectories: true); return u
    }()
    let ui: URL = Bundle.main.resourceURL!.appendingPathComponent("ui")
    var platform: String {
        #if os(iOS)
        return UIDevice.current.userInterfaceIdiom == .phone ? "phone" : "tablet"
        #else
        return "desktop"
        #endif
    }
    /// shells call this when the window or a file chooser has something to say
    var openFilePicker: (() -> Void)?
    var pickSave: ((String, @escaping (URL?) -> Void) -> Void)?
    var pickOpen: ((@escaping (URL?) -> Void) -> Void)?
    var setTitle: ((String) -> Void)?

    init(container: MeowView) { self.container = container; super.init() }

    // ---------------------------------------------------------------- start
    func start(open urls: [URL] = []) {
        settings = loadJSON("settings.json"); jar = loadJSON("jar.json"); loadVault()
        let fc = WKWebViewConfiguration(); fc.processPool = pool
        fc.userContentController.add(self, name: "meow"); fc.setURLSchemeHandler(self, forURLScheme: "meowzer")
        face = WKWebView(frame: .zero, configuration: fc); face.navigationDelegate = self
        #if os(macOS)
        face.setValue(false, forKey: "drawsBackground")
        #else
        face.isOpaque = false; face.backgroundColor = .clear; face.scrollView.isScrollEnabled = false
        #endif
        container.addSubview(face)
        face.load(URLRequest(url: URL(string: "meowzer://ui/meowzer-ui.html" + (platform == "phone" ? "?part=top" : ""))!))
        compileRules { [weak self] in guard let self else { return }
            if urls.isEmpty { self.newTab(nil) } else { urls.forEach { self.newTab(self.urlForFile($0).absoluteString) } } }
    }

    // ---------------------------------------------------------------- layout: the face on top, the active page under it
    func layout() {
        let b = container.bounds
        #if os(macOS)
        let top = b.height   // AppKit counts from the bottom
        face.frame = overlay ? b : CGRect(x: 0, y: top - faceH, width: b.width, height: faceH)
        for t in tabs { t.web.isHidden = t.id != active || overlay; t.web.frame = CGRect(x: 0, y: 0, width: b.width, height: top - faceH) }
        #else
        let inset = container.safeAreaInsets.top
        face.frame = overlay ? b : CGRect(x: 0, y: inset, width: b.width, height: faceH)
        for t in tabs { t.web.isHidden = t.id != active || overlay; t.web.frame = CGRect(x: 0, y: inset + faceH, width: b.width, height: b.height - inset - faceH) }
        #endif
    }

    // ---------------------------------------------------------------- tabs
    func pageConfig() -> WKWebViewConfiguration {
        let c = WKWebViewConfiguration(); c.processPool = pool; c.setURLSchemeHandler(self, forURLScheme: "meowzer")
        let u = c.userContentController, src = injectSource()
        u.addUserScript(WKUserScript(source: src, injectionTime: .atDocumentStart, forMainFrameOnly: false))                  // costume, cosmetics
        u.addUserScript(WKUserScript(source: src, injectionTime: .atDocumentStart, forMainFrameOnly: true, in: MeowHost.world))  // the vault's bridge
        u.add(self, contentWorld: MeowHost.world, name: "meow")
        u.add(self, name: "meowui")   // Meowzer's own pages (the viewer); obeyed only from meowzer:// addresses
        if let r = rules { u.add(r) }
        return c
    }
    @discardableResult func newTab(_ url: String?, activate: Bool = true) -> Int {
        let w = WKWebView(frame: .zero, configuration: pageConfig()); w.navigationDelegate = self; w.uiDelegate = self; w.allowsBackForwardNavigationGestures = true
        #if DEBUG
        if #available(macOS 13.3, iOS 16.4, *) { w.isInspectable = true }
        #endif
        let t = MeowTab(id: nextTab, web: w); nextTab += 1; tabs.append(t); container.addSubview(w)
        for k in ["URL", "title", "loading", "canGoBack", "canGoForward"] { w.addObserver(self, forKeyPath: k, options: .new, context: nil) }
        load(t, fixURL(url ?? ""))
        if activate || active == 0 { active = t.id }
        layout(); pushState(); return t.id
    }
    func load(_ t: MeowTab, _ s: String) {
        guard let u = URL(string: s) else { return }
        if u.isFileURL { t.web.loadFileURL(u, allowingReadAccessTo: u.deletingLastPathComponent()) } else { t.web.load(URLRequest(url: u)) }
    }
    func close(_ id: Int) {
        guard let i = tabs.firstIndex(where: { $0.id == id }) else { return }
        let t = tabs.remove(at: i); for k in ["URL", "title", "loading", "canGoBack", "canGoForward"] { t.web.removeObserver(self, forKeyPath: k) }
        t.web.removeFromSuperview()
        if tabs.isEmpty { active = 0; newTab(nil); return }
        if active == id { active = tabs[min(i, tabs.count - 1)].id }
        layout(); pushState()
    }
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey: Any]?, context: UnsafeMutableRawPointer?) { pushState() }
    func tab(_ id: Int?) -> MeowTab? { tabs.first { $0.id == (id ?? active) } }
    func tab(of w: WKWebView?) -> MeowTab? { tabs.first { $0.web === w } }
    func fixURL(_ s: String) -> String {
        if s.isEmpty || s == "meowzer://newtab" { return ntpURL() }
        if s.contains("://") || s.hasPrefix("about:") { return s }
        if !s.contains(" ") && s.contains(".") { return "https://" + s }
        let se = settings["search"] as? String ?? "https://duckduckgo.com/?q=%s"
        return se.replacingOccurrences(of: "%s", with: s.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? s)
    }
    func ntpURL() -> String {
        let k = ["canvas", "surface", "surface2", "border", "fg", "muted", "accent", "pink", "good", "bad", "warn"], tv = settings["themeVars"] as? [String: Any] ?? [:]
        let hx = k.compactMap { (tv[$0] as? String).flatMap { $0.count == 7 ? String($0.dropFirst()) : nil } }
        return "meowzer://ui/meowzer-ui.html" + (hx.count == 11 ? "?tv=" + hx.joined(separator: ".") : "") + "#ntp"
    }
    func pushState() {
        let list: [[String: Any]] = tabs.map { t in
            let u = t.web.url?.absoluteString ?? "", shown = u.hasPrefix("meowzer://ui/meowzer-ui.html") ? "meowzer://newtab" : viewerFile(u)?.absoluteString ?? u
            t.url = shown; t.title = t.web.title ?? ""
            return ["id": t.id, "url": shown, "title": t.title, "favicon": "", "loading": t.web.isLoading, "canBack": t.web.canGoBack, "canFwd": t.web.canGoForward]
        }
        toFace(["t": "state", "active": active, "tabs": list])
        setTitle?((tab(nil)?.title.isEmpty == false ? tab(nil)!.title + " — " : "") + "Meowzer")
    }

    // ---------------------------------------------------------------- talking
    func json(_ o: Any) -> String { (try? JSONSerialization.data(withJSONObject: o, options: [.fragmentsAllowed])).flatMap { String(data: $0, encoding: .utf8) } ?? "null" }
    func toFace(_ o: [String: Any]) { guard faceReady else { return }; face.evaluateJavaScript("window.meowReceive(\(json(o)))", completionHandler: nil) }
    func reply(_ t: String, _ id: Any?, _ data: Any) { toFace(["t": t, "id": id ?? 0, "data": data]) }
    func toPage(_ t: MeowTab, _ o: [String: Any]) {
        t.web.evaluateJavaScript("document.dispatchEvent(new CustomEvent(\(json(key)),{detail:\(json(o))}))", in: nil, in: MeowHost.world, completionHandler: nil)
    }
    func userContentController(_ uc: WKUserContentController, didReceive msg: WKScriptMessage) {
        let body: [String: Any]? = (msg.body as? [String: Any]) ?? (msg.body as? String).flatMap { try? JSONSerialization.jsonObject(with: Data($0.utf8)) as? [String: Any] }
        guard let m = body else { return }
        if msg.webView === face { onFace(m); return }
        guard let t = tab(of: msg.webView) else { return }
        if msg.name == "meow", msg.world == MeowHost.world, m["meow"] as? String == "vault" { vaultFromPage(t, m) }
        if msg.name == "meowui", t.web.url?.scheme == "meowzer", m["meow"] as? String == "file", let id = m["id"] as? Int { sendFile(t, id) }
    }
    func onFace(_ m: [String: Any]) {
        let t = m["t"] as? String ?? "", tt = tab(m["tab"] as? Int)
        switch t {
        case "nav": if let tt { load(tt, fixURL(m["url"] as? String ?? "")) }
        case "back": tt?.web.goBack()
        case "fwd": tt?.web.goForward()
        case "reload": tt?.web.reload()
        case "stop": tt?.web.stopLoading()
        case "newtab": newTab((m["url"] as? String).flatMap { $0.hasPrefix("http") ? $0 : nil })
        case "close": close(m["tab"] as? Int ?? 0)
        case "select": active = m["tab"] as? Int ?? active; layout(); pushState()
        case "chrome": if let h = m["h"] as? Double, h > 0 { faceH = CGFloat(h); layout() }
        case "overlay": overlay = m["open"] as? Bool ?? false; layout()
        case "win":
            #if os(macOS)
            let w = container.window; switch m["a"] as? String { case "min": w?.miniaturize(nil); case "max": w?.zoom(nil); case "close": w?.performClose(nil); default: break }
            #endif
            break
        case "core": let out = runCore(m["script"] as? String ?? ""); toFace(["t": "core", "id": m["id"] ?? 0, "out": out])
        case "settings": settings = m["settings"] as? [String: Any] ?? [:]; saveJSON("settings.json", settings)
        case "jar": jar = m["jar"] as? [String: Any] ?? [:]; saveJSON("jar.json", jar)
        case "lists": compileRules { [weak self] in self?.toFace(["t": "table", "stats": "# WebKit content rules rebuilt"]) }
        case "cookies", "history", "downloads": toFace(["t": t, "id": m["id"] ?? 0, "list": [Any]()])   // not kept on Apple yet
        case "burnAll": WKWebsiteDataStore.default().removeData(ofTypes: [WKWebsiteDataTypeCookies], modifiedSince: .distantPast) {}
        case "openFile": openFilePicker?()
        case "vault": vaultOp(m)
        case "probe", "tor", "seal", "route": reply(t, m["id"], ["unsupported": true])
        default: break
        }
    }
    func webView(_ w: WKWebView, didFinish n: WKNavigation!) {
        if w === face && !faceReady {
            faceReady = true
            toFace(["t": "init", "platform": platform, "caption": false, "tiles": 1, "max": false, "engine": "WebKit (WKWebView)", "settings": settings, "jar": jar, "table": "# WebKit content rules", "totalBlocked": 0])
            pushState()
        }
    }
    func webView(_ w: WKWebView, decidePolicyFor a: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if w !== face, let u = a.request.url, u.isFileURL, !engineShows(u.pathExtension) {   // files the engine doesn't show go to the viewer
            decisionHandler(.cancel); if let t = tab(of: w) { load(t, urlForFile(u).absoluteString) }; return
        }
        decisionHandler(.allow)
    }
    func webView(_ w: WKWebView, createWebViewWith c: WKWebViewConfiguration, for a: WKNavigationAction, windowFeatures f: WKWindowFeatures) -> WKWebView? {
        newTab(a.request.url?.absoluteString); return nil   // window.open and target=_blank open as tabs
    }

    // ---------------------------------------------------------------- meowzer://ui/ — Meowzer's own pages
    func webView(_ w: WKWebView, start task: WKURLSchemeTask) {
        let name = (task.request.url?.lastPathComponent).flatMap { $0.isEmpty ? nil : $0 } ?? "meowzer-ui.html"
        guard !name.contains(".."), let d = try? Data(contentsOf: ui.appendingPathComponent(name)) else { task.didFailWithError(URLError(.fileDoesNotExist)); return }
        let mime = name.hasSuffix(".html") ? "text/html" : name.hasSuffix(".js") ? "text/javascript" : name.hasSuffix(".png") ? "image/png" : "application/octet-stream"
        task.didReceive(URLResponse(url: task.request.url!, mimeType: mime, expectedContentLength: d.count, textEncodingName: "utf-8")); task.didReceive(d); task.didFinish()
    }
    func webView(_ w: WKWebView, stop task: WKURLSchemeTask) {}
    func injectSource() -> String {
        let src = (try? String(contentsOf: ui.appendingPathComponent("inject.js"), encoding: .utf8)) ?? ""
        return src.replacingOccurrences(of: "__MEOW_DATA__", with: json(["def": NSNull(), "pool": NSNull(), "sites": [String: Any](), "css": [String: Any](), "key": key]))
    }

    // ---------------------------------------------------------------- blocking: a content rule list from the same lists
    // ||host^ and plain host lines become "block this domain and its subdomains" (third-party only with $third-party);
    // @@||host^ becomes an exception. Everything else in Adblock syntax is left to the Windows host's meowcore table.
    func compileRules(_ done: @escaping () -> Void) {
        var text = (try? String(contentsOf: ui.deletingLastPathComponent().appendingPathComponent("lists/meowlist.txt"), encoding: .utf8)) ?? ""
        text += "\n" + (settings["customRules"] as? String ?? "")
        var block: [[String: Any]] = [], allow: [[String: Any]] = []
        for raw in text.split(whereSeparator: \.isNewline) {
            var l = raw.trimmingCharacters(in: .whitespaces); if l.isEmpty || l.hasPrefix("!") || l.hasPrefix("#") || l.contains("##") { continue }
            let exc = l.hasPrefix("@@"); if exc { l.removeFirst(2) }
            var opts = ""; if let d = l.firstIndex(of: "$") { opts = String(l[l.index(after: d)...]); l = String(l[..<d]) }
            if l.hasPrefix("||") { l.removeFirst(2) }
            if l.hasSuffix("^") { l.removeLast() }
            guard !l.isEmpty, l.allSatisfy({ $0.isLetter || $0.isNumber || $0 == "." || $0 == "-" }), l.contains(".") else { continue }
            let esc = l.replacingOccurrences(of: ".", with: "\\.")
            var trig: [String: Any] = ["url-filter": "^[a-z]+://([^/]*\\.)?" + esc + "[:/]"]
            if opts.contains("third-party") { trig["load-type"] = ["third-party"] }
            if exc { allow.append(["trigger": trig, "action": ["type": "ignore-previous-rules"]]) } else { block.append(["trigger": trig, "action": ["type": "block"]]) }
            if block.count >= 140_000 { break }   // WebKit takes up to 150,000 rules per list
        }
        let all = block + allow
        WKContentRuleListStore.default().compileContentRuleList(forIdentifier: "meowzer", encodedContentRuleList: json(all)) { [weak self] list, err in
            guard let self else { return }; if let list { self.rules = list; for t in self.tabs { t.web.configuration.userContentController.removeAllContentRuleLists(); t.web.configuration.userContentController.add(list) } }
            done()
        }
    }

    // ---------------------------------------------------------------- meowcore (macOS only; iOS can't start programs)
    func runCore(_ script: String) -> String {
        #if os(macOS)
        let exe = Bundle.main.url(forAuxiliaryExecutable: "meowcore") ?? Bundle.main.bundleURL.appendingPathComponent("Contents/MacOS/meowcore")
        guard FileManager.default.isExecutableFile(atPath: exe.path) else { return "" }
        let p = Process(), i = Pipe(), o = Pipe(); p.executableURL = exe; p.standardInput = i; p.standardOutput = o; p.standardError = FileHandle.nullDevice
        do { try p.run() } catch { return "" }
        i.fileHandleForWriting.write(Data(script.utf8)); try? i.fileHandleForWriting.close()
        let d = o.fileHandleForReading.readDataToEndOfFile(); p.waitUntilExit(); return String(decoding: d, as: UTF8.self)
        #else
        return ""
        #endif
    }

    // ---------------------------------------------------------------- files
    func engineShows(_ e: String) -> Bool { ["png", "jpg", "jpeg", "gif", "webp", "bmp", "ico", "svg", "heic", "avif", "pdf", "mp3", "wav", "m4a", "aac", "flac", "mp4", "m4v", "mov", "webm", "html", "htm", "xhtml", "txt"].contains(e.lowercased()) }
    func urlForFile(_ u: URL) -> URL {
        if engineShows(u.pathExtension) { return u }
        let id = nextFile; nextFile += 1; files[id] = u
        return URL(string: "meowzer://ui/meowzer-view.html?id=\(id)" + ((settings["theme"] as? String) == "light" ? "&light=1" : ""))!
    }
    func viewerFile(_ s: String) -> URL? {
        guard s.hasPrefix("meowzer://ui/meowzer-view.html"), let c = URLComponents(string: s), let id = c.queryItems?.first(where: { $0.name == "id" })?.value.flatMap(Int.init) else { return nil }
        return files[id]
    }
    func sendFile(_ t: MeowTab, _ id: Int) {
        guard let u = files[id] else { return }
        let ok = u.startAccessingSecurityScopedResource(); defer { if ok { u.stopAccessingSecurityScopedResource() } }
        let d = (try? Data(contentsOf: u)) ?? Data(), cut = d.count > 24 << 20
        let msg: [String: Any] = ["meow": "file", "id": id, "name": u.lastPathComponent, "path": u.path, "ext": u.pathExtension, "size": d.count, "cut": cut, "exists": !d.isEmpty || FileManager.default.fileExists(atPath: u.path),
                                  "b64": (cut ? d.prefix(24 << 20) : d).base64EncodedString()]
        t.web.evaluateJavaScript("dispatchEvent(new CustomEvent('meowfile',{detail:\(json(msg))}))", completionHandler: nil)
    }
    func openFiles(_ urls: [URL]) { for (i, u) in urls.enumerated() { newTab(urlForFile(u).absoluteString, activate: i == 0) } }

    // ---------------------------------------------------------------- the vault (same rules as hosts/windows/meowzer.cpp)
    var logins: [[String: Any]] { get { vault["logins"] as? [[String: Any]] ?? [] } set { vault["logins"] = newValue } }
    var never: [String] { get { vault["never"] as? [String] ?? [] } set { vault["never"] = newValue } }
    var pending: [String: Any]?
    func loadVault() {
        guard let f = try? Data(contentsOf: data.appendingPathComponent("vault.dat")) else { return }
        if let p = MeowVault.fromFile(Array(f), key: MeowKeychain.vaultKey()), let v = try? JSONSerialization.jsonObject(with: Data(p)) as? [String: Any] { vault = v }
        else { vaultBroken = true; try? f.write(to: data.appendingPathComponent("vault.dat.unreadable")) }
    }
    func saveVault() {
        let plain = Array(json(vault).utf8)
        try? Data(MeowVault.fileBytes(plain, key: MeowKeychain.vaultKey())).write(to: data.appendingPathComponent("vault.dat"), options: [.atomic, .completeFileProtection])
    }
    func origin(_ s: String) -> String { guard let u = URL(string: s), let h = u.host, let sc = u.scheme else { return "" }; return (sc + "://" + h + (u.port.map { ":\($0)" } ?? "")).lowercased() }
    func siteOf(_ host: String) -> String {
        let sfx: Set = ["co.uk", "org.uk", "ac.uk", "gov.uk", "co.jp", "ne.jp", "or.jp", "com.au", "net.au", "org.au", "co.nz", "com.br", "com.mx", "co.in", "co.za", "com.tr", "com.cn", "com.tw", "co.kr", "github.io", "blogspot.com", "herokuapp.com", "vercel.app", "netlify.app", "pages.dev"]
        let p = host.lowercased().split(separator: ".").map(String.init); if p.count < 3 { return p.joined(separator: ".") }
        return sfx.contains(p.suffix(2).joined(separator: ".")) ? p.suffix(3).joined(separator: ".") : p.suffix(2).joined(separator: ".")
    }
    func pub(_ e: [String: Any], _ o: String? = nil) -> [String: Any] {
        var r = e; r.removeValue(forKey: "pass"); if let o { r["exact"] = (e["origin"] as? String) == o }; return r
    }
    func vaultList() -> [String: Any] { ["logins": logins.map { pub($0) }, "never": never, "broken": vaultBroken] }
    func vaultFromPage(_ t: MeowTab, _ m: [String: Any]) {
        guard let src = t.web.url?.absoluteString, src.hasPrefix("http") else { return }
        let o = origin(src), site = siteOf(t.web.url?.host ?? ""), vs = settings["vault"] as? [String: Any] ?? [:]
        let mode = vs["fill"] as? String ?? "ask", exactOnly = vs["exact"] as? Bool ?? false
        switch m["op"] as? String {
        case "logins":
            guard mode != "off" else { return }
            let mine = logins.filter { ($0["origin"] as? String) == o || (!exactOnly && ($0["site"] as? String) == site) }
            guard !mine.isEmpty else { return }
            let exact = mine.filter { ($0["origin"] as? String) == o }
            let auto: Any = mode == "auto" && exact.count == 1 && o.hasPrefix("https://") ? ["id": exact[0]["id"]!, "user": exact[0]["user"]!, "pass": exact[0]["pass"]!] : NSNull()
            toPage(t, ["meow": "vault", "mode": mode, "logins": mine.map { pub($0, o) }, "auto": auto])
        case "fill", "filled":
            guard let i = logins.firstIndex(where: { ($0["id"] as? String) == m["id"] as? String }) else { return }
            let e = logins[i]; guard (e["origin"] as? String) == o || (!exactOnly && (e["site"] as? String) == site) else { return }
            if m["op"] as? String == "fill" { toPage(t, ["meow": "vault", "fill": ["user": e["user"] ?? "", "pass": e["pass"] ?? ""]]) }
            logins[i]["used"] = Int(Date().timeIntervalSince1970); logins[i]["uses"] = (e["uses"] as? Int ?? 0) + 1; saveVault()
        case "capture":
            if vs["offer"] as? Bool == false { return }
            let user = m["user"] as? String ?? "", pass = m["pass"] as? String ?? ""; guard !pass.isEmpty, !never.contains(site) else { return }
            let same = logins.first { ($0["origin"] as? String) == o && ($0["user"] as? String) == user }
            if let same, (same["pass"] as? String) == pass { return }
            pending = ["origin": o, "site": site, "user": user, "pass": pass, "id": same?["id"] ?? "", "update": same != nil]
            toFace(["t": "vaultOffer", "site": site, "origin": o, "user": user, "update": same != nil])
        default: break
        }
    }
    func addLogin(_ o: String, _ user: String, _ pass: String, _ note: String) {
        let now = Int(Date().timeIntervalSince1970)
        logins.append(["id": MeowVault.random(8).map { String(format: "%02x", $0) }.joined(), "origin": o, "site": siteOf(URL(string: o)?.host ?? ""), "user": user, "pass": pass, "note": note, "created": now, "changed": now, "used": 0, "uses": 0])
    }
    func copy(_ s: String) {
        #if os(macOS)
        NSPasteboard.general.clearContents(); NSPasteboard.general.setString(s, forType: .string)
        let n = NSPasteboard.general.changeCount, after = (settings["vault"] as? [String: Any])?["clip"] as? Int ?? 30
        if after > 0 { DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(after)) { if NSPasteboard.general.changeCount == n { NSPasteboard.general.clearContents() } } }
        #else
        let after = (settings["vault"] as? [String: Any])?["clip"] as? Int ?? 30   // iOS lets the pasteboard forget by itself, and keeps it on this device
        UIPasteboard.general.setItems([[UIPasteboard.typeAutomatic: s]], options: after > 0 ? [.expirationDate: Date().addingTimeInterval(TimeInterval(after)), .localOnly: true] : [.localOnly: true])
        #endif
    }
    var importBytes: [UInt8]?, importName = ""
    func vaultOp(_ m: [String: Any]) {
        let id = m["id"]; func r(_ d: Any) { reply("vault", id, d) }
        let lid = m["login"] as? String ?? "", idx = logins.firstIndex { ($0["id"] as? String) == lid }
        switch m["op"] as? String ?? "" {
        case "list": r(vaultList())
        case "reveal": r(["pass": idx.map { logins[$0]["pass"] ?? "" } ?? ""])
        case "copy": if let idx { copy((m["what"] as? String == "user" ? logins[idx]["user"] : logins[idx]["pass"]) as? String ?? "") }; r(["ok": true])
        case "copyText": copy(m["text"] as? String ?? ""); r(["ok": true])
        case "save":
            let l = m["login"] as? [String: Any] ?? [:]; var o = l["origin"] as? String ?? ""; if !o.contains("://") { o = "https://" + o }; o = origin(o + "/")
            guard o.count >= 10 else { r(["error": "That address doesn't look right."]); return }
            if let i = logins.firstIndex(where: { ($0["id"] as? String) == l["id"] as? String && !(l["id"] as? String ?? "").isEmpty }) {
                logins[i]["origin"] = o; logins[i]["site"] = siteOf(URL(string: o)?.host ?? ""); logins[i]["user"] = l["user"] ?? ""; logins[i]["note"] = l["note"] ?? ""
                if let p = l["pass"] as? String, !p.isEmpty { logins[i]["pass"] = p; logins[i]["changed"] = Int(Date().timeIntervalSince1970) }
            } else { addLogin(o, l["user"] as? String ?? "", l["pass"] as? String ?? "", l["note"] as? String ?? "") }
            saveVault(); r(vaultList())
        case "del": if let idx { logins.remove(at: idx) }; saveVault(); r(vaultList())
        case "never": let s = m["site"] as? String ?? ""; never.removeAll { $0 == s }; if m["on"] as? Bool == true { never.append(s) }; saveVault(); r(vaultList())
        case "wipe": vault = ["logins": [Any](), "never": [Any]()]; vaultBroken = false; if m["newKey"] as? Bool == true { MeowKeychain.newVaultKey() }; saveVault(); r(vaultList())
        case "gen": r(["pw": MeowVault.password(tier: m["tier"] as? Int ?? 3, length: m["len"] as? Int ?? 20, noLookAlikes: (m["flags"] as? Int ?? 0) & 1 == 1)])
        case "user": r(["user": MeowVault.userName(style: m["style"] as? Int ?? 0)])
        case "offer":
            if let p = pending, m["a"] as? String == "save" {
                if p["update"] as? Bool == true, let i = logins.firstIndex(where: { ($0["id"] as? String) == p["id"] as? String }) { logins[i]["pass"] = p["pass"]; logins[i]["changed"] = Int(Date().timeIntervalSince1970) }
                else { addLogin(p["origin"] as! String, p["user"] as! String, p["pass"] as! String, "") }
                saveVault()
            }
            if let p = pending, m["a"] as? String == "never" { never.append(p["site"] as! String); saveVault() }
            pending = nil; r(["ok": true])
        case "export":
            let pw = m["pw"] as? String ?? "", plain = Array(json(vault).utf8), count = logins.count
            let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd"
            pickSave?("Meowzer vault \(f.string(from: Date())).meowvault") { url in
                guard let url else { r(["cancelled": true]); return }
                DispatchQueue.global().async {   // 600,000 rounds take a moment
                    let bytes = MeowVault.export(plain, password: pw)
                    DispatchQueue.main.async { do { try Data(bytes).write(to: url); r(["ok": true, "count": count, "path": url.path, "locked": !pw.isEmpty]) } catch { r(["error": error.localizedDescription]) } }
                }
            }
        case "import":
            let finish = { [self] in
                guard let f = importBytes else { r(["cancelled": true]); return }
                let pw = m["pw"] as? String ?? ""
                DispatchQueue.global().async {
                    let res = MeowVault.importFile(f, password: pw)
                    DispatchQueue.main.async { [self] in
                        switch res {
                        case .notAVault: r(["error": "That file isn't a Meowzer vault."])
                        case .needsPassword: r(["need": "password", "name": importName])
                        case .wrong: r(["wrong": true])
                        case .damaged: r(["error": "The vault file was changed or is damaged; nothing was imported."])
                        case .ok(let p):
                            let v = (try? JSONSerialization.jsonObject(with: Data(p))) as? [String: Any] ?? [:]; var added = 0, updated = 0
                            for e in v["logins"] as? [[String: Any]] ?? [] {
                                if let i = logins.firstIndex(where: { ($0["origin"] as? String) == e["origin"] as? String && ($0["user"] as? String) == e["user"] as? String }) {
                                    if (logins[i]["pass"] as? String) != e["pass"] as? String { logins[i]["pass"] = e["pass"]; logins[i]["changed"] = Int(Date().timeIntervalSince1970); updated += 1 }
                                } else { var c = e; c["id"] = MeowVault.random(8).map { String(format: "%02x", $0) }.joined(); logins.append(c); added += 1 }
                            }
                            for s in v["never"] as? [String] ?? [] where !never.contains(s) { never.append(s) }
                            saveVault(); importBytes = nil; r(["ok": true, "added": added, "updated": updated])
                        }
                    }
                }
            }
            if m["again"] as? Bool == true { finish() }
            else { pickOpen? { [self] url in
                guard let url else { r(["cancelled": true]); return }
                let ok = url.startAccessingSecurityScopedResource(); defer { if ok { url.stopAccessingSecurityScopedResource() } }
                importBytes = (try? Data(contentsOf: url)).map(Array.init); importName = url.lastPathComponent; finish() } }
        default: r([String: Any]())
        }
    }

    // ---------------------------------------------------------------- storage
    func loadJSON(_ n: String) -> [String: Any] { (try? Data(contentsOf: data.appendingPathComponent(n))).flatMap { try? JSONSerialization.jsonObject(with: $0) as? [String: Any] } ?? [:] }
    func saveJSON(_ n: String, _ o: [String: Any]) { try? Data(json(o).utf8).write(to: data.appendingPathComponent(n), options: .atomic) }
}
