# Meowzer 4 for macOS and iOS / iPadOS

Meowzer on **WKWebView**, Apple's WebKit. Apple only allows WebKit on iPhone and iPad (outside the EU), and on a Mac it's the engine that's already there.

## Build it (on a Mac)
* **Mac app:** run `./build-mac.sh`.
  * It makes the Xcode project with XcodeGen, builds `build/apple/Meowzer.app`, and offers to copy it to /Applications.
  * The app isn't signed by Apple. The first time you open it, right-click ▸ Open.
* **iPhone / iPad:**
  1. Run `./build-mac.sh ios`. This opens Xcode.
  2. Pick **Meowzer4-iOS** and your device.
  3. Set your Team under Signing (a free Apple ID works for your own device).
  4. Press ▶.
* You need Xcode 15+ and XcodeGen (`brew install xcodegen`; the script fetches it if you have Homebrew).
* Optional: set `FXC=/path/to/fxc` (from ꟻX 0.28, `bin/macos-arm64` or `bin/macos-x64`). With it, `build-mac.sh` tries to compile meowcore into the Mac app. Today's fxc doesn't make macOS programs, so the Mac app uses the Swift vault instead; the script says so.

## Files
| File | What it is |
|---|---|
| `Shared/MeowHost.swift` | The host: face, tabs, `meowzer://ui/` pages, the viewer, the vault and content rules |
| `Shared/MeowVault.swift` | The vault lock and the generators in Swift, the same bytes as meowcore's (the construction is checked by `tests/vault-port.js`) |
| `macOS/AppDelegate.swift`, `iOS/AppDelegate.swift` | The window and the system's file boxes |
| `project.yml` | The XcodeGen project |

## What works
* The face, tabs and themes, including 🖌 Every colour.
* Blocking: the lists' domain rules become a WebKit content rule list.
* 🐾 **Vault**:
  * The key lives in the Keychain, for this device only.
  * The paw button sits in a separate WebKit content world that pages can't reach.
  * Export, import and wipe go through the system's Save and Open boxes. On iOS they use the Files app.
* Open files from Finder or the Files app. The engine shows images, PDF, audio, video, HTML and SVG; everything else opens in Meowzer's viewer.

## Not on Apple yet
* The costume's personas, the Mask's probes, the Tor route, the cookie oven's sweep, tiling, the bookshelf and ghost pages.
* iOS doesn't allow apps to start programs, and the Mac has no fxc target yet.

## Status
**Written, not yet compiled.** It was written on a Windows PC without Xcode, so expect a few compile errors to fix on the first build.
