// Android Gradle Plugin 9 compiles Kotlin itself (no separate Kotlin plugin is applied); needs Gradle 9.x and JDK 17+.
// The Kotlin plugin is only put on the build's classpath so AGP's built-in Kotlin uses 2.4: GeckoView 160 and
// AndroidX 1.19 bring kotlin-stdlib 2.4, which an older compiler can't read.
plugins {
    id("com.android.application") version "9.5.1" apply false
    id("org.jetbrains.kotlin.android") version "2.4.21" apply false
}
