#!/bin/sh
# The easy way: ./build-android.sh          → build/android/Meowzer4.apk  (then: adb install build/android/Meowzer4.apk)
# Needs: Android Studio (it brings the SDK and Java), or the Android command-line tools + JDK 17 + Gradle 9.x.
# Or skip this script: open this folder (hosts/android) in Android Studio and press ▶ with your phone plugged in.
set -e
cd "$(dirname "$0")"
say() { printf '\n\033[1;33m🐱 %s\033[0m\n' "$*"; }
if [ -z "$ANDROID_HOME" ]; then
  for d in "$HOME/Android/Sdk" "$HOME/Library/Android/sdk" "$LOCALAPPDATA/Android/Sdk"; do [ -d "$d" ] && export ANDROID_HOME="$d" && break; done
fi
[ -n "$ANDROID_HOME" ] || { echo "Android SDK not found: install Android Studio, open it once, then run this again."; exit 1; }
echo "sdk.dir=$ANDROID_HOME" > local.properties
if [ -x ./gradlew ]; then G=./gradlew; elif command -v gradle >/dev/null; then G=gradle
else echo "Gradle not found: open this folder in Android Studio once (it sets Gradle up), or install Gradle 9.x."; exit 1; fi
say "Building (the first time fetches GeckoView from maven.mozilla.org and the build tools; later builds are offline)"
$G :app:assembleRelease
mkdir -p ../../build/android; cp app/build/outputs/apk/release/app-release.apk ../../build/android/Meowzer4.apk
say "Built build/android/Meowzer4.apk"
if command -v adb >/dev/null && adb get-state >/dev/null 2>&1; then
  printf 'A phone is plugged in. Install Meowzer on it? [y/N] '; read -r y; [ "$y" = y ] && adb install -r ../../build/android/Meowzer4.apk
fi
