# The easy way on Windows: right-click ▸ Run with PowerShell   (or: powershell -File build-android.ps1)
# → build\android\Meowzer4.apk. Needs Android Studio installed and opened once (it brings the SDK and Java).
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
function Say($s) { Write-Host "`n🐱 $s" -ForegroundColor Yellow }
if (-not $env:ANDROID_HOME) { $d = "$env:LOCALAPPDATA\Android\Sdk"; if (Test-Path $d) { $env:ANDROID_HOME = $d } }
if (-not $env:ANDROID_HOME) { throw 'Android SDK not found: install Android Studio, open it once, then run this again.' }
if (-not $env:JAVA_HOME) { $j = 'C:\Program Files\Android\Android Studio\jbr'; if (Test-Path $j) { $env:JAVA_HOME = $j } }
"sdk.dir=$($env:ANDROID_HOME -replace '\\','/')" | Set-Content -Encoding ascii local.properties
$g = if (Test-Path .\gradlew.bat) { '.\gradlew.bat' } elseif (Get-Command gradle -ErrorAction SilentlyContinue) { 'gradle' } else { $null }
if (-not $g) { throw 'Gradle not found: open hosts\android in Android Studio once (it sets Gradle up), or install Gradle 9.x.' }
Say 'Building (the first time fetches GeckoView from maven.mozilla.org and the build tools)'
& $g ':app:assembleRelease'; if ($LASTEXITCODE) { throw 'The build failed (see above).' }
New-Item -ItemType Directory -Force ..\..\build\android | Out-Null
Copy-Item app\build\outputs\apk\release\app-release.apk ..\..\build\android\Meowzer4.apk -Force
Say 'Built build\android\Meowzer4.apk — copy it to your phone and tap it, or: adb install build\android\Meowzer4.apk'
