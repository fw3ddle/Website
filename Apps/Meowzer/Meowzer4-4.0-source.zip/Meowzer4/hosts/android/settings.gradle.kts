pluginManagement { repositories { gradlePluginPortal(); google(); mavenCentral() } }
dependencyResolutionManagement {
    repositories {
        // GeckoView comes from Mozilla's own Maven; google() only serves the Android build tools and AndroidX
        // (no Google Play Services, no Google engine in the app)
        maven("https://maven.mozilla.org/maven2/")
        google(); mavenCentral()
    }
}
rootProject.name = "Meowzer4"
include(":app")
