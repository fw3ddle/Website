# Meowzer 4 for Android

Meowzer on **GeckoView**, Mozilla's engine. There's no Google engine and no Google Play Services in the app.

## Build it
* **Easiest:**
  1. Install [Android Studio](https://developer.android.com/studio).
  2. Open the `hosts/android` folder.
  3. Plug in your phone with USB debugging on.
  4. Press ▶.
* **Script:** run `./build-android.sh` (Linux/macOS) or `build-android.ps1` (Windows). Either one makes `build/android/Meowzer4.apk`.
* **Already built:** the Android release zip has `Meowzer4.apk` ready to install.
* The first build downloads GeckoView (about 80 MB) from `maven.mozilla.org` and the Android build tools from Google's Maven. Those tools are only used to build; none of Google's code ends up in the app.

## What works
* The same face as on Windows: tabs, ☰ menu, themes including 🖌 Every colour, settings.
* Blocking with the domain rules from the lists, done in the built-in extension's `webRequest`.
* 🐾 **Vault**:
  * saved logins, with the paw button on login forms;
  * ask / auto / off autofill;
  * the generator tiers;
  * export, import and wipe through Android's file picker.
* The vault key sits in `vault.key`, sealed by an Android Keystore key.
* Exported vault files are the same format as on Windows, macOS, iOS and Linux, so they move between them.
* **Open with Meowzer** for any file (png, jpg, pdf, mp3, mp4, html, svg, .fx, zip, …). Files open in Meowzer's viewer. Meowzer can also be set as the default browser.

## Not on Android yet
There's no meowcore on Android: Android doesn't support apps starting a bundled Linux program. So these are missing:
* the costume's personas;
* the Mask's probes and the Tor route;
* the cookie oven's sweep;
* tiling, the bookshelf and ghost pages.

## Status
**Built, not yet run on a phone.** On 2026-11-14 this compiled on Windows into a 93 MB `Meowzer4.apk`, with no code errors. `aapt2` and `apksigner` both check out:
* package `app.meowzer.meowzer4` 4.0;
* Android 8.0+ (API 26), targets API 36;
* arm64-v8a only.

It hasn't been started on a device or emulator yet, so the first real run may need a few fixes.

Tested build setup:
* Android Gradle Plugin 9.5.1 (built-in Kotlin, held at 2.4.21 in `build.gradle.kts`);
* Gradle 9.9.1;
* JDK 17+ (Android Studio's bundled one is fine);
* compileSdk 37.2;
* GeckoView 160.

GeckoView's version is set in `app/build.gradle.kts`.

* **CPU:** the APK is arm64 only, which covers every current phone. The all-CPU GeckoView makes a 530 MB APK. For an x86_64 emulator, swap the dependency to `geckoview-x86_64` and the `abiFilters` to match.
* **Signing:** the release APK is signed with Android's debug key so it installs. Before publishing anywhere, set your own `signingConfig` in `app/build.gradle.kts`.
