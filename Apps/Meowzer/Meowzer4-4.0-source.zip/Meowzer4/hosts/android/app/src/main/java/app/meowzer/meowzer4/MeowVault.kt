// MeowVault.kt — the vault lock and the generators in Kotlin, for Android (no meowcore there: Android apps can't ship
// and start a Linux program in a supported way). The same bytes as meowcore's @vlock/@vopen and MeowVault.swift;
// tests/vault-port.js checks this construction against meowcore:
//   PBKDF2-HMAC-SHA256(pepper ‖ password, salt, rounds, 96) → two ChaCha20 streams XORed (RFC 8439, counter from 1)
//   → HMAC-SHA256(third 32 bytes, salt ‖ nonce ‖ ciphertext).
// PBKDF2 is written out here because Android's PBKDF2WithHmacSHA256 takes the password as characters, and the
// local vault's password is 32 random bytes.
package app.meowzer.meowzer4

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object MeowVault {
    val pepper = "Meowzer 4 vault pepper. Only a Meowzer opens what a Meowzer seals; the cat keeps the key under its paw.".toByteArray()
    const val ROUNDS_WITH_PASSWORD = 600_000
    private val rng = SecureRandom()
    fun random(n: Int) = ByteArray(n).also { rng.nextBytes(it) }
    fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

    fun pbkdf2(pw: ByteArray, salt: ByteArray, rounds: Int, len: Int): ByteArray {
        val mac = Mac.getInstance("HmacSHA256"); mac.init(SecretKeySpec(pw, "HmacSHA256"))   // pw always starts with the pepper, so it is never empty
        val out = ByteArray(len); var block = 1; var off = 0
        while (off < len) {
            mac.update(salt); mac.update(byteArrayOf((block ushr 24).toByte(), (block ushr 16).toByte(), (block ushr 8).toByte(), block.toByte()))
            var u = mac.doFinal(); val t = u.copyOf()
            for (i in 1 until rounds) { u = mac.doFinal(u); for (j in t.indices) t[j] = (t[j].toInt() xor u[j].toInt()).toByte() }
            System.arraycopy(t, 0, out, off, minOf(32, len - off)); off += 32; block++
        }
        return out
    }

    class ChaCha(key: ByteArray, nonce: ByteArray, counter: Int) {
        private val s = IntArray(16); private val x = IntArray(16); private val block = ByteArray(64); private var pos = 64
        private fun w(b: ByteArray, o: Int) = (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8) or ((b[o + 2].toInt() and 255) shl 16) or ((b[o + 3].toInt() and 255) shl 24)
        init {
            s[0] = 0x61707865; s[1] = 0x3320646e; s[2] = 0x79622d32; s[3] = 0x6b206574
            for (i in 0 until 8) s[4 + i] = w(key, 4 * i)
            s[12] = counter; for (i in 0 until 3) s[13 + i] = w(nonce, 4 * i)
        }
        private fun qr(a: Int, b: Int, c: Int, d: Int) {
            x[a] += x[b]; x[d] = Integer.rotateLeft(x[d] xor x[a], 16); x[c] += x[d]; x[b] = Integer.rotateLeft(x[b] xor x[c], 12)
            x[a] += x[b]; x[d] = Integer.rotateLeft(x[d] xor x[a], 8); x[c] += x[d]; x[b] = Integer.rotateLeft(x[b] xor x[c], 7)
        }
        fun next(): Int {
            if (pos == 64) {
                s.copyInto(x)
                repeat(10) { qr(0, 4, 8, 12); qr(1, 5, 9, 13); qr(2, 6, 10, 14); qr(3, 7, 11, 15); qr(0, 5, 10, 15); qr(1, 6, 11, 12); qr(2, 7, 8, 13); qr(3, 4, 9, 14) }
                for (i in 0 until 16) { val v = x[i] + s[i]; for (j in 0 until 4) block[4 * i + j] = (v ushr (8 * j)).toByte() }
                s[12]++; pos = 0
            }
            return block[pos++].toInt() and 255
        }
    }
    private fun tag(k: ByteArray, salt: ByteArray, nonce: ByteArray, ct: ByteArray) =
        Mac.getInstance("HmacSHA256").run { init(SecretKeySpec(k, "HmacSHA256")); update(salt); update(nonce); doFinal(ct) }

    /** salt(16) ‖ nonce(12) ‖ tag(32) ‖ ciphertext */
    fun lock(plain: ByteArray, rounds: Int, pw: ByteArray): ByteArray {
        val salt = random(16); val nonce = random(12); val dk = pbkdf2(pepper + pw, salt, rounds, 96)
        val a = ChaCha(dk.copyOfRange(0, 32), nonce, 1); val b = ChaCha(dk.copyOfRange(32, 64), nonce, 1)
        val ct = ByteArray(plain.size) { i -> (plain[i].toInt() xor a.next() xor b.next()).toByte() }
        return salt + nonce + tag(dk.copyOfRange(64, 96), salt, nonce, ct) + ct
    }
    fun open(d: ByteArray, rounds: Int, pw: ByteArray): ByteArray? {
        if (d.size < 60) return null
        val salt = d.copyOfRange(0, 16); val nonce = d.copyOfRange(16, 28); val t = d.copyOfRange(28, 60); val ct = d.copyOfRange(60, d.size)
        val dk = pbkdf2(pepper + pw, salt, rounds, 96)
        if (!MessageDigest.isEqual(tag(dk.copyOfRange(64, 96), salt, nonce, ct), t)) return null
        val a = ChaCha(dk.copyOfRange(0, 32), nonce, 1); val b = ChaCha(dk.copyOfRange(32, 64), nonce, 1)
        return ByteArray(ct.size) { i -> (ct[i].toInt() xor a.next() xor b.next()).toByte() }
    }

    private val LOCAL = "MEOWVLT1".toByteArray(); private val EXPORT = "MEOWVAULT".toByteArray()
    fun fileBytes(plain: ByteArray, key: ByteArray) = LOCAL + lock(plain, 1, key)
    fun fromFile(f: ByteArray, key: ByteArray) = if (f.size >= 68 && f.copyOfRange(0, 8).contentEquals(LOCAL)) open(f.copyOfRange(8, f.size), 1, key) else null
    fun export(plain: ByteArray, password: String): ByteArray {
        val pw = password.toByteArray(); val r = if (pw.isEmpty()) 1 else ROUNDS_WITH_PASSWORD
        return EXPORT + byteArrayOf(1, if (pw.isEmpty()) 0 else 1, r.toByte(), (r ushr 8).toByte(), (r ushr 16).toByte(), (r ushr 24).toByte()) + lock(plain, r, pw)
    }
    sealed class Import { object NotAVault : Import(); object NeedsPassword : Import(); object Wrong : Import(); object Damaged : Import(); class Ok(val plain: ByteArray) : Import() }
    fun importFile(f: ByteArray, password: String): Import {
        if (f.size < 75 || !f.copyOfRange(0, 9).contentEquals(EXPORT) || f[9].toInt() != 1) return Import.NotAVault
        val locked = f[10].toInt() and 1 == 1
        val rounds = (f[11].toInt() and 255) or ((f[12].toInt() and 255) shl 8) or ((f[13].toInt() and 255) shl 16) or ((f[14].toInt() and 255) shl 24)
        if (locked && password.isEmpty()) return Import.NeedsPassword
        val p = open(f.copyOfRange(15, f.size), rounds, if (locked) password.toByteArray() else ByteArray(0)) ?: return if (locked) Import.Wrong else Import.Damaged
        return Import.Ok(p)
    }

    // ------------------------------------------------------------------ the generators (the same tiers as meowcore's @gen / @user)
    private const val LOWER = "abcdefghijklmnopqrstuvwxyz"; private const val UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; private const val DIGIT = "0123456789"
    private const val SYM1 = "!@#$%&*-_+=?"; private const val SYM2 = "!#$%&()*+,-./:;<=>?@[]^_{|}~"; private const val LOOK = "0O1lI|"
    private val ADJ = "amber ancient arctic azure bashful bold brave breezy bright brisk bronze bubbly calm candid cheery chilly clever cloudy cosmic cozy crisp curly daring dapper dewy dizzy dreamy dusky eager early electric elder ember epic fancy feisty fiery fluffy foggy frosty fuzzy gentle giddy gilded glad gleaming golden grand happy hazel hidden honey humble icy indigo ivory jade jolly keen kind lavender lazy lemon lively lofty lucky lunar maple marble mellow merry minty misty modest mossy nimble noble odd olive orange pastel peachy pearl plucky polar proud quick quiet rainy rapid rosy royal ruby rustic sandy scarlet shiny silent silky silver sleepy smoky snowy solar sparkly spicy sunny swift tidal tiny tropic velvet violet vivid wandering warm wavy whimsy wild windy wise witty woolly zesty stormy starry toasty sly plush".split(" ")
    private val NOUN = "acorn anchor badger bagel banjo beacon beetle biscuit bobcat breeze brook bubble button cactus canyon cat cedar cello comet cookie coral cricket crystal cub dingo dolphin dragon drum dune eagle echo falcon feather fennec ferret fig firefly fjord flute fox gecko geyser glacier gopher harbor hedgehog heron hollow iris island jaguar jasper kettle kitten koala lantern lark lemur lily lion llama lynx magpie mango meadow meteor mitten moon moose moth muffin nebula nugget oak ocelot orbit otter owl panda panther paw pebble pepper pine pixel planet plum pond puffin puma quartz quill rabbit raven reef river robin rocket saddle sage salmon sparrow spruce star stone storm sunset swan thistle thunder tiger toffee trout tulip turtle valley walrus whisker willow wombat yarn yeti zebra zephyr biscotti clover".split(" ")
    fun pick(n: Int): Int { val lim = 65536 - 65536 % n; while (true) { val b = random(2); val v = ((b[0].toInt() and 255) shl 8) or (b[1].toInt() and 255); if (v < lim) return v % n } }
    fun password(tier: Int, length: Int, noLookAlikes: Boolean): String {
        if (tier == 5) { val all = ADJ + NOUN; val n = (length / 5).coerceIn(3, 8)
            return (0 until n).joinToString("-") { all[pick(all.size)].replaceFirstChar(Char::uppercase) } + "-" + pick(10) }
        val strip = { s: String -> if (noLookAlikes) s.filter { it !in LOOK } else s }
        val classes = mutableListOf(strip(DIGIT))
        if (tier >= 1) { classes.clear(); classes += strip(LOWER); classes += strip(UPPER) }
        if (tier >= 2) classes += strip(DIGIT)
        if (tier == 3) classes += SYM1 else if (tier >= 4) classes += strip(SYM2)
        val n = maxOf(if (tier == 0) 4 else classes.size, minOf(128, length)); val pool = classes.joinToString("")
        while (true) { val pw = String(CharArray(n) { pool[pick(pool.length)] }); if (classes.all { c -> pw.any { it in c } }) return pw }
    }
    fun userName(style: Int): String {
        val a = ADJ[pick(ADJ.size)]; val n = NOUN[pick(NOUN.size)]
        return when (style) { 0 -> a + n + "%02d".format(pick(100)); 1 -> "$a.$n"; 2 -> a + "_" + n + "_" + "%03d".format(pick(1000))
            else -> { val cs = "abcdefghijkmnpqrstuvwxyz23456789"; String(CharArray(10) { cs[pick(cs.length)] }) } }
    }
}

/** The 32-byte key that locks vault.dat. It is kept in vault.key, itself sealed by an AES key that lives in the
 *  Android Keystore (in the phone's secure hardware where there is one) and never leaves it. */
object MeowKeystore {
    private const val ALIAS = "meowzer-vault-wrap"
    private fun wrapKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build())
        }.generateKey()
    }
    fun vaultKey(ctx: Context): ByteArray {
        val f = File(ctx.filesDir, "vault.key")
        if (f.exists()) runCatching {
            val d = f.readBytes(); val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE, wrapKey(), GCMParameterSpec(128, d, 0, 12))
            return c.doFinal(d, 12, d.size - 12)
        }
        val k = MeowVault.random(32); val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, wrapKey())
        f.writeBytes(c.iv + c.doFinal(k)); return k
    }
    fun newVaultKey(ctx: Context) { File(ctx.filesDir, "vault.key").delete(); vaultKey(ctx) }
}
