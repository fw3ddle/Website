// background.js — Meowzer's built-in GeckoView extension. It holds one native port to the app ("meowzer"):
//   app → here: {t:'rules', block:[host…], allow:[host…], third:[host…]}  the blocking lists, already parsed
//               {t:'toPage', tab:<id>, msg:{…}}                          an answer for a page's script (the vault)
//   here → app: {t:'page', tab, url, frame, msg}                         a message from a page's script, with the address
//                                                                         Firefox itself reports (pages can't fake it)
//               {t:'blocked', host, ctx}                                  one blocked request, for the cat's count
'use strict';
const port = browser.runtime.connectNative('meowzer');
let block = new Set(), allow = new Set(), third = new Set();

function hostOf(u) { try { return new URL(u).hostname.toLowerCase(); } catch (e) { return ''; } }
// a host and every parent domain: a.b.example.com → a.b.example.com, b.example.com, example.com
function* parents(h) { const p = h.split('.'); for (let i = 0; i < p.length - 1; i++) yield p.slice(i).join('.'); }
const SFX = new Set(['co.uk', 'org.uk', 'ac.uk', 'gov.uk', 'co.jp', 'ne.jp', 'or.jp', 'com.au', 'net.au', 'org.au', 'co.nz', 'com.br', 'com.mx', 'co.in', 'co.za', 'com.tr', 'com.cn', 'com.tw', 'co.kr', 'github.io', 'blogspot.com', 'herokuapp.com', 'vercel.app', 'netlify.app', 'pages.dev']);
function siteOf(h) { const p = h.split('.'); if (p.length < 3) return h; return SFX.has(p.slice(-2).join('.')) ? p.slice(-3).join('.') : p.slice(-2).join('.'); }

port.onMessage.addListener((m) => {
  if (m.t === 'rules') { block = new Set(m.block || []); allow = new Set(m.allow || []); third = new Set(m.third || []); }
  else if (m.t === 'toPage') browser.tabs.sendMessage(m.tab, m.msg, { frameId: 0 }).catch(() => {});
});

browser.webRequest.onBeforeRequest.addListener((d) => {
  if (d.type === 'main_frame') return {};                  // a page you asked for always opens
  const h = hostOf(d.url); if (!h) return {};
  for (const p of parents(h)) if (allow.has(p)) return {};
  const from = hostOf(d.documentUrl || d.originUrl || ''), thirdParty = from && siteOf(from) !== siteOf(h);
  for (const p of parents(h)) {
    if (block.has(p) || (thirdParty && third.has(p))) {
      port.postMessage({ t: 'blocked', host: h, ctx: from }); return { cancel: true };
    }
  }
  return {};
}, { urls: ['<all_urls>'] }, ['blocking']);

// pages' scripts (inject.js) → the app, with Firefox's own idea of where the message came from
browser.runtime.onMessage.addListener((msg, sender) => {
  if (!sender.tab || !sender.url) return;
  port.postMessage({ t: 'page', tab: sender.tab.id, url: sender.url, frame: sender.frameId || 0, msg });
});
