// MainActivity.kt — Meowzer 4 for Android, on GeckoView (Mozilla's engine: no Google engine, no Play Services).
// The face (ui/meowzer-ui.html) is a page of the built-in extension in assets/ext, drawn by its own GeckoView at the
// top; the active tab's GeckoView sits under it. The extension's background blocks what the lists name and carries
// the page script's messages (the vault's autofill) to and from here. See hosts/PROTOCOL.md for the messages.
// Not done on Android yet: meowcore (so: personas, the Mask's probes, Tor route, the cookie oven's sweep), tiling,
// the bookshelf, ghost pages. Status: written to the protocol, not yet compiled (written on a PC without the Android SDK).
package app.meowzer.meowzer4

import android.app.Activity
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle
import android.util.Base64
import android.view.View
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import org.mozilla.geckoview.*
import java.io.File
import java.net.URI
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class Tab(val id: Int, val session: GeckoSession) { var url = ""; var title = "New tab"; var loading = false; var back = false; var fwd = false }

class MainActivity : AppCompatActivity() {
    private lateinit var runtime: GeckoRuntime
    private lateinit var faceView: GeckoView
    private lateinit var pageView: GeckoView
    private val faceSession = GeckoSession()
    private var base = ""                     // moz-extension://…/ of the built-in extension
    private var facePort: WebExtension.Port? = null
    private var bgPort: WebExtension.Port? = null
    private val viewerPorts = mutableMapOf<WebExtension.Port, GeckoSession?>()
    private val tabs = mutableListOf<Tab>()
    private var active = 0; private var nextTab = 1; private var faceReady = false; private var overlay = false; private var totalBlocked = 0
    private var settings = JSONObject(); private var jar = JSONObject(); private var vault = JSONObject("{\"logins\":[],\"never\":[]}"); private var vaultBroken = false
    private val files = mutableMapOf<Int, Uri>(); private var nextFile = 1
    private val main = Handler(Looper.getMainLooper())
    private val density by lazy { resources.displayMetrics.density }

    // ---------------------------------------------------------------- the system's file boxes
    private var onOpenDoc: ((Uri?) -> Unit)? = null; private var onCreateDoc: ((Uri?) -> Unit)? = null; private var onOpenMany: ((List<Uri>) -> Unit)? = null
    private val openDoc = registerForActivityResult(ActivityResultContracts.OpenDocument()) { onOpenDoc?.invoke(it); onOpenDoc = null }
    private val openMany = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { onOpenMany?.invoke(it); onOpenMany = null }
    private val createDoc = registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { onCreateDoc?.invoke(it); onCreateDoc = null }

    override fun onCreate(saved: Bundle?) {
        super.onCreate(saved)
        settings = loadJSON("settings.json"); jar = loadJSON("jar.json"); loadVault()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        faceView = GeckoView(this); pageView = GeckoView(this)
        root.addView(faceView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (78 * density).toInt()))
        root.addView(pageView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        runtime = GeckoRuntime.getDefault(this)
        runtime.webExtensionController.ensureBuiltIn("resource://android/assets/ext/", "engine@meowzer.app").accept({ ext ->
            ext!!.setMessageDelegate(object : WebExtension.MessageDelegate {
                override fun onConnect(port: WebExtension.Port) = adopt(port)
            }, "meowzer")
            base = ext.metaData.baseUrl
            faceSession.open(runtime); faceView.setSession(faceSession)
            faceSession.loadUri(base + "ui/meowzer-ui.html" + if (isPhone()) "?part=top" else "")
            val incoming = intentFiles(intent)
            if (incoming.isEmpty()) newTab(intent?.dataString?.takeIf { it.startsWith("http") }) else openFiles(incoming)
        }, { e -> android.util.Log.e("Meowzer", "the engine bridge didn't load", e) })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val t = tab(null)
                when { overlay -> toFace(JSONObject().put("t", "closePanels")); t != null && t.back -> t.session.goBack(); else -> finish() }
            }
        })
    }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); val f = intentFiles(i); if (f.isNotEmpty()) openFiles(f) else i.dataString?.let { if (it.startsWith("http")) newTab(it) } }
    private fun intentFiles(i: Intent?): List<Uri> = when {
        i == null -> emptyList()
        i.action == Intent.ACTION_VIEW && i.data?.scheme in setOf("content", "file") -> listOfNotNull(i.data)
        i.action == Intent.ACTION_SEND -> listOfNotNull(if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else @Suppress("DEPRECATION") i.getParcelableExtra(Intent.EXTRA_STREAM))
        else -> emptyList()
    }
    private fun isPhone() = resources.configuration.smallestScreenWidthDp < 600

    // ---------------------------------------------------------------- ports: the face, the extension's background, viewer pages
    private fun adopt(port: WebExtension.Port) {
        val s = port.sender
        when {
            s.session === faceSession -> { facePort = port; port.setDelegate(portDelegate { onFace(it) }); main.post { sendInit() } }
            s.session == null && s.environmentType == WebExtension.MessageSender.ENV_TYPE_EXTENSION ->   // the extension's background
                { bgPort = port; port.setDelegate(portDelegate { onBackground(it) }); sendRules() }
            s.url.startsWith(base + "ui/meowzer-view.html") -> { viewerPorts[port] = s.session; port.setDelegate(portDelegate { m -> if (m.optString("meow") == "file") sendFile(port, m.optInt("id")) }) }
            else -> port.disconnect()   // nothing else may talk to the app
        }
    }
    private fun portDelegate(f: (JSONObject) -> Unit) = object : WebExtension.PortDelegate {
        override fun onPortMessage(message: Any, port: WebExtension.Port) { (message as? JSONObject)?.let { main.post { f(it) } } }
        override fun onDisconnect(port: WebExtension.Port) { if (port === facePort) facePort = null; if (port === bgPort) bgPort = null; viewerPorts.remove(port) }
    }
    private fun toFace(o: JSONObject) { if (faceReady || o.optString("t") == "init") facePort?.postMessage(o) }
    private fun reply(t: String, id: Any?, data: Any) = toFace(JSONObject().put("t", t).put("id", id ?: 0).put("data", data))

    // ---------------------------------------------------------------- tabs
    private fun tab(id: Int?) = tabs.firstOrNull { it.id == (id ?: active) }
    private fun newTab(url: String?, activate: Boolean = true): Int {
        val s = GeckoSession(GeckoSessionSettings.Builder().usePrivateMode(false).build())
        val t = Tab(nextTab++, s); tabs += t
        s.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(sess: GeckoSession, url: String?, perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>, userGesture: Boolean) { t.url = url ?: ""; pushState() }
            override fun onCanGoBack(sess: GeckoSession, can: Boolean) { t.back = can; pushState() }
            override fun onCanGoForward(sess: GeckoSession, can: Boolean) { t.fwd = can; pushState() }
            override fun onNewSession(sess: GeckoSession, uri: String): GeckoResult<GeckoSession>? { newTab(uri); return null }   // target=_blank → a tab
        }
        s.contentDelegate = object : GeckoSession.ContentDelegate { override fun onTitleChange(sess: GeckoSession, title: String?) { t.title = title ?: ""; pushState() } }
        s.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(sess: GeckoSession, url: String) { t.loading = true; pushState() }
            override fun onPageStop(sess: GeckoSession, ok: Boolean) { t.loading = false; pushState() }
        }
        s.open(runtime); s.loadUri(fixURL(url ?: ""))
        if (activate || active == 0) select(t.id) else pushState()
        return t.id
    }
    private fun select(id: Int) {
        val t = tab(id) ?: return; active = id
        pageView.releaseSession(); pageView.setSession(t.session); pushState()
    }
    private fun close(id: Int) {
        val i = tabs.indexOfFirst { it.id == id }; if (i < 0) return
        val t = tabs.removeAt(i); if (active == id) pageView.releaseSession(); t.session.close()
        if (tabs.isEmpty()) { active = 0; newTab(null); return }
        if (active == id) select(tabs[minOf(i, tabs.size - 1)].id) else pushState()
    }
    private fun fixURL(s: String): String {
        if (s.isEmpty() || s == "meowzer://newtab") return base + "ui/meowzer-ui.html#ntp"
        if (s.contains("://") || s.startsWith("about:")) return s
        if (!s.contains(' ') && s.contains('.')) return "https://$s"
        return settings.optString("search", "https://duckduckgo.com/?q=%s").replace("%s", Uri.encode(s))
    }
    private fun shown(u: String) = when {
        u.startsWith(base + "ui/meowzer-ui.html") -> "meowzer://newtab"
        u.startsWith(base + "ui/meowzer-view.html") -> Uri.parse(u).getQueryParameter("id")?.toIntOrNull()?.let { files[it]?.toString() } ?: u
        else -> u
    }
    private fun pushState() {
        val list = JSONArray(); for (t in tabs) list.put(JSONObject().put("id", t.id).put("url", shown(t.url)).put("title", t.title).put("favicon", "")
            .put("loading", t.loading).put("canBack", t.back).put("canFwd", t.fwd))
        toFace(JSONObject().put("t", "state").put("active", active).put("tabs", list))
    }

    // ---------------------------------------------------------------- the face's messages
    private fun onFace(m: JSONObject) {
        val t = m.optString("t"); val tt = tab(if (m.has("tab")) m.optInt("tab") else null)
        when (t) {
            "ready", "hello" -> sendInit()
            "nav" -> tt?.session?.loadUri(fixURL(m.optString("url")))
            "back" -> tt?.session?.goBack(); "fwd" -> tt?.session?.goForward(); "reload" -> tt?.session?.reload(); "stop" -> tt?.session?.stop()
            "newtab" -> newTab(m.optString("url").takeIf { it.startsWith("http") })
            "close" -> close(m.optInt("tab")); "select" -> select(m.optInt("tab"))
            "chrome" -> m.optDouble("h").takeIf { it > 0 }?.let { faceView.layoutParams = (faceView.layoutParams as LinearLayout.LayoutParams).apply { height = (it * density).toInt() }; faceView.requestLayout() }
            "overlay" -> { overlay = m.optBoolean("open"); pageView.visibility = if (overlay) View.GONE else View.VISIBLE
                faceView.layoutParams = (faceView.layoutParams as LinearLayout.LayoutParams).apply { weight = if (overlay) 1f else 0f; if (overlay) height = 0 }; faceView.requestLayout() }
            "settings" -> { settings = m.optJSONObject("settings") ?: JSONObject(); saveJSON("settings.json", settings) }
            "jar" -> { jar = m.optJSONObject("jar") ?: JSONObject(); saveJSON("jar.json", jar) }
            "lists" -> sendRules()
            "cookies", "history", "downloads" -> toFace(JSONObject().put("t", t).put("id", m.opt("id")).put("list", JSONArray()))
            "burnAll" -> runtime.storageController.clearData(StorageController.ClearFlags.COOKIES)
            "openFile" -> { onOpenMany = { openFiles(it) }; openMany.launch(arrayOf("*/*")) }
            "core" -> toFace(JSONObject().put("t", "core").put("id", m.opt("id")).put("out", ""))   // no meowcore on Android
            "vault" -> vaultOp(m)
            "probe", "tor", "seal", "route" -> reply(t, m.opt("id"), JSONObject().put("unsupported", true))
        }
    }
    private fun sendInit() {
        faceReady = false
        toFace(JSONObject().put("t", "init").put("platform", if (isPhone()) "phone" else "tablet").put("caption", false).put("tiles", 1).put("max", true)
            .put("engine", "Gecko (GeckoView ${BuildConfig.GECKO_VERSION})").put("settings", settings).put("jar", jar).put("table", "# GeckoView: domain lists").put("totalBlocked", totalBlocked))
        faceReady = true; pushState()
    }

    // ---------------------------------------------------------------- blocking: the lists' domain rules, for background.js
    private fun sendRules() {
        thread {
            val block = JSONArray(); val allow = JSONArray(); val third = JSONArray()
            val text = runCatching { assets.open("lists/meowlist.txt").bufferedReader().readText() }.getOrDefault("") + "\n" + settings.optString("customRules")
            for (raw in text.lineSequence()) {
                var l = raw.trim(); if (l.isEmpty() || l.startsWith("!") || l.startsWith("#") || "##" in l) continue
                val exc = l.startsWith("@@"); if (exc) l = l.substring(2)
                var opts = ""; l.indexOf('$').takeIf { it >= 0 }?.let { opts = l.substring(it + 1); l = l.substring(0, it) }
                l = l.removePrefix("||").removeSuffix("^").lowercase()
                if (l.isEmpty() || '.' !in l || !l.all { it.isLetterOrDigit() || it == '.' || it == '-' }) continue
                when { exc -> allow.put(l); "third-party" in opts -> third.put(l); else -> block.put(l) }
            }
            main.post { bgPort?.postMessage(JSONObject().put("t", "rules").put("block", block).put("allow", allow).put("third", third))
                toFace(JSONObject().put("t", "table").put("stats", "# GeckoView: ${block.length()} blocked domains, ${third.length()} third-party, ${allow.length()} allowed")) }
        }
    }
    private fun onBackground(m: JSONObject) {
        when (m.optString("t")) {
            "blocked" -> { totalBlocked++; toFace(JSONObject().put("t", "blocked").put("tab", active).put("host", m.optString("host")).put("ctx", m.optString("ctx"))) }
            "page" -> { val msg = m.optJSONObject("msg") ?: return
                if (msg.optString("meow") == "vault" && m.optInt("frame") == 0) vaultFromPage(m.optInt("tab"), m.optString("url"), msg) }
        }
    }
    private fun toPage(tab: Int, msg: JSONObject) = bgPort?.postMessage(JSONObject().put("t", "toPage").put("tab", tab).put("msg", msg))

    // ---------------------------------------------------------------- files: everything opens in Meowzer's viewer
    private fun openFiles(urls: List<Uri>) {
        urls.forEachIndexed { i, u -> runCatching { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val id = nextFile++; files[id] = u
            newTab(base + "ui/meowzer-view.html?id=$id" + if (settings.optString("theme") == "light") "&light=1" else "", activate = i == 0) }
    }
    private fun nameOf(u: Uri): String = runCatching { contentResolver.query(u, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null } }.getOrNull() ?: (u.lastPathSegment ?: "file")
    private fun sendFile(port: WebExtension.Port, id: Int) {
        val u = files[id] ?: return
        thread {
            val name = nameOf(u); val limit = 24 shl 20
            val bytes = runCatching { contentResolver.openInputStream(u)?.use { it.readNBytesCompat(limit + 1) } }.getOrNull()
            val cut = bytes != null && bytes.size > limit; val d = if (cut) bytes!!.copyOf(limit) else bytes ?: ByteArray(0)
            val msg = JSONObject().put("meow", "file").put("id", id).put("name", name).put("path", u.toString()).put("ext", name.substringAfterLast('.', ""))
                .put("size", d.size).put("cut", cut).put("exists", bytes != null).put("b64", Base64.encodeToString(d, Base64.NO_WRAP))
            main.post { port.postMessage(msg) }
        }
    }
    private fun java.io.InputStream.readNBytesCompat(n: Int): ByteArray { val out = java.io.ByteArrayOutputStream(); val buf = ByteArray(65536); var left = n
        while (left > 0) { val r = read(buf, 0, minOf(buf.size, left)); if (r < 0) break; out.write(buf, 0, r); left -= r }; return out.toByteArray() }

    // ---------------------------------------------------------------- the vault (the same rules as the Windows host)
    private fun logins(): JSONArray = vault.optJSONArray("logins") ?: JSONArray().also { vault.put("logins", it) }
    private fun never(): JSONArray = vault.optJSONArray("never") ?: JSONArray().also { vault.put("never", it) }
    private fun loadVault() {
        val f = File(filesDir, "vault.dat"); if (!f.exists()) return
        val p = MeowVault.fromFile(f.readBytes(), MeowKeystore.vaultKey(this))
        if (p != null) vault = JSONObject(String(p)) else { vaultBroken = true; f.copyTo(File(filesDir, "vault.dat.unreadable"), true) }
    }
    private fun saveVault() { val f = File(filesDir, "vault.dat.new"); f.writeBytes(MeowVault.fileBytes(vault.toString().toByteArray(), MeowKeystore.vaultKey(this))); f.renameTo(File(filesDir, "vault.dat")) }
    private fun origin(s: String): String = runCatching { val u = URI(s); (u.scheme + "://" + u.host + if (u.port > 0) ":${u.port}" else "").lowercase() }.getOrDefault("")
    private val SFX = setOf("co.uk", "org.uk", "ac.uk", "gov.uk", "co.jp", "ne.jp", "or.jp", "com.au", "net.au", "org.au", "co.nz", "com.br", "com.mx", "co.in", "co.za", "com.tr", "com.cn", "com.tw", "co.kr", "github.io", "blogspot.com", "herokuapp.com", "vercel.app", "netlify.app", "pages.dev")
    private fun siteOf(h: String): String { val p = h.lowercase().split('.'); if (p.size < 3) return p.joinToString("."); return if (p.takeLast(2).joinToString(".") in SFX) p.takeLast(3).joinToString(".") else p.takeLast(2).joinToString(".") }
    private fun hostOf(o: String) = runCatching { URI(o).host ?: "" }.getOrDefault("")
    private fun pub(e: JSONObject, o: String? = null) = JSONObject(e.toString()).apply { remove("pass"); if (o != null) put("exact", e.optString("origin") == o) }
    private fun vaultList(): JSONObject { val l = JSONArray(); for (i in 0 until logins().length()) l.put(pub(logins().getJSONObject(i))); return JSONObject().put("logins", l).put("never", never()).put("broken", vaultBroken) }
    private fun find(id: String): Int { for (i in 0 until logins().length()) if (logins().getJSONObject(i).optString("id") == id) return i; return -1 }
    private fun neverHas(s: String): Boolean { for (i in 0 until never().length()) if (never().optString(i) == s) return true; return false }
    private fun now() = System.currentTimeMillis() / 1000
    private var pending: JSONObject? = null

    private fun vaultFromPage(tab: Int, url: String, m: JSONObject) {
        if (!url.startsWith("http")) return
        val o = origin(url); val site = siteOf(hostOf(url)); val vs = settings.optJSONObject("vault") ?: JSONObject()
        val mode = vs.optString("fill", "ask"); val exactOnly = vs.optBoolean("exact", false)
        fun mine(e: JSONObject) = e.optString("origin") == o || (!exactOnly && e.optString("site") == site)
        when (m.optString("op")) {
            "logins" -> {
                if (mode == "off") return
                val list = JSONArray(); val exact = mutableListOf<JSONObject>()
                for (i in 0 until logins().length()) { val e = logins().getJSONObject(i); if (mine(e)) { list.put(pub(e, o)); if (e.optString("origin") == o) exact += e } }
                if (list.length() == 0) return
                val auto: Any = if (mode == "auto" && exact.size == 1 && o.startsWith("https://")) JSONObject().put("id", exact[0].optString("id")).put("user", exact[0].optString("user")).put("pass", exact[0].optString("pass")) else JSONObject.NULL
                toPage(tab, JSONObject().put("meow", "vault").put("mode", mode).put("logins", list).put("auto", auto))
            }
            "fill", "filled" -> {
                val i = find(m.optString("id")); if (i < 0) return; val e = logins().getJSONObject(i); if (!mine(e)) return
                if (m.optString("op") == "fill") toPage(tab, JSONObject().put("meow", "vault").put("fill", JSONObject().put("user", e.optString("user")).put("pass", e.optString("pass"))))
                e.put("used", now()).put("uses", e.optInt("uses") + 1); saveVault()
            }
            "capture" -> {
                if (!vs.optBoolean("offer", true)) return
                val user = m.optString("user"); val pass = m.optString("pass"); if (pass.isEmpty() || neverHas(site)) return
                var same: JSONObject? = null; for (i in 0 until logins().length()) { val e = logins().getJSONObject(i); if (e.optString("origin") == o && e.optString("user") == user) same = e }
                if (same != null && same.optString("pass") == pass) return
                pending = JSONObject().put("origin", o).put("site", site).put("user", user).put("pass", pass).put("id", same?.optString("id") ?: "").put("update", same != null)
                toFace(JSONObject().put("t", "vaultOffer").put("site", site).put("origin", o).put("user", user).put("update", same != null))
            }
        }
    }
    private fun addLogin(o: String, user: String, pass: String, note: String) = logins().put(JSONObject().put("id", MeowVault.hex(MeowVault.random(8))).put("origin", o).put("site", siteOf(hostOf(o)))
        .put("user", user).put("pass", pass).put("note", note).put("created", now()).put("changed", now()).put("used", 0).put("uses", 0))
    private fun copy(s: String) {
        val cm = getSystemService(ClipboardManager::class.java); val clip = ClipData.newPlainText("Meowzer", s)
        clip.description.extras = PersistableBundle().apply { putBoolean(if (Build.VERSION.SDK_INT >= 33) ClipDescription.EXTRA_IS_SENSITIVE else "android.content.extra.IS_SENSITIVE", true) }
        cm.setPrimaryClip(clip)
        val after = (settings.optJSONObject("vault") ?: JSONObject()).optInt("clip", 30)
        if (after > 0) main.postDelayed({ if (cm.primaryClip?.getItemAt(0)?.text == s && Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip() }, after * 1000L)
    }
    private var importBytes: ByteArray? = null; private var importName = ""
    private fun vaultOp(m: JSONObject) {
        val id = m.opt("id"); fun r(d: Any) = reply("vault", id, d)
        val idx = find(m.optString("login"))
        when (m.optString("op")) {
            "list" -> r(vaultList())
            "reveal" -> r(JSONObject().put("pass", if (idx >= 0) logins().getJSONObject(idx).optString("pass") else ""))
            "copy" -> { if (idx >= 0) copy(logins().getJSONObject(idx).optString(if (m.optString("what") == "user") "user" else "pass")); r(JSONObject().put("ok", true)) }
            "copyText" -> { copy(m.optString("text")); r(JSONObject().put("ok", true)) }
            "save" -> {
                val l = m.optJSONObject("login") ?: JSONObject(); var o = l.optString("origin"); if ("://" !in o) o = "https://$o"; o = origin("$o/")
                if (o.length < 10) { r(JSONObject().put("error", "That address doesn't look right.")); return }
                val i = if (l.optString("id").isNotEmpty()) find(l.optString("id")) else -1
                if (i >= 0) { val e = logins().getJSONObject(i); e.put("origin", o).put("site", siteOf(hostOf(o))).put("user", l.optString("user")).put("note", l.optString("note"))
                    if (l.optString("pass").isNotEmpty()) e.put("pass", l.optString("pass")).put("changed", now()) }
                else addLogin(o, l.optString("user"), l.optString("pass"), l.optString("note"))
                saveVault(); r(vaultList())
            }
            "del" -> { if (idx >= 0) logins().remove(idx); saveVault(); r(vaultList()) }
            "never" -> { val s = m.optString("site"); val n = JSONArray(); for (i in 0 until never().length()) if (never().optString(i) != s) n.put(never().optString(i))
                if (m.optBoolean("on")) n.put(s); vault.put("never", n); saveVault(); r(vaultList()) }
            "wipe" -> { vault = JSONObject("{\"logins\":[],\"never\":[]}"); vaultBroken = false; if (m.optBoolean("newKey")) MeowKeystore.newVaultKey(this); saveVault(); r(vaultList()) }
            "gen" -> r(JSONObject().put("pw", MeowVault.password(m.optInt("tier", 3), m.optInt("len", 20), m.optInt("flags") and 1 == 1)))
            "user" -> r(JSONObject().put("user", MeowVault.userName(m.optInt("style"))))
            "offer" -> {
                val p = pending
                if (p != null && m.optString("a") == "save") {
                    val i = find(p.optString("id"))
                    if (p.optBoolean("update") && i >= 0) logins().getJSONObject(i).put("pass", p.optString("pass")).put("changed", now())
                    else addLogin(p.optString("origin"), p.optString("user"), p.optString("pass"), "")
                    saveVault()
                }
                if (p != null && m.optString("a") == "never") { never().put(p.optString("site")); saveVault() }
                pending = null; r(JSONObject().put("ok", true))
            }
            "export" -> {
                val pw = m.optString("pw"); val plain = vault.toString().toByteArray(); val count = logins().length()
                onCreateDoc = { u ->
                    if (u == null) r(JSONObject().put("cancelled", true))
                    else thread {   // 600,000 rounds take a few seconds on a phone
                        val res = runCatching { contentResolver.openOutputStream(u, "wt")!!.use { it.write(MeowVault.export(plain, pw)) } }
                        main.post { r(if (res.isSuccess) JSONObject().put("ok", true).put("count", count).put("path", nameOf(u)).put("locked", pw.isNotEmpty()) else JSONObject().put("error", res.exceptionOrNull()?.message ?: "Couldn't write the file.")) }
                    }
                }
                createDoc.launch("Meowzer vault " + SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(Date()) + ".meowvault")
            }
            "import" -> {
                val finish = finish@{
                    val f = importBytes ?: run { r(JSONObject().put("cancelled", true)); return@finish }
                    val pw = m.optString("pw")
                    thread {
                        val res = MeowVault.importFile(f, pw)
                        main.post {
                            when (res) {
                                MeowVault.Import.NotAVault -> r(JSONObject().put("error", "That file isn't a Meowzer vault."))
                                MeowVault.Import.NeedsPassword -> r(JSONObject().put("need", "password").put("name", importName))
                                MeowVault.Import.Wrong -> r(JSONObject().put("wrong", true))
                                MeowVault.Import.Damaged -> r(JSONObject().put("error", "The vault file was changed or is damaged; nothing was imported."))
                                is MeowVault.Import.Ok -> {
                                    val v = runCatching { JSONObject(String(res.plain)) }.getOrDefault(JSONObject()); var added = 0; var updated = 0
                                    val inc = v.optJSONArray("logins") ?: JSONArray()
                                    for (k in 0 until inc.length()) { val e = inc.getJSONObject(k); var hit = -1
                                        for (i in 0 until logins().length()) { val x = logins().getJSONObject(i); if (x.optString("origin") == e.optString("origin") && x.optString("user") == e.optString("user")) hit = i }
                                        if (hit >= 0) { val x = logins().getJSONObject(hit); if (x.optString("pass") != e.optString("pass")) { x.put("pass", e.optString("pass")).put("changed", now()); updated++ } }
                                        else { e.put("id", MeowVault.hex(MeowVault.random(8))); logins().put(e); added++ } }
                                    val nv = v.optJSONArray("never") ?: JSONArray(); for (k in 0 until nv.length()) if (!neverHas(nv.optString(k))) never().put(nv.optString(k))
                                    saveVault(); importBytes = null; r(JSONObject().put("ok", true).put("added", added).put("updated", updated))
                                }
                            }
                        }
                    }
                }
                if (m.optBoolean("again")) finish()
                else { onOpenDoc = { u -> importBytes = u?.let { runCatching { contentResolver.openInputStream(it)?.use { s -> s.readBytes() } }.getOrNull() }
                    importName = u?.let { nameOf(it) } ?: ""; finish() }; openDoc.launch(arrayOf("*/*")) }
            }
            else -> r(JSONObject())
        }
    }

    // ---------------------------------------------------------------- storage
    private fun loadJSON(n: String) = runCatching { JSONObject(File(filesDir, n).readText()) }.getOrDefault(JSONObject())
    private fun saveJSON(n: String, o: JSONObject) { val f = File(filesDir, "$n.new"); f.writeText(o.toString()); f.renameTo(File(filesDir, n)) }
}
