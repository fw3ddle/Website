// Meowzer 4 for Android. GeckoView's version: pick the current release from https://maven.mozilla.org/maven2/org/mozilla/geckoview/geckoview/
val geckoVersion = "160.0.20261104181552"

plugins { id("com.android.application") }

android {
    namespace = "app.meowzer.meowzer4"
    compileSdk { version = release(37) { minorApiLevel = 2 } }   // GeckoView 160 and AndroidX 1.19 compile against 37.2
    defaultConfig {
        applicationId = "app.meowzer.meowzer4"
        minSdk = 26; targetSdk = 36
        ndk { abiFilters += "arm64-v8a" }
        versionCode = 1; versionName = "4.0"
        buildConfigField("String", "GECKO_VERSION", "\"${geckoVersion.substringBefore('.')}\"")
    }
    buildFeatures { buildConfig = true }
    packaging { jniLibs { useLegacyPackaging = true } }   // compressed in the APK (Gecko's 147 MB engine library packs to a third), unpacked on install
    buildTypes {
        release { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("debug") }   // sign with your own key before publishing
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    sourceSets["main"].assets.directories.add(layout.buildDirectory.dir("meowassets").get().asFile.path)
}

dependencies {
    // arm64 only: every current phone (the all-CPU package makes a 530 MB APK); use geckoview-x86_64 for an emulator
    implementation("org.mozilla.geckoview:geckoview-arm64-v8a:$geckoVersion")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
}

// Meowzer's face and lists come from the shared ui/ and core/ folders; inject.js gets its data line filled
// (no personas on Android: there is no meowcore to draw them)
val root = rootDir.resolve("../..")
val meowAssets = tasks.register<Copy>("meowAssets") {
    into(layout.buildDirectory.dir("meowassets"))
    from(root.resolve("ui")) { into("ext/ui"); exclude("inject.js", "logo/**", "serve.ps1") }
    from(root.resolve("ui/inject.js")) { into("ext"); filter { it.replace("__MEOW_DATA__", "{\"def\":null,\"pool\":null,\"sites\":{},\"css\":{}}") } }
    from(root.resolve("core/lists/meowlist.txt")) { into("lists") }
}
tasks.named("preBuild") { dependsOn(meowAssets) }
