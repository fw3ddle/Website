﻿# Builds Meowzer 4 for Windows into ..\..\build\windows\:
#   meowcore.exe       core\meowcore.fx compiled by fxc (ꟻX 0.29 Helix)
#   meowpaint.exe      engine\meowpaint.fx, Meowzer's own document engine (Astra's Engine Lab), compiled by the same fxc
#   Meowzer.exe        this host, compiled by zig c++
#   WebView2Loader.dll Microsoft's loader from the WebView2 SDK
#   ui\, lists\        the shared face and the cat's list
# Usage: powershell -File build.ps1 -Fxc <fxc.exe> -Zig <zig.exe> -WebView2Sdk <unpacked nupkg folder>
param(
  [string]$Fxc = "",
  [string]$Zig = "$env:LOCALAPPDATA\fxtool\zig-windows-x86_64-0.13.0\zig.exe",
  [Parameter(Mandatory)] [string]$WebView2Sdk,
  [switch]$DevTools,
  [string]$Out = ''   # somewhere else than build\windows (for a test build while Meowzer runs)
)
$ErrorActionPreference = 'Stop'
if (-not $Fxc) { $Fxc = @("$PSScriptRoot\..\..\..\FX-0.29.0-Helix\FX-0.29.0\bin\windows-x64\fxc.exe", "$PSScriptRoot\..\..\..\FX-0.28.0-Omni\FX-0.28.0\bin\windows-x64\fxc.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1 }
$root = (Resolve-Path "$PSScriptRoot\..\..").Path
$out = if ($Out) { $Out } else { "$root\build\windows" }
New-Item -ItemType Directory -Force "$out\ui", "$out\lists" | Out-Null

& $Fxc "$root\core\meowcore.fx" -o "$out\meowcore.exe"
if ($LASTEXITCODE) { throw "fxc failed (meowcore)" }
& $Fxc "$root\engine\meowpaint.fx" -o "$out\meowpaint.exe" --target=windows
if ($LASTEXITCODE) { throw "fxc failed (meowpaint)" }

& $Zig rc /fo "$out\meowzer.res" "$PSScriptRoot\meowzer.rc"
if ($LASTEXITCODE) { throw "rc failed" }
$flags = @('-target', 'x86_64-windows-gnu', '-std=c++17', '-O2', '-municode', '-I', "$WebView2Sdk\build\native\include")
if ($DevTools) { $flags += '-DMEOW_DEBUG' }
$libs = @('-lole32', '-loleaut32', '-luser32', '-lshlwapi', '-lshell32', '-lgdi32', '-lurlmon', '-lcrypt32', '-ladvapi32', '-lws2_32', '-lbcrypt', '-lwinhttp', '-luuid', '-Wl,--subsystem,windows')
$ErrorActionPreference = 'Continue'
& $Zig c++ @flags "$PSScriptRoot\meowzer.cpp" "$out\meowzer.res" -o "$out\Meowzer.exe" @libs 2>&1 | Where-Object { $_ -notmatch 'libunwind|dll-attribute-on-redeclaration|previous declaration|^\s+\d+ \||^\s+\||^\s*\^|warnings? generated' }
if ($LASTEXITCODE) { throw "zig c++ failed" }
$ErrorActionPreference = 'Stop'
Remove-Item "$out\meowzer.res", "$out\Meowzer.pdb", "$out\meowzer.lib" -ErrorAction SilentlyContinue

Copy-Item "$WebView2Sdk\build\native\x64\WebView2Loader.dll" $out -Force
Copy-Item "$root\ui\meowzer-ui.html", "$root\ui\meowzer-shelf.html", "$root\ui\personas.js", "$root\ui\inject.js", "$root\ui\meowzer-ghost.html", "$root\ui\worldmap.js", "$root\ui\themes.js", "$root\ui\mask.js", "$root\ui\meowzer-logo.png", "$root\ui\meowzer-view.html", "$root\ui\vault.js", "$root\ui\meowzer-paint.html" "$out\ui" -Force
Copy-Item "$root\core\lists\meowlist.txt" "$out\lists" -Force
Get-ChildItem $out -Recurse -File | Select-Object @{n = 'file'; e = { $_.FullName.Substring($out.Length + 1) } }, Length | Format-Table -AutoSize
