# make-release.ps1 — makes the release zips for GitHub: one per platform, plus the whole project.
#   powershell -File tools\make-release.ps1 [-Out <folder>] [-Version 4.0]
# The Windows zip needs build\windows (run hosts\windows\build.ps1 first). Zips use / in their paths so they
# unpack right on Linux and macOS too, and the .sh scripts keep their run permission.
param([string]$Out = (Join-Path $PSScriptRoot '..\..\Meowzer4-release'), [string]$Version = '4.0')
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
New-Item -ItemType Directory -Force $Out | Out-Null; $Out = (Resolve-Path $Out).Path
$skip = '\\(build|out|\.gradle|\.idea|dd|node_modules)\\|\\local\.properties$|\\Meowzer4\.xcodeproj\\'

function Files($rel) {
    $p = Join-Path $root $rel
    if (Test-Path $p -PathType Leaf) { return ,(Get-Item $p) }
    Get-ChildItem -Recurse -File $p | Where-Object { $_.FullName -notmatch $skip }
}
function Zip($name, [string[]]$parts, [hashtable]$extra = @{}, [string]$prefix = 'Meowzer4/') {
    $zip = Join-Path $Out $name; if (Test-Path $zip) { Remove-Item $zip }
    $z = [IO.Compression.ZipFile]::Open($zip, 'Create'); $n = 0
    try {
        foreach ($part in $parts) {
            foreach ($f in (Files $part)) {
                $entry = $prefix + $f.FullName.Substring($root.Length + 1).Replace('\', '/')
                $e = [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($z, $f.FullName, $entry, 'Optimal')
                $mode = if ($f.Extension -eq '.sh' -or $f.Name -like 'meowcore-linux-*' -or $f.Name -eq 'PKGBUILD') { 0x81ED } else { 0x81A4 }   # rwxr-xr-x / rw-r--r--
                $e.ExternalAttributes = $mode -shl 16; $n++
            }
        }
        foreach ($k in $extra.Keys) {
            $e = $z.CreateEntry($prefix + $k); $w = New-Object IO.StreamWriter($e.Open(), (New-Object Text.UTF8Encoding $false))
            $w.Write(($extra[$k] -replace "`r`n", "`n")); $w.Dispose(); $e.ExternalAttributes = 0x81A4 -shl 16; $n++
        }
    } finally { $z.Dispose() }
    '{0,-36} {1,5} files {2,8:N0} KB' -f $name, $n, ((Get-Item $zip).Length / 1KB)
}

$shared = @('ui', 'core', 'engine', 'hosts\PROTOCOL.md', 'README.md', 'TEST-REPORT.md')
$untested = "Status: this host is written to Meowzer's protocol but has not been compiled yet (only the Windows build is built and tested). Expect a few fixes on the first build.`n"

# ---- Windows: the program itself, ready to install
if (-not (Test-Path (Join-Path $root 'build\windows\Meowzer.exe'))) { throw 'build\windows\Meowzer.exe is missing: run hosts\windows\build.ps1 first.' }
$zip = Join-Path $Out "Meowzer4-$Version-windows-x64.zip"; if (Test-Path $zip) { Remove-Item $zip }
$z = [IO.Compression.ZipFile]::Open($zip, 'Create')
try {
    foreach ($f in Get-ChildItem -Recurse -File (Join-Path $root 'build\windows')) {
        [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($z, $f.FullName, 'Meowzer4/Meowzer/' + $f.FullName.Substring((Join-Path $root 'build\windows').Length + 1).Replace('\', '/'), 'Optimal') }
    $sums = (Get-ChildItem -Recurse -File (Join-Path $root 'build\windows') | ForEach-Object { '{0}  Meowzer/{1}' -f (Get-FileHash $_.FullName -Algorithm SHA256).Hash.ToLower(), $_.FullName.Substring((Join-Path $root 'build\windows').Length + 1).Replace('\', '/') }) -join "`n"
    $e = $z.CreateEntry('Meowzer4/SHA256SUMS.txt'); $w = New-Object IO.StreamWriter($e.Open()); $w.Write($sums + "`n"); $w.Dispose()
    foreach ($f in 'install.ps1', 'Install.cmd') { [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($z, (Join-Path $root "hosts\windows\$f"), "Meowzer4/$f", 'Optimal') }
    $e = $z.CreateEntry('Meowzer4/README.txt'); $w = New-Object IO.StreamWriter($e.Open())
    $w.Write("Meowzer 4 for Windows 10/11 (x64)`r`n`r`nInstall: double-click Install.cmd. It copies Meowzer to your user folder, adds it to the Start menu and Settings > Apps (no admin needed).`r`nOr just run Meowzer\Meowzer.exe from anywhere.`r`nUninstall: Settings > Apps > Meowzer 4, or: powershell -File `"%LOCALAPPDATA%\Programs\Meowzer4\install.ps1`" -Uninstall`r`nNeeds the WebView2 Runtime (already part of Windows 11).`r`n"); $w.Dispose()
} finally { $z.Dispose() }
'{0,-36} {1,14:N0} KB' -f (Split-Path $zip -Leaf), ((Get-Item $zip).Length / 1KB)

# ---- Linux: one source tree, three ways in
$linux = $shared + @('hosts\linux', 'hosts\windows\icon')
Zip "Meowzer4-$Version-arch.zip" $linux @{ 'INSTALL.txt' = "Meowzer 4 for Arch Linux`n`n  cd Meowzer4/hosts/linux`n  makepkg -si`n`nor, without a package:  ./install.sh`n`n$untested" }
Zip "Meowzer4-$Version-debian.zip" $linux @{ 'INSTALL.txt' = "Meowzer 4 for Debian / Ubuntu`n`n  cd Meowzer4/hosts/linux`n  ./install.sh                 (builds and installs into ~/.local)`nor a .deb:`n  ./make-deb.sh && sudo apt install ./meowzer4_*.deb`n`n$untested" }
Zip "Meowzer4-$Version-flatpak.zip" $linux @{ 'INSTALL.txt' = "Meowzer 4 as a Flatpak`n`n  flatpak install flathub org.gnome.Platform//47 org.gnome.Sdk//47`n  cd Meowzer4/hosts/linux`n  flatpak-builder --user --install --force-clean build-dir app.meowzer.Meowzer4.yml`n  flatpak run app.meowzer.Meowzer4`n`n$untested" }

# ---- Apple: the same Swift sources make both apps
$apple = $shared + @('hosts\apple', 'hosts\windows\icon')
Zip "Meowzer4-$Version-mac.zip" $apple @{ 'INSTALL.txt' = "Meowzer 4 for macOS (13+)`n`nNeeds Xcode 15+ (App Store) and XcodeGen (brew install xcodegen).`n  cd Meowzer4/hosts/apple`n  ./build-mac.sh`nThen right-click Meowzer > Open the first time (it isn't signed by Apple).`n`n$untested" }
Zip "Meowzer4-$Version-ios.zip" $apple @{ 'INSTALL.txt' = "Meowzer 4 for iPhone and iPad (iOS 16+)`n`nOn a Mac with Xcode 15+ and XcodeGen:`n  cd Meowzer4/hosts/apple`n  ./build-mac.sh ios`nIn Xcode: pick Meowzer4-iOS and your device, set your Team under Signing & Capabilities, press Run.`n`n$untested" }

# ---- Android: the built APK (from hosts\android\build-android.ps1) plus its sources
$apk = Join-Path $root 'build\android\Meowzer4.apk'
if (Test-Path $apk) {
    $apkSum = (Get-FileHash $apk -Algorithm SHA256).Hash.ToLower()
    $droid = "Meowzer 4 for Android (8.0+, 64-bit ARM phones), on GeckoView`n`nInstall: copy Meowzer4.apk to your phone and open it (allow 'install unknown apps' for your file manager when asked).`nOr from a PC:  adb install Meowzer4.apk`n`nSHA-256: $apkSum`n`nIt is signed with a development key, not a store key: Android may warn about that. To rebuild or sign it yourself, see hosts/android/README.md.`nStatus: built and checked (package, signature) on Windows, but not yet run on a phone. Expect a few fixes after the first real run.`n"
} else {
    $droid = "Meowzer 4 for Android (8.0+), on GeckoView`n`nOpen Meowzer4/hosts/android in Android Studio, plug in your phone, press Run.`nOr: ./build-android.sh (Linux/macOS) or build-android.ps1 (Windows) -> build/android/Meowzer4.apk`n"
}
Zip "Meowzer4-$Version-android.zip" ($shared + @('hosts\android')) @{ 'INSTALL.txt' = $droid }
if (Test-Path $apk) {
    $z = [IO.Compression.ZipFile]::Open((Join-Path $Out "Meowzer4-$Version-android.zip"), 'Update')
    try { $e = [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($z, $apk, 'Meowzer4/Meowzer4.apk', 'NoCompression'); $e.ExternalAttributes = 0x81A4 -shl 16 }
    finally { $z.Dispose() }
    '  + Meowzer4.apk ({0:N0} KB, sha256 {1})' -f ((Get-Item $apk).Length / 1KB), $apkSum
}

# ---- QNX
Zip "Meowzer4-$Version-qnx.zip" ($shared + @('hosts\qnx')) @{ 'INSTALL.txt' = "Meowzer 4 for QNX: a starting point, not a finished port.`nRead Meowzer4/hosts/qnx/README.md. It needs QNX SDP 8.0 and Qt for QNX with WebEngine, which you download from BlackBerry QNX with your own myQNX account.`n" }

# ---- the whole project
Zip "Meowzer4-$Version-source.zip" @('README.md', 'TEST-REPORT.md', 'ui', 'core', 'engine', 'hosts', 'tests', 'tools')

# ---- checksums of every zip, and the test report beside them (as Astra's Engine Lab ships them)
Copy-Item (Join-Path $root 'TEST-REPORT.md') $Out -Force
(Get-ChildItem $Out -Filter *.zip | Sort-Object Name | ForEach-Object { '{0}  {1}' -f (Get-FileHash $_.FullName -Algorithm SHA256).Hash.ToLower(), $_.Name }) -join "`n" |
    ForEach-Object { [IO.File]::WriteAllText((Join-Path $Out 'SHA256SUMS.txt'), $_ + "`n") }
"`nZips, SHA256SUMS.txt and TEST-REPORT.md are in $Out"
