// cdp-shot.js — saves a PNG of one page through the DevTools protocol. Usage: node cdp-shot.js <url part> <out.png> [port]
const [, , part, out, port = '9333'] = process.argv;
(async () => {
  const list = await (await fetch(`http://127.0.0.1:${port}/json`)).json();
  const t = list.find((p) => p.type === 'page' && p.url.includes(part));
  if (!t) { console.log('no target'); process.exit(1); }
  const ws = new WebSocket(t.webSocketDebuggerUrl); await new Promise((r) => (ws.onopen = r));
  ws.send(JSON.stringify({ id: 1, method: 'Page.captureScreenshot', params: { format: 'png' } }));
  const m = await new Promise((r) => (ws.onmessage = (e) => { const x = JSON.parse(e.data); if (x.id === 1) r(x); }));
  require('fs').writeFileSync(out, Buffer.from(m.result.data, 'base64')); ws.close(); console.log('saved', out);
})();
