// cdp-click.js — clicks at a point in a page through the DevTools protocol (real input events, so it reaches closed
// shadow roots like the vault's 🐾 button). Usage: node cdp-click.js <url part> <x> <y> [port]
const [, , part, x, y, port = '9333'] = process.argv;
(async () => {
  const list = await (await fetch(`http://127.0.0.1:${port}/json`)).json();
  const t = list.find((p) => p.type === 'page' && (part[0] === '=' ? p.url === part.slice(1) : p.url.includes(part)));   // =<url>: exactly that page
  if (!t) { console.log('no target'); process.exit(1); }
  const ws = new WebSocket(t.webSocketDebuggerUrl); await new Promise((r) => (ws.onopen = r));
  let id = 0; const call = (method, params) => new Promise((res) => { const my = ++id; ws.addEventListener('message', function h(e) { const m = JSON.parse(e.data); if (m.id === my) { ws.removeEventListener('message', h); res(m); } }); ws.send(JSON.stringify({ id: my, method, params })); });
  for (const type of ['mouseMoved', 'mousePressed', 'mouseReleased']) await call('Input.dispatchMouseEvent', { type, x: +x, y: +y, button: 'left', clickCount: 1 });
  ws.close(); console.log('clicked', x, y);
})();
