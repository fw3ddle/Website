// cdp.js — drives a running Meowzer (started with WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS=--remote-debugging-port=9333)
// through the DevTools protocol. Usage: node cdp.js <ui|ui:N|uis|page|shelf> "<javascript expression>"
// Evaluates the expression in the face (ui; ui:N for the Nth tile's face; uis for every face), the active page
// (page) or the bookshelf, and prints the JSON result.
const [, , which, expr, port = '9333'] = process.argv;
const isFace = p => p.url.startsWith('https://meowzer.ui/meowzer-ui.html') && !p.url.includes('#ntp');
async function evalIn(t) {
  const ws = new WebSocket(t.webSocketDebuggerUrl);
  await new Promise(r => ws.onopen = r);
  return new Promise(res => {
    ws.onmessage = e => { const m = JSON.parse(e.data); if (m.id === 1) { ws.close(); res(m.result.result.value ?? m.result.exceptionDetails ?? m.result); } };
    ws.send(JSON.stringify({ id: 1, method: 'Runtime.evaluate', params: { expression: expr, awaitPromise: true, returnByValue: true } }));
  });
}
(async () => {
  const list = await (await fetch(`http://127.0.0.1:${port}/json`)).json();
  const pages = list.filter(t => t.type === 'page');
  if (which === 'uis') { for (const t of pages.filter(isFace)) console.log(JSON.stringify(await evalIn(t))); return; }
  const t = which.startsWith('ui') ? pages.filter(isFace)[+(which.split(':')[1] || 0)]
    : which === 'shelf' ? pages.find(p => p.url.startsWith('https://meowzer.ui/meowzer-shelf.html'))
    : which.startsWith('url:') ? pages.find(p => p.url.includes(which.slice(4)))   // url:<part of the address>

    : pages.find(p => !p.url.startsWith('https://meowzer.ui/meowzer-shelf.html') && !isFace(p));
  if (!t) { console.log('no target', pages.map(p => p.url)); process.exit(1); }
  console.log(JSON.stringify(await evalIn(t), null, 1));
})();
