// vault-port.js — checks that a port of meowcore's vault lock (what the Swift and Kotlin hosts do) gives exactly
// meowcore's bytes. Usage: node tests/vault-port.js <meowcore.exe>
const { execFileSync } = require('child_process'), crypto = require('crypto');
const PEPPER = 'Meowzer 4 vault pepper. Only a Meowzer opens what a Meowzer seals; the cat keeps the key under its paw.';
function chacha(key, nonce, counter) {   // RFC 8439 block function; returns a keystream reader
  const s = new Uint32Array(16), x = new Uint32Array(16), out = new Uint8Array(64); let pos = 64, ctr = counter;
  const rd = (b, o) => b[o] | b[o + 1] << 8 | b[o + 2] << 16 | b[o + 3] << 24;
  const qr = (a, b, c, d) => { x[a] += x[b]; x[d] = (x[d] ^ x[a]) << 16 | (x[d] ^ x[a]) >>> 16; x[c] += x[d]; x[b] = (x[b] ^ x[c]) << 12 | (x[b] ^ x[c]) >>> 20;
    x[a] += x[b]; x[d] = (x[d] ^ x[a]) << 8 | (x[d] ^ x[a]) >>> 24; x[c] += x[d]; x[b] = (x[b] ^ x[c]) << 7 | (x[b] ^ x[c]) >>> 25; };
  return () => {
    if (pos === 64) {
      s.set([0x61707865, 0x3320646e, 0x79622d32, 0x6b206574]); for (let i = 0; i < 8; i++) s[4 + i] = rd(key, 4 * i);
      s[12] = ctr++; for (let i = 0; i < 3; i++) s[13 + i] = rd(nonce, 4 * i); x.set(s);
      for (let r = 0; r < 10; r++) { qr(0, 4, 8, 12); qr(1, 5, 9, 13); qr(2, 6, 10, 14); qr(3, 7, 11, 15); qr(0, 5, 10, 15); qr(1, 6, 11, 12); qr(2, 7, 8, 13); qr(3, 4, 9, 14); }
      for (let i = 0; i < 16; i++) { const w = (x[i] + s[i]) >>> 0; out[4 * i] = w; out[4 * i + 1] = w >>> 8; out[4 * i + 2] = w >>> 16; out[4 * i + 3] = w >>> 24; }
      pos = 0;
    }
    return out[pos++];
  };
}
function lock(plain, rounds, pw, salt, nonce) {
  const dk = crypto.pbkdf2Sync(Buffer.concat([Buffer.from(PEPPER), pw]), salt, rounds, 96, 'sha256');
  const a = chacha(dk.subarray(0, 32), nonce, 1), b = chacha(dk.subarray(32, 64), nonce, 1);
  const ct = Buffer.alloc(plain.length); for (let i = 0; i < plain.length; i++) ct[i] = plain[i] ^ a() ^ b();
  const tag = crypto.createHmac('sha256', dk.subarray(64, 96)).update(salt).update(nonce).update(ct).digest();
  return { ct, tag };
}
const core = process.argv[2], salt = crypto.randomBytes(16), nonce = crypto.randomBytes(12);
let ok = true;
for (const [rounds, pw] of [[1, Buffer.alloc(0)], [1, crypto.randomBytes(32)], [1000, Buffer.from('pässwörd 🐾')]]) {
  const plain = Buffer.from(JSON.stringify({ logins: [{ user: 'cat', pass: 'x'.repeat(150) }], never: [] }));
  const hexLines = plain.toString('hex').match(/.{1,2048}/g).join('\n');
  const out = execFileSync(core, { input: `@vlock ${rounds} ${salt.toString('hex')} ${nonce.toString('hex')}${pw.length ? ' ' + pw.toString('hex') : ''}\n${hexLines}\n@end\n` }).toString();
  const ct = Buffer.from(out.split('\n').filter((l) => l.startsWith('x ')).map((l) => l.slice(2).trim()).join(''), 'hex');
  const tag = out.split('\n').find((l) => l.startsWith('t ')).slice(2).trim();
  const mine = lock(plain, rounds, pw, salt, nonce), same = mine.ct.equals(ct) && mine.tag.toString('hex') === tag;
  console.log(`rounds ${rounds}, password ${pw.length} bytes: ${same ? 'same bytes as meowcore' : 'DIFFERENT'}`); ok = ok && same;
}
process.exit(ok ? 0 : 1);
