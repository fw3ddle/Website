# The easy way on Windows: double-click Install.cmd (it runs this).
# Copies Meowzer into your user folder (no admin needed), adds it to the Start menu and, if you like, the desktop,
# and writes an uninstaller. Your data (settings, the vault) stays in %LOCALAPPDATA%\Meowzer4 and isn't touched.
param([switch]$Desktop, [switch]$Uninstall, [switch]$Quiet)
$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
$dest = Join-Path $env:LOCALAPPDATA 'Programs\Meowzer4'
$menu = Join-Path ([Environment]::GetFolderPath('Programs')) 'Meowzer.lnk'
$desk = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Meowzer.lnk'
function Say($s) { Write-Host "🐱 $s" -ForegroundColor Yellow }

if ($Uninstall) {
    Get-Process Meowzer -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "$dest*" } | ForEach-Object { Say 'Close Meowzer first, then run this again.'; exit 1 }
    Remove-Item $menu, $desk -ErrorAction SilentlyContinue
    Remove-Item -Recurse -Force $dest -ErrorAction SilentlyContinue
    Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Meowzer4' -Recurse -ErrorAction SilentlyContinue
    Say 'Meowzer is uninstalled. Your settings and vault are still in %LOCALAPPDATA%\Meowzer4 (delete that folder to remove them too).'
    exit 0
}

# where the program is: the zip's Meowzer folder, or a build of this source tree
$src = @((Join-Path $here 'Meowzer'), (Join-Path $here '..\..\build\windows')) | Where-Object { Test-Path (Join-Path $_ 'Meowzer.exe') } | Select-Object -First 1
if (-not $src) { Say 'No Meowzer.exe found next to this script. Build it first: powershell -File hosts\windows\build.ps1 (see BUILDING.md)'; exit 1 }

# WebView2 (the Edge engine Windows draws web pages with) comes with Windows 11 and up-to-date Windows 10
$wv = 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}'
if (-not (Test-Path $wv) -and -not (Test-Path 'HKCU:\Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}')) {
    Say 'The WebView2 Runtime looks missing. Get the "Evergreen Bootstrapper" from Microsoft (developer.microsoft.com/microsoft-edge/webview2) and run it, then install Meowzer again.'
}

if (Get-Process Meowzer -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "$dest*" }) { Say 'Close Meowzer first, then run this again.'; exit 1 }
Say "Installing into $dest"
New-Item -ItemType Directory -Force $dest | Out-Null
Copy-Item -Recurse -Force (Join-Path $src '*') $dest
Copy-Item -Force $PSCommandPath (Join-Path $dest 'install.ps1')

$sh = New-Object -ComObject WScript.Shell
function Link($path) { $l = $sh.CreateShortcut($path); $l.TargetPath = Join-Path $dest 'Meowzer.exe'; $l.WorkingDirectory = $dest; $l.Description = 'Meowzer 4'; $l.Save() }
Link $menu
if (-not $Desktop -and -not $Quiet) { $a = Read-Host 'Put Meowzer on the desktop too? [y/N]'; $Desktop = $a -match '^[yY]' }
if ($Desktop) { Link $desk }

# so it shows in Settings ▸ Apps, with Uninstall
$k = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Meowzer4'
New-Item -Force $k | Out-Null
$ver = (Get-Item (Join-Path $dest 'Meowzer.exe')).VersionInfo.ProductVersion; if (-not $ver) { $ver = '4.0' }
@{ DisplayName = 'Meowzer 4'; DisplayVersion = $ver; Publisher = 'Meowzer'; DisplayIcon = (Join-Path $dest 'Meowzer.exe'); InstallLocation = $dest; NoModify = 1; NoRepair = 1
   UninstallString = "powershell -NoProfile -ExecutionPolicy Bypass -File `"$dest\install.ps1`" -Uninstall" }.GetEnumerator() | ForEach-Object {
    New-ItemProperty -Force -Path $k -Name $_.Key -Value $_.Value -PropertyType ($(if ($_.Value -is [int]) { 'DWord' } else { 'String' })) | Out-Null }

Say 'Done. Meowzer is in your Start menu.'
if (-not $Quiet) { $a = Read-Host 'Open it now? [Y/n]'; if ($a -notmatch '^[nN]') { Start-Process (Join-Path $dest 'Meowzer.exe') } }
