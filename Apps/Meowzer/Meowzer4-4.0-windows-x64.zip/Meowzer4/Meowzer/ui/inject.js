// inject.js — runs in every page and frame before the page's own scripts (WebView2 AddScriptToExecuteOnDocumentCreated,
// WKUserScript at document start, WebKitGTK user scripts, the GeckoView content script). The host fills the
// placeholder on the const D line with JSON:
//   { def: persona|null, pool: [persona…]|null, sites: { "site": { persona, game } }, css: { "*": "sel,…", "<hash>": "…" } }
// It does three things: puts on the site's costume, hides elements the cosmetic rules name, and tells the host when
// a page looks like a game (so the toolbars get out of the way).
(function () {
  'use strict';
  const D = __MEOW_DATA__;
  const SFX = new Set(['co.uk', 'org.uk', 'ac.uk', 'gov.uk', 'co.jp', 'ne.jp', 'or.jp', 'com.au', 'net.au', 'org.au', 'co.nz',
    'com.br', 'com.mx', 'co.in', 'co.za', 'com.tr', 'com.cn', 'com.tw', 'co.kr', 'github.io', 'blogspot.com', 'herokuapp.com',
    'vercel.app', 'netlify.app', 'pages.dev']);
  function siteOf(h) { // the same rule as meowcore's `site`
    const p = h.toLowerCase().replace(/^\.+/, '').split('.');
    if (p.length < 3) return p.join('.');
    if (SFX.has(p.slice(-2).join('.'))) return p.slice(-3).join('.');
    return p.slice(-2).join('.');
  }
  const enc = (s) => new TextEncoder().encode(String(s).toLowerCase());
  function fnv(s) {
    let h = 0xcbf29ce484222325n;
    for (const b of enc(s)) h = ((h ^ BigInt(b)) * 0x100000001b3n) & 0xffffffffffffffffn;
    return h.toString(16).padStart(16, '0');
  }
  function fnv32(s) { let h = 0x811c9dc5; for (const b of enc(s)) h = Math.imul(h ^ b, 16777619) >>> 0; return h; }
  let host = '';
  try { host = location.hostname || ''; } catch (e) {}
  const site = host ? siteOf(host) : '';
  const conf = (D.sites && D.sites[site]) || {};
  const P = conf.persona || (D.pool && D.pool.length ? D.pool[fnv32(site) % D.pool.length] : D.def);

  // the host's message port; pages never get to see it (chrome.webview would tell them they run inside WebView2)
  let post = null, onHost = null;
  try {
    if (window.chrome && chrome.webview) {
      const wv = chrome.webview; post = (m) => wv.postMessage(m);
      wv.addEventListener('message', (e) => { try { onHost && onHost(e.data); } catch (x) {} });
      if (location.origin !== 'https://meowzer.ui')   // Meowzer's own new-tab page keeps it (it saves the search engine)
        Object.defineProperty(window.chrome, 'webview', { get: () => undefined, configurable: true });
    } else if (window.webkit && webkit.messageHandlers && webkit.messageHandlers.meow) {
      const mh = webkit.messageHandlers.meow; post = (m) => mh.postMessage(m);
    } else if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.sendMessage) {
      // GeckoView (Android): this runs as the built-in extension's content script, out of the page's reach;
      // the extension's background passes messages to and from the app over its native port
      post = (m) => browser.runtime.sendMessage(m);
      browser.runtime.onMessage.addListener((m) => { try { onHost && onHost(m); } catch (x) {} });
    }
    // WebKit hosts answer by dispatching an event under a name only this script and the host know
    if (D.key) document.addEventListener(D.key, (e) => { try { onHost && onHost(e.detail); } catch (x) {} });
  } catch (e) {}
  const send = (m) => { try { post && post(m); } catch (e) {} };

  // ------------------------------------------------------------------ cosmetic rules
  try {
    const css = [D.css && D.css['*'], D.css && D.css[fnv(site)]].filter(Boolean).join(',');
    if (css) {
      const st = document.createElement('style');
      st.textContent = css + '{display:none!important}';
      const put = () => (document.head || document.documentElement).appendChild(st);
      // at document creation there may be no root element yet; wait for one
      if (document.documentElement) put();
      else new MutationObserver((m, o) => { if (document.documentElement) { o.disconnect(); put(); } }).observe(document, { childList: true });
    }
  } catch (e) {}

  // ------------------------------------------------------------------ games: tell the host
  if (window.top === window) {
    let game = !!conf.game, said = null;
    const check = () => {
      let on = game || !!document.fullscreenElement || !!document.pointerLockElement;
      if (!on) {
        const vw = innerWidth * innerHeight;
        for (const c of document.querySelectorAll('canvas')) {
          const r = c.getBoundingClientRect();
          if (r.width * r.height > vw * 0.45) { on = true; break; }
        }
      }
      if (on !== said) { said = on; send({ meow: 'game', on }); }
    };
    addEventListener('load', check);
    document.addEventListener('fullscreenchange', check);
    document.addEventListener('pointerlockchange', check);
    setInterval(check, 3000);
    let lastY = 0;
    addEventListener('scroll', () => { const y = scrollY; if (Math.abs(y - lastY) > 24) { send({ meow: 'scroll', down: y > lastY, y }); lastY = y; } }, { passive: true });
  }

  // ------------------------------------------------------------------ the vault: fill logins, offer to save them
  // Top pages only, over the host port only. A page learns nothing until it shows a password box; then it gets the
  // names saved for it (when autofill is on), and a password only at the moment one is filled in. The paw button
  // lives in a closed shadow root, so the page's scripts and styles can't reach into it.
  if (window.top === window && /^https?:$/.test(location.protocol)) {
    let logins = null, mode = 'ask', asked = false, lastCap = '', paw = null, pawBtn = null, menu = null, target = null;
    const visible = (el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden'; };
    const pwFields = () => Array.from(document.querySelectorAll('input[type=password]')).filter(visible);
    const userFieldFor = (pw) => {   // the text or e-mail box just before the password box, in its form or the page
      const scope = pw.form || document; let best = null;
      for (const i of scope.querySelectorAll('input')) {
        if (i === pw) break;
        if (/^(text|email|tel|)$/i.test(i.getAttribute('type') || '') && visible(i)) best = i;
      }
      return best || document.querySelector('input[autocomplete~=username],input[type=email]');
    };
    const setVal = (el, v) => {
      if (!el) return; el.focus();
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(el, v);   // what frameworks listen to
      el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true }));
    };
    const fill = (user, pass) => {
      const pw = pwFields()[0], u = pw ? userFieldFor(pw) : document.querySelector('input[autocomplete~=username],input[type=email]');
      if (u && user) setVal(u, user);
      if (pw && pass) setVal(pw, pass);
      if (menu) menu.hidden = true;
    };
    const place = () => {
      if (!paw || !target || !target.isConnected || !visible(target)) { if (paw) paw.style.display = 'none'; return; }
      const r = target.getBoundingClientRect(), s = Math.min(22, r.height - 4);
      paw.style.cssText = 'all:initial;position:fixed;z-index:2147483647;left:' + (r.right - s - 6) + 'px;top:' + (r.top + (r.height - s) / 2) + 'px;width:' + s + 'px;height:' + s + 'px;display:block';
    };
    const showPaw = () => {
      if (!logins || !logins.length || mode === 'off') return;
      const pw = pwFields()[0]; if (!pw) return;
      target = userFieldFor(pw) || pw;
      if (!paw) {
        paw = document.createElement('meowzer-paw');
        const root = paw.attachShadow({ mode: 'closed' });
        root.innerHTML = '<style>button{all:initial;cursor:pointer;width:100%;height:100%;display:grid;place-items:center;border-radius:6px;font:14px system-ui;background:#ff8c42;box-shadow:0 1px 4px #0006}' +
          'button:hover{filter:brightness(1.1)}.m{all:initial;position:fixed;min-width:200px;background:#111b18;color:#e8f1ee;border:1px solid #2a3c36;border-radius:10px;box-shadow:0 10px 30px #0008;padding:4px;font:13px system-ui}' +
          '.m b{display:block;font-size:10px;letter-spacing:1px;text-transform:uppercase;color:#8aa39b;padding:6px 8px 4px}.m div{padding:7px 10px;border-radius:6px;cursor:pointer}.m div:hover{background:#1a2824}.m i{color:#8aa39b;font-style:normal;font-size:11px}</style>' +
          '<button title="Meowzer: fill a saved login">🐾</button><div class="m" hidden></div>';
        pawBtn = root.querySelector('button'); menu = root.querySelector('.m');
        pawBtn.addEventListener('click', (e) => {
          e.preventDefault(); e.stopPropagation();
          if (!menu.hidden) { menu.hidden = true; return; }
          const r = paw.getBoundingClientRect();
          menu.innerHTML = '<b>🐾 Saved for this site</b>' + logins.map((l) => '<div data-id="' + l.id + '"></div>').join('');
          menu.querySelectorAll('div').forEach((d, i) => { const l = logins[i]; d.textContent = l.user || '(no user name)';
            if (!l.exact) { const o = document.createElement('i'); o.textContent = ' · ' + l.origin.replace(/^https?:\/\//, ''); d.appendChild(o); } });
          menu.style.left = Math.max(4, r.right - 220) + 'px'; menu.style.top = (r.bottom + 6) + 'px'; menu.hidden = false;
        });
        menu.addEventListener('click', (e) => { const d = e.target.closest('div[data-id]'); if (d) { send({ meow: 'vault', op: 'fill', id: d.dataset.id }); menu.hidden = true; } });
        document.documentElement.appendChild(paw);
        addEventListener('scroll', place, true); addEventListener('resize', place);
        document.addEventListener('click', (e) => { if (menu && !menu.hidden && e.target !== paw) menu.hidden = true; });
      }
      place();
    };
    onHost = (m) => {
      if (!m || m.meow !== 'vault') return;
      if (m.logins) { logins = m.logins; mode = m.mode;
        if (m.auto) { fill(m.auto.user, m.auto.pass); send({ meow: 'vault', op: 'filled', id: m.auto.id }); }
        if (mode !== 'off') showPaw(); }
      if (m.fill) fill(m.fill.user, m.fill.pass);
    };
    // what was typed, when the form goes: the host asks the face whether to keep it
    const capture = (form) => {
      const pool = form && form.querySelectorAll ? Array.from(form.querySelectorAll('input[type=password]')) : pwFields();
      const pw = pool.find((p) => p.value); if (!pw) return;
      const u = userFieldFor(pw), user = u ? u.value : '', key = user + '\n' + pw.value;
      if (key === lastCap) return; lastCap = key;
      send({ meow: 'vault', op: 'capture', user, pass: pw.value });
    };
    document.addEventListener('submit', (e) => capture(e.target), true);
    document.addEventListener('click', (e) => {
      const b = e.target && e.target.closest && e.target.closest('button,input[type=submit],input[type=button],[role=button]'); if (!b) return;
      const f = b.form || b.closest('form');
      if ((f && f.querySelector('input[type=password]')) || (!f && pwFields().some((p) => p.value))) setTimeout(() => capture(f), 0);
    }, true);
    document.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target && e.target.type === 'password') capture(e.target.form || null); }, true);
    // ask once a password box appears (now, or later on pages that draw their forms with scripts)
    const look = () => { if (!document.documentElement) return; if (!asked && pwFields().length) { asked = true; send({ meow: 'vault', op: 'logins' }); } else if (paw) place(); };
    addEventListener('DOMContentLoaded', look); addEventListener('load', look); setInterval(look, 1500);
  }

  if (!P || !P.hardware) return;

  // ------------------------------------------------------------------ the costume
  // Getters are defined on the prototypes, where the real ones live, and each fake function reports itself as
  // native code, so neither `Object.getOwnPropertyNames(navigator)` nor `fn.toString()` gives the costume away.
  const natives = new WeakSet();
  const FTS = Function.prototype.toString;
  const nat = (f, name) => { natives.add(f); if (name) try { Object.defineProperty(f, 'name', { value: name }); } catch (e) {} return f; };
  Function.prototype.toString = nat(function toString() { return natives.has(this) ? 'function ' + (this.name || '') + '() { [native code] }' : FTS.call(this); });
  const def = (o, k, v) => { if (!o) return; try { const g = nat(typeof v === 'function' ? v : () => v, 'get ' + k); Object.defineProperty(o, k, { get: g, configurable: true, enumerable: true }); } catch (e) {} };
  const wrap = (o, k, f) => { if (!o || typeof o[k] !== 'function') return; const orig = o[k]; try { o[k] = nat(f(orig), k); } catch (e) {} };
  const hide = (o, k) => { try { if (o && k in o) delete o[k]; } catch (e) {} };
  const N = Navigator.prototype, S = Screen.prototype;
  const hw = P.hardware, sw = P.software || {}, fw = P.firmware || {}, net = P.internet || {}, tr = P.traces || { canvas: 1, audio: true, rects: true, webgl: true }, perm = P.permissions || {};
  const safari = P.fam === 4;
  const langs = (sw.languages && sw.languages.length ? sw.languages : ['en-US', 'en']).slice();
  const seed0 = (P.noise >>> 0) ^ fnv32(site);        // noise differs per persona and per site, but not between two reads
  const h32 = (a, b) => { let x = Math.imul(a ^ 0x9e3779b9, 0x85ebca6b) ^ b; x = Math.imul(x ^ x >>> 13, 0xc2b2ae35); return (x ^ x >>> 16) >>> 0; };

  // software
  def(N, 'userAgent', P.ua);
  def(N, 'appVersion', P.ua.replace(/^Mozilla\//, ''));
  def(N, 'platform', sw.platform);
  def(N, 'language', langs[0]);
  const frozenLangs = Object.freeze(langs.slice());
  def(N, 'languages', frozenLangs);
  def(N, 'doNotTrack', sw.doNotTrack ? '1' : null);
  def(N, 'globalPrivacyControl', sw.gpc !== false);
  def(N, 'webdriver', false);
  def(N, 'vendor', sw.vendor || (safari ? 'Apple Computer, Inc.' : 'Google Inc.'));
  def(N, 'cookieEnabled', sw.cookieEnabled !== false);
  def(N, 'pdfViewerEnabled', !!sw.pdfViewer);
  if (!sw.pdfViewer) {
    const empty = (proto) => { const o = Object.create(proto); Object.defineProperty(o, 'length', { value: 0 }); o.item = nat(() => null, 'item'); o.namedItem = nat(() => null, 'namedItem'); o[Symbol.iterator] = function* () {}; return o; };
    if (window.PluginArray) { const pa = empty(PluginArray.prototype); pa.refresh = nat(() => {}, 'refresh'); def(N, 'plugins', pa); }
    if (window.MimeTypeArray) def(N, 'mimeTypes', empty(MimeTypeArray.prototype));
  }
  // hardware
  def(N, 'hardwareConcurrency', hw.cores);
  def(N, 'maxTouchPoints', hw.touch);
  // the screen must hold the window: a window wider than the claimed screen would give the costume away
  const FITS = [[1920, 1080], [2560, 1440], [3440, 1440], [3840, 2160], [5120, 2880]];
  const scr = () => {
    let [w, h] = hw.screen, [aw, ah] = hw.avail || [w, h - 40];
    const ow = Math.max(outerWidth, innerWidth), oh = Math.max(outerHeight, innerHeight);
    if (!fw.mobile && (ow > w || oh > h)) { const f = FITS.find(([a, b]) => a >= ow && b >= oh) || [ow, oh]; aw += f[0] - w; ah += f[1] - h; [w, h] = f; }
    return { w, h, aw, ah };
  };
  def(S, 'width', () => scr().w); def(S, 'height', () => scr().h);
  def(S, 'availWidth', () => scr().aw); def(S, 'availHeight', () => scr().ah);
  def(S, 'availLeft', 0); def(S, 'availTop', 0);
  def(S, 'colorDepth', hw.colorDepth || 24); def(S, 'pixelDepth', hw.colorDepth || 24);
  def(window, 'devicePixelRatio', hw.dpr);
  if (window.ScreenOrientation) {
    const port = /portrait/.test(hw.orientation || '');
    def(ScreenOrientation.prototype, 'type', hw.orientation || 'landscape-primary');
    def(ScreenOrientation.prototype, 'angle', port || !fw.mobile ? 0 : 90);
  }
  if (safari) {   // Safari has none of these; a "Safari" that has them is not Safari
    for (const k of ['deviceMemory', 'connection', 'getBattery', 'userAgentData', 'bluetooth', 'usb', 'hid', 'serial', 'keyboard', 'scheduling', 'ink'])
      { hide(N, k); hide(navigator, k); }
    try { Object.defineProperty(window, 'chrome', { get: () => undefined, configurable: true }); } catch (e) {}
  } else {
    def(N, 'deviceMemory', hw.memory);
    if ('getBattery' in N) {
      const level = hw.hasBattery === false ? 1 : hw.battery, charging = hw.hasBattery === false ? true : hw.charging;
      wrap(N, 'getBattery', () => function getBattery() {
        const b = Object.assign(new EventTarget(), { charging, level, chargingTime: hw.hasBattery === false ? 0 : charging ? 3600 : Infinity,
          dischargingTime: charging ? Infinity : 14400, onchargingchange: null, onlevelchange: null, onchargingtimechange: null, ondischargingtimechange: null });
        return Promise.resolve(b);
      });
    }
    // firmware: User-Agent Client Hints
    if ('userAgentData' in N) {
      const brands = [{ brand: 'Chromium', version: '142' }, { brand: 'Google Chrome', version: '142' }, { brand: 'Not_A Brand', version: '99' }];
      const full = fw.uaFullVersion || '142.0.0.0';
      const low = { brands, mobile: !!fw.mobile, platform: fw.platform };
      const uad = Object.create(NavigatorUAData.prototype);
      def(uad, 'brands', brands); def(uad, 'mobile', !!fw.mobile); def(uad, 'platform', fw.platform);
      uad.getHighEntropyValues = nat((hints) => Promise.resolve(Object.assign({}, low, {
        architecture: fw.architecture, bitness: fw.bitness, model: fw.model || '', platformVersion: fw.platformVersion, uaFullVersion: full,
        fullVersionList: brands.map(b => ({ brand: b.brand, version: b.brand === 'Not_A Brand' ? '99.0.0.0' : full })),
        wow64: !!fw.wow64, formFactors: [fw.formFactor || (fw.mobile ? 'Mobile' : 'Desktop')] })), 'getHighEntropyValues');
      uad.toJSON = nat(() => low, 'toJSON');
      def(N, 'userAgentData', uad);
    }
    // internet
    if ('connection' in N) {
      const conn = Object.assign(new EventTarget(), { type: net.type, effectiveType: net.effectiveType, rtt: net.rtt,
        downlink: net.downlink, saveData: !!net.saveData, downlinkMax: Infinity, onchange: null });
      def(N, 'connection', conn);
    }
    if (sw.keyboard !== 'real' && N.keyboard) def(N, 'keyboard', undefined);   // the layout map tells a German keyboard from a US one
  }
  // WebRTC: the local network addresses
  if (net.webrtc !== 'real' && window.RTCPeerConnection) {
    const RPC = window.RTCPeerConnection;
    if (net.webrtc === 'block') {
      window.RTCPeerConnection = nat(function RTCPeerConnection() { throw new DOMException('WebRTC is turned off', 'NotAllowedError'); }, 'RTCPeerConnection');
      window.RTCPeerConnection.prototype = RPC.prototype;
    } else {
      const local = (c) => c && c.candidate && / typ host /.test(c.candidate);
      window.RTCPeerConnection = nat(function RTCPeerConnection(cfg, ...r) {
        const pc = new RPC(cfg, ...r);
        const add = pc.addEventListener.bind(pc);
        pc.addEventListener = nat((t, f, o) => add(t, t === 'icecandidate' && typeof f === 'function' ? (e) => { if (!local(e.candidate)) f.call(pc, e); } : f, o), 'addEventListener');
        let h = null;
        Object.defineProperty(pc, 'onicecandidate', { get: () => h, set(f) { h = f; }, configurable: true });
        add('icecandidate', (e) => { if (h && !local(e.candidate)) h.call(pc, e); });
        const lsd = Object.getOwnPropertyDescriptor(RPC.prototype, 'localDescription');
        if (lsd) Object.defineProperty(pc, 'localDescription', { get: () => { const d = lsd.get.call(pc); return d && d.sdp ? new RTCSessionDescription({ type: d.type, sdp: d.sdp.split('\r\n').filter(l => !/^a=candidate:.* typ host /.test(l)).join('\r\n') }) : d; }, configurable: true });
        return pc;
      }, 'RTCPeerConnection');
      window.RTCPeerConnection.prototype = RPC.prototype;
      Object.setPrototypeOf(window.RTCPeerConnection, RPC);
    }
  }

  // ------------------------------------------------------------------ the clock and the locale
  try {
    const tz = sw.timezone, L0 = langs[0];
    const DTF = Intl.DateTimeFormat;
    const RO = DTF.prototype.resolvedOptions;
    DTF.prototype.resolvedOptions = nat(function resolvedOptions() { const o = RO.call(this); if (!this.__meowTz) o.timeZone = tz; return o; }, 'resolvedOptions');
    const DTFw = nat(function DateTimeFormat(l, o) {
      const x = new DTF(l || L0, Object.assign({ timeZone: tz }, o));
      if (o && o.timeZone) try { Object.defineProperty(x, '__meowTz', { value: 1 }); } catch (e) {}
      return x;
    }, 'DateTimeFormat');
    DTFw.prototype = DTF.prototype; DTFw.supportedLocalesOf = DTF.supportedLocalesOf;
    Intl.DateTimeFormat = DTFw;
    for (const k of ['NumberFormat', 'Collator', 'PluralRules', 'RelativeTimeFormat', 'ListFormat', 'DisplayNames', 'Segmenter']) {
      const C = Intl[k]; if (!C) continue;
      const W = nat(function (l, o) { return new C(l || L0, o); }, k); W.prototype = C.prototype; W.supportedLocalesOf = C.supportedLocalesOf; Intl[k] = W;
    }
    const parts = new DTF('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' });
    const names = new DTF('en-US', { timeZone: tz, timeZoneName: 'long' });
    const GT = Date.prototype.getTime;
    const offC = new Map();
    const offAt = (t) => {   // the zone's offset, worked out once per hour (clocks change on the hour)
      const k = Math.floor(t / 36e5); let o = offC.get(k);
      if (o === undefined) {
        const p = {}; for (const x of parts.formatToParts(k * 36e5)) p[x.type] = x.value;
        o = Math.round((k * 36e5 - Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour % 24, +p.minute, +p.second)) / 60000);
        if (offC.size > 4000) offC.clear(); offC.set(k, o);
      }
      return o;
    };
    const local = (d) => { const t = GT.call(d), off = offAt(t); return { wall: t - off * 60000, off }; };   // the wall clock in the costume's zone
    const DP = Date.prototype, UTC = (k) => DP['getUTC' + k];
    DP.getTimezoneOffset = nat(function getTimezoneOffset() { return isNaN(GT.call(this)) ? NaN : local(this).off; }, 'getTimezoneOffset');
    for (const k of ['FullYear', 'Month', 'Date', 'Day', 'Hours', 'Minutes', 'Seconds', 'Milliseconds']) {
      const u = UTC(k);
      DP['get' + k] = nat(function () { const t = GT.call(this); return isNaN(t) ? NaN : u.call(new Date(local(this).wall)); }, 'get' + k);
    }
    const pad = (n, w = 2) => String(Math.abs(n)).padStart(w, '0');
    const WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], MO = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const zone = (d, off) => 'GMT' + (off <= 0 ? '+' : '-') + pad(Math.floor(Math.abs(off) / 60)) + pad(Math.abs(off) % 60) + ' (' + ((names.formatToParts(GT.call(d)).find(x => x.type === 'timeZoneName') || {}).value || tz) + ')';
    const ds = (w) => WD[w.getUTCDay()] + ' ' + MO[w.getUTCMonth()] + ' ' + pad(w.getUTCDate()) + ' ' + (w.getUTCFullYear() < 0 ? '-' + pad(-w.getUTCFullYear(), 6) : pad(w.getUTCFullYear(), 4));
    const ts = (w) => pad(w.getUTCHours()) + ':' + pad(w.getUTCMinutes()) + ':' + pad(w.getUTCSeconds());
    const TS = DP.toString;
    DP.toString = nat(function toString() { if (isNaN(GT.call(this))) return TS.call(this); const l = local(this), w = new Date(l.wall); return ds(w) + ' ' + ts(w) + ' ' + zone(this, l.off); }, 'toString');
    DP.toDateString = nat(function toDateString() { if (isNaN(GT.call(this))) return TS.call(this); return ds(new Date(local(this).wall)); }, 'toDateString');
    DP.toTimeString = nat(function toTimeString() { if (isNaN(GT.call(this))) return TS.call(this); const l = local(this); return ts(new Date(l.wall)) + ' ' + zone(this, l.off); }, 'toTimeString');
    for (const k of ['toLocaleString', 'toLocaleDateString', 'toLocaleTimeString']) {
      const o = DP[k]; DP[k] = nat(function (l, opt) { return o.call(this, l || L0, Object.assign({ timeZone: tz }, opt)); }, k);
    }
    const NL = Number.prototype.toLocaleString; Number.prototype.toLocaleString = nat(function toLocaleString(l, o) { return NL.call(this, l || L0, o); }, 'toLocaleString');
  } catch (e) {}

  // ------------------------------------------------------------------ media queries the page can ask from script
  if (window.matchMedia) {
    const MM = window.matchMedia;
    const [sw0, sh0] = hw.screen, dpr = hw.dpr, coarse = !!fw.mobile;
    const px = (v) => parseFloat(v) * (/em$/.test(v) ? 16 : 1);
    const ans = {
      'prefers-color-scheme': (v) => v === (sw.scheme || 'light'),
      'prefers-reduced-motion': (v) => v === (sw.motion || 'no-preference'),
      'prefers-contrast': (v) => v === (sw.contrast || 'no-preference'),
      'pointer': (v) => v === (coarse ? 'coarse' : 'fine'), 'any-pointer': (v) => v === (coarse ? 'coarse' : 'fine'),
      'hover': (v) => v === (coarse ? 'none' : 'hover'), 'any-hover': (v) => v === (coarse ? 'none' : 'hover'),
      'device-width': (v) => scr().w === px(v), 'min-device-width': (v) => scr().w >= px(v), 'max-device-width': (v) => scr().w <= px(v),
      'device-height': (v) => scr().h === px(v), 'min-device-height': (v) => scr().h >= px(v), 'max-device-height': (v) => scr().h <= px(v),
      '-webkit-device-pixel-ratio': (v) => dpr === +v, '-webkit-min-device-pixel-ratio': (v) => dpr >= +v, '-webkit-max-device-pixel-ratio': (v) => dpr <= +v,
      'resolution': (v) => dpr === parseFloat(v), 'min-resolution': (v) => dpr >= parseFloat(v) / (/dpi$/.test(v) ? 96 : 1), 'max-resolution': (v) => dpr <= parseFloat(v) / (/dpi$/.test(v) ? 96 : 1),
      'color-gamut': (v) => v === 'srgb' || (v === 'p3' && (hw.colorDepth || 24) >= 30),
    };
    window.matchMedia = nat(function matchMedia(q) {
      const src = String(q);
      const fixed = src.replace(/\(\s*([a-z-]+)\s*:\s*([^)]+?)\s*\)/gi, (m, k, v) => { const f = ans[k.toLowerCase()]; return f ? (f(v.trim().toLowerCase()) ? '(min-width: 0px)' : '(min-width: 999999px)') : m; });
      const mql = MM.call(window, fixed);
      if (fixed !== src) try { Object.defineProperty(mql, 'media', { value: src }); } catch (e) {}
      return mql;
    }, 'matchMedia');
  }

  // ------------------------------------------------------------------ fonts
  try {
    const have = new Set((sw.fonts || []).map(f => f.toLowerCase()));
    const generic = /^(serif|sans-serif|monospace|cursive|fantasy|system-ui|ui-[a-z-]+|emoji|math|fangsong|inherit|initial)$/;
    const FS = window.FontFaceSet && FontFaceSet.prototype;
    if (FS && have.size) {
      const chk = FS.check, own = () => new Set([...document.fonts].map(f => f.family.replace(/["']/g, '').toLowerCase()));
      FS.check = nat(function check(font, text) {
        const fam = String(font).replace(/^.*?\d+(\.\d+)?(px|pt|em|rem|%)(\s*\/\s*\S+)?\s+/, '').split(',').map(s => s.trim().replace(/["']/g, '').toLowerCase());
        const web = own();
        if (fam.every(f => generic.test(f) || have.has(f) || web.has(f))) return chk.call(this, font, text);
        return fam.some(f => web.has(f)) ? chk.call(this, font, text) : false;
      }, 'check');
    }
    if (window.queryLocalFonts) window.queryLocalFonts = nat(function queryLocalFonts() { return Promise.reject(new DOMException('Permission denied', 'NotAllowedError')); }, 'queryLocalFonts');
  } catch (e) {}

  // ------------------------------------------------------------------ devices, storage, place, permissions, voices
  const MD = window.MediaDevices && MediaDevices.prototype;
  if (MD && MD.enumerateDevices) {
    const ed = MD.enumerateDevices;
    MD.enumerateDevices = nat(function enumerateDevices() {
      return ed.call(this).then(real => {
        if (real.some(d => d.label)) return real;      // the page was allowed in: give it the real devices, or calls break
        const out = [], mk = (kind, n) => { if (n > 0) out.push(Object.freeze(Object.setPrototypeOf({ deviceId: '', kind, label: '', groupId: '', toJSON() { return { deviceId: '', kind, label: '', groupId: '' }; } },
          (kind === 'audiooutput' ? MediaDeviceInfo : (window.InputDeviceInfo || MediaDeviceInfo)).prototype))); };
        mk('audioinput', hw.mics); mk('videoinput', hw.cams); mk('audiooutput', hw.speakers);
        return out;
      });
    }, 'enumerateDevices');
  }
  if (window.StorageManager && StorageManager.prototype.estimate && hw.quotaGB) {
    const es = StorageManager.prototype.estimate;
    StorageManager.prototype.estimate = nat(function estimate() {
      return es.call(this).then(r => Object.assign({}, r, { quota: Math.round(hw.quotaGB * 1e9 * 0.6 / 1048576) * 1048576 }));
    }, 'estimate');
  }
  const geo = net.geo || { mode: 'deny' };
  if (window.Geolocation && geo.mode !== 'real') {
    const G = Geolocation.prototype; let watch = 1;
    const fail = (err) => err && setTimeout(() => err({ code: 1, message: 'User denied Geolocation', PERMISSION_DENIED: 1, POSITION_UNAVAILABLE: 2, TIMEOUT: 3 }), 120);
    const pos = () => ({ coords: { latitude: geo.lat, longitude: geo.lon, accuracy: geo.accuracy || 35, altitude: null, altitudeAccuracy: null, heading: null, speed: null,
      toJSON() { return this; } }, timestamp: Date.now(), toJSON() { return this; } });
    G.getCurrentPosition = nat(function getCurrentPosition(ok, err) { if (geo.mode === 'fake') setTimeout(() => ok(pos()), 300); else fail(err); }, 'getCurrentPosition');
    G.watchPosition = nat(function watchPosition(ok, err) { if (geo.mode === 'fake') setTimeout(() => ok(pos()), 300); else fail(err); return watch++; }, 'watchPosition');
    G.clearWatch = nat(function clearWatch() {}, 'clearWatch');
  }
  if (window.Permissions && Permissions.prototype.query) {
    const pq = Permissions.prototype.query;
    const fixed = Object.assign({}, perm, { geolocation: geo.mode === 'deny' ? 'denied' : geo.mode === 'fake' ? 'granted' : perm.geolocation });
    Permissions.prototype.query = nat(function query(d) {
      const name = d && d.name;
      if (name && fixed[name] && fixed[name] !== 'real') return pq.call(this, d).then(st => { try { Object.defineProperty(st, 'state', { value: fixed[name] }); } catch (e) {} return st; }, () => ({ state: fixed[name], name, onchange: null }));
      return pq.call(this, d);
    }, 'query');
    if (window.Notification && perm.notifications && perm.notifications !== 'real') { const map = { prompt: 'default', denied: 'denied', granted: 'granted' }; def(Notification, 'permission', map[perm.notifications] || 'default'); }
  }
  if (window.speechSynthesis && sw.voices !== 'real') {
    try { const SS = Object.getPrototypeOf(speechSynthesis); SS.getVoices = nat(function getVoices() { return []; }, 'getVoices'); } catch (e) {}
  }

  // ------------------------------------------------------------------ graphics: the card, and faint per-persona noise
  const glp = (proto) => {
    if (!proto) return;
    const gp = proto.getParameter, tex = hw.glMaxTexture || 16384;
    proto.getParameter = nat(function getParameter(p) {
      if (p === 0x9245) return hw.gpuVendor;   // UNMASKED_VENDOR_WEBGL
      if (p === 0x9246) return hw.gpu;         // UNMASKED_RENDERER_WEBGL
      if (p === 0x0D33 || p === 0x84E8) return tex;                     // MAX_TEXTURE_SIZE, MAX_RENDERBUFFER_SIZE
      if (p === 0x851C) return tex;                                     // MAX_CUBE_MAP_TEXTURE_SIZE
      if (p === 0x0D3A) return new Int32Array([tex * 2, tex * 2]);      // MAX_VIEWPORT_DIMS
      return gp.call(this, p);
    }, 'getParameter');
    if (tr.webgl !== false && tr.canvas) {
      const rp = proto.readPixels;
      proto.readPixels = nat(function readPixels(...a) { rp.apply(this, a); const px = a[6]; if (px && px.length) noisy(px, 4); }, 'readPixels');
    }
  };
  // canvas: flip the lowest bit of some pixels. Which pixels, and which way, depends only on the persona, the site,
  // the position and the colour, so reading the same picture twice gives the same (wrong) answer, like a real machine.
  const step = tr.canvas === 2 ? 7 : 97;
  function noisy(data, stride) {
    for (let i = 0; i < data.length; i += stride * step) { const v = data[i]; data[i] = v ^ (h32(seed0, (i << 8) ^ v) & 1); }
  }
  glp(window.WebGLRenderingContext && WebGLRenderingContext.prototype);
  glp(window.WebGL2RenderingContext && WebGL2RenderingContext.prototype);
  const C2 = window.CanvasRenderingContext2D && CanvasRenderingContext2D.prototype;
  if (C2 && tr.canvas) {
    const gid = C2.getImageData, pid = C2.putImageData;
    C2.getImageData = nat(function getImageData(...a) { const d = gid.apply(this, a); noisy(d.data, 4); return d; }, 'getImageData');
    const copy = (cv) => {   // a noised copy of the canvas, for the ways it can be read out whole
      try {
        const w = cv.width, h = cv.height; if (!w || !h || w * h > 16e6) return null;
        const c = document.createElement('canvas'); c.width = w; c.height = h;
        const x = c.getContext('2d'); x.drawImage(cv, 0, 0); const d = gid.call(x, 0, 0, w, h); noisy(d.data, 4); pid.call(x, d, 0, 0); return c;
      } catch (e) { return null; }
    };
    const HC = HTMLCanvasElement.prototype, tdu = HC.toDataURL, tb = HC.toBlob;
    HC.toDataURL = nat(function toDataURL(...a) { return tdu.apply(copy(this) || this, a); }, 'toDataURL');
    HC.toBlob = nat(function toBlob(...a) { return tb.apply(copy(this) || this, a); }, 'toBlob');
    if (tr.rects) {
      const mt = C2.measureText;
      C2.measureText = nat(function measureText(t) {
        const m = mt.call(this, t), w = m.width, j = ((h32(seed0, Math.round(w * 100)) % 200) - 100) * 1e-5;
        try { Object.defineProperty(m, 'width', { value: w + j }); } catch (e) {} return m;
      }, 'measureText');
    }
  }
  if (tr.rects && window.Element) {   // element sizes, to the millionth of a pixel: a font fingerprint's other half
    const jit = (v) => v + ((h32(seed0, Math.round(v * 64)) % 64) - 32) * 1e-6;
    const fix = (r) => new DOMRect(jit(r.x), jit(r.y), jit(r.width), jit(r.height));
    const E = Element.prototype, gbr = E.getBoundingClientRect, gcr = E.getClientRects;
    E.getBoundingClientRect = nat(function getBoundingClientRect() { return fix(gbr.call(this)); }, 'getBoundingClientRect');
    E.getClientRects = nat(function getClientRects() { const l = [...gcr.call(this)].map(fix); l.item = (i) => l[i] || null; return l; }, 'getClientRects');
  }
  if (tr.audio !== false) {
    if (window.AnalyserNode) {
      const A = AnalyserNode.prototype, gf = A.getFloatFrequencyData, gb = A.getByteFrequencyData;
      A.getFloatFrequencyData = nat(function getFloatFrequencyData(arr) { gf.call(this, arr); for (let i = 0; i < arr.length; i += 13) arr[i] += ((h32(seed0, i) % 1000) - 500) * 2e-7; }, 'getFloatFrequencyData');
      if (gb) A.getByteFrequencyData = nat(function getByteFrequencyData(arr) { gb.call(this, arr); for (let i = 0; i < arr.length; i += 97) if (arr[i] > 0 && arr[i] < 255) arr[i] ^= h32(seed0, i) & 1; }, 'getByteFrequencyData');
    }
    if (window.AudioBuffer) {
      const gc = AudioBuffer.prototype.getChannelData, done = new WeakSet();
      AudioBuffer.prototype.getChannelData = nat(function getChannelData(c) {
        const d = gc.call(this, c);
        if (!done.has(d)) { for (let i = 0; i < d.length; i += 101) d[i] += ((h32(seed0, i) % 1000) - 500) * 2e-10; done.add(d); }
        return d;
      }, 'getChannelData');
    }
  }
})();
