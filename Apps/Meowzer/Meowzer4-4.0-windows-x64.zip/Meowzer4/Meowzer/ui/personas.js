// personas.js — the tables meowcore's `@persona` indices point into. Shared by every Meowzer host.
// meowcore picks only values that belong together (a Mac gets an Apple GPU and a Retina screen); this file turns
// the numbers into the strings and objects a page would read. `fill` completes costumes saved by older versions.
(function (G) {
  const FAM = ['Windows', 'macOS', 'Linux', 'Android', 'iOS'];
  const GPU = [
    ['Google Inc. (Intel)', 'ANGLE (Intel, Intel(R) UHD Graphics 620 Direct3D11 vs_5_0 ps_5_0, D3D11)', 'Mesa Intel(R) UHD Graphics 620 (KBL GT2)'],
    ['Google Inc. (Intel)', 'ANGLE (Intel, Intel(R) Iris(R) Xe Graphics Direct3D11 vs_5_0 ps_5_0, D3D11)', 'Mesa Intel(R) Xe Graphics (TGL GT2)'],
    ['Google Inc. (NVIDIA)', 'ANGLE (NVIDIA, NVIDIA GeForce GTX 1650 Direct3D11 vs_5_0 ps_5_0, D3D11)'],
    ['Google Inc. (NVIDIA)', 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)'],
    ['Google Inc. (NVIDIA)', 'ANGLE (NVIDIA, NVIDIA GeForce RTX 4070 Direct3D11 vs_5_0 ps_5_0, D3D11)'],
    ['Google Inc. (AMD)', 'ANGLE (AMD, AMD Radeon RX 6600 Direct3D11 vs_5_0 ps_5_0, D3D11)', 'AMD Radeon RX 6600 (radeonsi, navi23, LLVM 17.0.6, DRM 3.54)'],
    ['Google Inc. (AMD)', 'ANGLE (AMD, AMD Radeon(TM) Vega 8 Graphics Direct3D11 vs_5_0 ps_5_0, D3D11)', 'AMD Radeon Vega 8 Graphics (radeonsi, raven, LLVM 17.0.6, DRM 3.54)'],
    ['Google Inc. (Intel)', 'ANGLE (Intel, Intel(R) Arc(TM) A750 Graphics Direct3D11 vs_5_0 ps_5_0, D3D11)'],
    ['Apple Inc.', 'Apple M1'], ['Apple Inc.', 'Apple M2'], ['Apple Inc.', 'Apple M3'], ['Apple Inc.', 'Apple M4'],
    ['Qualcomm', 'Adreno (TM) 740'], ['ARM', 'Mali-G715'], ['Samsung Electronics Co., Ltd.', 'Samsung Xclipse 940'],
    ['Qualcomm', 'Adreno (TM) 650'], ['Apple Inc.', 'Apple GPU'],
  ];
  const SCREEN = [[1366, 768], [1536, 864], [1920, 1080], [1920, 1080], [2560, 1440], [1600, 900],
    [1440, 900], [1512, 982], [1680, 1050], [1728, 1117],
    [360, 800], [393, 873], [384, 854], [412, 915], [360, 780],
    [375, 812], [390, 844], [393, 852], [430, 932]];
  const MODEL = { 12: 'SM-S928B', 13: 'Pixel 9', 14: 'SM-S921B', 15: 'KB2005' };
  const TZ = ['America/New_York', 'America/Chicago', 'America/Denver', 'America/Los_Angeles', 'Europe/London',
    'Europe/Berlin', 'Europe/Paris', 'Europe/Madrid', 'Asia/Tokyo', 'Australia/Sydney', 'America/Toronto', 'America/Sao_Paulo'];
  // a city in each time zone, so a made-up location agrees with the made-up clock
  const CITY = [[40.713, -74.006], [41.878, -87.630], [39.739, -104.990], [34.052, -118.244], [51.507, -0.128],
    [52.520, 13.405], [48.857, 2.352], [40.417, -3.704], [35.676, 139.650], [-33.869, 151.209], [43.653, -79.383], [-23.551, -46.633]];
  const LANG = [['en-US', 'en'], ['en-GB', 'en'], ['de-DE', 'de', 'en'], ['fr-FR', 'fr', 'en'], ['es-ES', 'es', 'en'],
    ['ja-JP', 'ja', 'en'], ['en-AU', 'en'], ['en-CA', 'en', 'fr'], ['pt-BR', 'pt', 'en']];
  const OSV = [
    [['10.0.0', 'Windows 10'], ['15.0.0', 'Windows 11']],
    [['13.6.9', 'macOS 13'], ['14.7.1', 'macOS 14'], ['15.5.0', 'macOS 15'], ['26.1.0', 'macOS 26']],
    [['6.8.0', 'Linux']],
    [['13.0.0', 'Android 13'], ['14.0.0', 'Android 14'], ['15.0.0', 'Android 15'], ['16.0.0', 'Android 16']],
    [['18.6', 'iOS 18'], ['26.0', 'iOS 26'], ['26.1', 'iOS 26.1']],
  ];
  // fonts every machine of the family has, then twelve optional ones the persona's font mask picks from
  const FONTS = [
    [['Arial', 'Calibri', 'Cambria', 'Consolas', 'Courier New', 'Georgia', 'Segoe UI', 'Tahoma', 'Times New Roman', 'Trebuchet MS', 'Verdana'],
     ['Bahnschrift', 'Candara', 'Comic Sans MS', 'Constantia', 'Corbel', 'Franklin Gothic Medium', 'Gabriola', 'Impact', 'Ink Free', 'Lucida Console', 'Palatino Linotype', 'Sitka Text']],
    [['Helvetica', 'Helvetica Neue', 'Arial', 'Times', 'Times New Roman', 'Courier', 'Courier New', 'Georgia', 'Menlo', 'Monaco', 'Avenir'],
     ['Avenir Next', 'Baskerville', 'Futura', 'Gill Sans', 'Optima', 'Palatino', 'Didot', 'Hoefler Text', 'American Typewriter', 'Chalkboard', 'Rockwell', 'Copperplate']],
    [['DejaVu Sans', 'DejaVu Serif', 'DejaVu Sans Mono', 'Liberation Sans', 'Liberation Serif', 'Liberation Mono'],
     ['Noto Sans', 'Noto Serif', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'FreeSans', 'Nimbus Sans', 'Roboto', 'Source Code Pro', 'Hack', 'Inter']],
    [['Roboto', 'Noto Sans', 'Noto Serif', 'Droid Sans Mono'],
     ['Cutive Mono', 'Coming Soon', 'Dancing Script', 'Carrois Gothic SC', 'Noto Color Emoji', 'Source Sans Pro', 'Google Sans', 'Roboto Flex', 'Roboto Serif', 'Noto Sans Mono', 'Noto Naskh Arabic', 'Noto Sans CJK']],
    [['Helvetica', 'Helvetica Neue', 'Arial', 'Times New Roman', 'Courier', 'Georgia', 'Menlo'],
     ['Avenir', 'Futura', 'Gill Sans', 'Optima', 'Palatino', 'Didot', 'Baskerville', 'Chalkboard SE', 'Marker Felt', 'Noteworthy', 'Papyrus', 'Snell Roundhand']],
  ];
  const DISK = [32, 64, 128, 256, 512, 1024];
  const CHROME = '142', CHROME_FULL = '142.0.7444.60';
  const CONN = [['wifi', '4g'], ['cellular', '4g'], ['wifi', '4g']];

  // "persona fam cores mem gpu screen dpr touch osv arch bits conn tz lang rtt down battery charging noise
  //          fonts cams mics spk quota scheme motion glat glon bar depth batt tex voices"
  function fromCore(line) {
    const v = line.trim().split(/\s+/).slice(1).map(Number);
    const [fam, cores, mem, gpu, screen, dpr, touch, osv, arch, bits, conn, tz, lang, rtt, down, battery, charging, noise,
      fonts, cams, mics, spk, quota, scheme, motion, glat, glon, bar, depth, batt, tex] = v;
    const o = OSV[fam][Math.min(osv, OSV[fam].length - 1)];
    const g = GPU[gpu] || GPU[0];
    const [w, h] = SCREEN[screen] || SCREEN[2];
    const mobile = fam >= 3;
    const P = {
      family: FAM[fam], fam, ua: userAgent(fam, o),
      hardware: { cores, memory: Math.min(mem, 8), memoryReal: mem, gpuVendor: g[0], gpu: fam === 2 && g[2] ? g[2] : g[1],
        screen: [w, h], avail: [w, h - (bar || 0)], dpr: dpr / 100, touch, colorDepth: depth || 24,
        orientation: mobile ? 'portrait-primary' : 'landscape-primary',
        hasBattery: batt === undefined ? true : !!batt, battery: battery / 100, charging: !!charging,
        cams: cams ?? 1, mics: mics ?? 1, speakers: spk ?? 1, quotaGB: DISK[quota ?? 3], glMaxTexture: tex || 16384 },
      software: { os: o[1], platform: ['Win32', 'MacIntel', 'Linux x86_64', 'Linux armv81', 'iPhone'][fam],
        vendor: fam === 4 ? 'Apple Computer, Inc.' : 'Google Inc.',
        browser: fam === 4 ? 'Safari 26' : 'Chrome ' + CHROME, languages: LANG[lang], timezone: TZ[tz], doNotTrack: true, gpc: true,
        cookieEnabled: true, pdfViewer: !mobile, fonts: fontList(fam, fonts ?? 0),
        scheme: scheme ? 'dark' : 'light', motion: motion ? 'reduce' : 'no-preference', contrast: 'no-preference',
        voices: 'hide', keyboard: 'hide' },
      firmware: { platform: ['Windows', 'macOS', 'Linux', 'Android', 'iOS'][fam], platformVersion: o[0],
        architecture: arch ? 'arm' : 'x86', bitness: String(bits), model: fam === 3 ? (MODEL[gpu] || 'Pixel 9') : '',
        mobile, uaFullVersion: CHROME_FULL, wow64: false, formFactor: mobile ? 'Mobile' : 'Desktop' },
      internet: { type: CONN[conn][0], effectiveType: CONN[conn][1], rtt, downlink: down / 10, saveData: false,
        webrtc: 'no-local-ip', acceptLanguage: '',
        geo: { mode: 'deny', lat: +(CITY[tz][0] + (glat || 0) / 1000).toFixed(4), lon: +(CITY[tz][1] + (glon || 0) / 1000).toFixed(4), accuracy: 35 } },
      traces: { canvas: 1, audio: true, rects: true, webgl: true },
      permissions: { notifications: 'prompt', camera: 'prompt', microphone: 'prompt', geolocation: 'prompt' },
      noise,
    };
    return P;
  }
  function fontList(fam, mask) { const [base, opt] = FONTS[fam] || FONTS[0]; return base.concat(opt.filter((_, i) => mask >> i & 1)); }

  // costumes saved by Meowzer 4.0 lack the newer parts; complete them from the same family's defaults
  function fill(P) {
    if (!P || typeof P !== 'object') return P;
    const fam = P.fam | 0, mobile = fam >= 3;
    const d = fromCore('persona ' + [fam, 8, 8, 0, 2, 100, 0, 0, 0, 64, 0, 0, 0, 100, 50, 80, 1, P.noise | 0, 0, 1, 1, 1, 3, 0, 0, 0, 0, 40, 24, 1, 16384].join(' '));
    for (const k of ['hardware', 'software', 'firmware', 'internet', 'traces', 'permissions']) P[k] = Object.assign({}, d[k], P[k] || {});
    const hw = P.hardware;
    if (!hw.avail) hw.avail = [hw.screen[0], hw.screen[1] - (mobile ? 0 : 40)];
    if (!P.software.fonts || !P.software.fonts.length) P.software.fonts = fontList(fam, 0);
    if (!P.internet.geo || typeof P.internet.geo !== 'object') P.internet.geo = d.internet.geo;
    return P;
  }

  function userAgent(fam, o) {
    const C = CHROME + '.0.0.0';
    switch (fam) {
      case 0: return `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${C} Safari/537.36`;
      case 1: return `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${C} Safari/537.36`;
      case 2: return `Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${C} Safari/537.36`;
      case 3: return `Mozilla/5.0 (Linux; Android ${o[0].split('.')[0]}; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${C} Mobile Safari/537.36`;
      default: return `Mozilla/5.0 (iPhone; CPU iPhone OS ${o[0].replace('.', '_')} like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/${o[0].split('.')[0]}.0 Mobile/15E148 Safari/604.1`;
    }
  }
  // the hash every host uses to give a site its costume from the every-site pool (FNV-1a, 32 bits)
  function siteIndex(site, n) { let h = 0x811c9dc5; for (const b of new TextEncoder().encode(String(site).toLowerCase())) h = Math.imul(h ^ b, 16777619) >>> 0; return n ? h % n : h; }

  G.MeowPersonas = { fromCore, fill, siteIndex, FAM, GPU, SCREEN, TZ, LANG, FONTS, DISK };
})(typeof window !== 'undefined' ? window : globalThis);
