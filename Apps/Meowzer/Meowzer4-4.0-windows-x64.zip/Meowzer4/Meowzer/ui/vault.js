// vault.js — the ☰ menu's 🐾 Vault page: saved logins (passwords shown as paw prints), autofill settings, the password
// and user-name generator, and export / import / wipe. The logins themselves stay in the host: it keeps them locked in
// vault.dat (ꟻX: PBKDF2-HMAC-SHA256, two ChaCha20 layers, an HMAC tag) and gives this page a password only when you
// press 👁 or copy one. Also the small "save this login?" panel that pops up after you sign in somewhere.
'use strict';
const VAULT = (() => {
  const PAW = '🐾🐾🐾🐾🐾🐾';
  const TIERS = [
    ['PIN', '0–9 only', 'Bank cards, phone locks, sites that ask for a number code'],
    ['Letters', 'a–z A–Z', 'Old sites that refuse digits and symbols'],
    ['+ Digits', 'a–z A–Z 0–9', 'Sites that say "letters and numbers only"'],
    ['+ Common symbols', 'adds ! @ # $ % & * - _ + = ?', 'Most sites: the symbols nearly everyone accepts'],
    ['+ All symbols', 'adds ( ) , . / : ; < > [ ] ^ { | } ~', 'Sites that take any printable character: the strongest per letter'],
    ['Passphrase', 'Word-Word-Word-7', 'Easy to type and remember; long enough to be strong'],
  ];
  const USTYLES = ['wordsNN', 'word.word', 'word_word_NNN', 'random 10'];
  const vs = () => (S.settings.vault = Object.assign({ fill: 'ask', offer: true, exact: false, clip: 30, hideUsers: false, gen: { tier: 3, len: 20, flags: 1, ustyle: 0 } }, S.settings.vault || {}));
  const v = (op, extra) => ask('vault', Object.assign({ op }, extra || {}));
  let list = { logins: [], never: [], broken: false }, shown = {}, editing = null, q = '';
  const host = (o) => String(o || '').replace(/^https?:\/\//, '');
  const ago = (s) => { if (!s) return 'never'; const d = Date.now() / 1000 - s; return d < 90 ? 'just now' : d < 5400 ? Math.round(d / 60) + ' min ago' : d < 129600 ? Math.round(d / 3600) + ' h ago' : Math.round(d / 86400) + ' days ago'; };

  function page(p) {
    const st = vs();
    p.innerHTML = head('🐾 ', 'Vault &amp; autofill') +
      '<div id="vbroken"></div>' +
      '<h6>Autofill</h6>' + seg('vfill', ['Off', '🐾 Ask (a paw button in the box)', 'Fill by itself'], ['off', 'ask', 'auto'].indexOf(st.fill)) +
      '<small id="vfilltxt"></small>' +
      '<div class="row"><label>Offer to save logins after you sign in</label>' + sw('voffer', st.offer !== false) + '</div>' +
      '<div class="row"><label>Only on the exact address it was saved on <small>· otherwise also on the same site\'s other addresses, like login.site.com</small></label>' + sw('vexact', !!st.exact) + '</div>' +
      '<div class="row"><label>Hide user names with paw prints too</label>' + sw('vhide', !!st.hideUsers) + '</div>' +
      '<div class="row"><label>Forget a copied password from the clipboard after</label><select class="inp" id="vclip">' +
      [[15, '15 s'], [30, '30 s'], [60, '1 min'], [120, '2 min'], [0, 'never']].map(([n, t]) => '<option value="' + n + '"' + (n === (st.clip ?? 30) ? ' selected' : '') + '>' + t + '</option>').join('') + '</select></div>' +
      '<h6>Saved logins</h6><div class="row"><input class="inp" id="vq" placeholder="Search sites and user names" style="font-family:var(--font)" value="' + esc(q) + '"><button class="btn sm a" id="vadd">+ Add a login</button></div>' +
      '<div id="vform"></div><div id="vlist" class="hist"><div class="muted">opening the vault…</div></div>' +
      '<h6>Make a password</h6>' + seg('vtier', TIERS.map((t) => t[0]), st.gen.tier) +
      '<small id="vtiertxt"></small>' +
      '<div class="row"><label>Length <b id="vlenn">' + st.gen.len + '</b></label><input type="range" id="vlen" min="4" max="64" value="' + st.gen.len + '" style="flex:2"></div>' +
      '<div class="row"><label>Leave out look-alikes <small>· 0 O 1 l I |</small></label>' + sw('vlook', !!(st.gen.flags & 1)) + '</div>' +
      '<div class="row"><input class="inp" id="vpw" readonly style="font-size:14px"><button class="btn sm" id="vpwr" title="Another one">🎲</button><button class="btn sm" id="vpwc">Copy</button></div>' +
      '<small id="vstr" class="muted"></small>' +
      '<h6>Make a user name</h6>' + seg('vus', USTYLES, st.gen.ustyle) +
      '<div class="row"><input class="inp" id="vun" readonly style="font-size:14px"><button class="btn sm" id="vunr" title="Another one">🎲</button><button class="btn sm" id="vunc">Copy</button></div>' +
      '<h6>The vault file</h6>' +
      '<div class="row"><label>Quick export <small>· a .meowvault file only Meowzer can open</small></label><button class="btn sm g" id="vexp">⬆ Export…</button></div>' +
      '<div id="vexpf" hidden class="grp"><div class="row"><label>Lock it with a password <small>· without one, anyone with Meowzer can open the file</small></label>' + sw('vexpl', true) + '</div>' +
      '<div id="vexppw"><input class="inp" type="password" id="vexp1" placeholder="Password for the file" autocomplete="new-password"><input class="inp" type="password" id="vexp2" placeholder="Type it again" autocomplete="new-password" style="margin-top:6px"></div>' +
      '<div class="row"><small id="vexpmsg">Meowzer can\'t get the logins back out of a locked file without this password. Keep it somewhere safe.</small><button class="btn sm a" id="vexpgo">Export</button></div></div>' +
      '<div class="row"><label>Import <small>· adds the logins from a .meowvault file to these</small></label><button class="btn sm" id="vimp">⬇ Import…</button></div>' +
      '<div id="vimpf" hidden class="grp"><div class="row"><label id="vimpn">This vault is locked.</label></div><input class="inp" type="password" id="vimppw" placeholder="The file\'s password" autocomplete="off">' +
      '<div class="row"><small id="vimpmsg"></small><button class="btn sm a" id="vimpgo">Unlock and import</button></div></div>' +
      '<div class="row"><label>Wipe the vault <small>· deletes every saved login on this computer</small></label><button class="btn sm d" id="vwipe">🔥 Wipe…</button></div>' +
      '<div id="vwipef" hidden class="grp"><div class="row"><label><b>Delete all <span id="vwn">0</span> logins?</b> This can\'t be undone, except from a file you exported.</label></div>' +
      '<div class="row"><label>Also make a new vault key <small>· old copies of vault.dat can never be opened again</small></label>' + sw('vwkey', true) + '</div>' +
      '<div class="row"><small>Type <b>wipe</b> to confirm</small><input class="inp" id="vwtxt" style="width:90px" autocomplete="off"><button class="btn sm d" id="vwgo" disabled>Wipe it</button></div></div>' +
      '<h6>Never offered on</h6><div id="vnever" class="list"></div>' +
      '<small class="muted">Logins live in vault.dat, locked by meowcore (ꟻX) with a key Windows keeps for your account. They are never stored in cookies, and a page only gets a password at the moment it is filled in.</small>';

    const fillTxt = { off: 'Meowzer never fills anything in.', ask: 'A 🐾 button appears in login boxes; press it to choose a login.', auto: 'When exactly one login is saved for an https page, Meowzer fills it in by itself. Otherwise you get the 🐾 button.' };
    const fillMode = () => ($('#vfilltxt', p).textContent = fillTxt[st.fill]);
    fillMode();
    onSeg(p, 'vfill', (i) => { st.fill = ['off', 'ask', 'auto'][i]; saveSettings(); fillMode(); });
    onSw(p, 'voffer', (on) => { st.offer = on; saveSettings(); });
    onSw(p, 'vexact', (on) => { st.exact = on; saveSettings(); });
    onSw(p, 'vhide', (on) => { st.hideUsers = on; saveSettings(); draw(p); });
    $('#vclip', p).onchange = (e) => { st.clip = +e.target.value; saveSettings(); };
    $('#vq', p).oninput = (e) => { q = e.target.value.trim().toLowerCase(); draw(p); };
    $('#vadd', p).onclick = () => form(p, {});

    // the generators
    const tierTxt = () => { const t = TIERS[st.gen.tier]; $('#vtiertxt', p).textContent = t[1] + ' · ' + t[2]; $('#vlen', p).disabled = st.gen.tier === 5; };
    const gen = async () => {
      tierTxt();
      const r = await v('gen', { tier: st.gen.tier, len: st.gen.len, flags: st.gen.flags });
      const box = $('#vpw', p); if (!box) return;
      box.value = r.pw || ''; $('#vstr', p).textContent = r.pw ? strength(r.pw, st.gen.tier) : (r.error || 'meowcore did not answer');
    };
    const user = async () => { const r = await v('user', { style: st.gen.ustyle }); const b = $('#vun', p); if (b) b.value = r.user || ''; };
    onSeg(p, 'vtier', (i) => { st.gen.tier = i; if (i === 0 && st.gen.len > 12) { st.gen.len = 6; $('#vlen', p).value = 6; $('#vlenn', p).textContent = 6; } saveSettings(); gen(); });
    let lt; $('#vlen', p).oninput = (e) => { st.gen.len = +e.target.value; $('#vlenn', p).textContent = st.gen.len; clearTimeout(lt); lt = setTimeout(() => { saveSettings(); gen(); }, 120); };
    onSw(p, 'vlook', (on) => { st.gen.flags = on ? st.gen.flags | 1 : st.gen.flags & ~1; saveSettings(); gen(); });
    $('#vpwr', p).onclick = gen; $('#vunr', p).onclick = user;
    $('#vpwc', p).onclick = () => { const t = $('#vpw', p).value; if (t) { v('copyText', { text: t }); toast('Password copied' + (st.clip ? ' · forgotten in ' + st.clip + ' s' : '')); } };
    $('#vunc', p).onclick = () => { const t = $('#vun', p).value; if (t) { v('copyText', { text: t }); toast('User name copied'); } };
    onSeg(p, 'vus', (i) => { st.gen.ustyle = i; saveSettings(); user(); });
    gen(); user();

    // export
    $('#vexp', p).onclick = () => { const f = $('#vexpf', p); f.hidden = !f.hidden; };
    onSw(p, 'vexpl', (on) => { $('#vexppw', p).hidden = !on; $('#vexpmsg', p).textContent = on ? 'Meowzer can\'t get the logins back out of a locked file without this password. Keep it somewhere safe.' : 'Without a password the file is only scrambled: anyone with Meowzer (or its source) can open it. Keep it private.'; });
    $('#vexpgo', p).onclick = async () => {
      const lock = $('#vexpl', p).classList.contains('on'), a = $('#vexp1', p).value, b = $('#vexp2', p).value, msg = $('#vexpmsg', p);
      if (lock && a.length < 8) { msg.textContent = 'Use at least 8 characters (the generator above makes good ones).'; return; }
      if (lock && a !== b) { msg.textContent = 'The two passwords are different.'; return; }
      msg.textContent = lock ? 'Locking (600,000 rounds of PBKDF2 in ꟻX)…' : 'Writing…';
      const r = await v('export', { pw: lock ? a : '' });
      $('#vexp1', p).value = $('#vexp2', p).value = '';
      if (r.cancelled) { msg.textContent = 'Not exported.'; return; }
      if (r.error) { msg.textContent = r.error; return; }
      msg.textContent = '✓ ' + r.count + ' login' + (r.count === 1 ? '' : 's') + ' exported' + (r.locked ? ', locked with your password' : ' (no password)') + ' to ' + r.path;
      toast('⬆ Vault exported');
    };
    // import
    const imported = (r) => {
      const msg = $('#vimpmsg', p), f = $('#vimpf', p);
      if (r.cancelled) return;
      if (r.need) { f.hidden = false; $('#vimpn', p).textContent = '🔒 ' + r.name + ' is locked with a password.'; msg.textContent = ''; $('#vimppw', p).focus(); return; }
      if (r.wrong) { f.hidden = false; msg.textContent = 'That isn\'t the password. Nothing was imported.'; $('#vimppw', p).select(); return; }
      if (r.error) { toast(r.error); msg.textContent = r.error; return; }
      f.hidden = true; $('#vimppw', p).value = '';
      toast('⬇ Imported: ' + r.added + ' new, ' + r.updated + ' updated'); refresh(p);
    };
    $('#vimp', p).onclick = async () => imported(await v('import'));
    $('#vimpgo', p).onclick = async () => { const pw = $('#vimppw', p).value; if (!pw) return; $('#vimpmsg', p).textContent = 'Unlocking…'; imported(await v('import', { again: true, pw })); };
    $('#vimppw', p).onkeydown = (e) => { if (e.key === 'Enter') $('#vimpgo', p).click(); };
    // wipe: open the box, then type "wipe"
    $('#vwipe', p).onclick = () => { const f = $('#vwipef', p); f.hidden = !f.hidden; $('#vwn', p).textContent = list.logins.length; $('#vwtxt', p).value = ''; $('#vwgo', p).disabled = true; };
    $('#vwtxt', p).oninput = (e) => ($('#vwgo', p).disabled = e.target.value.trim().toLowerCase() !== 'wipe');
    $('#vwgo', p).onclick = async () => {
      list = await v('wipe', { newKey: $('#vwkey', p).classList.contains('on') }); $('#vwipef', p).hidden = true; shown = {}; draw(p); toast('🔥 The vault is empty');
    };
    refresh(p);
  }
  async function refresh(p) { list = await v('list'); draw(p); }
  function draw(p) {
    const st = vs(), box = $('#vlist', p); if (!box) return;
    $('#vbroken', p).innerHTML = list.broken ? '<div class="grp" style="border-color:var(--bad)"><b style="color:var(--bad)">The vault on this computer could not be opened.</b> <small>It was kept as vault.dat.unreadable. Saving a login starts a new vault; wiping deletes the old one.</small></div>' : '';
    const L = list.logins.filter((l) => !q || (l.origin + ' ' + l.user + ' ' + l.note).toLowerCase().includes(q)).sort((a, b) => a.site.localeCompare(b.site) || a.user.localeCompare(b.user));
    box.innerHTML = L.length ? L.map((l) => '<div class="hrow vrow" data-id="' + l.id + '" title="' + esc(l.origin + (l.note ? '\n' + l.note : '') + '\nsaved ' + ago(l.created) + ' · used ' + ago(l.used) + (l.uses ? ' (' + l.uses + '×)' : '')) + '">' +
        '<span class="ti" style="flex:0 0 34%"><b>' + esc(l.site || host(l.origin)) + '</b> <small class="muted">' + esc(host(l.origin) === l.site ? '' : host(l.origin)) + '</small></span>' +
        '<span class="ti">' + (st.hideUsers && !shown[l.id] ? PAW : esc(l.user || '(no user name)')) + '</span>' +
        '<span class="ti vpass" style="font-family:var(--mono)">' + (shown[l.id] ? esc(shown[l.id]) : PAW) + '</span>' +
        '<button class="btn sm" data-va="reveal" title="' + (shown[l.id] ? 'Hide' : 'Show the password') + '">' + (shown[l.id] ? '🙈' : '👁') + '</button>' +
        '<button class="btn sm" data-va="user" title="Copy the user name">👤</button>' +
        '<button class="btn sm" data-va="pass" title="Copy the password">🔑</button>' +
        '<button class="btn sm" data-va="edit" title="Edit">✎</button>' +
        '<button class="btn sm d" data-va="del" title="Delete">×</button></div>').join('')
      : '<div class="empty">' + (list.logins.length ? 'Nothing matches.' : 'No logins saved yet. Sign in somewhere and Meowzer offers to keep it, or add one here.') + '</div>';
    box.onclick = async (e) => {
      const b = e.target.closest('[data-va]'), row = e.target.closest('.vrow'); if (!b || !row) return;
      const id = row.dataset.id, a = b.dataset.va, l = list.logins.find((x) => x.id === id);
      if (a === 'reveal') { if (shown[id]) delete shown[id]; else { const r = await v('reveal', { login: id }); shown[id] = r.pass || ''; setTimeout(() => { if (shown[id] !== undefined) { delete shown[id]; draw(p); } }, 20000); } draw(p); }
      if (a === 'user' || a === 'pass') { await v('copy', { login: id, what: a }); toast((a === 'user' ? 'User name' : 'Password') + ' copied' + (a === 'pass' && st.clip ? ' · forgotten in ' + st.clip + ' s' : '')); }
      if (a === 'edit') form(p, l);
      if (a === 'del' && confirm('Delete the login for ' + (l.user || '(no user name)') + ' on ' + host(l.origin) + '?')) { list = await v('del', { login: id }); delete shown[id]; draw(p); }
    };
    $('#vnever', p).innerHTML = list.never.length ? list.never.map((s) => '<div><span>' + esc(s) + '</span><button class="btn sm" data-nv="' + esc(s) + '">allow again</button></div>').join('') : '<div><span class="muted">no sites</span></div>';
    $('#vnever', p).onclick = async (e) => { const b = e.target.closest('[data-nv]'); if (b) { list = await v('never', { site: b.dataset.nv, on: false }); draw(p); } };
  }
  // add or edit one login; an empty password box while editing keeps the old password
  function form(p, l) {
    editing = l.id || null; const f = $('#vform', p);
    const site = l.origin || (isWeb(tab().url) ? new URL(tab().url).origin : '');
    f.innerHTML = '<div class="grp" style="display:flex;flex-direction:column;gap:6px;margin-bottom:8px"><h6>' + (editing ? 'Edit login' : 'Add a login') + '</h6>' +
      '<input class="inp" id="vfo" placeholder="Address, like https://example.com" value="' + esc(site) + '">' +
      '<div style="display:flex;gap:6px"><input class="inp" id="vfu" placeholder="User name or e-mail" value="' + esc(l.user || '') + '" autocomplete="off"><button class="btn sm" id="vfug" title="Make one">🎲</button></div>' +
      '<div style="display:flex;gap:6px"><input class="inp" id="vfp" type="password" placeholder="' + (editing ? 'New password (leave empty to keep it)' : 'Password') + '" autocomplete="new-password"><button class="btn sm" id="vfpe" title="Show what you type">👁</button><button class="btn sm" id="vfpg" title="Make one with the settings below">🎲</button></div>' +
      '<input class="inp" id="vfn" placeholder="Note (optional)" value="' + esc(l.note || '') + '" style="font-family:var(--font)">' +
      '<div class="row"><small id="vfmsg"></small><span><button class="btn sm" id="vfc">Cancel</button> <button class="btn sm a" id="vfs">Save</button></span></div></div>';
    const st = vs();
    $('#vfpe', p).onclick = () => { const i = $('#vfp', p); i.type = i.type === 'password' ? 'text' : 'password'; };
    $('#vfpg', p).onclick = async () => { const r = await v('gen', { tier: st.gen.tier, len: st.gen.len, flags: st.gen.flags }); if (r.pw) { $('#vfp', p).value = r.pw; $('#vfp', p).type = 'text'; } };
    $('#vfug', p).onclick = async () => { const r = await v('user', { style: st.gen.ustyle }); if (r.user) $('#vfu', p).value = r.user; };
    $('#vfc', p).onclick = () => { f.innerHTML = ''; editing = null; };
    $('#vfs', p).onclick = async () => {
      const origin = $('#vfo', p).value.trim(), pass = $('#vfp', p).value;
      if (!origin) { $('#vfmsg', p).textContent = 'Which site is it for?'; return; }
      if (!editing && !pass) { $('#vfmsg', p).textContent = 'A login needs a password.'; return; }
      const r = await v('save', { login: { id: editing || '', origin, user: $('#vfu', p).value, pass, note: $('#vfn', p).value } });
      if (r.error) { $('#vfmsg', p).textContent = r.error; return; }
      list = r; f.innerHTML = ''; editing = null; draw(p); toast('🐾 Saved');
    };
    $('#vfo', p).focus();
  }
  // a rough guide: bits of randomness in what was made
  function strength(pw, tier) {
    const pool = [10, 52, 62, 74, 94][tier]; let bits;
    if (tier === 5) bits = (pw.split('-').length - 1) * Math.log2(260) + Math.log2(10);
    else bits = pw.length * Math.log2(pool || 62);
    const w = bits < 40 ? 'weak' : bits < 64 ? 'fair' : bits < 90 ? 'strong' : 'very strong';
    return '≈ ' + Math.round(bits) + ' bits · ' + w + (tier === 0 ? ' (a PIN is only as strong as the lock-out after wrong tries)' : '');
  }

  // after you sign in somewhere: keep it?
  let offer = null;
  function offerPage(p) {
    const o = offer || {};
    p.innerHTML = head('🐾 ', o.update ? 'Update the saved password?' : 'Save this login?') +
      '<div class="grp"><div><b>' + esc(o.site || '') + '</b> <small class="muted">' + esc(host(o.origin)) + '</small></div>' +
      '<div style="margin-top:4px">' + esc(o.user || '(no user name)') + ' · <span style="font-family:var(--mono)">' + PAW + '</span></div></div>' +
      '<small class="muted">Kept in Meowzer\'s locked vault on this computer, never in a cookie.</small>' +
      '<div class="row"><button class="btn sm" id="ofn">Never for this site</button><span><button class="btn sm" id="ofl">Not now</button> <button class="btn sm a" id="ofs">' + (o.update ? 'Update' : 'Save') + '</button></span></div>';
    const answer = (a) => { v('offer', { a }); offer = null; closePanels(); if (a === 'save') toast('🐾 ' + (o.update ? 'Updated' : 'Saved')); };
    $('#ofs', p).onclick = () => answer('save'); $('#ofn', p).onclick = () => answer('never'); $('#ofl', p).onclick = () => answer('no');
  }
  function onOffer(m) { offer = m; open('voffer'); }
  return { page, offerPage, onOffer };
})();
function pVault(p) { VAULT.page(p); }
function pVaultOffer(p) { VAULT.offerPage(p); }
