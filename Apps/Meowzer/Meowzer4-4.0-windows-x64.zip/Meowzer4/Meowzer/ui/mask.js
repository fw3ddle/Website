// mask.js — the cat's third page: the Mask. Four channels, each its own layer, each with its own lever:
//   Route  where your pages leave from: Tor, a proxy you name, or a VPN app (Proton VPN Free, Windscribe Free) that
//          moves the whole computer. Meowzer makes no tunnel of its own; it uses one and checks it really carries you.
//   Match  what pages see of your clock, language and location follows the country the route leaves from.
//   Fuzz   what other sites hear: the address you came from, your language list, your machine's detailed hints.
//   Seal   what Meowzer keeps on disk, the route log included, sealed with ChaCha written in ꟻX (meowcore).
// Click a country on the map to see the free ways to leave from there.
'use strict';
const MASK = (() => {
  // [iso numeric (the map's id), iso2, name as am.i.mullvad.net says it, time zone, language, lat, lon (a big city)]
  const C = [
    ['840','US','United States','America/New_York','en-US',40.71,-74.01],['124','CA','Canada','America/Toronto','en-CA',43.65,-79.38],
    ['484','MX','Mexico','America/Mexico_City','es-MX',19.43,-99.13],['076','BR','Brazil','America/Sao_Paulo','pt-BR',-23.55,-46.63],
    ['032','AR','Argentina','America/Argentina/Buenos_Aires','es-AR',-34.6,-58.38],['152','CL','Chile','America/Santiago','es-CL',-33.45,-70.67],
    ['170','CO','Colombia','America/Bogota','es-CO',4.71,-74.07],['604','PE','Peru','America/Lima','es-PE',-12.05,-77.04],
    ['826','GB','United Kingdom','Europe/London','en-GB',51.51,-0.13],['372','IE','Ireland','Europe/Dublin','en-IE',53.35,-6.26],
    ['250','FR','France','Europe/Paris','fr-FR',48.86,2.35],['276','DE','Germany','Europe/Berlin','de-DE',52.52,13.4],
    ['528','NL','Netherlands','Europe/Amsterdam','nl-NL',52.37,4.9],['056','BE','Belgium','Europe/Brussels','nl-BE',50.85,4.35],
    ['442','LU','Luxembourg','Europe/Luxembourg','fr-LU',49.61,6.13],['756','CH','Switzerland','Europe/Zurich','de-CH',47.38,8.54],
    ['040','AT','Austria','Europe/Vienna','de-AT',48.21,16.37],['380','IT','Italy','Europe/Rome','it-IT',41.9,12.5],
    ['724','ES','Spain','Europe/Madrid','es-ES',40.42,-3.7],['620','PT','Portugal','Europe/Lisbon','pt-PT',38.72,-9.14],
    ['578','NO','Norway','Europe/Oslo','nb-NO',59.91,10.75],['752','SE','Sweden','Europe/Stockholm','sv-SE',59.33,18.07],
    ['208','DK','Denmark','Europe/Copenhagen','da-DK',55.68,12.57],['246','FI','Finland','Europe/Helsinki','fi-FI',60.17,24.94],
    ['352','IS','Iceland','Atlantic/Reykjavik','is-IS',64.15,-21.94],['616','PL','Poland','Europe/Warsaw','pl-PL',52.23,21.01],
    ['203','CZ','Czech Republic','Europe/Prague','cs-CZ',50.08,14.44],['703','SK','Slovakia','Europe/Bratislava','sk-SK',48.15,17.11],
    ['348','HU','Hungary','Europe/Budapest','hu-HU',47.5,19.04],['642','RO','Romania','Europe/Bucharest','ro-RO',44.43,26.1],
    ['100','BG','Bulgaria','Europe/Sofia','bg-BG',42.7,23.32],['300','GR','Greece','Europe/Athens','el-GR',37.98,23.73],
    ['191','HR','Croatia','Europe/Zagreb','hr-HR',45.81,15.98],['688','RS','Serbia','Europe/Belgrade','sr-RS',44.79,20.45],
    ['705','SI','Slovenia','Europe/Ljubljana','sl-SI',46.06,14.51],['233','EE','Estonia','Europe/Tallinn','et-EE',59.44,24.75],
    ['428','LV','Latvia','Europe/Riga','lv-LV',56.95,24.11],['440','LT','Lithuania','Europe/Vilnius','lt-LT',54.69,25.28],
    ['804','UA','Ukraine','Europe/Kyiv','uk-UA',50.45,30.52],['498','MD','Moldova','Europe/Chisinau','ro-MD',47.01,28.86],
    ['792','TR','Turkey','Europe/Istanbul','tr-TR',41.01,28.98],['376','IL','Israel','Asia/Jerusalem','he-IL',32.09,34.78],
    ['784','AE','United Arab Emirates','Asia/Dubai','ar-AE',25.2,55.27],['710','ZA','South Africa','Africa/Johannesburg','en-ZA',-26.2,28.05],
    ['566','NG','Nigeria','Africa/Lagos','en-NG',6.52,3.38],['818','EG','Egypt','Africa/Cairo','ar-EG',30.04,31.24],
    ['404','KE','Kenya','Africa/Nairobi','en-KE',-1.29,36.82],['356','IN','India','Asia/Kolkata','en-IN',19.08,72.88],
    ['702','SG','Singapore','Asia/Singapore','en-SG',1.35,103.82],['458','MY','Malaysia','Asia/Kuala_Lumpur','ms-MY',3.14,101.69],
    ['764','TH','Thailand','Asia/Bangkok','th-TH',13.76,100.5],['704','VN','Vietnam','Asia/Ho_Chi_Minh','vi-VN',10.82,106.63],
    ['360','ID','Indonesia','Asia/Jakarta','id-ID',-6.21,106.85],['608','PH','Philippines','Asia/Manila','en-PH',14.6,120.98],
    ['344','HK','Hong Kong','Asia/Hong_Kong','zh-HK',22.32,114.17],['158','TW','Taiwan','Asia/Taipei','zh-TW',25.03,121.57],
    ['410','KR','South Korea','Asia/Seoul','ko-KR',37.57,126.98],['392','JP','Japan','Asia/Tokyo','ja-JP',35.68,139.69],
    ['036','AU','Australia','Australia/Sydney','en-AU',-33.87,151.21],['554','NZ','New Zealand','Pacific/Auckland','en-NZ',-36.85,174.76],
    ['643','RU','Russia','Europe/Moscow','ru-RU',55.76,37.62],['156','CN','China','Asia/Shanghai','zh-CN',31.23,121.47],
  ].map(([num, iso, name, tz, lang, lat, lon]) => ({ num, iso, name, tz, lang, lat, lon }));
  const ALIAS = { 'USA': 'US', 'United States of America': 'US', 'UK': 'GB', 'Great Britain': 'GB', 'Czechia': 'CZ', 'Türkiye': 'TR', 'Republic of Korea': 'KR', 'Korea': 'KR', 'Viet Nam': 'VN', 'UAE': 'AE', 'Russian Federation': 'RU' };
  const byIso = iso => C.find(c => c.iso === iso), byNum = n => C.find(c => c.num === n);
  const byName = n => n ? C.find(c => c.name === n) || byIso(ALIAS[n]) : null;
  const mapName = n => ((window.WORLD || { c: [] }).c.find(x => x[0] === n) || [])[1] || (byNum(n) || {}).name || n;
  // free ways out, as their makers listed them in 2025. They change; each card links to its maker's own page.
  const FREE = {
    proton: { name: 'Proton VPN Free', where: ['US', 'NL', 'JP', 'RO', 'PL', 'NO', 'CH', 'MX', 'CA', 'SG'], url: 'https://protonvpn.com/free-vpn',
      what: 'An app for the whole computer. No data cap, no ads, no-logs policy audited; on the free plan Proton picks the server within the country.' },
    windscribe: { name: 'Windscribe Free', where: ['US', 'CA', 'GB', 'FR', 'DE', 'NL', 'NO', 'RO', 'CH', 'HK', 'TR'], url: 'https://windscribe.com/features/free-vpn',
      what: 'An app for the whole computer. 10 GB a month once you confirm an email address.' },
  };
  const BLUR = [0, 5, 25, 100], CHECK = [0, 1, 5, 15], ROUNDS = [8, 12, 20];
  const STORE_NAME = { history: 'History', jar: 'Cookie jar', shelf: 'Bookshelf', stats: 'Savings', route: 'Route log' };
  const D = { routeOn: false, route: { mode: 'direct', provider: '', country: '', proxy: '', port: 9150 }, check: 0,
    match: { on: false, tz: true, lang: true, geo: 'fake', blur: 2 }, fuzz: { on: false, ref: 1, lang: false, hints: true },
    seal: { on: false, rounds: 20, stores: ['history', 'jar', 'shelf', 'stats', 'route'] } };
  function mask() {
    const m = S.settings.mask = S.settings.mask || {};
    for (const k in D) { if (!(k in m)) m[k] = JSON.parse(JSON.stringify(D[k])); else if (D[k] && typeof D[k] === 'object' && !Array.isArray(D[k])) for (const j in D[k]) if (!(j in m[k])) m[k][j] = JSON.parse(JSON.stringify(D[k][j])); }
    return m;
  }
  let probe = null, sealSample = null, sealInfo = null, pane = null, popAt = null, dressed = '';
  const save = () => { saveSettings(); };

  // ------------------------------------------------------------------ what the route is doing
  function routeLabel(m) {
    if (!m.routeOn) return 'Direct: pages leave from your own connection';
    const r = m.route, c = byIso(r.country);
    if (r.mode === 'tor') return 'Tor (127.0.0.1:' + r.port + '): Tor picks the exit country';
    if (r.mode === 'proxy') return 'Your proxy: ' + r.proxy;
    if (r.mode === 'system') return (FREE[r.provider] || { name: 'A VPN app' }).name + (c ? ' → ' + c.name : '');
    return 'Direct';
  }
  function live() {
    const m = mask(); if (!m.routeOn) return { on: false, why: 'The route is off.' };
    if (!probe) return { on: false, why: 'Not checked yet.' };
    if (!probe.ok) return { on: false, why: probe.error || 'No answer.' };
    if (m.route.mode === 'system') {
      const c = byName(probe.country), want = byIso(m.route.country);
      if (want && (!c || c.iso !== want.iso)) return { on: false, why: 'Traffic still leaves from ' + (probe.country || '?') + '. Connect ' + (FREE[m.route.provider] || { name: 'the app' }).name + ' to ' + want.name + '.' };
      return { on: true };
    }
    if (probe.route === 'direct') return { on: false, why: 'Meowzer is still on its old route; it restarts to change.' };
    return { on: true };
  }
  function onProbe(d) {
    if (!d) return; probe = d; maybeDress();
    if (pane && pane.isConnected) { drawRoute(); drawMatch(); drawMap(); if (mask().seal.on) sample(); }
  }
  // Match: re-dress the costume only when the country (or the Match settings) actually change
  function maybeDress() {
    const m = mask(), key = JSON.stringify([m.match, probe && probe.ok && probe.country, probe && probe.ok && probe.city]);
    if (key !== dressed) { dressed = key; if (S.settings.costume !== 'off' && S.sessionPersona) sendCostume(); }
  }
  function dress(p) {
    const m = mask(); if (!m.match.on || !probe || !probe.ok) return p;
    const c = byName(probe.country); if (!c) return p;
    const q = JSON.parse(JSON.stringify(p)); q.software = q.software || {}; q.internet = q.internet || {};
    if (m.match.tz) q.software.timezone = c.tz;
    if (m.match.lang) { const base = c.lang.split('-')[0]; q.software.languages = [c.lang, base].concat(base === 'en' ? [] : ['en']); }
    if (m.match.geo === 'deny') q.internet.geo = { mode: 'deny' };
    else if (m.match.geo === 'fake') {
      const km = BLUR[m.match.blur] || 0, lat = typeof probe.latitude === 'number' ? probe.latitude : c.lat, lon = typeof probe.longitude === 'number' ? probe.longitude : c.lon;
      // a fixed nudge for this session (a new spot every reading would itself stand out)
      const s = (S.sessionPersona && S.sessionPersona.seed) || 7, a = (s % 360) * Math.PI / 180, r = km * ((s >> 3) % 100) / 100;
      q.internet.geo = { mode: 'fake', lat: +(lat + r / 111 * Math.cos(a)).toFixed(4), lon: +(lon + r / (111 * Math.max(.2, Math.cos(lat * Math.PI / 180))) * Math.sin(a)).toFixed(4), accuracy: Math.max(30, km * 1000) };
    }
    return q;
  }

  // ------------------------------------------------------------------ widgets: lever, knob, slider, latching buttons
  const lever = (id, on, label) => '<button class="lv' + (on ? ' on' : '') + '" id="' + id + '" role="switch" aria-checked="' + !!on + '" aria-label="' + esc(label) + '" title="' + esc(label) + '"><i></i></button>';
  function knob(id, label, stops, i) {
    const n = stops.length, ang = k => n < 2 ? 0 : -135 + 270 * k / (n - 1);
    const ticks = stops.map((_, k) => { const a = (ang(k) - 90) * Math.PI / 180; return '<line class="kt' + (k === i ? ' on' : '') + '" x1="' + (30 + 23 * Math.cos(a)).toFixed(1) + '" y1="' + (30 + 23 * Math.sin(a)).toFixed(1) + '" x2="' + (30 + 27 * Math.cos(a)).toFixed(1) + '" y2="' + (30 + 27 * Math.sin(a)).toFixed(1) + '"/>'; }).join('');
    return '<div class="kn" id="' + id + '" tabindex="0" role="slider" aria-label="' + esc(label) + '" aria-valuemin="0" aria-valuemax="' + (n - 1) + '" aria-valuenow="' + i + '" aria-valuetext="' + esc(stops[i]) + '">' +
      '<svg viewBox="0 0 60 60">' + ticks + '<circle class="kb" cx="30" cy="30" r="17"/><g class="kp" style="transform:rotate(' + ang(i) + 'deg)"><line x1="30" y1="30" x2="30" y2="16"/></g></svg>' +
      '<b>' + esc(label) + '</b><small>' + esc(stops[i]) + '</small></div>';
  }
  function wireKnob(root, id, stops, f) {
    const el = $('#' + id, root); if (!el) return; const n = stops.length; let i = +el.getAttribute('aria-valuenow');
    const set = k => { k = Math.max(0, Math.min(n - 1, k)); if (k === i) return; i = k;
      el.setAttribute('aria-valuenow', i); el.setAttribute('aria-valuetext', stops[i]); $('small', el).textContent = stops[i];
      $('.kp', el).style.transform = 'rotate(' + (n < 2 ? 0 : -135 + 270 * i / (n - 1)) + 'deg)';
      $$('.kt', el).forEach((t, j) => t.classList.toggle('on', j === i)); f(i); };
    let y0 = null, i0 = 0, moved = false;
    el.onpointerdown = e => { y0 = e.clientY; i0 = i; moved = false; el.setPointerCapture(e.pointerId); };
    el.onpointermove = e => { if (y0 === null) return; const d = Math.round((y0 - e.clientY) / 16); if (d) moved = true; set(i0 + d); };
    el.onpointerup = () => { if (y0 !== null && !moved) set(i === n - 1 ? 0 : i + 1); y0 = null; };
    el.onwheel = e => { e.preventDefault(); set(i + (e.deltaY < 0 ? 1 : -1)); };
    el.onkeydown = e => { if (e.key === 'ArrowUp' || e.key === 'ArrowRight') { set(i + 1); e.preventDefault(); } if (e.key === 'ArrowDown' || e.key === 'ArrowLeft') { set(i - 1); e.preventDefault(); } };
  }
  function wireLever(root, id, f) { const b = $('#' + id, root); if (b) b.onclick = () => { const on = !b.classList.contains('on'); if (f(on) === false) return; b.classList.toggle('on', on); b.setAttribute('aria-checked', on); }; }
  const latch = (id, on, label, tip) => '<button class="la' + (on ? ' on' : '') + '" id="' + id + '" aria-pressed="' + !!on + '" title="' + esc(tip || '') + '"><i></i>' + esc(label) + '</button>';
  function wireLatch(root, id, f) { const b = $('#' + id, root); if (b) b.onclick = () => { const on = !b.classList.contains('on'); b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); f(on); }; }

  // ------------------------------------------------------------------ the map
  let svgCache = '';
  const proj = (lat, lon) => [(lon + 180) / 360 * WORLD.w, (84 - lat) / 141 * WORLD.h];
  function svgBase() {
    if (svgCache || !window.WORLD) return svgCache;
    const on = n => { const c = byNum(n); return c && (FREE.proton.where.includes(c.iso) || FREE.windscribe.where.includes(c.iso)); };
    const have = new Set(WORLD.c.map(x => x[0]));
    svgCache = WORLD.c.map(([n, name, d]) => '<path data-n="' + n + '" class="' + (on(n) ? 'fr' : '') + '" d="' + d + '"><title>' + esc(name) + '</title></path>').join('') +
      C.filter(c => !have.has(c.num)).map(c => { const [x, y] = proj(c.lat, c.lon); return '<circle data-n="' + c.num + '" class="dot' + (on(c.num) ? ' fr' : '') + '" cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) + '" r="4"><title>' + esc(c.name) + '</title></circle>'; }).join('');
    return svgCache;
  }
  function drawMap() {
    const box = pane && $('#mmap', pane); if (!box) return; const m = mask();
    $$('.ex,.sel', box).forEach(x => x.classList.remove('ex', 'sel'));
    const ex = probe && probe.ok ? byName(probe.country) : null;
    if (ex) $$('[data-n="' + ex.num + '"]', box).forEach(x => x.classList.add('ex'));
    if (m.routeOn && m.route.country) { const c = byIso(m.route.country); if (c) $$('[data-n="' + c.num + '"]', box).forEach(x => x.classList.add('sel')); }
    const pin = $('#mpin', box);
    if (pin) { if (probe && probe.ok && typeof probe.latitude === 'number') { const [x, y] = proj(probe.latitude, probe.longitude); pin.setAttribute('transform', 'translate(' + x.toFixed(1) + ' ' + y.toFixed(1) + ')'); pin.style.display = ''; } else pin.style.display = 'none'; }
  }
  function popover(num, ev) {
    const wrap = $('#mapw', pane), pop = $('#mpop', pane), c = byNum(num), name = c ? c.name : mapName(num), m = mask();
    const has = k => c && FREE[k].where.includes(c.iso);
    const card = (k, title, kind, what, btn, extra) => '<div class="mo"><div><b>' + title + '</b><small class="kind">' + kind + '</small></div><p>' + what + '</p>' + (extra || '') +
      '<div class="row0"><button class="btn sm a" data-go="' + k + '">' + btn + '</button></div></div>';
    let h = '<h4><span class="iso">' + esc(c ? c.iso : '··') + '</span>' + esc(name) + '<button class="x" data-go="close" title="Close">×</button></h4>';
    for (const k of ['proton', 'windscribe']) if (has(k)) h += card(k, FREE[k].name, 'VPN app · free', esc(FREE[k].what), m.route.provider === k && m.route.country === c.iso && m.routeOn ? 'Watching for it' : 'Use this',
      '<a href="#" data-link="' + FREE[k].url + '" class="lnk">' + esc(new URL(FREE[k].url).hostname) + ' ↗</a>');
    h += card('tor', 'Tor', 'free · Meowzer only', 'Through the Tor network, if Tor Browser or the tor service runs on this computer. Tor chooses the exit country itself, so it may not be ' + esc(name) + '.', 'Use Tor',
      '<a href="#" data-link="https://www.torproject.org/download/" class="lnk">torproject.org ↗</a>');
    h += card('proxy', 'Your own proxy', 'Meowzer only', 'A SOCKS or HTTP proxy you run or trust in ' + esc(name) + ' (an SSH tunnel, a home server, a friend\'s box).', 'Use it',
      '<input class="inp" id="mpx" placeholder="socks5://host:1080" value="' + esc(m.route.mode === 'proxy' ? m.route.proxy : '') + '">');
    if (!has('proton') && !has('windscribe')) h += '<small class="muted">No free VPN plan lists ' + esc(name) + ' (as of 2025). Highlighted countries have one.</small>';
    pop.innerHTML = h; pop.hidden = false; pop.dataset.iso = c ? c.iso : ''; pop.dataset.n = num;
    const r = wrap.getBoundingClientRect(), x = ev.clientX - r.left, y = ev.clientY - r.top, pw = 280;
    pop.style.left = Math.max(4, Math.min(r.width - pw - 4, x - pw / 2)) + 'px';
    const ph = pop.offsetHeight; pop.style.top = (y + 14 + ph < r.height + 160 ? y + 14 : Math.max(4, y - ph - 14)) + 'px';
    popAt = num;
  }
  async function useRoute(k, iso) {
    const m = mask(), was = JSON.stringify([m.routeOn, m.route]);
    if (k === 'tor') {
      const t = await ask('tor'); if (!t.port) { toast('Tor isn\'t running on this computer. Start Tor Browser, then try again.'); return; }
      m.route = { mode: 'tor', provider: 'tor', country: '', proxy: '', port: t.port };
    } else if (k === 'proxy') {
      const v = ($('#mpx', pane) || {}).value.trim();
      if (!/^(socks5|socks4|http|https):\/\/[A-Za-z0-9.\-\[\]:]+:\d{1,5}$/.test(v)) { toast('A proxy looks like socks5://host:1080'); return; }
      m.route = { mode: 'proxy', provider: 'proxy', country: iso || '', proxy: v, port: 9150 };
    } else m.route = { mode: 'system', provider: k, country: iso, proxy: '', port: 9150 };
    m.routeOn = true; save(); $('#mpop', pane).hidden = true;
    if (JSON.stringify([m.routeOn, m.route]) !== was) await applyRoute();
    if (k === 'proton' || k === 'windscribe') toast('Connect ' + FREE[k].name + ' to ' + byIso(iso).name + '. The Route channel goes live when traffic leaves from there.');
    check(); open('mask');
  }
  // the engine takes its proxy when it starts: if that has to change, Meowzer restarts (asking first) and reopens its tabs
  async function applyRoute() {
    const r = await ask('route');
    if (r.want === r.now) return;
    if (confirm('Meowzer restarts to send its pages ' + (r.want === 'direct' ? 'directly again' : 'through ' + r.want) + '. Your tabs come back. Restart now?')) Host.send({ t: 'route', apply: true, id: 0 });
  }
  const check = () => ask('probe').then(onProbe);

  // ------------------------------------------------------------------ the channels
  function drawRoute() {
    const el = pane && $('#ro-route', pane); if (!el) return; const m = mask(), L = live();
    $('#ch-route', pane).classList.toggle('live', L.on); $('#ch-route', pane).classList.toggle('on', m.routeOn);
    const P = probe;
    el.innerHTML = '<div class="rl">' + esc(routeLabel(m)) + '</div>' +
      (P && P.ok ? '<div class="big"><span class="iso">' + esc((byName(P.country) || {}).iso || '··') + '</span>' + esc([P.city, P.country].filter(Boolean).join(', ')) + '</div>' +
        '<div class="kv"><span>IP</span><code>' + esc(P.ip || '?') + '</code><span>Network</span><code>' + esc(P.organization || '?') + '</code><span>Answer</span><code>' + (P.ms | 0) + ' ms · ' + new Date(P.time * 1000).toLocaleTimeString() + '</code>' +
        (P.listed ? '<span>Lists</span><code class="w">on a public blocklist</code>' : '') + '</div>'
        : P ? '<div class="big dim">' + esc(P.error || 'No answer') + '</div>' : '<div class="big dim">Not checked yet</div>') +
      (L.on ? '<div class="st ok">● live</div>' : '<div class="st">' + esc(L.why) + '</div>');
  }
  function drawMatch() {
    const el = pane && $('#ro-match', pane); if (!el) return; const m = mask(), c = probe && probe.ok ? byName(probe.country) : null;
    $('#ch-match', pane).classList.toggle('on', m.match.on); $('#ch-match', pane).classList.toggle('live', m.match.on && !!c && S.settings.costume !== 'off');
    const geo = m.match.geo === 'deny' ? 'asked for, refused' : m.match.geo === 'fake' ? 'near the exit, ±' + (BLUR[m.match.blur] || '<1') + ' km' : 'your real one (if you allow it)';
    el.innerHTML = !m.match.on ? '<div class="st">Off: pages see the costume as it is.</div>' : !c ? '<div class="st">Waiting for the Route to say where traffic leaves from' + (probe && probe.ok ? ' (' + esc(probe.country) + ' isn\'t in Meowzer\'s list)' : '') + '.</div>' :
      '<div class="kv"><span>Clock</span><code>' + (m.match.tz ? esc(c.tz) : 'the costume\'s') + '</code><span>Language</span><code>' + (m.match.lang ? esc(c.lang) : 'the costume\'s') + '</code><span>Location</span><code>' + esc(geo) + '</code></div>' +
      (S.settings.costume === 'off' ? '<div class="st w">The costume is off, so there is nothing to dress.</div>' : '<div class="st ok">● pages see someone in ' + esc(c.name) + '</div>');
  }
  function drawFuzz() {
    const el = pane && $('#ro-fuzz', pane); if (!el) return; const f = mask().fuzz;
    $('#ch-fuzz', pane).classList.toggle('on', f.on); $('#ch-fuzz', pane).classList.toggle('live', f.on);
    el.innerHTML = !f.on ? '<div class="st">Off: other sites hear what the engine normally sends.</div>' :
      '<div class="kv"><span>Came from</span><code>' + ['the full address', 'just the site', 'nothing'][f.ref] + '</code><span>Languages</span><code>' + (f.lang ? 'one' : 'the whole list') + '</code><span>Hints</span><code>' + (f.hints ? 'brand and platform only' : 'everything asked for') + '</code></div><div class="st ok">● applies to every request to another site</div>';
  }
  function drawSeal() {
    const el = pane && $('#ro-seal', pane); if (!el) return; const s = mask().seal, I = sealInfo, X = sealSample;
    $('#ch-seal', pane).classList.toggle('on', s.on); $('#ch-seal', pane).classList.toggle('live', !!(s.on && I && I.stores.some(x => x.sealed)));
    const stores = I ? I.stores.map(x => '<span class="sto' + (x.sealed ? ' on' : '') + '" title="' + (x.sealed ? 'sealed' : 'plain') + ' · ' + fmtB(x.bytes) + '">' + (x.sealed ? '🔒 ' : '') + esc(STORE_NAME[x.name] || x.name) + '</span>').join('') : '';
    let scope = '';
    if (X && X.hex) {
      const plain = JSON.stringify(probe && probe.ok ? { ip: probe.ip, country: probe.country, city: probe.city } : { route: 'no answer yet' });
      scope = '<div class="scope"><div class="pt" title="what goes in">' + esc(plain.slice(0, 64)) + '</div><div class="ar">ChaCha' + X.rounds + ' · ꟻX meowcore · ' + X.ms + ' ms · ' + (X.opens ? 'opens again ✓' : 'did not open ✗') + '</div><div class="hx">' +
        X.hex.match(/../g).map((b, k) => { const v = parseInt(b, 16); return '<i style="--v:' + (v / 255).toFixed(2) + ';animation-delay:' + (k * 6) + 'ms">' + b + '</i>'; }).join('') + '</div>' +
        '<small class="muted">nonce ' + X.nonce + ' · tag ' + X.tag + '…</small></div>';
    }
    el.innerHTML = (I ? '<div class="kv"><span>Key</span><code>' + esc(I.print) + ' · kept by Windows for your account</code></div><div class="stos">' + stores + '</div>' : '') + scope;
  }
  async function sample() {
    const text = JSON.stringify(probe && probe.ok ? { ip: probe.ip, country: probe.country, city: probe.city, org: probe.organization, at: probe.time } : { route: 'no answer yet', at: Date.now() / 1000 | 0 });
    sealSample = await ask('seal', { op: 'sample', text }); drawSeal();
  }
  async function sealStatus() { sealInfo = await ask('seal', { op: 'status' }); drawSeal(); }

  function page(p) {
    pane = p; const m = mask();
    p.innerHTML = head('', 'Mask') +
      '<small class="muted">Four layers, each with its own lever. Click a country to see free ways to leave from there.</small>' +
      '<div class="mapw" id="mapw"><svg id="mmap" viewBox="0 0 ' + (window.WORLD ? WORLD.w : 1000) + ' ' + (window.WORLD ? WORLD.h : 392) + '" role="img" aria-label="World map">' + svgBase() +
      '<g id="mpin" style="display:none"><circle r="9" class="pr"/><circle r="3.2" class="pc"/></g></svg><div id="mpop" class="mpop" hidden></div>' +
      '<div class="mleg"><span><i class="fr"></i>free VPN plan</span><span><i class="ex"></i>traffic leaves here</span><span><i class="sel"></i>your pick</span></div></div>' +
      '<div class="chs">' +
      // Route
      '<section class="ch" id="ch-route"><header><span class="led"></span><b>Route</b><small>where pages leave from</small>' + lever('lv-route', m.routeOn, 'Route on or off') + '</header>' +
      '<div class="ctl">' + knob('k-check', 'Check every', ['off', '1 min', '5 min', '15 min'], Math.max(0, CHECK.indexOf(m.check))) +
      '<div class="cb"><button class="btn sm" id="b-check">Check now</button><small class="muted">asks am.i.mullvad.net, through the route</small></div></div><div class="ro" id="ro-route"></div></section>' +
      // Match
      '<section class="ch" id="ch-match"><header><span class="led"></span><b>Match</b><small>the costume follows the exit</small>' + lever('lv-match', m.match.on, 'Match on or off') + '</header>' +
      '<div class="ctl"><div class="las">' + latch('la-tz', m.match.tz, 'Clock', 'Time zone of the exit country') + latch('la-lang', m.match.lang, 'Language', 'Language of the exit country') + '</div>' +
      knob('k-geo', 'Location', ['real', 'refuse', 'near exit'], ['real', 'deny', 'fake'].indexOf(m.match.geo)) + knob('k-blur', 'Blur', ['<1 km', '5 km', '25 km', '100 km'], m.match.blur) + '</div><div class="ro" id="ro-match"></div></section>' +
      // Fuzz
      '<section class="ch" id="ch-fuzz"><header><span class="led"></span><b>Fuzz</b><small>what other sites hear</small>' + lever('lv-fuzz', m.fuzz.on, 'Fuzz on or off') + '</header>' +
      '<div class="ctl"><label class="sl"><span>Where you came from</span><input type="range" id="s-ref" min="0" max="2" step="1" value="' + m.fuzz.ref + '"><span class="tk"><i>full</i><i>site</i><i>none</i></span></label>' +
      '<div class="las">' + latch('la-flang', m.fuzz.lang, 'One language', 'Send only your first language') + latch('la-hints', m.fuzz.hints, 'Keep hints home', 'Other sites don\'t get exact versions, CPU or model') + '</div></div><div class="ro" id="ro-fuzz"></div></section>' +
      // Seal
      '<section class="ch" id="ch-seal"><header><span class="led"></span><b>Seal</b><small>ChaCha in ꟻX, on what Meowzer keeps</small>' + lever('lv-seal', m.seal.on, 'Seal on or off') + '</header>' +
      '<div class="ctl">' + knob('k-rounds', 'Rounds', ['8', '12', '20'], Math.max(0, ROUNDS.indexOf(m.seal.rounds))) +
      '<div class="las chips">' + Object.keys(STORE_NAME).map(k => latch('st-' + k, m.seal.stores.includes(k), STORE_NAME[k], 'Seal ' + STORE_NAME[k].toLowerCase())).join('') + '</div>' +
      '<div class="cb row2"><button class="btn sm" id="b-rekey" title="Make a new key and seal everything again under it">New key</button><button class="btn sm" id="b-sample" title="Seal the route\'s latest answer again (a new nonce: new bytes)">Seal again</button></div></div><div class="ro" id="ro-seal"></div></section>' +
      '</div><small class="muted">What this does and doesn\'t: the Route hides your address only while a route is live, and only from sites (the route\'s operator sees your traffic). Pages already travel encrypted by HTTPS; the Seal protects what Meowzer stores on this computer, so another account or a copied disk can\'t read it. Free plans and their countries are as listed in 2025.</small>';

    // map
    const box = $('#mmap', p);
    box.onclick = e => { const t = e.target.closest('[data-n]'); if (t) popover(t.dataset.n, e); else $('#mpop', p).hidden = true; };
    $('#mpop', p).onclick = e => {
      const l = e.target.closest('[data-link]'); if (l) { e.preventDefault(); Host.send({ t: 'newtab', url: l.dataset.link }); return; }
      const g = e.target.closest('[data-go]'); if (!g) return; const iso = $('#mpop', p).dataset.iso;
      if (g.dataset.go === 'close') { $('#mpop', p).hidden = true; return; }
      useRoute(g.dataset.go, iso);
    };
    // Route
    wireLever(p, 'lv-route', on => {
      if (on && m.route.mode === 'direct') { toast('Pick a country on the map first.'); return false; }
      m.routeOn = on; save(); applyRoute(); drawRoute(); drawMap(); if (on) check(); });
    wireKnob(p, 'k-check', ['off', '1 min', '5 min', '15 min'], i => { m.check = CHECK[i]; save(); });
    $('#b-check', p).onclick = () => { $('#ro-route', p).insertAdjacentHTML('afterbegin', '<div class="st">checking…</div>'); check(); };
    // Match
    wireLever(p, 'lv-match', on => { m.match.on = on;
      if (on && S.settings.costume === 'off') { S.settings.costume = 'session'; toast('The costume is on for this session, so there is something to dress.'); newSessionPersona().then(() => { dressed = ''; maybeDress(); }); }
      save(); maybeDress(); drawMatch(); });
    wireLatch(p, 'la-tz', v => { m.match.tz = v; save(); maybeDress(); drawMatch(); });
    wireLatch(p, 'la-lang', v => { m.match.lang = v; save(); maybeDress(); drawMatch(); });
    wireKnob(p, 'k-geo', ['real', 'refuse', 'near exit'], i => { m.match.geo = ['real', 'deny', 'fake'][i]; save(); maybeDress(); drawMatch(); });
    wireKnob(p, 'k-blur', ['<1 km', '5 km', '25 km', '100 km'], i => { m.match.blur = i; save(); maybeDress(); drawMatch(); });
    // Fuzz
    wireLever(p, 'lv-fuzz', on => { m.fuzz.on = on; save(); drawFuzz(); });
    $('#s-ref', p).oninput = e => { m.fuzz.ref = +e.target.value; save(); drawFuzz(); };
    wireLatch(p, 'la-flang', v => { m.fuzz.lang = v; save(); drawFuzz(); });
    wireLatch(p, 'la-hints', v => { m.fuzz.hints = v; save(); drawFuzz(); });
    // Seal: each change rewrites the stores the new way (the host does it), then the readout catches up
    const later = () => setTimeout(sealStatus, 900);
    wireLever(p, 'lv-seal', on => { m.seal.on = on; save(); later(); if (on) sample(); });
    wireKnob(p, 'k-rounds', ['8', '12', '20'], i => { m.seal.rounds = ROUNDS[i]; save(); later(); sample(); });
    Object.keys(STORE_NAME).forEach(k => wireLatch(p, 'st-' + k, v => { const s = new Set(m.seal.stores); v ? s.add(k) : s.delete(k); m.seal.stores = [...s]; save(); later(); }));
    $('#b-rekey', p).onclick = async () => { if (!confirm('Make a new seal key and seal everything again under it? The old key is thrown away.')) return; await ask('seal', { op: 'rekey' }); sealStatus(); sample(); toast('🔑 New key'); };
    $('#b-sample', p).onclick = sample;

    drawRoute(); drawMatch(); drawFuzz(); drawMap(); sealStatus(); sample();
    if (!probe && m.routeOn) check();
  }
  function start() { mask(); }

  const css = document.createElement('style');
  css.textContent = `
.mapw{position:relative;border:1px solid var(--border);border-radius:10px;background:var(--canvas)}
#mmap{display:block;width:100%;height:auto;border-radius:10px}
#mmap path,#mmap circle.dot{fill:var(--surface2);stroke:var(--canvas);stroke-width:.6;cursor:pointer;transition:fill .15s}
#mmap path.fr,#mmap circle.dot.fr{fill:color-mix(in srgb,var(--accent) 30%,var(--surface2))}
#mmap path:hover,#mmap circle.dot:hover{fill:color-mix(in srgb,var(--fg) 25%,var(--surface2))}
#mmap path.fr:hover{fill:color-mix(in srgb,var(--accent) 55%,var(--surface2))}
#mmap .sel{fill:color-mix(in srgb,var(--pink) 60%,var(--surface2))!important}
#mmap .ex{fill:var(--good)!important;filter:drop-shadow(0 0 4px var(--good))}
#mpin .pr{fill:none;stroke:var(--good);stroke-width:1.5;animation:mpr 2.2s ease-out infinite;transform-box:fill-box;transform-origin:center}#mpin .pc{fill:var(--good)}
@keyframes mpr{0%{transform:scale(.4);opacity:1}100%{transform:scale(2.2);opacity:0}}
.mleg{position:absolute;left:8px;bottom:6px;display:flex;gap:10px;font-size:10px;color:var(--muted);pointer-events:none}
.mleg i{display:inline-block;width:9px;height:9px;border-radius:2px;margin-right:4px;vertical-align:-1px}
.mleg .fr{background:color-mix(in srgb,var(--accent) 30%,var(--surface2))}.mleg .ex{background:var(--good)}.mleg .sel{background:color-mix(in srgb,var(--pink) 60%,var(--surface2))}
.mpop{position:absolute;width:280px;max-height:300px;overflow:auto;background:var(--surface);border:1px solid var(--border);border-radius:10px;box-shadow:0 10px 30px rgba(0,0,0,.45);padding:10px;display:flex;flex-direction:column;gap:8px;z-index:2}
.mpop[hidden]{display:none}
.mpop h4{display:flex;align-items:center;gap:8px;font-size:13px}.mpop h4 .x{margin-left:auto;color:var(--muted);font-size:16px;padding:0 4px}
.iso{display:inline-flex;align-items:center;justify-content:center;min-width:24px;height:16px;padding:0 4px;border-radius:4px;background:var(--surface2);border:1px solid var(--border);font:700 10px/1 var(--mono);color:var(--fg)}
.mo{border:1px solid var(--border);border-radius:8px;padding:8px;display:flex;flex-direction:column;gap:5px;background:var(--canvas)}
.mo>div:first-child{display:flex;align-items:baseline;gap:6px}.mo .kind{margin-left:auto;font-size:10px}.mo p{color:var(--muted);font-size:11px;margin:0}
.mo .row0{display:flex;justify-content:flex-end}.mo .lnk{font-size:11px;color:var(--accent2)}
.chs{display:grid;grid-template-columns:1fr 1fr;gap:10px}
@media (max-width:700px){.chs{grid-template-columns:1fr}}
.ch{border:1px solid var(--border);border-radius:10px;background:var(--canvas);padding:10px;display:flex;flex-direction:column;gap:8px;transition:border-color .2s,box-shadow .2s}
.ch header{display:flex;align-items:center;gap:7px}.ch header small{color:var(--muted);font-size:10.5px;flex:1}
.ch .led{width:8px;height:8px;border-radius:50%;background:var(--border);flex:none;transition:background .2s,box-shadow .2s}
.ch.on .led{background:var(--warn)}.ch.live .led{background:var(--good);box-shadow:0 0 8px var(--good)}
.ch.live{border-color:color-mix(in srgb,var(--good) 45%,var(--border))}
.ch:not(.on) .ctl{opacity:.55}
.ctl{display:flex;align-items:center;gap:10px;flex-wrap:wrap;transition:opacity .2s}
.cb{display:flex;flex-direction:column;gap:4px;align-items:flex-start;flex:1;min-width:120px}.cb.row2{flex-direction:row;flex-wrap:wrap}.cb small{font-size:10px}.cb .btn+.btn{margin-top:2px}
.ro{border-top:1px dashed var(--border);padding-top:7px;font-size:11.5px;display:flex;flex-direction:column;gap:5px;min-height:38px}
.ro .rl{color:var(--muted);font-size:11px}.ro .big{font-size:14px;font-weight:700;display:flex;align-items:center;gap:7px}.ro .big.dim{color:var(--muted);font-weight:400;font-size:12px}
.kv{display:grid;grid-template-columns:auto 1fr;gap:2px 10px;align-items:baseline}.kv span{color:var(--muted);font-size:10.5px}.kv code{font:11px var(--mono);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;user-select:text}.kv code.w{color:var(--warn)}
.st{color:var(--muted);font-size:11px}.st.ok{color:var(--good)}.st.w{color:var(--warn)}
.lv{width:22px;height:38px;border-radius:11px;background:var(--surface2);border:1px solid var(--border);position:relative;flex:none;box-shadow:inset 0 2px 5px rgba(0,0,0,.35)}
.lv i{position:absolute;left:2px;right:2px;height:16px;bottom:2px;border-radius:8px;background:linear-gradient(180deg,var(--fg),var(--muted));box-shadow:0 2px 3px rgba(0,0,0,.4);transition:bottom .18s cubic-bezier(.3,1.4,.6,1)}
.lv.on{background:color-mix(in srgb,var(--good) 35%,var(--surface2));border-color:var(--good)}.lv.on i{bottom:18px}
.lv:focus-visible,.kn:focus-visible,.la:focus-visible{outline:2px solid var(--accent2);outline-offset:2px}
.kn{display:flex;flex-direction:column;align-items:center;width:64px;cursor:ns-resize;touch-action:none;border-radius:8px;outline:0}
.kn svg{width:46px;height:46px}.kn b{font-size:10px;font-weight:700;margin-top:-2px}.kn small{font-size:10px;color:var(--accent);font-family:var(--mono)}
.kn .kb{fill:var(--surface2);stroke:var(--border);stroke-width:1.5}.kn:hover .kb{stroke:var(--muted)}
.kn .kp{transform-origin:30px 30px;transition:transform .15s ease-out}.kn .kp line{stroke:var(--accent);stroke-width:3;stroke-linecap:round}
.kn .kt{stroke:var(--border);stroke-width:2;stroke-linecap:round}.kn .kt.on{stroke:var(--accent)}
.las{display:flex;flex-wrap:wrap;gap:5px}.las.chips{flex:1 1 100%}
.la{display:inline-flex;align-items:center;gap:6px;padding:4px 9px;border:1px solid var(--border);border-radius:6px;background:var(--surface2);font-size:11px;color:var(--muted);box-shadow:0 2px 0 var(--border);transition:transform .06s,box-shadow .06s}
.la i{width:6px;height:6px;border-radius:50%;background:var(--border)}.la.on{color:var(--fg);transform:translateY(1px);box-shadow:0 1px 0 var(--border)}.la.on i{background:var(--good);box-shadow:0 0 5px var(--good)}
.sl{display:flex;flex-direction:column;gap:3px;flex:1 1 100%;font-size:11px}.sl>span:first-child{color:var(--muted);font-size:10.5px}
.sl input[type=range]{width:100%;accent-color:var(--accent)}.sl .tk{display:flex;justify-content:space-between;font-size:10px;color:var(--muted)}
.stos{display:flex;flex-wrap:wrap;gap:4px}.sto{font-size:10px;padding:1px 6px;border-radius:4px;border:1px solid var(--border);color:var(--muted)}.sto.on{color:var(--good);border-color:color-mix(in srgb,var(--good) 50%,var(--border))}
.scope{display:flex;flex-direction:column;gap:4px;margin-top:2px}
.scope .pt{font:10.5px var(--mono);color:var(--fg);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.scope .ar{font-size:10px;color:var(--accent)}
.scope .hx{display:grid;grid-template-columns:repeat(16,1fr);gap:1px;font:9.5px/1.5 var(--mono)}
.scope .hx i{font-style:normal;text-align:center;border-radius:2px;color:var(--fg);background:color-mix(in srgb,var(--accent) calc(var(--v)*55%),var(--surface2));animation:hxin .35s ease-out both}
@keyframes hxin{from{opacity:0;transform:translateY(-3px)}}
@media (prefers-reduced-motion:reduce){#mpin .pr,.scope .hx i{animation:none}}`;
  document.head.appendChild(css);
  return { page, start, dress, onProbe, mask, C };
})();
function pMask(p) { MASK.page(p); }
