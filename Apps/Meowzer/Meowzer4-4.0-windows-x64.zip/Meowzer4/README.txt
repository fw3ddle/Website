Meowzer 4 for Windows 10/11 (x64)

Install: double-click Install.cmd. It copies Meowzer to your user folder, adds it to the Start menu and Settings > Apps (no admin needed).
Or just run Meowzer\Meowzer.exe from anywhere.
Uninstall: Settings > Apps > Meowzer 4, or: powershell -File "%LOCALAPPDATA%\Programs\Meowzer4\install.ps1" -Uninstall
Needs the WebView2 Runtime (already part of Windows 11).
