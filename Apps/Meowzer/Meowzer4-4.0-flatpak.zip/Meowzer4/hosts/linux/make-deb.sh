#!/bin/sh
# Builds meowzer4_<version>_<arch>.deb for Debian and Ubuntu:  ./make-deb.sh   then   sudo apt install ./meowzer4_*.deb
set -e
cd "$(dirname "$0")"
VER=4.0.0
ARCH=$(dpkg --print-architecture)
sudo apt-get install -y build-essential pkg-config libgtk-3-dev libwebkit2gtk-4.1-dev libjson-glib-dev
make
rm -rf pkg && make install DESTDIR="$PWD/pkg" PREFIX=/usr
mkdir -p pkg/DEBIAN
cat > pkg/DEBIAN/control <<EOF
Package: meowzer4
Version: $VER
Architecture: $ARCH
Maintainer: Meowzer
Depends: libgtk-3-0, libwebkit2gtk-4.1-0 (>= 2.42), libjson-glib-1.0-0
Section: web
Priority: optional
Description: A private browser with a cat that blocks trackers
 Meowzer blocks ads and trackers, burns cookies when you leave a site unless you
 keep them in the jar, keeps logins in a locked vault, and opens pictures, PDFs,
 sound, video, code and ꟻX bundles. Pages are drawn by WebKitGTK.
EOF
dpkg-deb --build --root-owner-group pkg "meowzer4_${VER}_${ARCH}.deb"
echo "Built meowzer4_${VER}_${ARCH}.deb  —  install it with:  sudo apt install ./meowzer4_${VER}_${ARCH}.deb"
