// meowzer-webext.c — runs inside each WebKitGTK web process and decides every request, like the Windows host's
// WebResourceRequested handler: the request's host and each parent domain are hashed (FNV-1a 64, lowercased, the
// same hash as meowcore) and looked up in the table meowcore compiled (table.txt in the data folder):
//   b HASH  block, first or third party      t HASH  block when another site loads it
//   a HASH  never block (exceptions win)     p HASH  strip this query parameter
// The host passes the table's path as the initialization data, and sends "table" when it changes.
#include <webkit2/webkit-web-extension.h>
#include <string.h>
#include <stdlib.h>

static GHashTable *B, *T, *A, *P;   // hash -> 1
static char *gTablePath;

static guint64 fnv(const char *s, size_t n) {
  guint64 h = 0xcbf29ce484222325ULL;
  for (size_t i = 0; i < n; i++) { unsigned char c = (unsigned char)s[i]; if (c >= 'A' && c <= 'Z') c += 32; h ^= c; h *= 0x100000001b3ULL; }
  return h;
}
static void load_table(void) {
  if (!B) { B = g_hash_table_new_full(g_int64_hash, g_int64_equal, g_free, NULL); T = g_hash_table_new_full(g_int64_hash, g_int64_equal, g_free, NULL);
            A = g_hash_table_new_full(g_int64_hash, g_int64_equal, g_free, NULL); P = g_hash_table_new_full(g_int64_hash, g_int64_equal, g_free, NULL); }
  g_hash_table_remove_all(B); g_hash_table_remove_all(T); g_hash_table_remove_all(A); g_hash_table_remove_all(P);
  char *txt = NULL; if (!gTablePath || !g_file_get_contents(gTablePath, &txt, NULL, NULL)) return;
  for (char *l = strtok(txt, "\n"); l; l = strtok(NULL, "\n")) {
    if (l[0] && l[1] == ' ' && strchr("btap", l[0])) {
      gint64 *k = g_new(gint64, 1); *k = (gint64)g_ascii_strtoull(l + 2, NULL, 16);
      g_hash_table_add(l[0] == 'b' ? B : l[0] == 't' ? T : l[0] == 'a' ? A : P, k);
    }
  }
  g_free(txt);
}
static int has(GHashTable *t, guint64 h) { gint64 k = (gint64)h; return g_hash_table_contains(t, &k); }
// the host itself, then each parent domain: a.b.example.com, b.example.com, example.com, com
static int lookup(GHashTable *t, const char *host) {
  for (const char *p = host; p && *p; ) { if (has(t, fnv(p, strlen(p)))) return 1; p = strchr(p, '.'); if (p) p++; }
  return 0;
}
static const char *SFX[] = {"co.uk","org.uk","ac.uk","gov.uk","co.jp","ne.jp","or.jp","com.au","net.au","org.au","co.nz","com.br","com.mx","co.in","co.za","com.tr","com.cn","com.tw","co.kr","github.io","blogspot.com","herokuapp.com","vercel.app","netlify.app","pages.dev",NULL};
static char *site_of(const char *h) {
  char **p = g_strsplit(h, ".", -1); int n = g_strv_length(p); char *r;
  if (n < 3) r = g_strdup(h);
  else { char *two = g_strjoin(".", p[n - 2], p[n - 1], NULL); int s = 0; for (int i = 0; SFX[i]; i++) if (!g_ascii_strcasecmp(SFX[i], two)) s = 1;
    r = s ? g_strjoin(".", p[n - 3], p[n - 2], p[n - 1], NULL) : two; if (s) g_free(two); }
  g_strfreev(p); return r;
}
// take tracking parameters off an address; returns a new string, or NULL if nothing was taken
static char *lick(const char *uri) {
  const char *q = strchr(uri, '?'); if (!q || !g_hash_table_size(P)) return NULL;
  const char *hash = strchr(q, '#'); GString *out = g_string_new_len(uri, q - uri); int kept = 0, gone = 0;
  char *query = g_strndup(q + 1, hash ? (size_t)(hash - q - 1) : strlen(q + 1)); char **parts = g_strsplit(query, "&", -1);
  for (char **x = parts; *x; x++) { const char *eq = strchr(*x, '='); size_t n = eq ? (size_t)(eq - *x) : strlen(*x);
    if (n && has(P, fnv(*x, n))) { gone++; continue; } g_string_append_c(out, kept++ ? '&' : '?'); g_string_append(out, *x); }
  if (hash) g_string_append(out, hash);
  g_strfreev(parts); g_free(query);
  if (!gone) { g_string_free(out, TRUE); return NULL; }
  return g_string_free(out, FALSE);
}

static gboolean on_send_request(WebKitWebPage *page, WebKitURIRequest *req, WebKitURIResponse *redirect, gpointer d) {
  const char *uri = webkit_uri_request_get_uri(req);
  if (!g_str_has_prefix(uri, "http")) return FALSE;
  GUri *u = g_uri_parse(uri, G_URI_FLAGS_NONE, NULL); if (!u) return FALSE;
  char *host = g_ascii_strdown(g_uri_get_host(u) ? g_uri_get_host(u) : "", -1); g_uri_unref(u);
  const char *top = webkit_web_page_get_uri(page); GUri *tu = top ? g_uri_parse(top, G_URI_FLAGS_NONE, NULL) : NULL;
  char *topHost = g_ascii_strdown(tu && g_uri_get_host(tu) ? g_uri_get_host(tu) : "", -1); if (tu) g_uri_unref(tu);
  char *s1 = site_of(host), *s2 = site_of(topHost); int third = *topHost && strcmp(s1, s2);
  int block = !lookup(A, host) && (lookup(B, host) || (third && lookup(T, host)));
  if (block) {
    webkit_web_page_send_message_to_view(page, webkit_user_message_new("blocked", g_variant_new_string(host)), NULL, NULL, NULL);
  } else { char *clean = lick(uri); if (clean) { webkit_uri_request_set_uri(req, clean); g_free(clean); } }
  g_free(host); g_free(topHost); g_free(s1); g_free(s2);
  return block;   // TRUE stops the request
}
static void on_page(WebKitWebExtension *ext, WebKitWebPage *page, gpointer d) { g_signal_connect(page, "send-request", G_CALLBACK(on_send_request), NULL); }
static gboolean on_message(WebKitWebExtension *ext, WebKitUserMessage *m, gpointer d) { if (!strcmp(webkit_user_message_get_name(m), "table")) load_table(); return TRUE; }

G_MODULE_EXPORT void webkit_web_extension_initialize_with_user_data(WebKitWebExtension *ext, GVariant *data) {
  gTablePath = g_strdup(g_variant_get_string(data, NULL)); load_table();
  g_signal_connect(ext, "page-created", G_CALLBACK(on_page), NULL);
  g_signal_connect(ext, "user-message-received", G_CALLBACK(on_message), NULL);
}
