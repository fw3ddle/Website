// meowzer-linux.c — Meowzer 4 on Linux: GTK 3 + WebKitGTK (webkit2gtk-4.1, 2.42 or newer).
//
// The same face, page script and meowcore as Windows (see hosts/PROTOCOL.md). One window: the face on top, a
// stack of page views (one per tab) below. Per-request blocking happens in the web process, in
// meowzer-webext.c, which reads the table meowcore compiled. This host does tabs, the face's messages, meowcore
// batches, settings and the jar, history, downloads, opening files, and the vault.
//
// Status: written to the same protocol as the Windows host, but not yet built or run on Linux here (the PC this was
// written on has no Linux). Not done yet compared with Windows: tiling, the bookshelf, the cookie sweep (the oven),
// the costume's per-site data, the Mask page's probes and Tor route, ghost pages.
#include <gtk/gtk.h>
#include <webkit2/webkit2.h>
#include <json-glib/json-glib.h>
#include <sys/random.h>
#include <sys/stat.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define WORLD "meowzer"
static GtkWidget *gWin, *gBox, *gFace, *gStack;
static WebKitWebContext *gCtx;
static WebKitUserContentManager *gPageUcm;
static char *gData, *gUi, *gCore, *gKey;      // folders, meowcore's path, the page bridge's event name
static JsonNode *gSettings, *gJar, *gVault;
static int gFaceH = 78, gNextTab = 1, gActive = 0, gFaceReady = 0, gOverlay = 0, gVaultBroken = 0;
static char *gTableStats;
typedef struct { int id; WebKitWebView *v; char *url, *title; int loading, back, fwd; } Tab;
static GPtrArray *gTabs;

// ------------------------------------------------------------------------------------------- small things
static char *path_in(const char *dir, const char *name) { return g_build_filename(dir, name, NULL); }
static char *read_text(const char *p) { char *s = NULL; g_file_get_contents(p, &s, NULL, NULL); return s; }
static GBytes *read_bytes(const char *p) { char *s = NULL; gsize n = 0; if (!g_file_get_contents(p, &s, &n, NULL)) return NULL; return g_bytes_new_take(s, n); }
static void write_file(const char *p, const void *d, gsize n, int private_) {
  g_file_set_contents(p, d, n, NULL); if (private_) chmod(p, 0600);
}
static void q(GString *s, const char *v) {   // a JSON string
  g_string_append_c(s, '"');
  for (const unsigned char *c = (const unsigned char *)(v ? v : ""); *c; c++) {
    if (*c == '"' || *c == '\\') { g_string_append_c(s, '\\'); g_string_append_c(s, *c); }
    else if (*c == '\n') g_string_append(s, "\\n"); else if (*c == '\r') g_string_append(s, "\\r"); else if (*c == '\t') g_string_append(s, "\\t");
    else if (*c < 0x20) g_string_append_printf(s, "\\u%04x", *c); else g_string_append_c(s, *c);
  }
  g_string_append_c(s, '"');
}
static char *qs(const char *v) { GString *s = g_string_new(NULL); q(s, v); return g_string_free(s, FALSE); }
static char *dump(JsonNode *n) { return n ? json_to_string(n, FALSE) : g_strdup("null"); }
static JsonNode *parse(const char *t) { if (!t) return NULL; JsonParser *p = json_parser_new(); JsonNode *r = NULL; if (json_parser_load_from_data(p, t, -1, NULL)) r = json_node_copy(json_parser_get_root(p)); g_object_unref(p); return r; }
static JsonObject *obj(JsonNode *n) { return n && JSON_NODE_HOLDS_OBJECT(n) ? json_node_get_object(n) : NULL; }
static const char *gs(JsonObject *o, const char *k) { return o && json_object_has_member(o, k) && JSON_NODE_HOLDS_VALUE(json_object_get_member(o, k)) && json_node_get_value_type(json_object_get_member(o, k)) == G_TYPE_STRING ? json_object_get_string_member(o, k) : ""; }
static gint64 gi(JsonObject *o, const char *k, gint64 d) { if (!o || !json_object_has_member(o, k)) return d; JsonNode *n = json_object_get_member(o, k); if (!JSON_NODE_HOLDS_VALUE(n)) return d;
  GType t = json_node_get_value_type(n); return t == G_TYPE_INT64 ? json_node_get_int(n) : t == G_TYPE_DOUBLE ? (gint64)json_node_get_double(n) : t == G_TYPE_BOOLEAN ? json_node_get_boolean(n) : d; }
static int gb(JsonObject *o, const char *k) { return gi(o, k, 0) != 0; }
static JsonObject *sub(JsonObject *o, const char *k) { return o && json_object_has_member(o, k) ? obj(json_object_get_member(o, k)) : NULL; }
static char *hex(const guint8 *d, gsize n) { char *s = g_malloc(n * 2 + 1); for (gsize i = 0; i < n; i++) sprintf(s + 2 * i, "%02x", d[i]); s[n * 2] = 0; return s; }
static GByteArray *unhex(const char *s) { GByteArray *a = g_byte_array_new(); for (; s[0] && s[1]; s += 2) { unsigned v; if (sscanf(s, "%2x", &v) != 1) break; guint8 b = v; g_byte_array_append(a, &b, 1); } return a; }
static void rnd(guint8 *d, gsize n) { while (n) { ssize_t k = getrandom(d, n, 0); if (k <= 0) continue; d += k; n -= k; } }
static char *rnd_hex(gsize n) { guint8 *b = g_malloc(n); rnd(b, n); char *h = hex(b, n); g_free(b); return h; }

// FNV-1a 64 over lowercased bytes and the registrable domain: the same rules as meowcore and inject.js
static const char *SFX[] = {"co.uk","org.uk","ac.uk","gov.uk","co.jp","ne.jp","or.jp","com.au","net.au","org.au","co.nz","com.br","com.mx","co.in","co.za","com.tr","com.cn","com.tw","co.kr","github.io","blogspot.com","herokuapp.com","vercel.app","netlify.app","pages.dev",NULL};
static char *site_of(const char *host) {
  char *h = g_ascii_strdown(host ? host : "", -1); while (*h == '.') memmove(h, h + 1, strlen(h));
  char **p = g_strsplit(h, ".", -1); int n = g_strv_length(p); char *r;
  if (n < 3) r = g_strdup(h);
  else { char *two = g_strjoin(".", p[n - 2], p[n - 1], NULL); int s = 0; for (int i = 0; SFX[i]; i++) if (!strcmp(SFX[i], two)) s = 1;
    r = s ? g_strjoin(".", p[n - 3], p[n - 2], p[n - 1], NULL) : two; if (s) g_free(two); }
  g_strfreev(p); g_free(h); return r;
}
static char *host_of(const char *url) { GUri *u = g_uri_parse(url, G_URI_FLAGS_NONE, NULL); if (!u) return g_strdup(""); char *h = g_strdup(g_uri_get_host(u) ? g_uri_get_host(u) : ""); g_uri_unref(u); return h; }
static char *origin_of(const char *url) { GUri *u = g_uri_parse(url, G_URI_FLAGS_NONE, NULL); if (!u || !g_uri_get_host(u)) { if (u) g_uri_unref(u); return g_strdup(""); }
  int port = g_uri_get_port(u); char *o = port > 0 ? g_strdup_printf("%s://%s:%d", g_uri_get_scheme(u), g_uri_get_host(u), port) : g_strdup_printf("%s://%s", g_uri_get_scheme(u), g_uri_get_host(u));
  char *l = g_ascii_strdown(o, -1); g_free(o); g_uri_unref(u); return l; }

// ------------------------------------------------------------------------------------------- meowcore
static char *run_core(const char *script) {
  const char *argv[] = {gCore, NULL}; GError *e = NULL;
  GSubprocess *p = g_subprocess_newv(argv, G_SUBPROCESS_FLAGS_STDIN_PIPE | G_SUBPROCESS_FLAGS_STDOUT_PIPE | G_SUBPROCESS_FLAGS_STDERR_SILENCE, &e);
  if (!p) { g_clear_error(&e); return g_strdup(""); }
  char *out = NULL; g_subprocess_communicate_utf8(p, script, NULL, &out, NULL, &e); g_clear_error(&e); g_object_unref(p);
  return out ? out : g_strdup("");
}

// ------------------------------------------------------------------------------------------- talking to the face and pages
static void to_view(WebKitWebView *v, const char *world, const char *js) { webkit_web_view_evaluate_javascript(v, js, -1, world, NULL, NULL, NULL, NULL); }
static void to_face(const char *json) {
  if (!gFace || !gFaceReady) return;
  char *js = g_strdup_printf("window.meowReceive(%s)", json); to_view(WEBKIT_WEB_VIEW(gFace), NULL, js); g_free(js);
}
static void to_page(Tab *t, const char *json) {   // into inject.js's own world, as the event only it listens for
  char *k = qs(gKey), *js = g_strdup_printf("document.dispatchEvent(new CustomEvent(%s,{detail:%s}))", k, json);
  to_view(t->v, WORLD, js); g_free(js); g_free(k);
}
static void reply(const char *t, gint64 id, const char *data) { char *s = g_strdup_printf("{\"t\":\"%s\",\"id\":%" G_GINT64_FORMAT ",\"data\":%s}", t, id, data); to_face(s); g_free(s); }
static Tab *tab_by_id(int id) { for (guint i = 0; i < gTabs->len; i++) { Tab *t = g_ptr_array_index(gTabs, i); if (t->id == id) return t; } return NULL; }
static Tab *tab_by_view(WebKitWebView *v) { for (guint i = 0; i < gTabs->len; i++) { Tab *t = g_ptr_array_index(gTabs, i); if (t->v == v) return t; } return NULL; }
static void push_state(void) {
  GString *s = g_string_new(NULL); g_string_append_printf(s, "{\"t\":\"state\",\"active\":%d,\"tabs\":[", gActive);
  for (guint i = 0; i < gTabs->len; i++) { Tab *t = g_ptr_array_index(gTabs, i); if (i) g_string_append_c(s, ',');
    g_string_append_printf(s, "{\"id\":%d,\"url\":", t->id); q(s, t->url); g_string_append(s, ",\"title\":"); q(s, t->title);
    g_string_append_printf(s, ",\"favicon\":\"\",\"loading\":%s,\"canBack\":%s,\"canFwd\":%s}", t->loading ? "true" : "false", t->back ? "true" : "false", t->fwd ? "true" : "false"); }
  g_string_append(s, "]}"); to_face(s->str); g_string_free(s, TRUE);
  Tab *a = tab_by_id(gActive); char *title = g_strdup_printf("%s%sMeowzer", a && a->title && *a->title ? a->title : "", a && a->title && *a->title ? " — " : "");
  gtk_window_set_title(GTK_WINDOW(gWin), title); g_free(title);
}

// ------------------------------------------------------------------------------------------- storage
static void save_json(const char *name, JsonNode *n) { char *p = path_in(gData, name), *s = dump(n); write_file(p, s, strlen(s), 1); g_free(s); g_free(p); }
static JsonNode *load_json(const char *name) { char *p = path_in(gData, name), *s = read_text(p); JsonNode *n = parse(s); g_free(s); g_free(p);
  if (!obj(n)) { if (n) json_node_unref(n); n = json_node_new(JSON_NODE_OBJECT); json_node_take_object(n, json_object_new()); } return n; }

// the theme: the window's own background from themeVars.frame (else the palette's surface)
static GtkCssProvider *gCss;
static void paint_frame(void) {
  JsonObject *tv = sub(obj(gSettings), "themeVars"); const char *f = gs(tv, "frame"); if (!*f) f = gs(tv, "surface");
  if (!*f) f = !strcmp(gs(obj(gSettings), "theme"), "light") ? "#f4f8f6" : "#111b18";
  char *css = g_strdup_printf("window{background:%s}", f); gtk_css_provider_load_from_data(gCss, css, -1, NULL); g_free(css);
}

// ------------------------------------------------------------------------------------------- the blocker table
static void compile_table(void) {
  GString *s = g_string_new("@table\n");
  char *lp = path_in(gUi, "../lists/meowlist.txt"), *l = read_text(lp); if (l) g_string_append(s, l); g_free(l); g_free(lp);
  const char *custom = gs(obj(gSettings), "customRules"); if (*custom) { g_string_append_c(s, '\n'); g_string_append(s, custom); }
  char *dl = path_in(gData, "lists.txt"), *d = read_text(dl); if (d) { g_string_append_c(s, '\n'); g_string_append(s, d); } g_free(d); g_free(dl);
  g_string_append(s, "\n@end\n");
  char *out = run_core(s->str); g_string_free(s, TRUE);
  char *tp = path_in(gData, "table.txt"); write_file(tp, out, strlen(out), 0); g_free(tp);
  int b = 0, c = 0, p = 0; for (char *x = out; *x; x++) if (x == out || x[-1] == '\n') { if (*x == 'b' || *x == 't') b++; else if (*x == 'c') c++; else if (*x == 'p') p++; }
  g_free(gTableStats); gTableStats = g_strdup_printf("# %d hosts, %d cosmetic rules, %d parameters", b, c, p); g_free(out);
  webkit_web_context_send_message_to_all_extensions(gCtx, webkit_user_message_new("table", NULL));   // the web processes reload it
}

// ------------------------------------------------------------------------------------------- tabs
static void on_page_message(WebKitUserContentManager *m, WebKitJavascriptResult *r, gpointer d);
static WebKitWebView *new_page_view(void);
static void select_tab(int id) {
  Tab *t = tab_by_id(id); if (!t) return; gActive = id;
  char name[16]; snprintf(name, sizeof name, "%d", id); gtk_stack_set_visible_child_name(GTK_STACK(gStack), name); push_state();
}
static char *ntp_url(void) {
  char *u = g_strdup("meowzer://ui/meowzer-ui.html");
  JsonObject *tv = sub(obj(gSettings), "themeVars"); static const char *K[] = {"canvas","surface","surface2","border","fg","muted","accent","pink","good","bad","warn"};
  GString *s = g_string_new(NULL); int ok = tv != NULL;
  for (int i = 0; ok && i < 11; i++) { const char *v = gs(tv, K[i]); if (strlen(v) != 7) ok = 0; else g_string_append_printf(s, "%s%s", i ? "." : "", v + 1); }
  char *r = ok ? g_strdup_printf("%s?tv=%s#ntp", u, s->str) : g_strdup_printf("%s#ntp", u); g_string_free(s, TRUE); g_free(u); return r;
}
static char *fix_url(const char *in) {
  if (!in || !*in || !strcmp(in, "meowzer://newtab")) return ntp_url();
  if (strstr(in, "://") || g_str_has_prefix(in, "about:") || g_str_has_prefix(in, "file:")) return g_strdup(in);
  if (!strchr(in, ' ') && strchr(in, '.')) return g_strdup_printf("https://%s", in);
  const char *se = gs(obj(gSettings), "search"); if (!*se) se = "https://duckduckgo.com/?q=%s";
  char *e = g_uri_escape_string(in, NULL, FALSE), **parts = g_strsplit(se, "%s", 2); char *r = g_strconcat(parts[0], e, parts[1] ? parts[1] : "", NULL);
  g_strfreev(parts); g_free(e); return r;
}
static void tab_changed(WebKitWebView *v, GParamSpec *ps, gpointer d) {
  Tab *t = tab_by_view(v); if (!t) return;
  const char *u = webkit_web_view_get_uri(v); g_free(t->url);
  t->url = g_str_has_prefix(u ? u : "", "meowzer://ui/meowzer-ui.html") ? g_strdup("meowzer://newtab") : g_strdup(u ? u : "");
  g_free(t->title); t->title = g_strdup(webkit_web_view_get_title(v) ? webkit_web_view_get_title(v) : "");
  t->loading = webkit_web_view_is_loading(v); t->back = webkit_web_view_can_go_back(v); t->fwd = webkit_web_view_can_go_forward(v);
  push_state();
}
static int create_tab(const char *url, int activate);
static GtkWidget *on_create(WebKitWebView *v, WebKitNavigationAction *a, gpointer d) {   // window.open and target=_blank: a new tab
  WebKitURIRequest *r = webkit_navigation_action_get_request(a); create_tab(webkit_uri_request_get_uri(r), 1); return NULL;
}
static int create_tab(const char *url, int activate) {
  Tab *t = g_new0(Tab, 1); t->id = gNextTab++; t->v = new_page_view(); t->url = g_strdup(""); t->title = g_strdup("New tab");
  g_ptr_array_add(gTabs, t);
  char name[16]; snprintf(name, sizeof name, "%d", t->id); gtk_stack_add_named(GTK_STACK(gStack), GTK_WIDGET(t->v), name); gtk_widget_show(GTK_WIDGET(t->v));
  g_signal_connect(t->v, "notify::uri", G_CALLBACK(tab_changed), NULL); g_signal_connect(t->v, "notify::title", G_CALLBACK(tab_changed), NULL);
  g_signal_connect(t->v, "notify::is-loading", G_CALLBACK(tab_changed), NULL); g_signal_connect(t->v, "create", G_CALLBACK(on_create), NULL);
  char *u = fix_url(url); webkit_web_view_load_uri(t->v, u); g_free(u);
  if (activate || !gActive) select_tab(t->id); else push_state();
  return t->id;
}
static void close_tab(int id) {
  Tab *t = tab_by_id(id); if (!t) return;
  int idx = -1; for (guint i = 0; i < gTabs->len; i++) if (g_ptr_array_index(gTabs, i) == t) idx = i;
  gtk_container_remove(GTK_CONTAINER(gStack), GTK_WIDGET(t->v)); g_ptr_array_remove_index(gTabs, idx);
  g_free(t->url); g_free(t->title); g_free(t);
  if (!gTabs->len) { gActive = 0; create_tab(NULL, 1); return; }
  if (gActive == id) { Tab *n = g_ptr_array_index(gTabs, MIN((guint)idx, gTabs->len - 1)); select_tab(n->id); } else push_state();
}

// ------------------------------------------------------------------------------------------- files
static GHashTable *gFiles; static int gNextFile = 1;
static int engine_shows(const char *ext) {
  static const char *N[] = {"png","jpg","jpeg","jfif","gif","webp","bmp","ico","svg","avif","pdf","mp3","wav","ogg","oga","opus","m4a","aac","flac","mp4","m4v","webm","ogv","html","htm","xhtml",NULL};
  for (int i = 0; N[i]; i++) if (!g_ascii_strcasecmp(N[i], ext)) return 1; return 0;
}
static char *url_for_file(const char *path) {
  const char *dot = strrchr(path, '.'), *sl = strrchr(path, '/'); const char *ext = dot && (!sl || dot > sl) ? dot + 1 : "";
  if (engine_shows(ext)) return g_filename_to_uri(path, NULL, NULL);
  int id = gNextFile++; g_hash_table_insert(gFiles, GINT_TO_POINTER(id), g_strdup(path));
  JsonObject *tv = sub(obj(gSettings), "themeVars"); (void)tv;
  return g_strdup_printf("meowzer://ui/meowzer-view.html?id=%d%s", id, !strcmp(gs(obj(gSettings), "theme"), "light") ? "&light=1" : "");
}
static void send_file(Tab *t, int id) {
  const char *p = g_hash_table_lookup(gFiles, GINT_TO_POINTER(id)); if (!p) return;
  GBytes *b = read_bytes(p); gsize n = 0; const guint8 *d = b ? g_bytes_get_data(b, &n) : NULL; gsize size = n; int cut = n > (24u << 20); if (cut) n = 24u << 20;
  char *b64 = g_base64_encode(d ? d : (const guint8 *)"", n), *name = g_path_get_basename(p);
  GString *s = g_string_new("{\"meow\":\"file\",\"id\":"); g_string_append_printf(s, "%d,\"name\":", id); q(s, name); g_string_append(s, ",\"path\":"); q(s, p);
  g_string_append_printf(s, ",\"ext\":\"\",\"size\":%" G_GSIZE_FORMAT ",\"cut\":%s,\"exists\":%s,\"b64\":\"%s\"}", size, cut ? "true" : "false", b ? "true" : "false", b64);
  char *js = g_strdup_printf("dispatchEvent(new CustomEvent('meowfile',{detail:%s}))", s->str); to_view(t->v, NULL, js);
  g_free(js); g_string_free(s, TRUE); g_free(b64); g_free(name); if (b) g_bytes_unref(b);
}
static void open_files(void) {
  GtkFileChooserNative *d = gtk_file_chooser_native_new("Open in Meowzer", GTK_WINDOW(gWin), GTK_FILE_CHOOSER_ACTION_OPEN, "_Open", "_Cancel");
  gtk_file_chooser_set_select_multiple(GTK_FILE_CHOOSER(d), TRUE);
  if (gtk_native_dialog_run(GTK_NATIVE_DIALOG(d)) == GTK_RESPONSE_ACCEPT) {
    GSList *fs = gtk_file_chooser_get_filenames(GTK_FILE_CHOOSER(d)); int first = 1;
    for (GSList *f = fs; f; f = f->next) { char *u = url_for_file(f->data); create_tab(u, first); first = 0; g_free(u); }
    g_slist_free_full(fs, g_free);
  }
  g_object_unref(d);
}

// ------------------------------------------------------------------------------------------- the vault
// Same format and the same meowcore commands as Windows (hosts/PROTOCOL.md). The key is 32 random bytes in a
// file only this user can read; the Secret Service would be better where there is one (not done yet).
static const char *VAULT_MAGIC = "MEOWVLT1", *VAULT_X = "MEOWVAULT";
static char *vault_key_hex(void) {
  char *p = path_in(gData, "vault.key"); GBytes *b = read_bytes(p); char *h;
  if (b && g_bytes_get_size(b) == 32) h = hex(g_bytes_get_data(b, NULL), 32);
  else { guint8 k[32]; rnd(k, 32); write_file(p, k, 32, 1); h = hex(k, 32); }
  if (b) g_bytes_unref(b); g_free(p); return h;
}
// lock: returns salt|nonce|tag|ct in one buffer, or NULL
static GByteArray *vault_lock(const char *plain, int rounds, const char *pwhex) {
  guint8 salt[16], nonce[12]; rnd(salt, 16); rnd(nonce, 12); char *sh = hex(salt, 16), *nh = hex(nonce, 12);
  GString *s = g_string_new(NULL); g_string_append_printf(s, "@vlock %d %s %s%s%s\n", rounds, sh, nh, pwhex && *pwhex ? " " : "", pwhex ? pwhex : "");
  gsize n = strlen(plain); for (gsize i = 0; i < n; i += 1024) { char *h = hex((const guint8 *)plain + i, MIN(1024, n - i)); g_string_append(s, h); g_string_append_c(s, '\n'); g_free(h); }
  g_string_append(s, "@end\n"); char *out = run_core(s->str); g_string_free(s, TRUE);
  GByteArray *ct = g_byte_array_new(), *tag = NULL; char **L = g_strsplit(out, "\n", -1);
  for (char **l = L; *l; l++) { g_strstrip(*l); if (g_str_has_prefix(*l, "x ")) { GByteArray *x = unhex(*l + 2); g_byte_array_append(ct, x->data, x->len); g_byte_array_unref(x); }
    else if (g_str_has_prefix(*l, "t ")) tag = unhex(*l + 2); }
  g_strfreev(L); g_free(out);
  GByteArray *r = NULL;
  if (tag && tag->len == 32 && ct->len == n) { r = g_byte_array_new(); g_byte_array_append(r, salt, 16); g_byte_array_append(r, nonce, 12); g_byte_array_append(r, tag->data, 32); g_byte_array_append(r, ct->data, ct->len); }
  if (tag) g_byte_array_unref(tag); g_byte_array_unref(ct); g_free(sh); g_free(nh); return r;
}
static char *vault_open(const guint8 *d, gsize n, int rounds, const char *pwhex) {   // d = salt|nonce|tag|ct
  if (n < 60) return NULL;
  char *sh = hex(d, 16), *nh = hex(d + 16, 12), *th = hex(d + 28, 32);
  GString *s = g_string_new(NULL); g_string_append_printf(s, "@vopen %d %s %s %s%s%s\n", rounds, sh, nh, th, pwhex && *pwhex ? " " : "", pwhex ? pwhex : "");
  for (gsize i = 60; i < n; i += 1024) { char *h = hex(d + i, MIN(1024, n - i)); g_string_append(s, h); g_string_append_c(s, '\n'); g_free(h); }
  g_string_append(s, "@end\n"); char *out = run_core(s->str); g_string_free(s, TRUE);
  GByteArray *pl = g_byte_array_new(); int ok = 0; char **L = g_strsplit(out, "\n", -1);
  for (char **l = L; *l; l++) { g_strstrip(*l); if (g_str_has_prefix(*l, "x ")) { GByteArray *x = unhex(*l + 2); g_byte_array_append(pl, x->data, x->len); g_byte_array_unref(x); } else if (!strcmp(*l, "ok")) ok = 1; }
  g_strfreev(L); g_free(out); g_free(sh); g_free(nh); g_free(th);
  if (!ok || pl->len != n - 60) { memset(pl->data, 0, pl->len); g_byte_array_unref(pl); return NULL; }
  guint8 z = 0; g_byte_array_append(pl, &z, 1); return (char *)g_byte_array_free(pl, FALSE);
}
static JsonArray *arr(JsonObject *o, const char *k) { if (!json_object_has_member(o, k) || !JSON_NODE_HOLDS_ARRAY(json_object_get_member(o, k))) json_object_set_array_member(o, k, json_array_new()); return json_object_get_array_member(o, k); }
static void vault_fresh(void) { if (gVault) json_node_unref(gVault); gVault = json_node_new(JSON_NODE_OBJECT); json_node_take_object(gVault, json_object_new()); arr(obj(gVault), "logins"); arr(obj(gVault), "never"); }
static void load_vault(void) {
  vault_fresh(); char *p = path_in(gData, "vault.dat"); GBytes *b = read_bytes(p); gsize n = 0; const guint8 *d = b ? g_bytes_get_data(b, &n) : NULL;
  if (d && n >= 68 && !memcmp(d, VAULT_MAGIC, 8)) {
    char *k = vault_key_hex(), *plain = vault_open(d + 8, n - 8, 1, k);
    if (!plain) { gVaultBroken = 1; char *bad = path_in(gData, "vault.dat.unreadable"); write_file(bad, d, n, 1); g_free(bad); }
    else { JsonNode *v = parse(plain); if (obj(v)) { json_node_unref(gVault); gVault = v; arr(obj(gVault), "logins"); arr(obj(gVault), "never"); } else if (v) json_node_unref(v); memset(plain, 0, strlen(plain)); g_free(plain); }
    g_free(k);
  }
  if (b) g_bytes_unref(b); g_free(p);
}
static void save_vault(void) {
  char *s = dump(gVault), *k = vault_key_hex(); GByteArray *L = vault_lock(s, 1, k); memset(s, 0, strlen(s)); g_free(s); g_free(k); if (!L) return;
  GByteArray *f = g_byte_array_new(); g_byte_array_append(f, (const guint8 *)VAULT_MAGIC, 8); g_byte_array_append(f, L->data, L->len);
  char *p = path_in(gData, "vault.dat"); write_file(p, f->data, f->len, 1); g_free(p); g_byte_array_unref(f); g_byte_array_unref(L);
}
static JsonObject *login_by_id(const char *id) { JsonArray *a = arr(obj(gVault), "logins"); for (guint i = 0; i < json_array_get_length(a); i++) { JsonObject *e = json_array_get_object_element(a, i); if (!strcmp(gs(e, "id"), id)) return e; } return NULL; }
static void login_public(GString *s, JsonObject *e, const char *origin) {
  g_string_append(s, "{\"id\":"); q(s, gs(e, "id")); g_string_append(s, ",\"origin\":"); q(s, gs(e, "origin")); g_string_append(s, ",\"site\":"); q(s, gs(e, "site"));
  g_string_append(s, ",\"user\":"); q(s, gs(e, "user")); g_string_append(s, ",\"note\":"); q(s, gs(e, "note"));
  g_string_append_printf(s, ",\"created\":%" G_GINT64_FORMAT ",\"changed\":%" G_GINT64_FORMAT ",\"used\":%" G_GINT64_FORMAT ",\"uses\":%" G_GINT64_FORMAT, gi(e, "created", 0), gi(e, "changed", 0), gi(e, "used", 0), gi(e, "uses", 0));
  if (origin) g_string_append_printf(s, ",\"exact\":%s", !strcmp(gs(e, "origin"), origin) ? "true" : "false");
  g_string_append_c(s, '}');
}
static char *vault_list(void) {
  GString *s = g_string_new("{\"logins\":["); JsonArray *a = arr(obj(gVault), "logins");
  for (guint i = 0; i < json_array_get_length(a); i++) { if (i) g_string_append_c(s, ','); login_public(s, json_array_get_object_element(a, i), NULL); }
  char *nv = json_to_string(json_object_get_member(obj(gVault), "never"), FALSE); g_string_append_printf(s, "],\"never\":%s,\"broken\":%s}", nv, gVaultBroken ? "true" : "false"); g_free(nv);
  return g_string_free(s, FALSE);
}
static int never_for(const char *site) { JsonArray *a = arr(obj(gVault), "never"); for (guint i = 0; i < json_array_get_length(a); i++) if (!strcmp(json_array_get_string_element(a, i), site)) return 1; return 0; }
static JsonObject *add_login(const char *origin, const char *user, const char *pass, const char *note) {
  JsonObject *e = json_object_new(); char *id = rnd_hex(8), *site = NULL, *h = host_of(origin); site = site_of(h);
  json_object_set_string_member(e, "id", id); json_object_set_string_member(e, "origin", origin); json_object_set_string_member(e, "site", site);
  json_object_set_string_member(e, "user", user); json_object_set_string_member(e, "pass", pass); json_object_set_string_member(e, "note", note);
  gint64 now = time(NULL); json_object_set_int_member(e, "created", now); json_object_set_int_member(e, "changed", now); json_object_set_int_member(e, "used", 0); json_object_set_int_member(e, "uses", 0);
  json_array_add_object_element(arr(obj(gVault), "logins"), e); g_free(id); g_free(site); g_free(h); return e;
}
static struct { int tab; char *origin, *site, *user, *pass, *id; int update; } gPending;
static void pending_clear(void) { if (gPending.pass) memset(gPending.pass, 0, strlen(gPending.pass)); g_free(gPending.origin); g_free(gPending.site); g_free(gPending.user); g_free(gPending.pass); g_free(gPending.id); memset(&gPending, 0, sizeof gPending); }
static void vault_from_page(Tab *t, JsonObject *m) {
  const char *src = webkit_web_view_get_uri(t->v); if (!src || !g_str_has_prefix(src, "http")) return;
  char *origin = origin_of(src), *h = host_of(src), *site = site_of(h); const char *op = gs(m, "op");
  JsonObject *vs = sub(obj(gSettings), "vault"); const char *mode = *gs(vs, "fill") ? gs(vs, "fill") : "ask"; int exactOnly = gb(vs, "exact");
  JsonArray *a = arr(obj(gVault), "logins");
  if (!strcmp(op, "logins") && strcmp(mode, "off")) {
    GString *list = g_string_new(NULL); JsonObject *one = NULL; int exact = 0;
    for (guint i = 0; i < json_array_get_length(a); i++) { JsonObject *e = json_array_get_object_element(a, i); int ex = !strcmp(gs(e, "origin"), origin);
      if (!ex && (exactOnly || strcmp(gs(e, "site"), site))) continue; if (ex) { exact++; one = e; } if (list->len) g_string_append_c(list, ','); login_public(list, e, origin); }
    if (list->len) {
      GString *s = g_string_new("{\"meow\":\"vault\",\"mode\":"); q(s, mode); g_string_append_printf(s, ",\"logins\":[%s],\"auto\":", list->str);
      if (!strcmp(mode, "auto") && exact == 1 && g_str_has_prefix(origin, "https://")) { g_string_append(s, "{\"id\":"); q(s, gs(one, "id")); g_string_append(s, ",\"user\":"); q(s, gs(one, "user")); g_string_append(s, ",\"pass\":"); q(s, gs(one, "pass")); g_string_append(s, "}"); }
      else g_string_append(s, "null");
      g_string_append_c(s, '}'); to_page(t, s->str); g_string_free(s, TRUE);
    }
    g_string_free(list, TRUE);
  } else if (!strcmp(op, "fill") || !strcmp(op, "filled")) {
    JsonObject *e = login_by_id(gs(m, "id"));
    if (e && (!strcmp(gs(e, "origin"), origin) || (!exactOnly && !strcmp(op, "fill") && !strcmp(gs(e, "site"), site)))) {
      if (!strcmp(op, "fill")) { GString *s = g_string_new("{\"meow\":\"vault\",\"fill\":{\"user\":"); q(s, gs(e, "user")); g_string_append(s, ",\"pass\":"); q(s, gs(e, "pass")); g_string_append(s, "}}"); to_page(t, s->str); g_string_free(s, TRUE); }
      json_object_set_int_member(e, "used", time(NULL)); json_object_set_int_member(e, "uses", gi(e, "uses", 0) + 1); save_vault();
    }
  } else if (!strcmp(op, "capture")) {
    if (vs && json_object_has_member(vs, "offer") && !gb(vs, "offer")) goto done;
    const char *user = gs(m, "user"), *pass = gs(m, "pass"); if (!*pass || never_for(site)) goto done;
    JsonObject *same = NULL; for (guint i = 0; i < json_array_get_length(a); i++) { JsonObject *e = json_array_get_object_element(a, i); if (!strcmp(gs(e, "origin"), origin) && !strcmp(gs(e, "user"), user)) same = e; }
    if (same && !strcmp(gs(same, "pass"), pass)) goto done;
    pending_clear(); gPending.tab = t->id; gPending.origin = g_strdup(origin); gPending.site = g_strdup(site); gPending.user = g_strdup(user); gPending.pass = g_strdup(pass);
    gPending.id = g_strdup(same ? gs(same, "id") : ""); gPending.update = same != NULL;
    GString *s = g_string_new("{\"t\":\"vaultOffer\",\"site\":"); q(s, site); g_string_append(s, ",\"origin\":"); q(s, origin); g_string_append(s, ",\"user\":"); q(s, user);
    g_string_append_printf(s, ",\"update\":%s}", same ? "true" : "false"); to_face(s->str); g_string_free(s, TRUE);
  }
done:
  g_free(origin); g_free(h); g_free(site);
}
static char *pick_vault_file(int save) {
  GtkFileChooserNative *d = gtk_file_chooser_native_new(save ? "Export the Meowzer vault" : "Import a Meowzer vault", GTK_WINDOW(gWin), save ? GTK_FILE_CHOOSER_ACTION_SAVE : GTK_FILE_CHOOSER_ACTION_OPEN, save ? "_Save" : "_Open", "_Cancel");
  GtkFileFilter *f = gtk_file_filter_new(); gtk_file_filter_set_name(f, "Meowzer vault"); gtk_file_filter_add_pattern(f, "*.meowvault"); gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(d), f);
  if (save) { char day[64]; time_t now = time(NULL); strftime(day, sizeof day, "Meowzer vault %Y-%m-%d.meowvault", localtime(&now)); gtk_file_chooser_set_current_name(GTK_FILE_CHOOSER(d), day); gtk_file_chooser_set_do_overwrite_confirmation(GTK_FILE_CHOOSER(d), TRUE); }
  char *r = gtk_native_dialog_run(GTK_NATIVE_DIALOG(d)) == GTK_RESPONSE_ACCEPT ? gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(d)) : NULL; g_object_unref(d); return r;
}
// a copied password leaves the clipboard again after a while, unless something else was copied since
static char *gClipText; static guint gClipTimer;
static gboolean forget_clip(gpointer d) {
  GtkClipboard *c = gtk_clipboard_get(GDK_SELECTION_CLIPBOARD); char *now = gtk_clipboard_wait_for_text(c);
  if (now && gClipText && !strcmp(now, gClipText)) gtk_clipboard_set_text(c, "", 0);
  g_free(now); if (gClipText) { memset(gClipText, 0, strlen(gClipText)); g_free(gClipText); gClipText = NULL; } gClipTimer = 0; return G_SOURCE_REMOVE;
}
static void forget_later(const char *txt, int sec) {
  if (gClipTimer) g_source_remove(gClipTimer); if (gClipText) { memset(gClipText, 0, strlen(gClipText)); g_free(gClipText); }
  gClipText = g_strdup(txt); gClipTimer = g_timeout_add_seconds(sec, forget_clip, NULL);
}
static GBytes *gImport; static char *gImportName;
static void vault_op(JsonObject *m) {
  const char *op = gs(m, "op"); gint64 id = gi(m, "id", 0); JsonArray *a = arr(obj(gVault), "logins"); char *r = NULL;
  int clip = (int)gi(sub(obj(gSettings), "vault"), "clip", 30);
  if (!strcmp(op, "list")) r = vault_list();
  else if (!strcmp(op, "reveal")) { JsonObject *e = login_by_id(gs(m, "login")); GString *s = g_string_new("{\"pass\":"); q(s, e ? gs(e, "pass") : ""); g_string_append_c(s, '}'); r = g_string_free(s, FALSE); }
  else if (!strcmp(op, "copy") || !strcmp(op, "copyText")) {
    JsonObject *e = !strcmp(op, "copy") ? login_by_id(gs(m, "login")) : NULL;
    const char *txt = e ? (!strcmp(gs(m, "what"), "user") ? gs(e, "user") : gs(e, "pass")) : gs(m, "text");
    GtkClipboard *c = gtk_clipboard_get(GDK_SELECTION_CLIPBOARD); gtk_clipboard_set_text(c, txt, -1);
    if (clip > 0) { forget_later(txt, clip); }
    r = g_strdup("{\"ok\":true}");
  }
  else if (!strcmp(op, "save")) {
    JsonObject *in = sub(m, "login"); char *o0 = strstr(gs(in, "origin"), "://") ? g_strdup(gs(in, "origin")) : g_strdup_printf("https://%s", gs(in, "origin")), *o = origin_of(o0); g_free(o0);
    if (strlen(o) < 10) r = g_strdup("{\"error\":\"That address doesn't look right.\"}");
    else { JsonObject *e = *gs(in, "id") ? login_by_id(gs(in, "id")) : NULL;
      if (!e) add_login(o, gs(in, "user"), gs(in, "pass"), gs(in, "note"));
      else { char *h = host_of(o), *st = site_of(h); json_object_set_string_member(e, "origin", o); json_object_set_string_member(e, "site", st); json_object_set_string_member(e, "user", gs(in, "user"));
        json_object_set_string_member(e, "note", gs(in, "note")); if (*gs(in, "pass")) { json_object_set_string_member(e, "pass", gs(in, "pass")); json_object_set_int_member(e, "changed", time(NULL)); } g_free(h); g_free(st); }
      save_vault(); r = vault_list(); }
    g_free(o);
  }
  else if (!strcmp(op, "del")) { for (guint i = 0; i < json_array_get_length(a); i++) if (!strcmp(gs(json_array_get_object_element(a, i), "id"), gs(m, "login"))) { json_array_remove_element(a, i); break; } save_vault(); r = vault_list(); }
  else if (!strcmp(op, "never")) { JsonArray *n = arr(obj(gVault), "never"); for (guint i = 0; i < json_array_get_length(n); i++) if (!strcmp(json_array_get_string_element(n, i), gs(m, "site"))) { json_array_remove_element(n, i); break; }
    if (gb(m, "on")) json_array_add_string_element(n, gs(m, "site")); save_vault(); r = vault_list(); }
  else if (!strcmp(op, "wipe")) { vault_fresh(); gVaultBroken = 0; if (gb(m, "newKey")) { guint8 k[32]; rnd(k, 32); char *p = path_in(gData, "vault.key"); write_file(p, k, 32, 1); g_free(p); } save_vault(); r = vault_list(); }
  else if (!strcmp(op, "gen") || !strcmp(op, "user")) {
    char *rh = rnd_hex(!strcmp(op, "gen") ? 1500 : 600);
    char *sc = !strcmp(op, "gen") ? g_strdup_printf("@gen %" G_GINT64_FORMAT " %" G_GINT64_FORMAT " %" G_GINT64_FORMAT " %s\n", gi(m, "tier", 3), gi(m, "len", 20), gi(m, "flags", 0), rh)
                                   : g_strdup_printf("@user %" G_GINT64_FORMAT " %s\n", gi(m, "style", 0), rh);
    char *out = g_strstrip(run_core(sc)); GString *s = g_string_new(NULL);
    if (g_str_has_prefix(out, "pw ")) { g_string_append(s, "{\"pw\":"); q(s, out + 3); } else if (g_str_has_prefix(out, "user ")) { g_string_append(s, "{\"user\":"); q(s, out + 5); } else { g_string_append(s, "{\"error\":"); q(s, out); }
    g_string_append_c(s, '}'); r = g_string_free(s, FALSE); g_free(out); g_free(sc); g_free(rh);
  }
  else if (!strcmp(op, "offer")) {
    const char *ans = gs(m, "a");
    if (gPending.pass && !strcmp(ans, "save")) { JsonObject *e = gPending.update ? login_by_id(gPending.id) : NULL;
      if (e) { json_object_set_string_member(e, "pass", gPending.pass); json_object_set_int_member(e, "changed", time(NULL)); } else add_login(gPending.origin, gPending.user, gPending.pass, ""); save_vault(); }
    if (gPending.pass && !strcmp(ans, "never")) { json_array_add_string_element(arr(obj(gVault), "never"), gPending.site); save_vault(); }
    pending_clear(); r = g_strdup("{\"ok\":true}");
  }
  else if (!strcmp(op, "export")) {
    char *path = pick_vault_file(1);
    if (!path) r = g_strdup("{\"cancelled\":true}");
    else { const char *pw = gs(m, "pw"); char *pwh = *pw ? hex((const guint8 *)pw, strlen(pw)) : NULL; int rounds = *pw ? 600000 : 1;
      char *plain = dump(gVault); GByteArray *L = vault_lock(plain, rounds, pwh); memset(plain, 0, strlen(plain)); g_free(plain);
      if (!L) r = g_strdup("{\"error\":\"meowcore could not lock the vault\"}");
      else { GByteArray *f = g_byte_array_new(); guint8 head[6] = {1, *pw ? 1 : 0, rounds & 255, (rounds >> 8) & 255, (rounds >> 16) & 255, (rounds >> 24) & 255};
        g_byte_array_append(f, (const guint8 *)VAULT_X, 9); g_byte_array_append(f, head, 6); g_byte_array_append(f, L->data, L->len); write_file(path, f->data, f->len, 1);
        GString *s = g_string_new(NULL); g_string_append_printf(s, "{\"ok\":true,\"count\":%u,\"path\":", json_array_get_length(a)); q(s, path); g_string_append_printf(s, ",\"locked\":%s}", *pw ? "true" : "false");
        r = g_string_free(s, FALSE); g_byte_array_unref(f); g_byte_array_unref(L); }
      g_free(pwh); g_free(path); }
  }
  else if (!strcmp(op, "import")) {
    if (!gb(m, "again")) { char *p = pick_vault_file(0); if (!p) { reply("vault", id, "{\"cancelled\":true}"); return; }
      if (gImport) g_bytes_unref(gImport); gImport = read_bytes(p); g_free(gImportName); gImportName = g_path_get_basename(p); g_free(p); }
    gsize n = 0; const guint8 *f = gImport ? g_bytes_get_data(gImport, &n) : NULL;
    if (!f || n < 75 || memcmp(f, VAULT_X, 9) || f[9] != 1) r = g_strdup("{\"error\":\"That file isn't a Meowzer vault.\"}");
    else { int locked = f[10] & 1; guint32 rounds = f[11] | f[12] << 8 | f[13] << 16 | (guint32)f[14] << 24; const char *pw = gs(m, "pw");
      if (locked && !*pw) { GString *s = g_string_new("{\"need\":\"password\",\"name\":"); q(s, gImportName); g_string_append_c(s, '}'); r = g_string_free(s, FALSE); }
      else { char *pwh = locked ? hex((const guint8 *)pw, strlen(pw)) : NULL; char *plain = vault_open(f + 15, n - 15, rounds, pwh); g_free(pwh);
        if (!plain) r = g_strdup(locked ? "{\"wrong\":true}" : "{\"error\":\"The vault file was changed or is damaged; nothing was imported.\"}");
        else { JsonNode *in = parse(plain); memset(plain, 0, strlen(plain)); g_free(plain); int added = 0, updated = 0;
          JsonArray *li = obj(in) ? arr(obj(in), "logins") : NULL;
          for (guint i = 0; li && i < json_array_get_length(li); i++) { JsonObject *e = json_array_get_object_element(li, i), *same = NULL;
            for (guint j = 0; j < json_array_get_length(a); j++) { JsonObject *x = json_array_get_object_element(a, j); if (!strcmp(gs(x, "origin"), gs(e, "origin")) && !strcmp(gs(x, "user"), gs(e, "user"))) same = x; }
            if (!same) { JsonObject *c = json_object_ref(e); char *nid = rnd_hex(8); json_object_set_string_member(c, "id", nid); g_free(nid); json_array_add_object_element(a, c); added++; }
            else if (strcmp(gs(same, "pass"), gs(e, "pass"))) { json_object_set_string_member(same, "pass", gs(e, "pass")); json_object_set_int_member(same, "changed", time(NULL)); updated++; } }
          JsonArray *nv = obj(in) ? arr(obj(in), "never") : NULL;
          for (guint i = 0; nv && i < json_array_get_length(nv); i++) if (!never_for(json_array_get_string_element(nv, i))) json_array_add_string_element(arr(obj(gVault), "never"), json_array_get_string_element(nv, i));
          if (in) json_node_unref(in); save_vault(); if (gImport) { g_bytes_unref(gImport); gImport = NULL; }
          r = g_strdup_printf("{\"ok\":true,\"added\":%d,\"updated\":%d}", added, updated); } } }
  }
  reply("vault", id, r ? r : "{}"); g_free(r);
}

// ------------------------------------------------------------------------------------------- the face's messages
static void on_face_message(WebKitUserContentManager *m, WebKitJavascriptResult *r, gpointer d) {
  JSCValue *v = webkit_javascript_result_get_js_value(r); char *txt = jsc_value_is_string(v) ? jsc_value_to_string(v) : jsc_value_to_json(v, 0);
  JsonNode *n = parse(txt); g_free(txt); JsonObject *o = obj(n); if (!o) { if (n) json_node_unref(n); return; }
  const char *t = gs(o, "t"); Tab *a = tab_by_id(gActive), *tt = json_object_has_member(o, "tab") ? tab_by_id((int)gi(o, "tab", 0)) : a;
  if (!strcmp(t, "nav") && tt) { char *u = fix_url(gs(o, "url")); webkit_web_view_load_uri(tt->v, u); g_free(u); }
  else if (!strcmp(t, "back") && tt) webkit_web_view_go_back(tt->v);
  else if (!strcmp(t, "fwd") && tt) webkit_web_view_go_forward(tt->v);
  else if (!strcmp(t, "reload") && tt) webkit_web_view_reload(tt->v);
  else if (!strcmp(t, "stop") && tt) webkit_web_view_stop_loading(tt->v);
  else if (!strcmp(t, "newtab")) create_tab(g_str_has_prefix(gs(o, "url"), "http") ? gs(o, "url") : NULL, 1);
  else if (!strcmp(t, "close")) close_tab((int)gi(o, "tab", 0));
  else if (!strcmp(t, "select")) select_tab((int)gi(o, "tab", 0));
  else if (!strcmp(t, "chrome")) { int h = (int)gi(o, "h", 78); if (h > 0) gFaceH = h; if (!gOverlay) gtk_widget_set_size_request(gFace, -1, gFaceH); }
  else if (!strcmp(t, "overlay")) {   // a panel is open: the face takes the whole window (the page behind is not drawn under it on Linux yet)
    gOverlay = gb(o, "open"); gtk_widget_set_vexpand(gFace, gOverlay); gtk_widget_set_visible(gStack, !gOverlay);
    gtk_widget_set_size_request(gFace, -1, gOverlay ? -1 : gFaceH);
  }
  else if (!strcmp(t, "win")) { const char *w = gs(o, "a");
    if (!strcmp(w, "min")) gtk_window_iconify(GTK_WINDOW(gWin)); else if (!strcmp(w, "max")) { if (gtk_window_is_maximized(GTK_WINDOW(gWin))) gtk_window_unmaximize(GTK_WINDOW(gWin)); else gtk_window_maximize(GTK_WINDOW(gWin)); }
    else if (!strcmp(w, "close")) gtk_window_close(GTK_WINDOW(gWin)); }
  else if (!strcmp(t, "core")) { char *out = run_core(gs(o, "script")); GString *s = g_string_new(NULL); g_string_append_printf(s, "{\"t\":\"core\",\"id\":%" G_GINT64_FORMAT ",\"out\":", gi(o, "id", 0)); q(s, out); g_string_append_c(s, '}'); to_face(s->str); g_string_free(s, TRUE); g_free(out); }
  else if (!strcmp(t, "settings")) { if (gSettings) json_node_unref(gSettings); gSettings = json_node_copy(json_object_get_member(o, "settings")); save_json("settings.json", gSettings); paint_frame(); }
  else if (!strcmp(t, "jar")) { if (gJar) json_node_unref(gJar); gJar = json_node_copy(json_object_get_member(o, "jar")); save_json("jar.json", gJar); }
  else if (!strcmp(t, "lists")) { compile_table(); GString *s = g_string_new("{\"t\":\"table\",\"stats\":"); q(s, gTableStats); g_string_append_c(s, '}'); to_face(s->str); g_string_free(s, TRUE); }
  else if (!strcmp(t, "cookies") || !strcmp(t, "history") || !strcmp(t, "downloads")) { char *s = g_strdup_printf("{\"t\":\"%s\",\"id\":%" G_GINT64_FORMAT ",\"list\":[]}", t, gi(o, "id", 0)); to_face(s); g_free(s); }   // not kept on Linux yet
  else if (!strcmp(t, "burnAll")) webkit_website_data_manager_clear(webkit_web_context_get_website_data_manager(gCtx), WEBKIT_WEBSITE_DATA_COOKIES, 0, NULL, NULL, NULL);
  else if (!strcmp(t, "openFile")) open_files();
  else if (!strcmp(t, "vault")) vault_op(o);
  else if (!strcmp(t, "probe") || !strcmp(t, "tor") || !strcmp(t, "seal") || !strcmp(t, "route")) reply(t, gi(o, "id", 0), "{\"unsupported\":true}");
  json_node_unref(n);
}
static void face_loaded(WebKitWebView *v, WebKitLoadEvent e, gpointer d) {
  if (e != WEBKIT_LOAD_FINISHED) return; gFaceReady = 1;
  char *st = dump(gSettings), *jr = dump(gJar); GString *s = g_string_new("{\"t\":\"init\",\"platform\":\"desktop\",\"caption\":false,\"tiles\":1,\"max\":false,\"engine\":");
  char *eng = g_strdup_printf("WebKitGTK %u.%u.%u", webkit_get_major_version(), webkit_get_minor_version(), webkit_get_micro_version()); q(s, eng); g_free(eng);
  g_string_append_printf(s, ",\"settings\":%s,\"jar\":%s,\"table\":", st, jr); q(s, gTableStats); g_string_append(s, ",\"totalBlocked\":0}");
  to_face(s->str); g_string_free(s, TRUE); g_free(st); g_free(jr); push_state();
}

// ------------------------------------------------------------------------------------------- pages' messages
static void on_page_message(WebKitUserContentManager *m, WebKitJavascriptResult *r, gpointer d) {
  // which view sent it? WebKitGTK doesn't say, so the vault only answers the active tab (where the user is typing)
  Tab *t = tab_by_id(gActive); if (!t) return;
  JSCValue *v = webkit_javascript_result_get_js_value(r); char *txt = jsc_value_is_string(v) ? jsc_value_to_string(v) : jsc_value_to_json(v, 0);
  JsonNode *n = parse(txt); g_free(txt); JsonObject *o = obj(n);
  if (o && !strcmp(gs(o, "meow"), "vault")) vault_from_page(t, o);
  if (n) json_node_unref(n);
}
static void on_ui_message(WebKitUserContentManager *m, WebKitJavascriptResult *r, gpointer d) {   // Meowzer's own pages (the viewer)
  Tab *t = tab_by_id(gActive); if (!t) return; const char *u = webkit_web_view_get_uri(t->v); if (!u || !g_str_has_prefix(u, "meowzer://")) return;
  JSCValue *v = webkit_javascript_result_get_js_value(r); char *txt = jsc_value_is_string(v) ? jsc_value_to_string(v) : jsc_value_to_json(v, 0);
  JsonNode *n = parse(txt); g_free(txt); JsonObject *o = obj(n);
  if (o && !strcmp(gs(o, "meow"), "file")) send_file(t, (int)gi(o, "id", 0));
  if (n) json_node_unref(n);
}
static gboolean on_user_message(WebKitWebView *v, WebKitUserMessage *msg, gpointer d) {   // from meowzer-webext.c
  Tab *t = tab_by_view(v); const char *name = webkit_user_message_get_name(msg); GVariant *p = webkit_user_message_get_parameters(msg);
  if (t && !strcmp(name, "blocked") && p) { GString *s = g_string_new(NULL); g_string_append_printf(s, "{\"t\":\"blocked\",\"tab\":%d,\"host\":", t->id); q(s, g_variant_get_string(p, NULL)); g_string_append_c(s, '}'); to_face(s->str); g_string_free(s, TRUE); }
  return TRUE;
}
static gboolean on_decide(WebKitWebView *v, WebKitPolicyDecision *dec, WebKitPolicyDecisionType type, gpointer d) {
  if (type != WEBKIT_POLICY_DECISION_TYPE_NAVIGATION_ACTION) return FALSE;
  const char *u = webkit_uri_request_get_uri(webkit_navigation_action_get_request(webkit_navigation_policy_decision_get_navigation_action(WEBKIT_NAVIGATION_POLICY_DECISION(dec))));
  if (g_str_has_prefix(u, "file:")) {   // files the engine can't show go to the viewer
    char *p = g_filename_from_uri(u, NULL, NULL);
    if (p && g_file_test(p, G_FILE_TEST_IS_REGULAR)) { char *to = url_for_file(p); if (!g_str_has_prefix(to, "file:")) { webkit_policy_decision_ignore(dec); webkit_web_view_load_uri(v, to); g_free(to); g_free(p); return TRUE; } g_free(to); }
    g_free(p);
  }
  return FALSE;
}
static WebKitWebView *new_page_view(void) {
  WebKitWebView *v = WEBKIT_WEB_VIEW(g_object_new(WEBKIT_TYPE_WEB_VIEW, "web-context", gCtx, "user-content-manager", gPageUcm, NULL));
  WebKitSettings *s = webkit_web_view_get_settings(v); webkit_settings_set_enable_developer_extras(s, getenv("MEOWZER_DEBUG") != NULL);
  g_signal_connect(v, "user-message-received", G_CALLBACK(on_user_message), NULL); g_signal_connect(v, "decide-policy", G_CALLBACK(on_decide), NULL);
  return v;
}

// ------------------------------------------------------------------------------------------- serving meowzer://ui/
static void serve_ui(WebKitURISchemeRequest *req, gpointer d) {
  const char *path = webkit_uri_scheme_request_get_path(req); char *name = g_path_get_basename(path && *path ? path : "meowzer-ui.html");
  char *full = path_in(gUi, name); GBytes *b = strstr(name, "..") ? NULL : read_bytes(full);
  if (!b) { GError *e = g_error_new_literal(G_IO_ERROR, G_IO_ERROR_NOT_FOUND, "not found"); webkit_uri_scheme_request_finish_error(req, e); g_error_free(e); }
  else { const char *mime = g_str_has_suffix(name, ".html") ? "text/html" : g_str_has_suffix(name, ".js") ? "text/javascript" : g_str_has_suffix(name, ".png") ? "image/png" : g_str_has_suffix(name, ".svg") ? "image/svg+xml" : "application/octet-stream";
    GInputStream *st = g_memory_input_stream_new_from_bytes(b); webkit_uri_scheme_request_finish(req, st, g_bytes_get_size(b), mime); g_object_unref(st); g_bytes_unref(b); }
  g_free(full); g_free(name);
}
static void init_extensions(WebKitWebContext *c, gpointer d) {
  char *dir = getenv("MEOWZER_WEBEXT") ? g_strdup(getenv("MEOWZER_WEBEXT")) : path_in(gUi, "../webext");
  webkit_web_context_set_web_extensions_directory(c, dir);
  char *tp = path_in(gData, "table.txt"); webkit_web_context_set_web_extensions_initialization_user_data(c, g_variant_new_string(tp)); g_free(tp); g_free(dir);
}
static char *inject_source(void) {
  char *p = path_in(gUi, "inject.js"), *src = read_text(p); g_free(p); if (!src) return g_strdup("");
  GString *d = g_string_new("{\"def\":null,\"pool\":null,\"sites\":{},\"css\":{},\"key\":"); q(d, gKey); g_string_append_c(d, '}');
  char **parts = g_strsplit(src, "__MEOW_DATA__", 2); char *r = g_strconcat(parts[0], d->str, parts[1] ? parts[1] : "", NULL);
  g_strfreev(parts); g_string_free(d, TRUE); g_free(src); return r;
}

static void on_destroy(GtkWidget *w, gpointer d) { gtk_main_quit(); }
int main(int argc, char **argv) {
  gtk_init(&argc, &argv);
  char *exe = g_file_read_link("/proc/self/exe", NULL), *bin = g_path_get_dirname(exe ? exe : argv[0]);
  gUi = getenv("MEOWZER_UI") ? g_strdup(getenv("MEOWZER_UI")) : g_file_test("/usr/share/meowzer4/ui", G_FILE_TEST_IS_DIR) && !g_file_test(path_in(bin, "ui"), G_FILE_TEST_IS_DIR) ? g_strdup("/usr/share/meowzer4/ui") : path_in(bin, "ui");
  gCore = getenv("MEOWZER_CORE") ? g_strdup(getenv("MEOWZER_CORE")) : path_in(bin, "meowcore");
  gData = getenv("MEOWZER_DATA") ? g_strdup(getenv("MEOWZER_DATA")) : g_build_filename(g_get_user_data_dir(), "meowzer4", NULL);
  g_mkdir_with_parents(gData, 0700); g_free(exe); g_free(bin);
  gKey = g_strdup_printf("meow%s", rnd_hex(8)); gTabs = g_ptr_array_new(); gFiles = g_hash_table_new_full(g_direct_hash, g_direct_equal, NULL, g_free);
  gSettings = load_json("settings.json"); gJar = load_json("jar.json"); load_vault(); compile_table();

  char *cache = g_build_filename(g_get_user_cache_dir(), "meowzer4", NULL);
  WebKitWebsiteDataManager *dm = webkit_website_data_manager_new("base-data-directory", gData, "base-cache-directory", cache, NULL); g_free(cache);
  gCtx = webkit_web_context_new_with_website_data_manager(dm);
  webkit_cookie_manager_set_accept_policy(webkit_website_data_manager_get_cookie_manager(dm), WEBKIT_COOKIE_POLICY_ACCEPT_NO_THIRD_PARTY);
  g_signal_connect(gCtx, "initialize-web-extensions", G_CALLBACK(init_extensions), NULL);
  webkit_web_context_register_uri_scheme(gCtx, "meowzer", serve_ui, NULL, NULL);
  WebKitSecurityManager *sm = webkit_web_context_get_security_manager(gCtx);
  webkit_security_manager_register_uri_scheme_as_secure(sm, "meowzer"); webkit_security_manager_register_uri_scheme_as_cors_enabled(sm, "meowzer");

  // pages: inject.js in the page's world (costume, cosmetics) and again in Meowzer's own world (the vault's bridge)
  gPageUcm = webkit_user_content_manager_new(); char *src = inject_source();
  webkit_user_content_manager_add_script(gPageUcm, webkit_user_script_new(src, WEBKIT_USER_CONTENT_INJECT_ALL_FRAMES, WEBKIT_USER_SCRIPT_INJECT_AT_DOCUMENT_START, NULL, NULL));
  webkit_user_content_manager_add_script(gPageUcm, webkit_user_script_new_for_world(src, WEBKIT_USER_CONTENT_INJECT_TOP_FRAME, WEBKIT_USER_SCRIPT_INJECT_AT_DOCUMENT_START, WORLD, NULL, NULL));
  g_free(src);
  webkit_user_content_manager_register_script_message_handler_in_world(gPageUcm, "meow", WORLD);
  g_signal_connect(gPageUcm, "script-message-received::meow", G_CALLBACK(on_page_message), NULL);
  webkit_user_content_manager_register_script_message_handler(gPageUcm, "meowui");
  g_signal_connect(gPageUcm, "script-message-received::meowui", G_CALLBACK(on_ui_message), NULL);

  // the window: the face on top, the pages under it
  gWin = gtk_window_new(GTK_WINDOW_TOPLEVEL); gtk_window_set_default_size(GTK_WINDOW(gWin), 1280, 820); gtk_window_set_title(GTK_WINDOW(gWin), "Meowzer");
  char *icon = path_in(gUi, "meowzer-logo.png"); gtk_window_set_icon_from_file(GTK_WINDOW(gWin), icon, NULL); g_free(icon);
  gCss = gtk_css_provider_new(); gtk_style_context_add_provider_for_screen(gdk_screen_get_default(), GTK_STYLE_PROVIDER(gCss), GTK_STYLE_PROVIDER_PRIORITY_APPLICATION); paint_frame();
  gBox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0); gtk_container_add(GTK_CONTAINER(gWin), gBox);
  WebKitUserContentManager *fu = webkit_user_content_manager_new(); webkit_user_content_manager_register_script_message_handler(fu, "meow");
  g_signal_connect(fu, "script-message-received::meow", G_CALLBACK(on_face_message), NULL);
  gFace = GTK_WIDGET(g_object_new(WEBKIT_TYPE_WEB_VIEW, "web-context", gCtx, "user-content-manager", fu, NULL));
  GdkRGBA clear = {0, 0, 0, 0}; webkit_web_view_set_background_color(WEBKIT_WEB_VIEW(gFace), &clear);
  gtk_widget_set_size_request(gFace, -1, gFaceH); gtk_box_pack_start(GTK_BOX(gBox), gFace, FALSE, TRUE, 0);
  g_signal_connect(gFace, "load-changed", G_CALLBACK(face_loaded), NULL);
  gStack = gtk_stack_new(); gtk_box_pack_start(GTK_BOX(gBox), gStack, TRUE, TRUE, 0);
  webkit_web_view_load_uri(WEBKIT_WEB_VIEW(gFace), "meowzer://ui/meowzer-ui.html");

  int first = 1;   // files and addresses on the command line open as tabs
  for (int i = 1; i < argc; i++) { char *u = g_file_test(argv[i], G_FILE_TEST_IS_REGULAR) ? url_for_file(argv[i]) : g_strdup(argv[i]); create_tab(u, first); first = 0; g_free(u); }
  if (first) create_tab(NULL, 1);
  g_signal_connect(gWin, "destroy", G_CALLBACK(on_destroy), NULL); gtk_widget_show_all(gWin);
  gtk_main(); return 0;
}
