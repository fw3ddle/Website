#!/bin/sh
# The easy way: ./install.sh
# Installs what Meowzer needs to build, builds it, and installs it for you (into ~/.local) or for everyone (with sudo).
# Works on Arch, Debian/Ubuntu and Fedora. Uses fxc if it is on your PATH, else the prebuilt meowcore in prebuilt/.
set -e
cd "$(dirname "$0")"
say() { printf '\n\033[1;33m🐱 %s\033[0m\n' "$*"; }

say "Getting the build tools (your password may be asked for)"
if command -v pacman >/dev/null; then sudo pacman -S --needed --noconfirm base-devel pkgconf gtk3 webkit2gtk-4.1 json-glib
elif command -v apt-get >/dev/null; then sudo apt-get update && sudo apt-get install -y build-essential pkg-config libgtk-3-dev libwebkit2gtk-4.1-dev libjson-glib-dev
elif command -v dnf >/dev/null; then sudo dnf install -y gcc make pkgconf-pkg-config gtk3-devel webkit2gtk4.1-devel json-glib-devel
else echo "Unknown package manager: install gtk3, webkit2gtk-4.1 and json-glib development files yourself, then run this again."; fi

say "Building"
make ${FXC:+FXC="$FXC"}

if [ "$(id -u)" = 0 ] || [ "$1" = "--system" ]; then
  say "Installing for everyone (/usr/local)"; sudo make install PREFIX=/usr/local
else
  say "Installing for you (~/.local)"; make install PREFIX="$HOME/.local"
  case ":$PATH:" in *":$HOME/.local/bin:"*) ;; *) echo "Add ~/.local/bin to your PATH to start it as 'meowzer4'.";; esac
fi
say "Done. Start Meowzer from your apps menu, or run: meowzer4"
