# Meowzer 4 for Linux (Arch, Debian/Ubuntu, Fedora, Flatpak)

Meowzer on **WebKitGTK** (GTK 3 + webkit2gtk-4.1). It's not Google's engine and has no Google code.

## Install it, the easy way
```sh
./install.sh            # installs for you, into ~/.local
./install.sh --system   # installs for everyone, into /usr/local
```
`install.sh`:
1. fetches the build tools (pacman, apt or dnf; it asks for your password);
2. builds Meowzer;
3. installs it with a menu entry.

## Packages
| | |
|---|---|
| **Arch** | `makepkg -si` (uses `PKGBUILD`) |
| **Debian / Ubuntu** | `./make-deb.sh`, then `sudo apt install ./meowzer4_4.0_amd64.deb` |
| **Flatpak** | `flatpak-builder --user --install --force-clean build-dir app.meowzer.Meowzer4.yml` (needs `flatpak install flathub org.gnome.Sdk//47 org.gnome.Platform//47`) |

## meowcore
`prebuilt/meowcore-linux-x86_64` is meowcore compiled by fxc (ꟻX 0.28). The build uses it when fxc isn't on your PATH. On arm64 or riscv64, get fxc from ꟻX 0.28 (`bin/linux-arm64` or `bin/linux-riscv64`) and run `make FXC=/path/to/fxc`.

## What works
The host was written to the same protocol as Windows. It has:
* the face, tabs and themes;
* blocking with meowcore's table in a web extension;
* the 🐾 vault (its key is in `~/.local/share/meowzer4/vault.key`, mode 0600);
* the file viewer;
* settings and the cookie jar.

The page's vault messages go to the active tab, because WebKitGTK doesn't say which view sent them.

## Status
**Written, not yet compiled.** It was written on a Windows PC; `meowcore-linux-x86_64` is the only part that was really built. Expect a few compile errors to fix on the first `make`.
