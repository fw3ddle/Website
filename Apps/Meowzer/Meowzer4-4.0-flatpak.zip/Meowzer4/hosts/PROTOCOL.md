# What every Meowzer 4 host does

Every platform runs the same face (`ui/meowzer-ui.html`), the same page script (`ui/inject.js`) and the same brain
(`core/meowcore.fx`, compiled by fxc). A host is the thin native part in between. This file lists what a host must
provide, so the ports stay alike. `hosts/windows/meowzer.cpp` is the reference: when in doubt, do what it does.

## Views
- **The face**: one web view showing `meowzer-ui.html` (top strip; `?part=bottom` is the phone toolbar). It tells the
  host how tall it is (`{t:'chrome', part, h}`); the page views fill the rest. While a panel is open
  (`{t:'overlay', open:true}`) the face covers the whole window; the host sends it a picture of the page behind
  (`{t:'backdrop', top, url:'data:image/jpeg;base64,…'}`).
- **Pages**: one engine view per tab. `inject.js` runs in every page at document start, with `__MEOW_DATA__` replaced
  by JSON `{def, pool, sites, css, key}`.
- **Meowzer's own pages** (`meowzer-ui.html#ntp`, `meowzer-view.html`, `meowzer-ghost.html`) are served from the `ui`
  folder under the host's own address (`https://meowzer.ui/` on Windows and Android, `meowzer://ui/` on WebKit).

## Messages
JSON objects with a `t` field. Face → host, by bridge:
- WebView2: `chrome.webview.postMessage`.
- WebKit: `webkit.messageHandlers.meow.postMessage(JSON string)`. The host answers by running `meowReceive(json)` in the face.
- GeckoView: the built-in extension's native port. On Android the face and the viewer are pages of that extension
  (`moz-extension://…/ui/…`) and call `browser.runtime.connectNative('meowzer')` themselves. inject.js runs as the
  extension's content script and uses `browser.runtime.sendMessage`; `background.js` adds the tab id and Firefox's own
  record of the sender's address, forwards it as `{t:'page', tab, url, frame, msg}`, and passes answers back with
  `{t:'toPage', tab, msg}`.

| from the face | the host |
|---|---|
| `nav back fwd reload stop newtab close select` | drives tabs; answers with `{t:'state', active, tabs:[{id,url,title,favicon,loading,canBack,canFwd}]}` |
| `chrome bars overlay win` | layout and the window |
| `core {id, script}` | runs meowcore with `script` on stdin, answers `{t:'core', id, out}` |
| `settings {settings}` / `jar {jar}` | stores them (`settings.json`, `jar.json` in the data folder) |
| `cookies history downloads {id}` | answers `{t:…, id, list}` |
| `vault {id, op, …}` | the vault (below); answers `{t:'vault', id, data}` |
| `openFile` | the system's Open box; each file opens in a tab (below) |

Host → face, unasked: `init` (once the face has loaded: settings, jar, platform, engine, table), `state`, `navstart`,
`blocked {tab, host}`, `licked`, `dl {item}`, `vaultOffer {site, origin, user, update}`, `table {stats}`.

Pages → host (only from page views, never trusted with more than their own origin): `{meow:'vault', op:'logins'|'fill'|'filled'|'capture'}`.
The host answers a page with `{meow:'vault', mode, logins, auto}` or `{meow:'vault', fill:{user, pass}}`
(WebView2: `PostWebMessageAsJson`; WebKit: a `CustomEvent` named `D.key` with the JSON as `detail`, dispatched in the
script world `inject.js` runs in).

On WebKit, pages can see `webkit.messageHandlers`. So the vault's handler lives in a separate script world
(`meowzer`), where a second copy of `inject.js` runs; page scripts can't reach that world. Meowzer's own pages use a
main-world handler named `meowui`, which the host obeys only while that view shows a `meowzer://` address.

## meowcore
Run per batch: write the script to its stdin, read stdout to the end. Never per request. `@table` compiles the lists
into FNV-1a 64 hashes (`b` block, `t` third-party only, `a` allow, `p` strip parameter, `c` cosmetic); per request the
host hashes the request's host and each parent domain and looks them up. `@hash meowzer` = `6c6fd0a2ec8bd0bc` is the
self-test.

## Files
- Pictures, PDF, sound, video and web pages open as `file:` addresses.
- Anything else opens in `meowzer-view.html?id=N` (plus `&tv=…&tx=…&light=1` for the theme).
- The viewer asks `{meow:'file', id}` and gets `{meow:'file', id, name, path, ext, size, cut, exists, b64}`.
- The host only ever serves files the user opened, by number.

## The vault
- **`vault.dat`**: `"MEOWVLT1"` + salt(16) + nonce(12) + tag(32) + ciphertext. It is meowcore `@vlock 1 SALT NONCE KEYHEX`, where the
  key is 32 random bytes the platform keeps safe:
  - Windows: DPAPI.
  - macOS/iOS: the Keychain.
  - Android: the Keystore.
  - Linux: a 0600 file (or the Secret Service, where present).
- **Exports (`.meowvault`)**: `"MEOWVAULT"`, version 1, flags (bit 0: has a password), rounds (u32 LE), salt, nonce, tag,
  ciphertext. They are locked with 600000 rounds when there is a password, 1 when there isn't.
  - Because the format is the same everywhere, any Meowzer opens any export.
  - Without a password, only Meowzer's pepper protects it.
- **Contents**: the plaintext is JSON `{logins:[{id, origin, site, user, pass, note, created, changed, used, uses}], never:[site]}`.
  - The face never gets a password, except one at a time for 👁 and copy.
  - A page gets a password only when it is filled in.

## Theme
`settings.themeVars` holds every colour the face wears: the 11 palette keys plus any of the studio's extra keys. A host paints:
- its own window from `frame`;
- tile gaps from `gap`;
- the focused-tile outline from `grip`.
