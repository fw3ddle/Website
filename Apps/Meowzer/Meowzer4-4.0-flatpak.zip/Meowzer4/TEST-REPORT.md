# Meowzer 4 — what was tested (2026-11-15)

Environment: Windows 11 Pro 10.0.26100 x64, WebView2 (Edge's engine), zig c++ 0.13, ꟻX 0.29.0 Helix `fxc.exe` for both ꟻX programs.

| Part | How | Result |
|---|---|---|
| `meowpaint.exe` (the ꟻX engine, `engine/meowpaint.fx`) | `node engine/tests/test-engine.js`: Astra's 14 engine checks ported from Python, plus the fixtures and a tampering test of the page's validator | 16 of 16 passed, including a seeded corpus of 300 malformed documents |
| Same engine, reproducible build | Compiled here with Helix fxc and compared with Astra's `windows-x64/meowpaint.exe` | Byte-identical (SHA-256 `6c6155a0…b2fa82`) |
| `meowcore.exe` rebuilt with Helix | `node tests/vault-port.js` (the vault cipher, byte for byte) and `@hash`/`@site` checked against the 0.28 build | Same bytes and same hashes |
| ꟻX engine in the real Windows app (test copy, its own data folder) | Driven over the DevTools protocol with real mouse clicks | All passed: <ul><li>A fixture page drew 210 text runs; screenshot checked.</li><li>The address bar showed `fx:…`.</li><li>An anchor link scrolled the page.</li><li>`meowzer:` links were ignored.</li><li>Plain text drew.</li><li>A PNG was refused as "not a page".</li><li>A page over 1 MiB was refused.</li><li>Latin-1 came out as UTF-8 ("café").</li><li>`https://example.com` drew.</li><li>A self-signed certificate was refused.</li><li>An unknown host showed an error.</li><li>The ☰ engine switch went web → ꟻX → web.</li></ul> |
| 🎲 Somewhere random (new-tab page) and the Fweddle tile | 5 real rolls in the test copy | Every roll reached a live site in 2–10 s (wxr.com, sbds.org, npr.com → npr.org, cobu.app, hage.org). The Fweddle tile appears and links to https://www.fweddle.com/ |
| Android APK (`hosts/android`, GeckoView 160) | Built with Gradle 9.9.1 + Android Gradle Plugin 9.5.1, then checked with `aapt2 dump badging` and `apksigner verify` | Builds with no code errors: 93 MB, `app.meowzer.meowzer4` 4.0, API 26+, arm64-v8a, v2 signature valid (debug key). **Not run on a phone or emulator** (none was connected) |
| Fixes from your report (test copy, DevTools protocol) | Each bug reproduced first where possible, then re-run | <ul><li>**Stuck toolbar face (the dice "not working"):** a ☰ panel closing before the page picture finished left the face covering the whole tab (764 px tall). Reproduced, fixed: it now stays 84 px.</li><li>**Hidden toolbars:** a 6 px strip now stays at the top. Clicking or hovering it brings the bars back (checked: 6 px → 84 px).</li><li>**Bars reset:** they reset when you switch tabs or open a new page.</li><li>**Cookie jar:** the glowing dot is gone.</li><li>**Divider drag:** checked with window messages. Tiles glide to the new spot and the faces re-zoom once after release. The smoothness itself was not measured.</li></ul> |
| 🎲 dice pool | 15 rolls from fresh new tabs | <ul><li>The pool grew from NetAPI's 10-domain .world sample to 139 sites, with dead seeds dropped.</li><li>Rolls took 1–7 s.</li><li>No site came up twice in a row.</li><li>The 45 s "roll again" safety was not triggered in testing.</li></ul> |
| The rest of the Windows app (vault, viewer, themes, tiles, blocking) | Tested in earlier rounds; this round's changes don't touch them | Not re-run end to end this round |

## Not tested
- **Linux, macOS and iOS hosts:** never compiled.
  - Linux needs GTK and WebKitGTK.
  - macOS and iOS need a Mac with Xcode.
- **Android:** the APK is built, but it hasn't been run yet. It is also signed with a development key, not a store key.
- **No Apple app is in the release.**
  - An `.app` or `.ipa` can only be built on a Mac.
  - An iOS install also needs your Apple signing.
- **The ꟻX engine on platforms other than Windows:** it is only wired into the Windows host so far.
- **Signing:** the Windows build is unsigned. SHA-256 sums show whether a file was damaged; they don't prove who made it.
- **The ꟻX engine is a document reader, not a browser.**
  - It has no CSS, JavaScript, pictures, forms, cookies or logins.
  - It lays text out on a monospace grid. Characters outside basic Latin may not fit their cells exactly.
  - Its page process runs with a 256 MB memory limit, an 8 second limit and bounded input and output. That is **not an OS security sandbox**.
