// meowcore.fx — Meowzer's brain, written in ꟻX (Forge 0.28 "Omni").
//
// The page engine (WebView2 / WebKit / GeckoView) draws pages. Every decision about what a page may do is made
// here: which hosts the cat hisses at, which query parameters get licked off, what happens to a cookie, how a
// saved cookie is decorated, and which made-up machine a site gets to see.
//
// ꟻX programs talk through standard input and output, and a compiled program flushes its output when it ends.
// So the hosts run meowcore in batches: they write a script of commands, read the answers, and the process ends.
// Per-request work is never a round trip: `@table` compiles the filter lists into a flat table of 64-bit FNV-1a
// hashes once, and the host looks hashes up in memory (the hash is defined below and nowhere else).
//
// Commands, one per line:
//   @table ... @end            filter rules in between; prints the table (see `rule`)
//   @hash TEXT                 prints the FNV-1a 64 hash of TEXT, lowercased (hosts self-test against it)
//   @verdict MODE JAR 3P TRK   cookie verdict: K keep, S session (burn when the site is left), B burn now
//   @decorate SEED BITS        a decoration for a jarred cookie; BITS are its site settings
//   @persona SEED FAMILY       a coherent made-up device (FAMILY 0 win, 1 mac, 2 linux, 3 android, 4 ios, 9 any)
//   @site HOST                 the site (registrable domain) of HOST, by a small public-suffix table
//   @sweep ... @end            what to do with every cookie the engine holds (see `sweep`)
//   @chacha R KEY NONCE ... @end   ChaCha-R keystream XOR over hex lines (the seal on what Meowzer stores)
//   @vlock / @vopen ... @end   the vault: PBKDF2-stretched pepper + password, two ChaCha20 layers, an HMAC tag
//   @gen TIER LEN FLAGS RAND   a password (or passphrase) from the host's random bytes
//   @user STYLE RAND           a user name
//   @sha HEX, @kdf ITER S P    SHA-256 and PBKDF2 on their own (self-tests)

const LINE = 8192;
let ln: [u8; 8192];
let n = 0;

// ---------------------------------------------------------------------------------------------- reading lines
fn readline() -> int {
    n = 0;
    let c = getc();
    if c < 0 { give -1; }
    while c >= 0 && c != '\n' {
        if c != '\r' && n < LINE { ln[n] = c; n++; }
        c = getc();
    }
    if n >= 3 && ln[0] == 0xEF && ln[1] == 0xBB && ln[2] == 0xBF {   // a byte-order mark: drop it
        repeat i in 3..n { ln[i - 3] = ln[i]; }
        n -= 3;
    }
    give n;
}

fn lower(c) -> int {
    if c >= 'A' && c <= 'Z' { give c + 32; }
    give c;
}

// ---------------------------------------------------------------------------------------------- writing
let dig: [u8; 24];
fn putnum(v) -> int {
    if v < 0 { putc('-'); v = 0 - v; }
    let k = 0;
    if v == 0 { putc('0'); give 0; }
    while v > 0 { dig[k] = '0' + v % 10; v = v / 10; k++; }
    while k > 0 { k--; putc(dig[k]); }
    give 0;
}

fn puthex(h) -> int {
    repeat i in 0..16 {
        let d = (h >> (60 - 4 * i)) & 15;
        if d < 10 { putc('0' + d); } else { putc('a' + d - 10); }
    }
    give 0;
}

// ---------------------------------------------------------------------------------------------- the hash
// FNV-1a, 64 bits, over the lowercased bytes ln[a..b). Every host implements exactly this.
fn hash(a, b) -> int {
    let h = 0xcbf2_9ce4_8422_2325;
    let i = a;
    while i < b { h = (h ^ lower(ln[i])) *% 0x100_0000_01b3; i++; }
    give h;
}

// ---------------------------------------------------------------------------------------------- numbers in a line
let at = 0;
fn skipsp() -> int { while at < n && ln[at] == ' ' { at++; } give at; }
fn num() -> int {
    skipsp();
    let neg = 0;
    if at < n && ln[at] == '-' { neg = 1; at++; }
    let v = 0;
    while at < n && ln[at] >= '0' && ln[at] <= '9' && v < 100_000_000_000_000 { v = v * 10 + ln[at] - '0'; at++; }
    if neg == 1 { give 0 - v; }
    give v;
}

// ---------------------------------------------------------------------------------------------- keywords
// One text, many words: KW[off .. off+len).
const KW = "third-party~third-partyremoveparam=domain=@table@end@hash@verdict@decorate@persona@site3p@sweep@chacha@vlock@vopen@gen@user@sha@kdf";
const K_3P = 0;      const L_3P = 11;
const K_N3P = 11;    const L_N3P = 12;
const K_RP = 23;     const L_RP = 12;
const K_DOM = 35;    const L_DOM = 7;
const K_TABLE = 42;  const L_TABLE = 6;
const K_END = 48;    const L_END = 4;
const K_HASH = 52;   const L_HASH = 5;
const K_VERD = 57;   const L_VERD = 8;
const K_DECO = 65;   const L_DECO = 9;
const K_PERS = 74;   const L_PERS = 8;
const K_SITE = 82;   const L_SITE = 5;
const K_3PS = 87;    const L_3PS = 2;
const K_SWEEP = 89;  const L_SWEEP = 6;
const K_CHA = 95;    const L_CHA = 7;
const K_VLOCK = 102; const L_VLOCK = 6;
const K_VOPEN = 108; const L_VOPEN = 6;
const K_GEN = 114;   const L_GEN = 4;
const K_USER = 118;  const L_USER = 5;
const K_SHA = 123;   const L_SHA = 4;
const K_KDF = 127;   const L_KDF = 4;

fn word(pos, off, len) -> int {
    if pos + len > n { give 0; }
    repeat i in 0..len { if lower(ln[pos + i]) != KW[off + i] { give 0; } }
    give 1;
}
// is the word somewhere in ln[a..b)?
fn findw(a, b, off, len) -> int {
    let i = a;
    while i + len <= b { if word(i, off, len) == 1 { give i; } i++; }
    give -1;
}

// ---------------------------------------------------------------------------------------------- the filter compiler
// Output lines:  b HASH  block this host and its subdomains, first or third party
//                t HASH  block it only when it is loaded by another site
//                a HASH  never block it (exceptions win)
//                p HASH  remove this query parameter from every address
//                c HASH SELECTOR   hide SELECTOR on pages of that site (HASH 0: everywhere)
let nb = 0; let nt = 0; let na = 0; let np = 0; let nc = 0; let nskip = 0; let nrules = 0;

fn hostch(c) -> int {
    if c >= 'a' && c <= 'z' { give 1; }
    if c >= 'A' && c <= 'Z' { give 1; }
    if c >= '0' && c <= '9' { give 1; }
    if c == '.' || c == '-' || c == '_' { give 1; }
    give 0;
}

// ln[a..] holds a host; returns its end, or -1 if it is not a plain host (wildcards, paths we don't do).
fn hostend(a) -> int {
    let i = a;
    while i < n && hostch(ln[i]) == 1 { i++; }
    if i == a { give -1; }
    if i < n && ln[i] != '^' && ln[i] != '$' && ln[i] != '|' && ln[i] != ' ' && ln[i] != '/' { give -1; }
    if i < n && ln[i] == '/' && i + 1 < n { give -1; }
    if ln[a] == '.' || ln[i - 1] == '.' { give -1; }
    give i;
}

fn emit(kind, h) -> int { putc(kind); putc(' '); puthex(h); putc('\n'); give 0; }

fn rule() -> int {
    if n == 0 { give 0; }
    if ln[0] == '!' || ln[0] == '[' || ln[0] == '#' && (n < 2 || ln[1] != '#') { give 0; }
    nrules++;
    // cosmetic: [domain]##selector
    let i = 0;
    while i + 1 < n && !(ln[i] == '#' && ln[i + 1] == '#') { i++; }
    if i + 1 < n {
        if i + 2 >= n || ln[i + 2] == '+' || ln[i + 2] == '^' { nskip++; give 0; }
        let dh = 0;
        if i > 0 {
            let j = 0;
            while j < i && ln[j] != ',' { j++; }
            if j < i || ln[0] == '~' { nskip++; give 0; }   // several or negated domains: not yet
            dh = hash(0, i);
        }
        putc('c'); putc(' '); puthex(dh); putc(' ');
        repeat k in i + 2..n { putc(ln[k]); }
        putc('\n'); nc++;
        give 0;
    }
    let allow = 0;
    let s = 0;
    if n >= 2 && ln[0] == '@' && ln[1] == '@' { allow = 1; s = 2; }
    // options
    let dollar = -1;
    repeat w in s..n { if ln[w] == '$' { dollar = w; } }
    let oend = n;
    if dollar < 0 { dollar = n; }
    if findw(dollar, oend, K_DOM, L_DOM) >= 0 { nskip++; give 0; }
    let rp = findw(dollar, oend, K_RP, L_RP);
    if rp >= 0 && dollar == s {
        // $removeparam=name with no host: a global parameter rule
        let a = rp + L_RP;
        let b = a;
        while b < n && ln[b] != ',' && ln[b] != '|' { b++; }
        if b > a && ln[a] != '/' && allow == 0 { emit('p', hash(a, b)); np++; give 0; }
        nskip++; give 0;
    }
    if rp >= 0 { nskip++; give 0; }
    let third = 0;
    if findw(dollar, oend, K_3PS, L_3PS) >= 0 { third = 1; }
    if findw(dollar, oend, K_3P, L_3P) >= 0 && findw(dollar, oend, K_N3P, L_N3P) < 0 { third = 1; }
    // ||host^
    if s + 2 <= n && ln[s] == '|' && ln[s + 1] == '|' {
        let e1 = hostend(s + 2);
        if e1 < 0 { nskip++; give 0; }
        let h = hash(s + 2, e1);
        if allow == 1 { emit('a', h); na++; give 0; }
        if third == 1 { emit('t', h); nt++; } else { emit('b', h); nb++; }
        give 0;
    }
    // hosts file: 0.0.0.0 host / 127.0.0.1 host
    if allow == 0 && ln[0] >= '0' && ln[0] <= '9' {
        let q = 0;
        while q < n && ln[q] != ' ' && ln[q] != '\t' { q++; }
        while q < n && (ln[q] == ' ' || ln[q] == '\t') { q++; }
        if q < n {
            let e2 = hostend(q);
            if e2 > 0 && e2 == n || e2 > 0 && ln[e2] == ' ' {
                if !(e2 - q == 9 && ln[q] == 'l' && ln[q + 1] == 'o') { emit('b', hash(q, e2)); nb++; give 0; }
            }
        }
        nskip++; give 0;
    }
    // a bare host
    if allow == 0 && dollar == n {
        let e3 = hostend(0);
        if e3 == n {
            let dots = 0;
            repeat r in 0..n { if ln[r] == '.' { dots++; } }
            if dots > 0 { emit('b', hash(0, n)); nb++; give 0; }
        }
    }
    nskip++;
    give 0;
}

fn table() -> int {
    while readline() >= 0 {
        if word(0, K_END, L_END) == 1 { break; }
        rule();
    }
    puts("# rules "); putnum(nrules);
    puts(" block "); putnum(nb);
    puts(" third "); putnum(nt);
    puts(" allow "); putnum(na);
    puts(" params "); putnum(np);
    puts(" cosmetic "); putnum(nc);
    puts(" skipped "); putnum(nskip);
    putc('\n');
    give 0;
}

// ---------------------------------------------------------------------------------------------- cookies
// MODE: the site's oven heat. 0 raw (a normal browser), 1 warm, 2 bake (default), 3 scorch (no cookies at all).
// JAR: the user pulled this site's cookie into the jar.  3P: set by another site.  TRK: the host is in the table.
fn verdict(mode, jar, third, trk) -> int {
    if mode >= 3 { give 'B'; }
    if trk == 1 && !(mode == 0 && jar == 1) { give 'B'; }
    if jar == 1 {
        if third == 0 { give 'K'; }
        if mode == 0 { give 'K'; }
        give 'B';
    }
    if third == 1 && mode >= 1 { give 'B'; }
    if mode == 0 { give 'K'; }
    give 'S';
}

// ---------------------------------------------------------------------------------------------- decorating
// BITS (from the host, one site's settings):
//   0-2 lifetime (0 session, 1 day, 2 week, 3 month, 4 year, 5 forever)   3-4 heat mode
//   5 third-party allowed   6 spoofing on   7 scripts off   8-9 blocker (0 off, 1 normal, 2 strict)
//   10 referrer trimmed     11 storage kept
// The settings decide what the decoration MEANS (icing = lifetime, paw stamp = spoofing, chips = third party,
// crust = heat, cracks = strict blocker); the dice decide how it looks (shape wobble, sprinkles, name).
fluct die = 500 +- 500;

fn roll(k) -> int { give die % k; }

fn decorate(sd, bits) -> int {
    seed(sd);
    let life = bits & 7;
    let heat = (bits >> 3) & 3;
    let shape = roll(6);                 // round, scalloped, heart, fish, paw, star
    let wob = roll(5);
    let icing = life;                    // the colour of the icing tells how long it lasts
    let swirl = roll(4);
    let sprinkles = 6 + roll(18);
    let palette = roll(8);
    let stamp = (bits >> 6) & 1;         // a paw print: this site sees a made-up machine
    let chips = 0;
    if ((bits >> 5) & 1) == 1 { chips = 3 + roll(6); }
    let crust = heat;
    let cracks = 0;
    if ((bits >> 8) & 3) == 2 { cracks = 1 + roll(3); }
    let nm1 = roll(24);
    let nm2 = roll(24);
    puts("deco");
    each emitn(shape, wob, icing, swirl, sprinkles, palette, stamp, chips, crust, cracks, nm1, nm2);
    putc(' ');
    // sprinkle positions: polar, radius 0..99, angle 0..359, colour 0..5
    repeat k in 0..sprinkles {
        putnum(roll(100)); putc(','); putnum(roll(360)); putc(','); putnum(roll(6));
        if k + 1 < sprinkles { putc(';'); }
    }
    putc('\n');
    give 0;
}

fn emitn(v) -> int { putc(' '); putnum(v); give 0; }

// ---------------------------------------------------------------------------------------------- personas
// A made-up machine has to hang together: a Mac does not report an NVIDIA card and 6 cores, a phone has a
// phone-sized screen and touch points. Each field is an index into a table the hosts share (ui/personas.js),
// chosen only among values that are common for that family, so a persona blends in rather than standing out.
fn pick(k) -> int { give die % k; }
const CW = [4, 6, 8, 8, 12, 16];  const MW = [8, 8, 16, 16, 32];  const DW = [100, 100, 125, 150];
const CM = [8, 8, 10, 12];        const MM = [8, 16, 16, 24, 32];
const CL = [4, 8, 8, 12, 16];     const ML = [8, 16, 16, 32];     const GL = [0, 1, 5, 6];
const TZL = [0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8];
const MA = [4, 6, 8, 8, 12];      const DA = [275, 300, 350, 263];

fn persona(sd, fam) -> int {
    seed(sd);
    if fam == 8 {                        // any desktop: a costume that fits a desktop-sized window
        let r8 = pick(100);
        fam = 0;
        if r8 >= 75 { fam = 1; }
        if r8 >= 93 { fam = 2; }
    }
    if fam == 7 {                        // any phone
        fam = 3;
        if pick(100) >= 70 { fam = 4; }
    }
    if fam < 0 || fam > 4 {
        let r = pick(100);               // roughly what the web sees
        fam = 0;
        if r >= 62 { fam = 3; }
        if r >= 62 && r < 70 { fam = 1; }
        if r >= 70 && r < 73 { fam = 2; }
        if r >= 90 { fam = 4; }
    }
    let cores = 8; let mem = 8; let gpu = 0; let screen = 0; let dpr = 100; let touch = 0;
    let osv = 0; let arch = 0; let bits = 64; let conn = 0;
    if fam == 0 {
        cores = CW[pick(6)];
        mem = MW[pick(5)];
        gpu = pick(8);                    // 0-7: Intel UHD/Iris Xe, NVIDIA GTX/RTX, AMD Radeon
        screen = pick(6);                 // 0-5: 1366x768 .. 2560x1440
        dpr = DW[pick(4)];
        osv = pick(2);                    // Windows 10 / 11 (both report 10.0 in the UA)
    }
    if fam == 1 {
        cores = CM[pick(4)];
        mem = MM[pick(5)];
        gpu = 8 + pick(4);                // 8-11: Apple M1 .. M4
        screen = 6 + pick(4);             // 6-9: 1440x900 .. 1728x1117
        dpr = 200;
        osv = pick(4);
        arch = 1;
    }
    if fam == 2 {
        cores = CL[pick(5)];
        mem = ML[pick(4)];
        gpu = GL[pick(4)];   // Mesa Intel or AMD
        screen = 2 + pick(4);
        osv = 0;
    }
    if fam == 3 {
        cores = 8;
        mem = MA[pick(5)];
        gpu = 12 + pick(4);               // 12-15: Adreno, Mali, Xclipse, PowerVR
        screen = 10 + pick(5);            // 10-14: 360x800 .. 412x915
        dpr = DA[pick(4)];
        touch = 5;
        osv = pick(4);                    // Android 12 .. 15
        arch = 1;
        conn = 1 + pick(2);
    }
    if fam == 4 {
        cores = 6;
        mem = 4 + pick(2) * 2;
        gpu = 16;                         // Apple GPU
        screen = 15 + pick(4);            // 15-18: 375x812 .. 430x932
        dpr = 300;
        touch = 5;
        osv = pick(3);                    // iOS 17 / 18 / 19
        arch = 1;
        conn = 1 + pick(2);
    }
    let tz = pick(12);                    // index into personas.js time zones
    let lang = TZL[tz];                  // the language follows the clock, with English as a common second
    if pick(5) == 0 { lang = 0; }
    let rtt = 25 + pick(8) * 25;
    let down = 10 + pick(10) * 10;
    let battery = 30 + pick(70);
    let charging = pick(2);
    let noise = pick(1000) * 1000 + pick(1000);          // canvas / audio noise seed
    // the extras a fingerprinter also collects, kept plausible for the family
    let fonts = pick(64) * 64 + pick(64);             // which of the family's optional fonts are "installed" (bit mask)
    let cams = 1; let mics = 1; let spk = 1 + pick(2);
    if fam == 0 || fam == 2 { cams = pick(3); if cams > 1 { cams = 1; } mics = 1 + pick(2); }
    if fam >= 3 { cams = 2 + pick(2); mics = 1 + pick(3); spk = 1; }
    let quota = 0;                        // index into personas.js disk sizes
    if fam <= 2 { quota = 2 + pick(4); } else { quota = pick(4); }
    let scheme = 0; if pick(10) < 4 { scheme = 1; }          // 1: prefers dark
    let motion = 0; if pick(20) == 0 { motion = 1; }          // 1: prefers reduced motion
    let glat = pick(1001) - 500;          // geolocation jitter around the time zone's city, 1/1000 degree
    let glon = pick(1001) - 500;
    let bar = 0;                          // taskbar / menu bar height the screen loses
    if fam == 0 { bar = 40 + pick(2) * 8; }
    if fam == 1 { bar = 25 + pick(2) * 8; }
    if fam == 2 { bar = 27 + pick(3) * 5; }
    let depth = 24; if fam == 1 || fam == 4 { depth = 30; }
    let batt = 1;                         // has a battery at all (desktops do not)
    if fam == 0 || fam == 2 { batt = pick(2); }
    let tex = 16384; if fam >= 3 { tex = 8192 - (pick(2) * 4096); if fam == 4 { tex = 16384; } }
    let voices = pick(3);                 // 0 few, 1 some, 2 many speech voices
    puts("persona");
    each emitn(fam, cores, mem, gpu, screen, dpr, touch, osv, arch, bits, conn, tz, lang, rtt, down, battery, charging, noise);
    each emitn(fonts, cams, mics, spk, quota, scheme, motion, glat, glon, bar, depth, batt, tex, voices);
    putc('\n');
    give 0;
}

// ---------------------------------------------------------------------------------------------- sites
// The registrable domain: the last two labels, or three under the second-level suffixes in SFX.
const SFX = "|co.uk|org.uk|ac.uk|gov.uk|co.jp|ne.jp|or.jp|com.au|net.au|org.au|co.nz|com.br|com.mx|co.in|co.za|com.tr|com.cn|com.tw|co.kr|github.io|blogspot.com|herokuapp.com|vercel.app|netlify.app|pages.dev|";

fn issuffix(a, b) -> int {
    // is ln[a..b) one of SFX's entries?
    let w = b - a;
    let i = 0;
    while i + w + 1 < len(SFX) {
        if SFX[i] == '|' && SFX[i + w + 1] == '|' {
            let ok = 1;
            repeat k in 0..w { if lower(ln[a + k]) != SFX[i + 1 + k] { ok = 0; } }
            if ok == 1 { give 1; }
        }
        i++;
    }
    give 0;
}

fn site(a, b) -> int {
    // returns the start of the site in ln[a..b)
    let d1 = -1; let d2 = -1; let d3 = -1;
    let i = b - 1;
    while i >= a {
        if ln[i] == '.' {
            if d1 < 0 { d1 = i; } else if d2 < 0 { d2 = i; } else if d3 < 0 { d3 = i; }
        }
        i--;
    }
    if d1 < 0 { give a; }
    if d2 < 0 { give a; }
    if issuffix(d2 + 1, b) == 1 { if d3 < 0 { give a; } give d3 + 1; }
    give d2 + 1;
}

// ---------------------------------------------------------------------------------------------- the sweep
// Every few seconds a host lists every cookie the engine holds and asks what to do with each:
//   @sweep
//   H MODE               the heat for sites that are not in the jar (default 2, bake)
//   J MODE SITE          a site in the jar, with its own heat
//   O ALLOW3P SITE       a site open in some tab; ALLOW3P 1 if its jar settings let third parties keep cookies
//   C I TRK DOMAIN       cookie number I, set for DOMAIN; TRK 1 if the domain is in the blocker table
//   @end
// Answers: one `v I K|S|B` per cookie (K keep, S leave it for now, B burn it), then `# kept .. spared .. burnt ..`.
// A cookie belongs to the site of its domain. Cookies of jarred sites follow that site's heat. Cookies of other
// sites live only while their site is open in a tab (that is the oven), unless an open site lets third parties
// keep cookies; trackers burn at any heat but raw-in-the-jar.
const HT = 8192;
let hk: [int; 8192];
let hv: [int; 8192];
let hu: [u8; 8192];
let hcount = 0;

fn slot(h) -> int {
    let i = h & (HT - 1);
    while hu[i] == 1 && hk[i] != h { i = (i + 1) & (HT - 1); }
    give i;
}
// value bits: 0-2 jar heat + 1 (0 = not in the jar), 3 open, 4 open and allows third parties
fn hor(h, v) -> int {
    let i = slot(h);
    if hu[i] == 0 {
        if hcount >= HT / 2 { give 0; }
        hu[i] = 1; hk[i] = h; hv[i] = 0; hcount++;
    }
    hv[i] = hv[i] | v;
    give 0;
}
fn hget(h) -> int {
    let i = slot(h);
    if hu[i] == 0 { give 0; }
    give hv[i];
}

// the site hash of ln[a..n), a leading dot ignored
fn sitehash(a) -> int {
    while a < n && ln[a] == '.' { a++; }
    give hash(site(a, n), n);
}

fn sweep() -> int {
    let heat = 2;
    let any3p = 0;
    let kept = 0; let spared = 0; let burnt = 0;
    while readline() >= 0 {
        if word(0, K_END, L_END) == 1 { break; }
        if n < 3 { continue; }
        let op = ln[0];
        at = 1;
        if op == 'H' { heat = clamp(num(), 0, 3); continue; }
        if op == 'J' { let m = clamp(num(), 0, 3); skipsp(); hor(sitehash(at), m + 1); continue; }
        if op == 'O' {
            let al = num(); skipsp();
            if al == 1 { any3p = 1; hor(sitehash(at), 24); } else { hor(sitehash(at), 8); }
            continue;
        }
        if op == 'C' {
            let id = num(); let trk = num(); skipsp();
            let v = hget(sitehash(at));
            let jar = v & 7;
            let r = 'B';
            if jar > 0 {
                r = verdict(jar - 1, 1, 0, trk);
            } else if (v & 8) != 0 {
                r = verdict(heat, 0, 0, trk);
            } else if any3p == 1 && trk == 0 {
                r = 'S';
            } else {
                r = verdict(heat, 0, 1, trk);
            }
            if r == 'K' { kept++; } else if r == 'S' { spared++; } else { burnt++; }
            puts("v "); putnum(id); putc(' '); putc(r); putc('\n');
        }
    }
    puts("# kept "); putnum(kept); puts(" spared "); putnum(spared); puts(" burnt "); putnum(burnt); putc('\n');
    give 0;
}

// ---------------------------------------------------------------------------------------------- the seal: ChaCha
// @chacha ROUNDS KEYHEX NONCEHEX, then lines of hex bytes, then @end. Each line comes back as "x HEX": its bytes
// XORed with the ChaCha keystream (RFC 8439 layout: 256-bit key, 96-bit nonce, 32-bit block counter from 1). The
// stream runs on across lines, and the same key and nonce turn the output back into the input. ROUNDS is 8, 12 or
// 20 (ChaCha20 is the standard; 12 and 8 are its faster, thinner-margin siblings).
const M32 = 0xFFFF_FFFF;
let cs: [int; 16];
let cx: [int; 16];
let ckey: [int; 8];
let cnon: [int; 3];
let ck: [u8; 64];
let ctr = 1; let cpos = 64; let crounds = 20;

fn hexv(c) -> int {
    if c >= '0' && c <= '9' { give c - '0'; }
    if c >= 'a' && c <= 'f' { give c - 'a' + 10; }
    if c >= 'A' && c <= 'F' { give c - 'A' + 10; }
    give 0;
}
// the little-endian 32-bit word in the 8 hex digits at ln[p..p+8)
fn le32(p) -> int {
    let v = 0;
    repeat i in 0..4 { v = v | ((hexv(ln[p + 2 * i]) * 16 + hexv(ln[p + 2 * i + 1])) << (8 * i)); }
    give v;
}
fn rotl(x, k) -> int { give ((x << k) & M32) | (x >> (32 - k)); }
fn qr(a, b, c, d) -> int {
    cx[a] = (cx[a] + cx[b]) & M32; cx[d] = rotl(cx[d] ^ cx[a], 16);
    cx[c] = (cx[c] + cx[d]) & M32; cx[b] = rotl(cx[b] ^ cx[c], 12);
    cx[a] = (cx[a] + cx[b]) & M32; cx[d] = rotl(cx[d] ^ cx[a], 8);
    cx[c] = (cx[c] + cx[d]) & M32; cx[b] = rotl(cx[b] ^ cx[c], 7);
    give 0;
}
fn chablock() -> int {
    cs[0] = 0x6170_7865; cs[1] = 0x3320_646e; cs[2] = 0x7962_2d32; cs[3] = 0x6b20_6574;   // "expand 32-byte k"
    repeat ki in 0..8 { cs[4 + ki] = ckey[ki]; }
    cs[12] = ctr & M32; cs[13] = cnon[0]; cs[14] = cnon[1]; cs[15] = cnon[2];
    repeat si in 0..16 { cx[si] = cs[si]; }
    let r = 0;
    while r < crounds {
        qr(0, 4, 8, 12); qr(1, 5, 9, 13); qr(2, 6, 10, 14); qr(3, 7, 11, 15);
        qr(0, 5, 10, 15); qr(1, 6, 11, 12); qr(2, 7, 8, 13); qr(3, 4, 9, 14);
        r += 2;
    }
    repeat i in 0..16 {
        let w = (cx[i] + cs[i]) & M32;
        repeat j in 0..4 { ck[4 * i + j] = (w >> (8 * j)) & 255; }
    }
    ctr++; cpos = 0;
    give 0;
}
fn hex2(b) -> int {
    let hi = (b >> 4) & 15; let lo = b & 15;
    if hi < 10 { putc('0' + hi); } else { putc('a' + hi - 10); }
    if lo < 10 { putc('0' + lo); } else { putc('a' + lo - 10); }
    give 0;
}
fn chacha() -> int {
    at = L_CHA; crounds = num();
    if crounds != 8 && crounds != 12 { crounds = 20; }
    let p = skipsp(); let ok = 1;
    if p + 64 > n { ok = 0; }
    if ok == 1 { repeat ki in 0..8 { ckey[ki] = le32(p + 8 * ki); } at = p + 64; p = skipsp(); }
    if ok == 1 && p + 24 > n { ok = 0; }
    if ok == 1 { repeat ni in 0..3 { cnon[ni] = le32(p + 8 * ni); } }
    ctr = 1; cpos = 64;
    while readline() >= 0 {
        if word(0, K_END, L_END) == 1 { break; }
        if ok == 0 { continue; }
        putc('x'); putc(' ');
        let bi = 0;
        while bi + 1 < n {
            if cpos >= 64 { chablock(); }
            hex2((hexv(ln[bi]) * 16 + hexv(ln[bi + 1])) ^ ck[cpos]);
            cpos++; bi += 2;
        }
        putc('\n');
    }
    if ok == 0 { putc('!'); putc(' '); putc('k'); putc('e'); putc('y'); putc('\n'); }
    give 0;
}

// ---------------------------------------------------------------------------------------------- SHA-256
// FIPS 180-4, fed a byte at a time. One running hash at a time: hs (state), hb (the block being filled).
const SK = [0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
            0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
            0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
            0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
            0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
            0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
            0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
            0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2];
let hs: [int; 8];
let hw: [int; 64];
let hb: [u8; 64];
let hd: [u8; 32];          // the last digest
let hbn = 0; let htot = 0;

fn rotr(x, k) -> int { give ((x >> k) | (x << (32 - k))) & M32; }
fn shainit() -> int {
    hs[0] = 0x6a09e667; hs[1] = 0xbb67ae85; hs[2] = 0x3c6ef372; hs[3] = 0xa54ff53a;
    hs[4] = 0x510e527f; hs[5] = 0x9b05688c; hs[6] = 0x1f83d9ab; hs[7] = 0x5be0cd19;
    hbn = 0; htot = 0;
    give 0;
}
fn shablock() -> int {
    repeat wi in 0..16 { hw[wi] = (hb[4 * wi] << 24) | (hb[4 * wi + 1] << 16) | (hb[4 * wi + 2] << 8) | hb[4 * wi + 3]; }
    repeat wj in 16..64 {
        let x = hw[wj - 15]; let y = hw[wj - 2];
        let s0 = rotr(x, 7) ^ rotr(x, 18) ^ (x >> 3);
        let s1 = rotr(y, 17) ^ rotr(y, 19) ^ (y >> 10);
        hw[wj] = (hw[wj - 16] + s0 + hw[wj - 7] + s1) & M32;
    }
    let a = hs[0]; let b = hs[1]; let c = hs[2]; let d = hs[3];
    let e = hs[4]; let f = hs[5]; let g = hs[6]; let h = hs[7];
    repeat ri in 0..64 {
        let t1 = (h + (rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)) + ((e & f) ^ ((e ^ M32) & g)) + SK[ri] + hw[ri]) & M32;
        let t2 = ((rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)) + ((a & b) ^ (a & c) ^ (b & c))) & M32;
        h = g; g = f; f = e; e = (d + t1) & M32; d = c; c = b; b = a; a = (t1 + t2) & M32;
    }
    hs[0] = (hs[0] + a) & M32; hs[1] = (hs[1] + b) & M32; hs[2] = (hs[2] + c) & M32; hs[3] = (hs[3] + d) & M32;
    hs[4] = (hs[4] + e) & M32; hs[5] = (hs[5] + f) & M32; hs[6] = (hs[6] + g) & M32; hs[7] = (hs[7] + h) & M32;
    hbn = 0;
    give 0;
}
fn shabyte(v) -> int { hb[hbn] = v & 255; hbn++; htot++; if hbn == 64 { shablock(); } give 0; }
fn shafinal() -> int {
    let bits = htot * 8;
    hb[hbn] = 0x80; hbn++;
    if hbn > 56 { while hbn < 64 { hb[hbn] = 0; hbn++; } shablock(); }
    while hbn < 56 { hb[hbn] = 0; hbn++; }
    repeat bi in 0..8 { hb[56 + bi] = (bits >> (56 - 8 * bi)) & 255; }
    shablock();
    repeat di in 0..8 { repeat dj in 0..4 { hd[4 * di + dj] = (hs[di] >> (24 - 8 * dj)) & 255; } }
    give 0;
}

// ---------------------------------------------------------------------------------------------- HMAC and PBKDF2
// HMAC-SHA256 with the key's inner and outer pads hashed once (ist, ost), so each PBKDF2 round is two compressions.
let mk: [u8; 4096];        // the key being prepared (the vault's: pepper then password)
let mkn = 0;
let ist: [int; 8];
let ost: [int; 8];
let kb: [u8; 64];
fn hmackey() -> int {
    repeat zi in 0..64 { kb[zi] = 0; }
    if mkn > 64 { shainit(); repeat ki in 0..mkn { shabyte(mk[ki]); } shafinal(); repeat kj in 0..32 { kb[kj] = hd[kj]; } }
    else { repeat kk in 0..mkn { kb[kk] = mk[kk]; } }
    shainit(); repeat pi in 0..64 { shabyte(kb[pi] ^ 0x36); } repeat si in 0..8 { ist[si] = hs[si]; }
    shainit(); repeat po in 0..64 { shabyte(kb[po] ^ 0x5c); } repeat so in 0..8 { ost[so] = hs[so]; }
    give 0;
}
fn hfrom(which) -> int {   // start a hash from a pad state, as if its 64 pad bytes had gone in
    repeat fi in 0..8 { if which == 0 { hs[fi] = ist[fi]; } else { hs[fi] = ost[fi]; } }
    hbn = 0; htot = 64;
    give 0;
}
let tmp: [u8; 32];
fn houter() -> int {       // finish the inner hash in hd, then run it through the outer pad; the MAC lands in hd
    shafinal();
    repeat ci in 0..32 { tmp[ci] = hd[ci]; }
    hfrom(1); repeat cj in 0..32 { shabyte(tmp[cj]); } shafinal();
    give 0;
}
let salt: [u8; 64];
let saltn = 0;
let dk: [u8; 96];          // derived: ChaCha key one, ChaCha key two, the MAC key
let pu: [u8; 32];
fn pbkdf2(iter, blocks) -> int {
    hmackey();
    repeat blk in 1..blocks + 1 {
        hfrom(0);
        repeat sa in 0..saltn { shabyte(salt[sa]); }
        shabyte(0); shabyte(0); shabyte(0); shabyte(blk);
        houter();
        repeat u0 in 0..32 { pu[u0] = hd[u0]; dk[32 * (blk - 1) + u0] = hd[u0]; }
        let it = 1;
        while it < iter {
            hfrom(0); repeat u1 in 0..32 { shabyte(pu[u1]); } houter();
            repeat u2 in 0..32 { pu[u2] = hd[u2]; dk[32 * (blk - 1) + u2] = dk[32 * (blk - 1) + u2] ^ hd[u2]; }
            it++;
        }
    }
    give 0;
}

// ---------------------------------------------------------------------------------------------- the vault lock
// What only a Meowzer opens. A vault file's key is stretched from Meowzer's own pepper (below, the same in every
// Meowzer) and the user's password if they gave one, with PBKDF2-HMAC-SHA256 over a random salt. Then two layers of
// ChaCha20 under two different keys, and an HMAC-SHA256 tag over salt, nonce and ciphertext under a third key, so
// a wrong password or a changed byte is refused before anything is shown.
//   @vlock ITER SALTHEX NONCEHEX [PWHEX]   then hex lines of the vault, then @end   ->  x HEX lines, t TAGHEX
//   @vopen ITER SALTHEX NONCEHEX TAGHEX [PWHEX]   then hex lines of the file, @end  ->  x HEX lines, then ok | ! tag
// Without a password the pepper alone is the secret: anyone holding a Meowzer (or its source) can open that file,
// so the page offers the password for anything leaving this PC.
const PEPPER = "Meowzer 4 vault pepper. Only a Meowzer opens what a Meowzer seals; the cat keeps the key under its paw.";
let vkey: [int; 16];
let vks: [u8; 128];
let vpos: [int; 2];
let vctr: [int; 2];
fn dkword(off) -> int { give dk[off] | (dk[off + 1] << 8) | (dk[off + 2] << 16) | (dk[off + 3] << 24); }
fn vblock(sx) -> int {
    cs[0] = 0x6170_7865; cs[1] = 0x3320_646e; cs[2] = 0x7962_2d32; cs[3] = 0x6b20_6574;
    repeat vk in 0..8 { cs[4 + vk] = vkey[8 * sx + vk]; }
    cs[12] = vctr[sx] & M32; cs[13] = cnon[0]; cs[14] = cnon[1]; cs[15] = cnon[2];
    repeat vs in 0..16 { cx[vs] = cs[vs]; }
    let r2 = 0;
    while r2 < 20 {
        qr(0, 4, 8, 12); qr(1, 5, 9, 13); qr(2, 6, 10, 14); qr(3, 7, 11, 15);
        qr(0, 5, 10, 15); qr(1, 6, 11, 12); qr(2, 7, 8, 13); qr(3, 4, 9, 14);
        r2 += 2;
    }
    repeat vi in 0..16 {
        let w2 = (cx[vi] + cs[vi]) & M32;
        repeat vj in 0..4 { vks[64 * sx + 4 * vi + vj] = (w2 >> (8 * vj)) & 255; }
    }
    vctr[sx] = vctr[sx] + 1; vpos[sx] = 0;
    give 0;
}
fn vstream(sx) -> int { if vpos[sx] >= 64 { vblock(sx); } let k3 = vks[64 * sx + vpos[sx]]; vpos[sx] = vpos[sx] + 1; give k3; }
// read hex bytes at ln[at..] into dst (salt, or the password into mk after the pepper)
fn hexto(which, max) -> int {
    skipsp();
    let cnt = 0;
    while at + 1 < n && ln[at] != ' ' && cnt < max {
        let bv = hexv(ln[at]) * 16 + hexv(ln[at + 1]);
        if which == 0 { salt[cnt] = bv; } else { mk[mkn] = bv; mkn++; }
        cnt++; at += 2;
    }
    give cnt;
}
let tagw: [u8; 32];
fn vault(open) -> int {
    at = 6;
    let iter = num();
    if iter < 1 { iter = 1; }
    saltn = hexto(0, 64);
    skipsp();
    let okn = 1;
    if at + 24 > n { okn = 0; } else { repeat ni in 0..3 { cnon[ni] = le32(at + 8 * ni); } at += 24; }
    if open == 1 {
        skipsp();
        repeat ti in 0..32 { if at + 1 < n { tagw[ti] = hexv(ln[at]) * 16 + hexv(ln[at + 1]); at += 2; } }
    }
    mkn = 0;
    repeat pp in 0..len(PEPPER) { mk[mkn] = PEPPER[pp]; mkn++; }
    hexto(1, 2048);
    pbkdf2(iter, 3);
    repeat kw in 0..8 { vkey[kw] = dkword(4 * kw); vkey[8 + kw] = dkword(32 + 4 * kw); }
    vctr[0] = 1; vctr[1] = 1; vpos[0] = 64; vpos[1] = 64;
    // the MAC key is the third block; its running hash takes salt, nonce, then the ciphertext as it passes
    mkn = 0; repeat mm in 0..32 { mk[mkn] = dk[64 + mm]; mkn++; }
    hmackey(); hfrom(0);
    repeat sb in 0..saltn { shabyte(salt[sb]); }
    repeat nb2 in 0..3 { repeat nb3 in 0..4 { shabyte((cnon[nb2] >> (8 * nb3)) & 255); } }
    while readline() >= 0 {
        if word(0, K_END, L_END) == 1 { break; }
        if okn == 0 { continue; }
        putc('x'); putc(' ');
        let bi = 0;
        while bi + 1 < n {
            let bv = hexv(ln[bi]) * 16 + hexv(ln[bi + 1]);
            if open == 1 { shabyte(bv); hex2(bv ^ vstream(1) ^ vstream(0)); }
            else { let cv = bv ^ vstream(0) ^ vstream(1); shabyte(cv); hex2(cv); }
            bi += 2;
        }
        putc('\n');
    }
    if okn == 0 { puts("! nonce\n"); give 0; }
    houter();
    if open == 1 {
        let diff = 0;
        repeat ci in 0..32 { diff = diff | (hd[ci] ^ tagw[ci]); }
        if diff == 0 { puts("ok\n"); } else { puts("! tag\n"); }
    } else {
        putc('t'); putc(' '); repeat ti2 in 0..32 { hex2(hd[ti2]); } putc('\n');
    }
    give 0;
}

// ---------------------------------------------------------------------------------------------- generators
// Passwords and user names from random bytes the host draws from the system. Bytes become choices by rejection
// (a byte past the last whole multiple of the choice count is thrown away), so no character is likelier than another.
//   @gen TIER LEN FLAGS RANDHEX    TIER 0 PIN, 1 letters, 2 +digits, 3 +common symbols, 4 +all symbols, 5 passphrase
//                                  FLAGS bit 0: leave out look-alikes (0 O 1 l I |)          -> pw TEXT
//   @user STYLE RANDHEX            STYLE 0 wordsnum, 1 word.word, 2 word_word_num, 3 random  -> user TEXT
const LOWER = "abcdefghijklmnopqrstuvwxyz";
const UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const DIGIT = "0123456789";
const SYM1 = "!@#$%&*-_+=?";
const SYM2 = "!#$%&()*+,-./:;<=>?@[]^_{|}~";
const LOOK = "0O1lI|";
const ADJ = "amber|ancient|arctic|azure|bashful|bold|brave|breezy|bright|brisk|bronze|bubbly|calm|candid|cheery|chilly|clever|cloudy|cosmic|cozy|crisp|curly|daring|dapper|dewy|dizzy|dreamy|dusky|eager|early|electric|elder|ember|epic|fancy|feisty|fiery|fluffy|foggy|frosty|fuzzy|gentle|giddy|gilded|glad|gleaming|golden|grand|happy|hazel|hidden|honey|humble|icy|indigo|ivory|jade|jolly|keen|kind|lavender|lazy|lemon|lively|lofty|lucky|lunar|maple|marble|mellow|merry|minty|misty|modest|mossy|nimble|noble|odd|olive|orange|pastel|peachy|pearl|plucky|polar|proud|quick|quiet|rainy|rapid|rosy|royal|ruby|rustic|sandy|scarlet|shiny|silent|silky|silver|sleepy|smoky|snowy|solar|sparkly|spicy|sunny|swift|tidal|tiny|tropic|velvet|violet|vivid|wandering|warm|wavy|whimsy|wild|windy|wise|witty|woolly|zesty|stormy|starry|toasty|sly|merry|plush|";
const NOUN = "acorn|anchor|badger|bagel|banjo|beacon|beetle|biscuit|bobcat|breeze|brook|bubble|button|cactus|canyon|cat|cedar|cello|comet|cookie|coral|cricket|crystal|cub|dingo|dolphin|dragon|drum|dune|eagle|echo|falcon|feather|fennec|ferret|fig|firefly|fjord|flute|fox|gecko|geyser|glacier|gopher|harbor|hedgehog|heron|hollow|iris|island|jaguar|jasper|kettle|kitten|koala|lantern|lark|lemur|lily|lion|llama|lynx|magpie|mango|meadow|meteor|mitten|moon|moose|moth|muffin|nebula|nugget|oak|ocelot|orbit|otter|owl|panda|panther|paw|pebble|pepper|pine|pixel|planet|plum|pond|puffin|puma|quartz|quill|rabbit|raven|reef|river|robin|rocket|saddle|sage|salmon|sparrow|spruce|star|stone|storm|sunset|swan|thistle|thunder|tiger|toffee|trout|tulip|turtle|valley|walrus|whisker|willow|wombat|yarn|yeti|zebra|zephyr|biscotti|clover|";
let al: [u8; 128];
let aln = 0;
let gout: [u8; 512];
let gn = 0;
fn rbyte() -> int {
    if at + 1 >= n { give -1; }
    let rv = hexv(ln[at]) * 16 + hexv(ln[at + 1]);
    at += 2;
    give rv;
}
fn rpick(k) -> int {
    if k <= 1 { give 0; }
    let lim = 256 - 256 % k;
    let rb = rbyte();
    while rb >= lim { rb = rbyte(); }
    if rb < 0 { give -1; }
    give rb % k;
}
fn looks(c) -> int { repeat li in 0..len(LOOK) { if LOOK[li] == c { give 1; } } give 0; }
fn addset(which, flags) -> int {
    let sl = 0;
    if which == 0 { sl = len(LOWER); } if which == 1 { sl = len(UPPER); } if which == 2 { sl = len(DIGIT); }
    if which == 3 { sl = len(SYM1); } if which == 4 { sl = len(SYM2); }
    repeat ai in 0..sl {
        let ch = 0;
        if which == 0 { ch = LOWER[ai]; } if which == 1 { ch = UPPER[ai]; } if which == 2 { ch = DIGIT[ai]; }
        if which == 3 { ch = SYM1[ai]; } if which == 4 { ch = SYM2[ai]; }
        if (flags & 1) == 0 || looks(ch) == 0 { al[aln] = ch; aln++; }
    }
    give 0;
}
fn classof(c) -> int {
    if c >= 'a' && c <= 'z' { give 0; }
    if c >= 'A' && c <= 'Z' { give 1; }
    if c >= '0' && c <= '9' { give 2; }
    give 3;
}
// the k-th word of a |-separated list into gout; returns how many words the list has when k < 0
fn wordat(which, k) -> int {
    let wl = len(ADJ); if which == 1 { wl = len(NOUN); }
    let cnt = 0; let wi = 0;
    while wi < wl {
        let ch = ADJ[0]; if which == 0 { ch = ADJ[wi]; } else { ch = NOUN[wi]; }
        if ch == '|' { cnt++; } else if cnt == k { gout[gn] = ch; gn++; }
        wi++;
    }
    give cnt;
}
fn putgout() -> int { repeat oi in 0..gn { putc(gout[oi]); } putc('\n'); give 0; }
fn gen() -> int {
    at = 4;
    let tier = clamp(num(), 0, 5); let glen = num(); let flags = num(); skipsp();
    if tier == 5 {
        glen = clamp(glen, 3, 12);
        gn = 0;
        let na2 = wordat(0, -1); let nn2 = wordat(1, -1);
        repeat wk in 0..glen {
            if wk > 0 { gout[gn] = '-'; gn++; }
            let st = gn;
            let pick2 = rpick(na2 + nn2);
            if pick2 < 0 { puts("! random\n"); give 0; }
            if pick2 < na2 { wordat(0, pick2); } else { wordat(1, pick2 - na2); }
            gout[st] = gout[st] - 32;                          // a capital, which most sites want
        }
        gout[gn] = '-'; gn++;
        gout[gn] = DIGIT[clamp(rpick(10), 0, 9)]; gn++;        // and a digit
        puts("pw "); putgout();
        give 0;
    }
    glen = clamp(glen, 4, 128);
    aln = 0;
    if tier == 0 { addset(2, flags); } else { addset(0, flags); addset(1, flags); }
    if tier >= 2 { addset(2, flags); }
    if tier == 3 { addset(3, flags); }
    if tier == 4 { addset(4, flags); }
    let want = 0;
    if tier >= 1 { want = 3; } if tier >= 2 { want = 7; } if tier >= 3 { want = 15; }
    if tier == 0 { want = 4; }
    let tries = 0;
    while tries < 40 {
        gn = 0; let have = 0; let bad = 0;
        repeat gi in 0..glen {
            let pk = rpick(aln);
            if pk < 0 { bad = 1; } else { gout[gn] = al[pk]; gn++; have = have | (1 << classof(al[pk])); }
        }
        if bad == 1 { puts("! random\n"); give 0; }
        if (have & want) == want || glen < 4 { puts("pw "); putgout(); give 0; }
        tries++;
    }
    puts("! random\n");
    give 0;
}
fn user() -> int {
    at = 5;
    let style = clamp(num(), 0, 3); skipsp();
    gn = 0;
    let na3 = wordat(0, -1); let nn3 = wordat(1, -1);
    if style == 3 {
        gout[gn] = LOWER[clamp(rpick(26), 0, 25)]; gn++;
        repeat ui in 0..9 { let rp = rpick(36); if rp < 26 { gout[gn] = LOWER[clamp(rp, 0, 25)]; } else { gout[gn] = DIGIT[clamp(rp - 26, 0, 9)]; } gn++; }
    } else {
        wordat(0, clamp(rpick(na3), 0, na3 - 1));
        if style == 1 { gout[gn] = '.'; gn++; }
        if style == 2 { gout[gn] = '_'; gn++; }
        wordat(1, clamp(rpick(nn3), 0, nn3 - 1));
        if style == 2 { gout[gn] = '_'; gn++; }
        if style != 1 {
            let dn = 2; if style == 2 { dn = 3; }
            repeat di2 in 0..dn { gout[gn] = DIGIT[clamp(rpick(10), 0, 9)]; gn++; }
        }
    }
    puts("user "); putgout();
    give 0;
}

// ---------------------------------------------------------------------------------------------- main
fn main() -> int {
    while readline() >= 0 {
        if n == 0 { continue; }
        if word(0, K_TABLE, L_TABLE) == 1 { table(); continue; }
        if word(0, K_SWEEP, L_SWEEP) == 1 { sweep(); continue; }
        if word(0, K_CHA, L_CHA) == 1 { chacha(); continue; }
        if word(0, K_VLOCK, L_VLOCK) == 1 { vault(0); continue; }
        if word(0, K_VOPEN, L_VOPEN) == 1 { vault(1); continue; }
        if word(0, K_GEN, L_GEN) == 1 { gen(); continue; }
        if word(0, K_USER, L_USER) == 1 { user(); continue; }
        if word(0, K_SHA, L_SHA) == 1 {           // @sha HEX: SHA-256 of the bytes (self-test)
            at = L_SHA; skipsp(); shainit();
            while at + 1 < n { shabyte(hexv(ln[at]) * 16 + hexv(ln[at + 1])); at += 2; }
            shafinal(); puts("sha "); repeat hi in 0..32 { hex2(hd[hi]); } putc('\n');
            continue;
        }
        if word(0, K_KDF, L_KDF) == 1 {           // @kdf ITER SALTHEX PWHEX: plain PBKDF2-HMAC-SHA256, 32 bytes (self-test)
            at = L_KDF; let it2 = num(); saltn = hexto(0, 64); mkn = 0; hexto(1, 2048);
            pbkdf2(it2, 1); puts("kdf "); repeat ki2 in 0..32 { hex2(dk[ki2]); } putc('\n');
            continue;
        }
        if word(0, K_HASH, L_HASH) == 1 {
            let a = L_HASH;
            while a < n && ln[a] == ' ' { a++; }
            puts("hash "); puthex(hash(a, n)); putc('\n');
            continue;
        }
        if word(0, K_VERD, L_VERD) == 1 {
            at = L_VERD;
            let m = num(); let j = num(); let t = num(); let k = num();
            putc(verdict(m, j, t, k)); putc('\n');
            continue;
        }
        if word(0, K_DECO, L_DECO) == 1 { at = L_DECO; let s = num(); let b = num(); decorate(s, b); continue; }
        if word(0, K_PERS, L_PERS) == 1 { at = L_PERS; let s2 = num(); let f = num(); persona(s2, f); continue; }
        if word(0, K_SITE, L_SITE) == 1 {
            let a2 = L_SITE;
            while a2 < n && ln[a2] == ' ' { a2++; }
            let st = site(a2, n);
            puts("site ");
            repeat k2 in st..n { putc(lower(ln[k2])); }
            puts(" "); puthex(hash(st, n)); putc('\n');
            continue;
        }
        puts("? unknown command\n");
    }
    give 0;
}
