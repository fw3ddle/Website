# Meowzer 4 🐱

A browser with its brain written in ꟻX (`core/meowcore.fx`). Each platform draws pages with the engine it already has: WebView2 on Windows, WebKit on Linux, macOS and iOS, and Gecko on Android. Every platform shares one face (`ui/`).

## Install — the easy way
| Platform | Do this |
|---|---|
| **Windows** | Double-click `hosts/windows/Install.cmd` in the Windows zip. No admin needed. |
| **Arch** | `cd hosts/linux && makepkg -si`, or `./install.sh` |
| **Debian / Ubuntu** | `cd hosts/linux && ./install.sh`, or `./make-deb.sh`, then `sudo apt install ./meowzer4_*.deb` |
| **Fedora** | `cd hosts/linux && ./install.sh` |
| **Flatpak** | `cd hosts/linux && flatpak-builder --user --install build-dir app.meowzer.Meowzer4.yml` |
| **macOS** | `cd hosts/apple && ./build-mac.sh` |
| **iPhone / iPad** | `cd hosts/apple && ./build-mac.sh ios`, then press ▶ in Xcode |
| **Android** | Install `Meowzer4.apk` from the Android zip (64-bit ARM phones), or rebuild: open `hosts/android` in Android Studio and press ▶, or run `./build-android.sh` |
| **QNX** | See `hosts/qnx/README.md`. It's a starting point; it needs QNX SDP 8, which you download yourself. |

## What's tested
* **Windows** is built and tested.
* The **Android** host is built (a debug-signed APK) but hasn't been run on a phone yet.
* The **Linux, macOS and iOS** hosts are written to the same protocol (`hosts/PROTOCOL.md`), but they **haven't been compiled yet**. Expect a few fixes on the first build.
* The vault's cipher in the Swift and Kotlin ports follows the construction that `tests/vault-port.js` checks byte for byte against meowcore.

## What's in it
* **🐾 ꟻX engine** (Windows):
  * Any tab can draw a page with Meowzer's own document engine instead of the web engine. Use ☰ ▸ Engine for this tab, or type `fx:` before an address.
  * The page is fetched alone: no cookies, scripts, styles, pictures or trackers.
  * `engine/meowpaint.fx` (from Astra's Engine Lab) reads it and lays it out in native ꟻX. Meowzer checks the display list before drawing it.
  * It's a reader for simple pages, not a replacement for the web engine.
* **🎲 Somewhere random** on the new-tab page (Windows):
  * Meowzer makes up web addresses from random bytes: no directory or list.
  * It tries eight at a time and goes only to one that is really alive: https, a real HTML page with a title, not a parked "for sale" page.
  * Obvious adult and gambling sites are skipped by a word check, which is a rough filter, not a guarantee.
* **Blocking** with the lists in `core/lists`, and the cat counts what it blocks.
* **Themes**: the theme studio, plus 🖌 Every colour, which can change any colour of the face, the shelf and the window.
* **🐾 Vault**:
  * Saved logins, with passwords hidden behind paw prints.
  * The paw button on login forms.
  * Autofill set to ask, auto or off (☰ ▸ Vault & autofill).
  * A password and user-name generator with six tiers.
  * Export, import and wipe, with an optional password on export.
  * Vault files are sealed so that only Meowzer opens them: PBKDF2-SHA256, two ChaCha20 streams, then HMAC-SHA256.
* **Open any file** (Ctrl+O): png, jpg, gif, webp, svg, pdf, mp3, mp4, webm and html go to the engine. ꟻX source, ꟻX bundles, zip, Markdown, CSV, JSON, code and anything else open in Meowzer's viewer, with a hex view as the last resort.

## Folders
* `core/`: meowcore (ꟻX) and the lists.
* `engine/`: meowpaint, the ꟻX document engine, with its fixtures and tests (`node engine/tests/test-engine.js <meowpaint.exe>`).
* `TEST-REPORT.md`: exactly what was tested and what wasn't.
* `ui/`: the face, the page script, the viewer, the shelf and the themes.
* `hosts/<platform>/`: each platform's host and its build scripts.
* `tests/`: test scripts for the Windows build, plus `vault-port.js`.
* `tools/make-release.ps1`: makes the release zips.
