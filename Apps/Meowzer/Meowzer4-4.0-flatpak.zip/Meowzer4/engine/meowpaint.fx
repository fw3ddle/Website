// Meowzer's first independent document engine, written in native ꟻX 0.29.
// It builds a bounded DOM subset and emits a text display list. No browser engine,
// JavaScript, CSS implementation, HTTP client or GUI toolkit is linked here.
// Input: @render WIDTH ADV16 ADV20 ADV24 ADV28 ADV32\n followed by UTF-8 HTML.
// Output: JSON Lines; consumers must require a final `end` before showing a page.

const MAX_INPUT = 1048576;
const MAX_NODES = 16384;
const MAX_DEPTH = 128;
const MAX_OPS = 32768;
const MAX_HEIGHT = 200000;
let G_Input: [u8; 1048576];
let g_length = 0;
let g_width = 900;
let g_error = 0;
let G_Advance = [10, 12, 15, 17, 20];
const G_Size = [16, 20, 24, 28, 32];
const G_TagNames = "html|head|body|title|script|style|template|p|div|section|article|main|header|footer|nav|aside|h1|h2|h3|h4|h5|h6|br|hr|a|b|strong|i|em|u|pre|code|ul|ol|li|blockquote|img|table|tr|td|th|span|form|input|button|select|textarea|noscript|meta|link|base|source|wbr";
let G_TagStart: [int; 64];
let G_TagLength: [int; 64];
let g_tagCount = 0;
let G_Kind: [int; 16384];
let G_Parent: [int; 16384];
let G_First: [int; 16384];
let G_Last: [int; 16384];
let G_Next: [int; 16384];
let G_Start: [int; 16384];
let G_Length: [int; 16384];
let G_HrefStart: [int; 16384];
let G_HrefLength: [int; 16384];
let G_HrefSeen: [int; 16384];
let G_IDStart: [int; 16384];
let G_IDLength: [int; 16384];
let G_Hidden: [int; 16384];
let G_Stack: [int; 128];
let g_nodes = 1;
let g_depth = 0;
let g_attrStart = 0;
let g_attrLength = 0;
let g_pos = 0;
let g_decodeEnd = 0;
let G_Buffer: [u8; 8192];
let g_bufferLen = 0;
let g_bufferCells = 0;
let g_cursorX = 24;
let g_cursorY = 24;
let g_lineHeight = 24;
let g_margin = 24;
let g_pendingSpace = 0;
let g_ops = 0;
let g_titleEmitted = 0;
let G_Font: [int; 16384];
let G_Bold: [int; 16384];
let G_Italic: [int; 16384];
let G_Pre: [int; 16384];
let G_Link: [int; 16384];
let G_Indent: [int; 16384];
let G_ListCount: [int; 16384];
let G_Digits: [u8; 24];

fn lower(a) { if a >= 'A' && a <= 'Z' { give a + 32; } give a; }
fn space(a) { give a == 32 || a == 9 || a == 10 || a == 12 || a == 13; }
fn alpha(a) { a = lower(a); give a >= 'a' && a <= 'z'; }
fn namechar(a) { give alpha(a) || a >= '0' && a <= '9' || a == '-' || a == ':' || a == '_'; }
fn numout(a) {
    if a < 0 { putc('-'); a = 0 - a; }
    if a == 0 { putc('0'); give 0; }
    let k = 0;
    while a > 0 { G_Digits[k] = '0' + a % 10; a /= 10; k++; }
    while k > 0 { k--; putc(G_Digits[k]); }
    give 0;
}
fn jsonbyte(a) {
    if a == '"' || a == '\\' { putc('\\'); putc(a); }
    else if a == 10 { puts("\\n"); }
    else if a == 13 { puts("\\r"); }
    else if a == 9 { puts("\\t"); }
    else if a < 32 { putc(' '); }
    else { putc(a); }
    give 0;
}
fn jsonbuffer() { putc('"'); repeat k in 0..g_bufferLen { jsonbyte(G_Buffer[k]); } putc('"'); give 0; }
fn tagsInit() {
    let a = 0;
    repeat k in 0..len(G_TagNames) + 1 {
        if k == len(G_TagNames) || G_TagNames[k] == '|' {
            g_tagCount++; G_TagStart[g_tagCount] = a; G_TagLength[g_tagCount] = k - a; a = k + 1;
        }
    }
    give 0;
}
fn tagAt(a, n, kind) {
    if kind < 1 || kind > g_tagCount || n != G_TagLength[kind] { give 0; }
    repeat k in 0..n { if lower(G_Input[a + k]) != G_TagNames[G_TagStart[kind] + k] { give 0; } }
    give 1;
}
fn tagKind(a, n) { repeat k in 1..g_tagCount + 1 { if tagAt(a, n, k) { give k; } } give 0; }
fn attrName(a, n, which) {
    if which == 1 { give n == 4 && lower(G_Input[a]) == 'h' && lower(G_Input[a+1]) == 'r' && lower(G_Input[a+2]) == 'e' && lower(G_Input[a+3]) == 'f'; }
    if which == 2 { give n == 2 && lower(G_Input[a]) == 'i' && lower(G_Input[a+1]) == 'd'; }
    if which == 3 { give n == 3 && lower(G_Input[a]) == 'a' && lower(G_Input[a+1]) == 'l' && lower(G_Input[a+2]) == 't'; }
    if which == 4 { give n == 6 && lower(G_Input[a]) == 'h' && lower(G_Input[a+1]) == 'i' && lower(G_Input[a+2]) == 'd' && lower(G_Input[a+3]) == 'd' && lower(G_Input[a+4]) == 'e' && lower(G_Input[a+5]) == 'n'; }
    give 0;
}
fn nodeAdd(kind, a, n) {
    if g_nodes >= MAX_NODES { g_error = 2; give 0; }
    let result = g_nodes; g_nodes++;
    let parent = G_Stack[g_depth];
    G_Kind[result] = kind; G_Start[result] = a; G_Length[result] = n; G_Parent[result] = parent;
    if G_First[parent] == 0 { G_First[parent] = result; } else { G_Next[G_Last[parent]] = result; }
    G_Last[parent] = result;
    give result;
}
fn voidTag(kind) { give kind == 23 || kind == 24 || kind == 37 || kind == 44 || kind >= 49; }
fn blockTag(kind) { give kind >= 8 && kind <= 24 || kind >= 31 && kind <= 36 || kind >= 38 && kind <= 41 || kind == 43; }
fn closeTag(kind) {
    let k = g_depth;
    while k > 0 { if G_Kind[G_Stack[k]] == kind { g_depth = k - 1; give 0; } k--; }
    give 0;
}
fn rawEnd(a, kind) {
    while a < g_length {
        if G_Input[a] == '<' && a + 2 < g_length && G_Input[a+1] == '/' {
            let p = a + 2; let begin = p;
            while p < g_length && namechar(G_Input[p]) { p++; }
            if tagAt(begin, p - begin, kind) && (p == g_length || space(G_Input[p]) || G_Input[p] == '>') { give a; }
        }
        a++;
    }
    give g_length;
}
fn parseDOM() {
    let p = 0;
    while p < g_length && g_error == 0 {
        if G_Input[p] != '<' || p + 1 >= g_length || !(alpha(G_Input[p+1]) || G_Input[p+1] == '/' || G_Input[p+1] == '!' || G_Input[p+1] == '?') {
            let start = p; p++;
            while p < g_length && G_Input[p] != '<' { p++; }
            nodeAdd(100, start, p - start); continue;
        }
        if p + 3 < g_length && G_Input[p+1] == '!' && G_Input[p+2] == '-' && G_Input[p+3] == '-' {
            p += 4;
            while p + 2 < g_length && !(G_Input[p] == '-' && G_Input[p+1] == '-' && G_Input[p+2] == '>') { p++; }
            p = min(p + 3, g_length); continue;
        }
        if G_Input[p+1] == '!' || G_Input[p+1] == '?' {
            p += 2; while p < g_length && G_Input[p] != '>' { p++; } p = min(p + 1, g_length); continue;
        }
        p++; let closing = 0;
        if G_Input[p] == '/' { closing = 1; p++; }
        let nameStart = p; while p < g_length && namechar(G_Input[p]) { p++; }
        let kind = tagKind(nameStart, p - nameStart);
        if kind == 0 || closing {
            let quote = 0;
            while p < g_length {
                let ch = G_Input[p]; p++;
                if quote != 0 { if ch == quote { quote = 0; } }
                else if ch == '"' || ch == '\'' { quote = ch; }
                else if ch == '>' { break; }
            }
            if closing && kind != 0 { closeTag(kind); }
            continue;
        }
        if kind == 8 || blockTag(kind) && kind != 23 { if G_Kind[G_Stack[g_depth]] == 8 { closeTag(8); } }
        if kind == 35 {
            let back = g_depth;
            while back > 0 {
                let prior = G_Kind[G_Stack[back]];
                if prior == 33 || prior == 34 { break; }
                if prior == 35 { g_depth = back - 1; break; }
                back--;
            }
        }
        let node = nodeAdd(kind, 0, 0); if g_error { break; }
        while p < g_length {
            while p < g_length && space(G_Input[p]) { p++; }
            if p >= g_length { break; }
            if G_Input[p] == '>' { p++; break; }
            if G_Input[p] == '/' { p++; continue; }
            let attr = p;
            while p < g_length && !space(G_Input[p]) && G_Input[p] != '=' && G_Input[p] != '>' && G_Input[p] != '/' { p++; }
            let alen = p - attr;
            if alen == 0 { p++; continue; }
            while p < g_length && space(G_Input[p]) { p++; }
            let value = p; let vlen = 0;
            if p < g_length && G_Input[p] == '=' {
                p++; while p < g_length && space(G_Input[p]) { p++; }
                let aq = 0;
                if p < g_length && (G_Input[p] == '"' || G_Input[p] == '\'') { aq = G_Input[p]; p++; }
                value = p;
                while p < g_length {
                    if aq != 0 && G_Input[p] == aq { break; }
                    if aq == 0 && (space(G_Input[p]) || G_Input[p] == '>') { break; }
                    p++;
                }
                vlen = p - value; if aq != 0 && p < g_length { p++; }
            }
            if attrName(attr, alen, 1) && !G_HrefSeen[node] { G_HrefSeen[node]=1; if vlen<=4096 { G_HrefStart[node] = value; G_HrefLength[node] = vlen; } }
            if attrName(attr, alen, 2) && G_IDLength[node] == 0 { G_IDStart[node] = value; G_IDLength[node] = min(vlen, 256); }
            if attrName(attr, alen, 3) && kind == 37 { G_Start[node] = value; G_Length[node] = min(vlen, 4096); }
            if attrName(attr, alen, 4) { G_Hidden[node] = 1; }
        }
        if kind == 5 || kind == 6 || kind == 4 || kind == 47 {
            let end = rawEnd(p, kind);
            if kind == 4 || kind == 47 {
                if g_depth + 1 >= MAX_DEPTH { g_error = 3; break; }
                g_depth++; G_Stack[g_depth] = node; nodeAdd(100, p, end-p); g_depth--;
            }
            p = end; continue;
        }
        if !voidTag(kind) {
            if g_depth + 1 >= MAX_DEPTH { g_error = 3; break; }
            g_depth++; G_Stack[g_depth] = node;
        }
    }
    give 0;
}

// Decode UTF-8 and a deliberately small entity set. Invalid scalars become U+FFFD.
fn scalar(cp) { if cp <= 0 || cp > 0x10FFFF || cp >= 0xD800 && cp <= 0xDFFF { give 0xFFFD; } give cp; }
fn hexval(a) { if a >= '0' && a <= '9' { give a-'0'; } a=lower(a); if a >= 'a' && a <= 'f' { give a-'a'+10; } give -1; }
fn nextCode() {
    if g_pos >= g_decodeEnd { give -1; }
    let ch = G_Input[g_pos]; g_pos++;
    if ch == '&' {
        let a = g_pos; let end = a;
        while end < g_decodeEnd && end-a < 16 && G_Input[end] != ';' && !space(G_Input[end]) && G_Input[end] != '<' { end++; }
        if end < g_decodeEnd && G_Input[end] == ';' {
            let cp = -1; let n = end-a;
            if n > 1 && G_Input[a] == '#' {
                let k = a+1; let base = 10;
                if k < end && lower(G_Input[k]) == 'x' { base = 16; k++; }
                cp = 0; let digits = 0;
                while k < end { let v = hexval(G_Input[k]); if v < 0 || v >= base || cp > 0x10FFFF { cp = -1; break; } cp = cp*base+v; digits++; k++; }
                if digits == 0 { cp = -1; }
            }
            else if n == 3 && G_Input[a] == 'a' && G_Input[a+1] == 'm' && G_Input[a+2] == 'p' { cp = '&'; }
            else if n == 2 && G_Input[a+1] == 't' { if G_Input[a] == 'l' { cp = '<'; } else if G_Input[a] == 'g' { cp = '>'; } }
            else if n == 4 {
                if G_Input[a] == 'q' && G_Input[a+1] == 'u' && G_Input[a+2] == 'o' && G_Input[a+3] == 't' { cp = '"'; }
                else if G_Input[a] == 'a' && G_Input[a+1] == 'p' && G_Input[a+2] == 'o' && G_Input[a+3] == 's' { cp = '\''; }
                else if G_Input[a] == 'n' && G_Input[a+1] == 'b' && G_Input[a+2] == 's' && G_Input[a+3] == 'p' { cp = 160; }
                else if G_Input[a] == 'c' && G_Input[a+1] == 'o' && G_Input[a+2] == 'p' && G_Input[a+3] == 'y' { cp = 169; }
            }
            if cp >= 0 { g_pos = end+1; give scalar(cp); }
        }
        give '&';
    }
    if ch < 128 { if ch == 0 { give 0xFFFD; } if ch == 13 { if g_pos < g_decodeEnd && G_Input[g_pos] == 10 { g_pos++; } give 10; } give ch; }
    let need = 0; let code = 0; let low = 0;
    if ch >= 194 && ch <= 223 { need=1; code=ch&31; low=128; }
    else if ch >= 224 && ch <= 239 { need=2; code=ch&15; low=2048; }
    else if ch >= 240 && ch <= 244 { need=3; code=ch&7; low=65536; }
    else { give 0xFFFD; }
    if g_pos+need > g_decodeEnd { give 0xFFFD; }
    repeat k in 0..need { let v2=G_Input[g_pos+k]; if v2 < 128 || v2 > 191 { give 0xFFFD; } code=code*64+(v2&63); }
    if code < low || scalar(code) != code { give 0xFFFD; }
    g_pos += need; give code;
}
fn bufferClear() { g_bufferLen=0; g_bufferCells=0; give 0; }
fn bufferByte(a) { if g_bufferLen < 8192 { G_Buffer[g_bufferLen]=a; g_bufferLen++; } else { g_error=4; } give 0; }
fn bufferCode(cp) {
    if cp < 128 { bufferByte(cp); }
    else if cp < 2048 { bufferByte(192|(cp>>6)); bufferByte(128|(cp&63)); }
    else if cp < 65536 { bufferByte(224|(cp>>12)); bufferByte(128|((cp>>6)&63)); bufferByte(128|(cp&63)); }
    else { bufferByte(240|(cp>>18)); bufferByte(128|((cp>>12)&63)); bufferByte(128|((cp>>6)&63)); bufferByte(128|(cp&63)); }
    g_bufferCells++;
    give 0;
}
fn decodeSlice(a,n) { bufferClear(); let save=g_pos; let stop=g_decodeEnd; g_pos=a; g_decodeEnd=a+n; while g_pos < g_decodeEnd && g_bufferLen < 8188 { bufferCode(nextCode()); } g_pos=save; g_decodeEnd=stop; give 0; }
fn jsonSlice(a,n) { decodeSlice(a,n); jsonbuffer(); give 0; }
fn newline(extra) {
    g_cursorY += g_lineHeight + extra; g_cursorX=g_margin; g_lineHeight=24; g_pendingSpace=0;
    if g_cursorY > MAX_HEIGHT { g_error=5; }
    give 0;
}
fn drawBuffer(node) {
    if g_bufferLen == 0 || g_error { give 0; }
    if g_ops >= MAX_OPS { g_error=6; give 0; }
    let font=G_Font[node]; let size=G_Size[font]; let width=g_bufferCells*G_Advance[font];
    if g_pendingSpace && g_cursorX > g_margin { g_cursorX += G_Advance[font]; }
    if g_cursorX > g_margin && g_cursorX+width > g_width-24 { newline(0); }
    g_pendingSpace=0;
    puts("{\"kind\":\"text\",\"x\":");numout(g_cursorX);puts(",\"y\":");numout(g_cursorY);
    puts(",\"w\":");numout(width);puts(",\"h\":");numout(size+8);puts(",\"size\":");numout(size);
    puts(",\"bold\":");numout(G_Bold[node]);puts(",\"italic\":");numout(G_Italic[node]);puts(",\"node\":");numout(node);
    puts(",\"text\":");jsonbuffer();puts(",\"href\":");
    let link=G_Link[node]; if link>0 { jsonSlice(G_HrefStart[link],G_HrefLength[link]); } else { puts("\"\""); }
    puts("}\n");g_ops++;g_cursorX+=width;g_lineHeight=max(g_lineHeight,size+8);bufferClear();give 0;
}
fn renderText(node,a,n) {
    g_pos=a;g_decodeEnd=a+n;bufferClear();
    let maxCells=max(1,(g_width-24-g_margin)/G_Advance[G_Font[node]]);
    while g_pos < g_decodeEnd && !g_error {
        let cp=nextCode();
        if G_Pre[node] && cp==10 { drawBuffer(node);newline(0);continue; }
        if space(cp) {
            drawBuffer(node);
            if G_Pre[node] { let count=1; if cp==9 { count=4-((g_cursorX-g_margin)/G_Advance[G_Font[node]])%4; } repeat k in 0..count { bufferCode(' '); } drawBuffer(node); }
            else { g_pendingSpace=1; }
        } else {
            if g_bufferCells>=maxCells || g_bufferLen>8180 { drawBuffer(node);newline(0); }
            bufferCode(cp);
        }
    }
    drawBuffer(node);give 0;
}
fn inherited(node) {
    let p=G_Parent[node];G_Font[node]=G_Font[p];G_Bold[node]=G_Bold[p];G_Italic[node]=G_Italic[p];G_Pre[node]=G_Pre[p];G_Link[node]=G_Link[p];G_Indent[node]=G_Indent[p];
    let kind=G_Kind[node];
    if kind>=17 && kind<=22 { G_Font[node]=max(0,21-kind);G_Bold[node]=1; }
    if kind==26 || kind==27 || kind==41 { G_Bold[node]=1; }
    if kind==28 || kind==29 { G_Italic[node]=1; }
    if kind==31 { G_Pre[node]=1; }
    if kind==25 && G_HrefLength[node]>0 { G_Link[node]=node; }
    if kind==33 || kind==34 || kind==36 { G_Indent[node]++; }
    give 0;
}
fn layoutNode(node) {
    if g_error { give 0; }
    let kind=G_Kind[node]; inherited(node);
    if kind==4 && !g_titleEmitted && G_First[node]>0 {
        let t=G_First[node];puts("{\"kind\":\"title\",\"text\":");jsonSlice(G_Start[t],min(G_Length[t],512));puts("}\n");g_titleEmitted=1;give 0;
    }
    if kind==2 || kind==5 || kind==6 || kind==7 || G_Hidden[node] { 
        // A head may contain title metadata but none of its contents are painted.
        if kind==2 { let c=G_First[node];while c>0 { if G_Kind[c]==4 { layoutNode(c); } c=G_Next[c]; } }
        give 0;
    }
    let oldMargin=g_margin;g_margin=min(24+G_Indent[node]*24,max(24,g_width-100));
    if blockTag(kind) && kind!=23 {
        if g_cursorX>oldMargin { newline(0); }
        g_cursorX=g_margin;g_pendingSpace=0;
        if kind>=17 && kind<=22 { g_cursorY+=12; }
    }
    if G_IDLength[node]>0 { puts("{\"kind\":\"anchor\",\"y\":");numout(g_cursorY);puts(",\"text\":");jsonSlice(G_IDStart[node],G_IDLength[node]);puts("}\n"); }
    if kind==100 { renderText(node,G_Start[node],G_Length[node]); }
    else if kind==23 { newline(0); }
    else if kind==24 {
        if g_ops>=MAX_OPS { g_error=6;give 0; }
        puts("{\"kind\":\"rule\",\"x\":");numout(g_margin);puts(",\"y\":");numout(g_cursorY+10);puts(",\"w\":");numout(g_width-g_margin-24);puts(",\"h\":1}\n");g_ops++;newline(6);
    }
    else if kind==37 {
        bufferClear();bufferCode('[');bufferCode('i');bufferCode('m');bufferCode('a');bufferCode('g');bufferCode('e');bufferCode(']');drawBuffer(node);g_pendingSpace=1;
        if G_Length[node]>0 { renderText(node,G_Start[node],G_Length[node]); }
    }
    else {
        if kind==35 {
            bufferClear();let lp=G_Parent[node];
            if G_Kind[lp]==34 {
                G_ListCount[lp]++;let count=G_ListCount[lp];let digits=0;
                while count>0 { G_Digits[digits]='0'+count%10;count/=10;digits++; }
                while digits>0 { digits--;bufferCode(G_Digits[digits]); }
                bufferCode('.');
            } else { bufferCode(8226); }
            drawBuffer(node);g_pendingSpace=1;
        }
        let child=G_First[node];while child>0 && !g_error { layoutNode(child);child=G_Next[child]; }
    }
    if blockTag(kind) && kind!=23 && kind!=24 {
        if g_cursorX>g_margin { newline(0); }
        if kind==8 || kind>=17 && kind<=22 || kind==31 || kind==36 { g_cursorY+=8; }
    }
    g_margin=oldMargin;if g_cursorX<g_margin { g_cursorX=g_margin; }
    give 0;
}
fn headerNumber() {
    let value=0;
    while g_pos<g_length && space(G_Input[g_pos]) { g_pos++; }
    if g_pos>=g_length || G_Input[g_pos]<'0' || G_Input[g_pos]>'9' { g_error=7;give 0; }
    while g_pos<g_length && G_Input[g_pos]>='0' && G_Input[g_pos]<='9' {
        if value>1000000 { g_error=7;give 0; }value=value*10+G_Input[g_pos]-'0';g_pos++;
    }
    give value;
}
fn main() {
    let ch=getc();
    while ch>=0 && ch!=10 && g_length<512 { G_Input[g_length]=ch;g_length++;ch=getc(); }
    const prefix="@render ";
    if ch!=10 || g_length<8 { puts("{\"kind\":\"error\",\"code\":7}\n");give 1; }
    repeat p in 0..8 { if G_Input[p]!=prefix[p] { g_error=7; } }
    g_pos=7;g_width=headerNumber();
    if g_width<240 || g_width>4096 { puts("{\"kind\":\"error\",\"code\":7}\n");give 1; }
    repeat k in 0..5 { let adv=headerNumber();if adv>=1 && adv<=64 { G_Advance[k]=adv; } else { g_error=7; } }
    while g_pos<g_length && space(G_Input[g_pos]) { g_pos++; }
    if g_pos!=g_length || g_error { puts("{\"kind\":\"error\",\"code\":7}\n");give 1; }
    g_length=0;ch=getc();
    while ch>=0 && g_length<MAX_INPUT { G_Input[g_length]=ch;g_length++;ch=getc(); }
    if ch>=0 { puts("{\"kind\":\"error\",\"code\":1}\n");give 1; }
    tagsInit();parseDOM();
    if !g_error {
        puts("{\"kind\":\"document\",\"schema\":1,\"engine\":\"Meowzer-FX-0.1\",\"width\":");numout(g_width);puts("}\n");
        let child=G_First[0];while child>0 && !g_error { layoutNode(child);child=G_Next[child]; }
    }
    if g_cursorY+g_lineHeight+24>MAX_HEIGHT { g_error=5; }
    if g_error { puts("{\"kind\":\"error\",\"code\":");numout(g_error);puts("}\n");give 1; }
    puts("{\"kind\":\"end\",\"height\":");numout(g_cursorY+g_lineHeight+24);puts(",\"nodes\":");numout(g_nodes);puts(",\"ops\":");numout(g_ops);puts("}\n");give 0;
}
