// test-engine.js — the same checks as Astra's test_engine.py, in Node (no Python on the Windows build machine).
//   node engine/tests/test-engine.js <meowpaint.exe>
// Every rendered answer is also checked by the viewer's own validator (ui/meowzer-paint.html's parseFrame).
'use strict';
const { spawnSync } = require('child_process'), fs = require('fs'), path = require('path'), vm = require('vm');
const ENGINE = process.argv[2] || path.join(__dirname, '..', 'meowpaint.exe');

// load parseFrame straight out of the page, so the test checks the code that ships
const page = fs.readFileSync(path.join(__dirname, '..', '..', 'ui', 'meowzer-paint.html'), 'utf8');
const m = page.match(/\/\/ <parseFrame>([\s\S]*?)\/\/ <\/parseFrame>/); if (!m) throw new Error('parseFrame not found in meowzer-paint.html');
const box = {}; vm.runInNewContext(m[1] + ';this.parseFrame=parseFrame;', box); const parseFrame = box.parseFrame;

function run(source, width = 800, header) {
  const data = Buffer.concat([header || Buffer.from(`@render ${width} 10 12 15 17 20\n`), Buffer.isBuffer(source) ? source : Buffer.from(source)]);
  const r = spawnSync(ENGINE, { input: data, timeout: 8000, maxBuffer: 16 << 20 });
  const text = r.stdout.toString('utf8'), records = text.split('\n').filter(Boolean).map((l) => JSON.parse(l));
  if (r.status === 0) {
    const f = parseFrame(text, width); if (f.error) throw new Error('validator refused a good answer: ' + f.error);
    const ops = records.filter((o) => o.kind === 'text' || o.kind === 'rule'), end = records.at(-1);
    if (records[0].kind !== 'document' || end.kind !== 'end' || ops.length !== end.ops) throw new Error('bad framing');
    for (const o of ops) if (o.x < 0 || o.x + o.w > width || o.y < 0 || o.y + o.h > end.height || end.height > 200000) throw new Error('out of bounds ' + JSON.stringify(o));
  } else {
    if (r.status !== 1) throw new Error('exit ' + r.status + ' ' + (r.error || ''));
    if (records.at(-1).kind !== 'error') throw new Error('no error record');
    if (!parseFrame(text, width).error) throw new Error('validator accepted an error answer');
  }
  return [r.status, records];
}
const words = (r) => r.filter((o) => o.kind === 'text').map((o) => o.text).join(' ');
const eq = (a, b, what) => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`${what}: ${JSON.stringify(a)} != ${JSON.stringify(b)}`); };
const ok = (c, what) => { if (!c) throw new Error(what); };

const tests = {
  basic_dom_and_emphasis() { const [c, r] = run('<TITLE>Meowzer &amp; ꟻX</TITLE><h1>Hello</h1><p>A <b>bold</b> <i>cat</i>.</p>');
    eq(c, 0, 'exit'); eq(r[1].text, 'Meowzer & ꟻX', 'title'); ok(r.some((o) => o.text === 'bold' && o.bold === 1), 'bold'); ok(r.some((o) => o.text === 'cat' && o.italic === 1), 'italic'); },
  script_style_head_hidden_template() { const [, r] = run('<head>HEAD<style>STYLE</style><title>Title</title></head><script>"<b>SCRIPT</b>"</script><template>TEMPLATE</template><p hidden>SECRET</p>Visible'); eq(words(r), 'Visible', 'text'); },
  entities_utf8_invalid_scalars() { const [, r] = run(Buffer.concat([Buffer.from('<p>&lt;&gt;&amp;&quot;&apos;&nbsp;&copy; &#x1F408; &#955; &#0; '), Buffer.from([0xc0, 0xaf]), Buffer.from('</p>')]));
    const t = words(r); ok(t.includes('<>&"\' ©'), 'entities'); ok(t.includes('🐈'), 'emoji'); ok(t.includes('λ'), 'lambda'); ok(t.includes('�'), 'replacement'); },
  href_decoding_and_first_duplicate() { const [, r] = run('<a href="/next?a=1&amp;b=2">one two three</a><a href="" href="https://bad.example">empty</a>');
    eq(r.filter((o) => ['one', 'two', 'three'].includes(o.text)).map((o) => o.href), Array(3).fill('/next?a=1&b=2'), 'hrefs'); eq(r.find((o) => o.text === 'empty').href, '', 'empty href'); },
  wrapping_and_long_words() { const [, r] = run('<h1>' + 'hello '.repeat(60) + '</h1><p>' + 'x'.repeat(2000) + '</p>', 240); ok(r.at(-1).height > 1000, 'height'); },
  pre_and_lists() { const [, r] = run('<pre>a\n\tb</pre><ol><li>one<li>two</ol><ul><li>three</ul>'); const t = words(r);
    ok(t.includes('1.') && t.includes('2.') && t.includes('•'), 'markers'); const a = r.find((o) => o.text === 'a'), b = r.find((o) => o.text === 'b'); ok(b.y > a.y && b.x > a.x, 'pre layout'); },
  anchor_and_image_alt() { const [, r] = run('<h2 id="a&amp;b">Section</h2><img alt="sleepy cat"><p>after</p>'); ok(r.some((o) => o.kind === 'anchor' && o.text === 'a&b'), 'anchor'); ok(words(r).includes('[image] sleepy cat'), 'alt'); },
  empty_and_comments() { for (const s of ['', '<!-- hidden -->', '<', '</', '<!--', '<!doctype html>']) eq(run(s)[0], 0, JSON.stringify(s)); },
  protocol_rejects_bad_header() { for (const h of ['@oopsxx 800 10 12 15 17 20\n', '@render 800\n', '@render 800 10 12 15 17 0\n', '@render 239 10 12 15 17 20\n', '@render 800 10 12 15 17 20junk\n']) eq(run('', 800, Buffer.from(h))[0], 1, h.trim()); },
  input_limit() { eq(run(' '.repeat(1 << 20))[0], 0, '1 MiB'); eq(run(' '.repeat((1 << 20) + 1))[1].at(-1).code, 1, 'over'); },
  depth_limit() { eq(run('<div>'.repeat(130))[1].at(-1).code, 3, 'depth'); },
  node_and_height_limits() { eq(run('<img>'.repeat(16400))[1].at(-1).code, 2, 'nodes'); eq(run('<br>'.repeat(10000))[1].at(-1).code, 5, 'height'); },
  determinism() { const s = '<h2>Repeat me</h2><p>same input = same output</p>'; eq(run(s), run(s), 'same'); },
  fixtures() { for (const f of fs.readdirSync(path.join(__dirname, '..', 'fixtures'))) eq(run(fs.readFileSync(path.join(__dirname, '..', 'fixtures', f)), 900)[0], 0, f); },
  malformed_seeded_corpus() {
    let s = 42029; const rnd = (n) => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s % n; };   // xorshift32: its own seed, not Python's
    const atoms = ['<p>', '</p>', '<div>', '</div>', '<b>', '</h1>', '<a href="x&amp;y">', '</a>', '<!--', '-->', '<script>', '</script>', '\x00', '&amp;', '&#999999999999;', 'ꟻX', '🐈', 'text ', '<', '>', '"', "'", '<br>', '<li>', '<pre>', '</pre>'];
    const widths = [240, 400, 800, 1200, 4096];
    for (let i = 0; i < 300; i++) { let d = ''; for (let k = 1 + rnd(99); k > 0; k--) d += atoms[rnd(atoms.length)]; run(d, widths[rnd(5)]); }
  },
  validator_rejects_tampering() {
    const [, r] = run('<p>hello</p>', 800), good = r.map((o) => JSON.stringify(o));
    const bad = [good.slice(0, -1), [...good, good[1]], good.map((l) => l.replace('"x":24', '"x":900')), good.map((l) => l.replace('"size":16', '"size":17')),
      good.map((l) => l.replace('"Meowzer-FX-0.1"', '"Other"')), good.map((l) => l.replace(/"ops":\d+/, '"ops":99'))];
    for (const b of bad) ok(parseFrame(b.join('\n') + '\n', 800).error, 'accepted: ' + b.join(' ').slice(0, 120));
  },
};
let pass = 0, fail = 0;
for (const [name, f] of Object.entries(tests)) { try { f(); pass++; console.log('ok   ' + name); } catch (e) { fail++; console.log('FAIL ' + name + ': ' + e.message); } }
console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
