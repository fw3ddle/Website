#!/usr/bin/env python3
"""Compare native Forge output with the SDK's reference interpreter."""
import argparse, random, subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--fxc',required=True);p.add_argument('--cases',type=int,default=100);args=p.parse_args()
rng=random.Random(290042)
parts=['<p>','</p>','<h1>','</h1>','<a href="/x?a=1&amp;b=2">','</a>','<ol><li>','</ol>','<pre>','\n','</pre>','<script>x</script>','<img alt="CAT">','word ','&#x1f408;','<','\x00','</','<head><title>cat</title></head>']
for i in range(args.cases):
    html=''.join(rng.choice(parts) for _ in range(rng.randrange(1,80)))
    data=f'@render {rng.choice([240,800,4096])} 10 12 15 17 20\n'.encode()+html.encode()
    a=subprocess.run([str(root/'engine/meowpaint')],input=data,capture_output=True,timeout=8)
    b=subprocess.run([args.fxc,'run',str(root/'engine/meowpaint.fx')],input=data,capture_output=True,timeout=10)
    assert (a.returncode,a.stdout)==(b.returncode,b.stdout),(i,a.stdout[:300],b.stdout[:300],b.stderr[:300])
print(f'{args.cases} native/reference differential cases passed')
