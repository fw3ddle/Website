#!/usr/bin/env python3
"""Native FX engine checks. No browser engine is used as a renderer."""
import json, os, random, subprocess, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
ENGINE = Path(os.environ.get('MEOWPAINT', ROOT/'engine/meowpaint'))

def run(source, width=800, header=None):
    if isinstance(source, str): source=source.encode()
    data=header or f'@render {width} 10 12 15 17 20\n'.encode()
    r=subprocess.run([str(ENGINE)], input=data+source, capture_output=True, timeout=8)
    records=[json.loads(line) for line in r.stdout.splitlines()]
    if r.returncode==0:
        assert records[0]['kind']=='document' and records[-1]['kind']=='end'
        ops=[o for o in records if o['kind'] in ('text','rule')]
        assert len(ops)==records[-1]['ops']
        for o in ops:
            assert 0<=o['x'] and o['x']+o['w']<=width, o
            assert 0<=o['y'] and o['y']+o['h']<=records[-1]['height']<=200000, o
    else:
        assert r.returncode==1, (r.returncode,r.stderr,source[:500])
        assert records[-1]['kind']=='error'
    return r.returncode,records
def text(records):return ' '.join(o['text'] for o in records if o['kind']=='text')

class EngineTests(unittest.TestCase):
    def test_basic_dom_and_emphasis(self):
        code,r=run('<TITLE>Meowzer &amp; ꟻX</TITLE><h1>Hello</h1><p>A <b>bold</b> <i>cat</i>.</p>')
        self.assertEqual(code,0);self.assertEqual(r[1]['text'],'Meowzer & ꟻX')
        self.assertTrue(any(o.get('text')=='bold' and o.get('bold')==1 for o in r))
        self.assertTrue(any(o.get('text')=='cat' and o.get('italic')==1 for o in r))
    def test_script_style_head_hidden_template(self):
        _,r=run('<head>HEAD<style>STYLE</style><title>Title</title></head><script>"<b>SCRIPT</b>"</script><template>TEMPLATE</template><p hidden>SECRET</p>Visible')
        self.assertEqual(text(r),'Visible')
    def test_entities_utf8_invalid_scalars(self):
        _,r=run(b'<p>&lt;&gt;&amp;&quot;&apos;&nbsp;&copy; &#x1F408; &#955; &#0; \xc0\xaf</p>')
        self.assertIn('<>&"\'\u00a0©',text(r));self.assertIn('🐈',text(r));self.assertIn('λ',text(r));self.assertIn('�',text(r))
    def test_href_decoding_and_first_duplicate(self):
        _,r=run('<a href="/next?a=1&amp;b=2">one two three</a><a href="" href="https://bad.example">empty</a>')
        self.assertEqual([o['href'] for o in r if o.get('text') in ['one','two','three']],['/next?a=1&b=2']*3)
        self.assertEqual(next(o for o in r if o.get('text')=='empty')['href'],'')
    def test_wrapping_and_long_words(self):
        _,r=run('<h1>'+('hello '*60)+'</h1><p>'+('x'*2000)+'</p>',240)
        self.assertGreater(r[-1]['height'],1000)
    def test_pre_and_lists(self):
        _,r=run('<pre>a\n\tb</pre><ol><li>one<li>two</ol><ul><li>three</ul>')
        t=text(r);self.assertIn('1.',t);self.assertIn('2.',t);self.assertIn('•',t)
        a=next(o for o in r if o.get('text')=='a');b=next(o for o in r if o.get('text')=='b');self.assertGreater(b['y'],a['y']);self.assertGreater(b['x'],a['x'])
    def test_anchor_and_image_alt(self):
        _,r=run('<h2 id="a&amp;b">Section</h2><img alt="sleepy cat"><p>after</p>')
        self.assertTrue(any(o['kind']=='anchor' and o['text']=='a&b' for o in r));self.assertIn('[image] sleepy cat',text(r))
    def test_empty_and_comments(self):
        for s in ['', '<!-- hidden -->','<','</','<!--','<!doctype html>']:
            self.assertEqual(run(s)[0],0)
    def test_protocol_rejects_bad_header(self):
        for h in [b'@oopsxx 800 10 12 15 17 20\n',b'@render 800\n',b'@render 800 10 12 15 17 0\n',b'@render 239 10 12 15 17 20\n',b'@render 800 10 12 15 17 20junk\n']:
            self.assertEqual(run('',header=h)[0],1)
    def test_input_limit(self):
        self.assertEqual(run(' '*(1<<20))[0],0);self.assertEqual(run(' '*((1<<20)+1))[1][-1]['code'],1)
    def test_depth_limit(self):
        self.assertEqual(run('<div>'*130)[1][-1]['code'],3)
    def test_node_and_height_limits(self):
        self.assertEqual(run('<img>'*16400)[1][-1]['code'],2)
        self.assertEqual(run('<br>'*10000)[1][-1]['code'],5)
    def test_determinism(self):
        s='<h2>Repeat me</h2><p>same input = same output</p>';self.assertEqual(run(s),run(s))
    def test_malformed_seeded_corpus(self):
        rng=random.Random(42029)
        atoms=['<p>','</p>','<div>','</div>','<b>','</h1>','<a href="x&amp;y">','</a>','<!--','-->','<script>','</script>','\x00','&amp;','&#999999999999;','ꟻX','🐈','text ','<','>','"',"'",'<br>','<li>','<pre>','</pre>']
        for i in range(300):
            s=''.join(rng.choice(atoms) for _ in range(rng.randrange(1,100)))
            with self.subTest(case=i):run(s,rng.choice([240,400,800,1200,4096]))

if __name__=='__main__':unittest.main(verbosity=2)
