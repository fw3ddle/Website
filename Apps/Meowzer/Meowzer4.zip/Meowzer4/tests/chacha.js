// chacha.js — checks meowcore's @chacha against RFC 8439 §2.4.2 and against Node's own ChaCha20.
//   node tests/chacha.js <path to meowcore.exe>
const { execFileSync } = require('child_process');
const crypto = require('crypto');
const exe = process.argv[2] || require('path').join(__dirname, '..', 'build', 'windows', 'meowcore.exe');
const run = (rounds, key, nonce, lines) => execFileSync(exe, { input: '@chacha ' + rounds + ' ' + key.toString('hex') + ' ' + nonce.toString('hex') + '\n' + lines.map(b => b.toString('hex')).join('\n') + '\n@end\n' })
  .toString().split('\n').filter(l => l.startsWith('x ')).map(l => Buffer.from(l.slice(2).trim(), 'hex'));
let bad = 0; const check = (name, ok) => { console.log((ok ? 'ok   ' : 'FAIL ') + name); if (!ok) bad++; };

// RFC 8439 2.4.2: key 00..1f, nonce 000000000000004a00000000, counter 1
const key = Buffer.from([...Array(32).keys()]), nonce = Buffer.from('000000000000004a00000000', 'hex');
const pt = Buffer.from("Ladies and Gentlemen of the class of '99: If I could offer you only one tip for the future, sunscreen would be it.");
const want = Buffer.from('6e2e359a2568f98041ba0728dd0d6981e97e7aec1d4360c20a27afccfd9fae0bf91b65c5524733ab8f593dabcd62b3571639d624e65152ab8f530c359f0861d807ca0dbf500d6a6156a38e088a22b65e52bc514d16ccf806818ce91ab77937365af90bbf74a35be6b40b8eedf2785e42874d', 'hex');
check('RFC 8439 2.4.2', run(20, key, nonce, [pt])[0].equals(want));

// against Node across lines of odd lengths (the stream must run on between lines), and back again
const k2 = crypto.randomBytes(32), n2 = crypto.randomBytes(12), data = crypto.randomBytes(5000);
const parts = [data.subarray(0, 2048), data.subarray(2048, 2048 + 77), data.subarray(2125)];
const out = Buffer.concat(run(20, k2, n2, parts));
const iv = Buffer.concat([Buffer.from([1, 0, 0, 0]), n2]);   // Node's chacha20 IV: 32-bit LE counter, then the nonce
const node = crypto.createCipheriv('chacha20', k2, iv).update(data);
check('matches Node chacha20 over 3 lines (5000 bytes)', out.equals(node));
const chunks = b => { const l = []; for (let i = 0; i < b.length; i += 2048) l.push(b.subarray(i, i + 2048)); return l; };   // meowcore lines hold 4096 bytes at most
check('sealing twice gives the input back', Buffer.concat(run(20, k2, n2, chunks(out))).equals(data));
const r12 = Buffer.concat(run(12, k2, n2, [data.subarray(0, 300)])), r8 = Buffer.concat(run(8, k2, n2, [data.subarray(0, 300)]));
check('12 and 8 rounds differ from 20 and from each other', !r12.equals(node.subarray(0, 300)) && !r8.equals(r12));
check('12 rounds round-trips', Buffer.concat(run(12, k2, n2, [r12])).equals(data.subarray(0, 300)));
process.exit(bad ? 1 : 0);
