// cdp-errors.js — reloads the active page of a running Meowzer and prints script exceptions and console errors for 6 s.
const port = process.argv[2] || '9333';
(async () => {
  const list = await (await fetch(`http://127.0.0.1:${port}/json`)).json();
  const t = list.find(p => p.type === 'page' && !p.url.startsWith('https://meowzer.ui/meowzer-ui.html') || p.type === 'page' && p.url.includes('#ntp'));
  const ws = new WebSocket(t.webSocketDebuggerUrl); let id = 0;
  const send = (method, params = {}) => ws.send(JSON.stringify({ id: ++id, method, params }));
  await new Promise(r => ws.onopen = r);
  ws.onmessage = e => { const m = JSON.parse(e.data);
    if (m.method === 'Runtime.exceptionThrown') console.log('EXC', JSON.stringify(m.params.exceptionDetails).slice(0, 600));
    if (m.method === 'Runtime.consoleAPICalled' && /error|warn/.test(m.params.type)) console.log('CON', m.params.args.map(a => a.value || a.description).join(' ').slice(0, 300)); };
  send('Runtime.enable'); send('Page.reload');
  setTimeout(() => { ws.close(); process.exit(0); }, 6000);
})();
