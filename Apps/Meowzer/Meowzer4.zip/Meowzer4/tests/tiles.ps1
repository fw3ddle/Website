# tiles.ps1 — looks at and drags Meowzer's tiles from outside.
#   powershell -File tests\tiles.ps1                      lists the tile, page and shelf windows (x,y in window coordinates)
#   powershell -File tests\tiles.ps1 -From 632,424 -To 432,304   drags the divider(s) under From to To (page-area coordinates)
param([string]$From, [string]$To)   # "x,y" (powershell -File passes 1,2 as one string)
Add-Type @"
using System; using System.Runtime.InteropServices; using System.Text; using System.Collections.Generic;
public class MT {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc f, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr p, EnumProc f, IntPtr l);
  [DllImport("user32.dll")] public static extern IntPtr FindWindowEx(IntPtr p, IntPtr a, string c, string w);
  [DllImport("user32.dll")] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr GetParent(IntPtr h);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
  public struct RECT { public int L, T, R, B; }
  public static IntPtr Top() { IntPtr top = IntPtr.Zero; EnumWindows((h, l) => { var s = new StringBuilder(64); GetClassName(h, s, 64); if (s.ToString() == "Meowzer4" && IsWindowVisible(h)) { top = h; return false; } return true; }, IntPtr.Zero); return top; }
  public static List<string> Dump() {
    IntPtr top = Top(); var o = new List<string>(); RECT tr; GetWindowRect(top, out tr);
    EnumChildWindows(top, (h, l) => { if (GetParent(h) != top) return true; var s = new StringBuilder(64); GetClassName(h, s, 64); RECT r; GetWindowRect(h, out r);
      o.Add(s + " vis=" + IsWindowVisible(h) + " at " + (r.L - tr.L) + "," + (r.T - tr.T) + " size " + (r.R - r.L) + "x" + (r.B - r.T)); return true; }, IntPtr.Zero);
    return o;
  }
  public static IntPtr P(int x, int y) { return (IntPtr)((y << 16) | (x & 0xffff)); }
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint f, int x, int y, uint d, IntPtr e);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  // A drag sent as window messages (injected real input doesn't reach other apps from a sandboxed shell). The cursor
  // follows along, so any move the system adds while the divider holds the mouse reports the same place.
  // Coordinates are in the page area under the tiles.
  public static void Drag(int x0, int y0, int x1, int y1) {
    IntPtr top = Top(), p = FindWindowEx(top, IntPtr.Zero, "MeowzerPages", null);
    RECT r; GetWindowRect(p, out r);
    SetCursorPos(r.L + x0, r.T + y0); System.Threading.Thread.Sleep(100);
    SendMessage(p, 0x201, (IntPtr)1, P(x0, y0));
    for (int i = 1; i <= 12; i++) { int x = x0 + (x1 - x0) * i / 12, y = y0 + (y1 - y0) * i / 12; SetCursorPos(r.L + x, r.T + y); SendMessage(p, 0x200, (IntPtr)1, P(x, y)); System.Threading.Thread.Sleep(25); }
    SendMessage(p, 0x202, IntPtr.Zero, P(x1, y1));
  }
}
"@
if ($From) { $a = $From -split ',' | ForEach-Object { [int]$_ }; $b = $To -split ',' | ForEach-Object { [int]$_ }; [MT]::Drag($a[0], $a[1], $b[0], $b[1]); Start-Sleep -Milliseconds 300 }
[MT]::Dump()
