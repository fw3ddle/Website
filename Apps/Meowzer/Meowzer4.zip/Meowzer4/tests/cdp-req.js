// cdp-req.js — shows what happens to the first few requests to a host: node cdp-req.js <host-part>
const want = process.argv[2] || '';
(async () => {
  const list = await (await fetch('http://127.0.0.1:9333/json')).json();
  const t = list.find(p => p.type === 'page' && !p.url.startsWith('https://meowzer.ui/'));
  const ws = new WebSocket(t.webSocketDebuggerUrl); await new Promise(r => ws.onopen = r);
  const ids = new Set(); let shown = 0;
  ws.onmessage = e => {
    const m = JSON.parse(e.data), p = m.params || {};
    if (m.method === 'Network.requestWillBeSent' && p.request.url.includes(want) && ids.size < 2) { ids.add(p.requestId); console.log('REQ', p.type, p.request.method, p.request.url.slice(0, 160), 'init:', p.initiator && p.initiator.type); }
    if (!ids.has(p.requestId)) return;
    if (m.method === 'Network.responseReceived') console.log('RES', p.response.status, JSON.stringify(p.response.headers).slice(0, 200));
    if (m.method === 'Network.loadingFailed') console.log('FAIL', p.errorText, p.corsErrorStatus ? JSON.stringify(p.corsErrorStatus) : '');
    if (m.method === 'Network.loadingFinished' && ++shown >= 2) process.exit(0);
  };
  ws.send(JSON.stringify({ id: 1, method: 'Network.enable' }));
  setTimeout(() => process.exit(0), 4000);
})();
