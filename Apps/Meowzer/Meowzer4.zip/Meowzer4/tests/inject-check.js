// inject-check.js — compiles ui/inject.js with sample data, the way a host fills __MEOW_DATA__, and reports errors.
const fs = require('fs'), path = require('path');
const src = fs.readFileSync(path.join(__dirname, '../ui/inject.js'), 'utf8');
const data = JSON.stringify({ def: null, sites: { 'example.com': { game: true } }, css: { '*': '.ad' } });
try { new Function(src.replace('__MEOW_DATA__', data)); console.log('inject.js: syntax ok'); }
catch (e) { console.log('inject.js: ' + e.message); process.exit(1); }
