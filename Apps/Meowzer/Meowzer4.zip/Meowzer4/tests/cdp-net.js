// cdp-net.js — counts the active page's requests per host for a few seconds: node cdp-net.js [seconds]
const secs = +(process.argv[2] || 4);
(async () => {
  const list = await (await fetch('http://127.0.0.1:9333/json')).json();
  const t = list.find(p => p.type === 'page' && !p.url.startsWith('https://meowzer.ui/'));
  const ws = new WebSocket(t.webSocketDebuggerUrl); await new Promise(r => ws.onopen = r);
  const n = {};
  ws.onmessage = e => { const m = JSON.parse(e.data); if (m.method === 'Network.requestWillBeSent') { const h = new URL(m.params.request.url).hostname; n[h] = (n[h] || 0) + 1; } };
  ws.send(JSON.stringify({ id: 1, method: 'Network.enable' }));
  setTimeout(() => { console.log(Object.entries(n).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([h, c]) => c + ' ' + h).join('\n')); process.exit(0); }, secs * 1000);
})();
