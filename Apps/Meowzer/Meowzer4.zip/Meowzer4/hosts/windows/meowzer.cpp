// meowzer.cpp — Meowzer 4's Windows host.
//
// Pages are drawn by WebView2, the web engine Windows already has (nothing is bundled). The browser's face is
// ui/meowzer-ui.html in its own WebView2; every decision comes from meowcore.exe, compiled from core/meowcore.fx
// (ꟻX). This file only connects them: it keeps the tabs, looks request hosts up in the table meowcore compiled,
// sweeps cookies through meowcore's verdicts, applies costumes, and lays out windows.
//
// The window can be split into tiles. Each tile has its own face (tabs, address bar, panels) and its own tabs; the
// tiles form a tree of splits, and the gaps between them are dividers that can be dragged, alone or where they meet.
//
// Build: hosts/windows/build.ps1 (zig c++, WebView2.h from Microsoft's SDK). Ships with WebView2Loader.dll.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <winsock2.h>
#include <bcrypt.h>
#include <shlobj.h>
#include <shlwapi.h>
#include <urlmon.h>
#include <wincrypt.h>
#include "WebView2.h"
// mingw needs each interface's IID spelled out for __uuidof / IID_PPV_ARGS (from WebView2.h's MIDL_INTERFACE lines)
__CRT_UUID_DECL(ICoreWebView2_2, 0x9E8F0CF8, 0xE670, 0x4B5E, 0xB2,0xBC,0x73,0xE0,0x61,0xE3,0x18,0x4C)
__CRT_UUID_DECL(ICoreWebView2Controller2, 0xc979903e, 0xd4ca, 0x4228, 0x92,0xeb,0x47,0xee,0x3f,0xa9,0x6e,0xab)
__CRT_UUID_DECL(ICoreWebView2_3, 0xA0D6DF20, 0x3B92, 0x416D, 0xAA,0x0C,0x43,0x7A,0x9C,0x72,0x78,0x57)
__CRT_UUID_DECL(ICoreWebView2Settings2, 0xee9a0f68, 0xf46c, 0x4e32, 0xac,0x23,0xef,0x8c,0xac,0x22,0x4d,0x2a)
__CRT_UUID_DECL(ICoreWebView2_15, 0x517B2D1D, 0x7DAE, 0x4A66, 0xA4,0xF4,0x10,0x35,0x2F,0xFB,0x95,0x18)
__CRT_UUID_DECL(ICoreWebView2_22, 0xdb75dfc7, 0xa857, 0x4632, 0xa3,0x98,0x69,0x69,0xdd,0xe2,0x6c,0x0a)
__CRT_UUID_DECL(ICoreWebView2_4, 0x20d02d59, 0x6df2, 0x42dc, 0xbd,0x06,0xf9,0x8a,0x69,0x4b,0x13,0x02)
#include <shellapi.h>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <functional>
#include <thread>
#include <algorithm>
#include <cstdint>
#include <ctime>
#include <mutex>
#include <atomic>

// =============================================================================================== small things
static std::string u8(const std::wstring& w) {
  if (w.empty()) return {};
  int n = WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), nullptr, 0, nullptr, nullptr);
  std::string s(n, 0); WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), s.data(), n, nullptr, nullptr); return s;
}
static std::wstring w16(const std::string& s) {
  if (s.empty()) return {};
  int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
  std::wstring w(n, 0); MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), w.data(), n); return w;
}
static std::string takeStr(LPWSTR p) { std::string s = p ? u8(p) : std::string(); if (p) CoTaskMemFree(p); return s; }
static std::string readFile(const std::wstring& p) {
  HANDLE h = CreateFileW(p.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
  if (h == INVALID_HANDLE_VALUE) return {};
  std::string s; char buf[65536]; DWORD n;
  while (ReadFile(h, buf, sizeof buf, &n, nullptr) && n) s.append(buf, n);
  CloseHandle(h); return s;
}
static void writeFile(const std::wstring& p, const std::string& s) {
  std::wstring tmp = p + L".tmp";
  HANDLE h = CreateFileW(tmp.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, 0, nullptr);
  if (h == INVALID_HANDLE_VALUE) return;
  DWORD n; WriteFile(h, s.data(), (DWORD)s.size(), &n, nullptr); CloseHandle(h);
  MoveFileExW(tmp.c_str(), p.c_str(), MOVEFILE_REPLACE_EXISTING);
}
static std::string lower(std::string s) { for (auto& c : s) if (c >= 'A' && c <= 'Z') c += 32; return s; }

// the one hash: FNV-1a 64 over lowercased bytes (meowcore's `hash`)
static uint64_t fnv(const std::string& s, size_t a = 0) {
  uint64_t h = 0xcbf29ce484222325ull;
  for (size_t i = a; i < s.size(); i++) { unsigned char c = s[i]; if (c >= 'A' && c <= 'Z') c += 32; h = (h ^ c) * 0x100000001b3ull; }
  return h;
}
static const char* SFX[] = {"co.uk","org.uk","ac.uk","gov.uk","co.jp","ne.jp","or.jp","com.au","net.au","org.au","co.nz","com.br",
  "com.mx","co.in","co.za","com.tr","com.cn","com.tw","co.kr","github.io","blogspot.com","herokuapp.com","vercel.app","netlify.app","pages.dev"};
// the same rule as meowcore's `site`
static std::string siteOf(std::string h) {
  h = lower(h); while (!h.empty() && h[0] == '.') h.erase(0, 1);
  size_t d1 = h.rfind('.'); if (d1 == std::string::npos || d1 == 0) return h;
  size_t d2 = h.rfind('.', d1 - 1); if (d2 == std::string::npos) return h;
  std::string last2 = h.substr(d2 + 1);
  for (auto s : SFX) if (last2 == s) { if (d2 == 0) return h; size_t d3 = h.rfind('.', d2 - 1); return d3 == std::string::npos ? h : h.substr(d3 + 1); }
  return last2;
}
static std::string hostOf(const std::string& url) {
  size_t p = url.find("://"); if (p == std::string::npos) return {};
  size_t a = p + 3, b = url.find_first_of("/?#", a); std::string h = url.substr(a, b == std::string::npos ? std::string::npos : b - a);
  size_t at = h.rfind('@'); if (at != std::string::npos) h = h.substr(at + 1);
  if (!h.empty() && h[0] == '[') return h;
  size_t c = h.find(':'); if (c != std::string::npos) h = h.substr(0, c);
  return lower(h);
}

// =============================================================================================== JSON
struct J {
  enum T { Null, Bool, Num, Str, Arr, Obj } t = Null;
  bool b = false; double n = 0; std::string s; std::vector<J> a; std::vector<std::pair<std::string, J>> o;
  const J& operator[](const std::string& k) const { static J nil; for (auto& p : o) if (p.first == k) return p.second; return nil; }
  J& set(const std::string& k) { for (auto& p : o) if (p.first == k) return p.second; o.push_back({k, J()}); return o.back().second; }
  bool truthy() const { return t == Bool ? b : t == Num ? n != 0 : t == Str ? !s.empty() : t != Null; }
  int num(int d = 0) const { return t == Num ? (int)n : d; }
};
struct JP {
  const std::string& s; size_t i = 0;
  explicit JP(const std::string& x) : s(x) {}
  void ws() { while (i < s.size() && (s[i] == ' ' || s[i] == '\n' || s[i] == '\r' || s[i] == '\t')) i++; }
  J val() {
    ws(); J v; if (i >= s.size()) return v;
    char c = s[i];
    if (c == '{') { v.t = J::Obj; i++; ws(); if (s[i] == '}') { i++; return v; }
      while (i < s.size()) { ws(); std::string k = str(); ws(); i++; J x = val(); v.o.push_back({k, std::move(x)}); ws(); if (s[i] == ',') { i++; continue; } i++; break; } return v; }
    if (c == '[') { v.t = J::Arr; i++; ws(); if (s[i] == ']') { i++; return v; }
      while (i < s.size()) { v.a.push_back(val()); ws(); if (s[i] == ',') { i++; continue; } i++; break; } return v; }
    if (c == '"') { v.t = J::Str; v.s = str(); return v; }
    if (s.compare(i, 4, "true") == 0) { v.t = J::Bool; v.b = true; i += 4; return v; }
    if (s.compare(i, 5, "false") == 0) { v.t = J::Bool; i += 5; return v; }
    if (s.compare(i, 4, "null") == 0) { i += 4; return v; }
    size_t e = i; while (e < s.size() && strchr("+-0123456789.eE", s[e])) e++;
    v.t = J::Num; v.n = atof(s.substr(i, e - i).c_str()); i = e; return v;
  }
  std::string str() {
    std::string r; i++;
    while (i < s.size() && s[i] != '"') {
      if (s[i] == '\\') { i++; char e = s[i];
        if (e == 'n') r += '\n'; else if (e == 't') r += '\t'; else if (e == 'r') r += '\r'; else if (e == 'b') r += '\b'; else if (e == 'f') r += '\f';
        else if (e == 'u') { unsigned cp = strtoul(s.substr(i + 1, 4).c_str(), nullptr, 16); i += 4;
          if (cp >= 0xD800 && cp < 0xDC00 && s.compare(i + 1, 2, "\\u") == 0) { unsigned lo = strtoul(s.substr(i + 3, 4).c_str(), nullptr, 16); i += 6; cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00); }
          if (cp < 0x80) r += (char)cp; else if (cp < 0x800) { r += (char)(0xC0 | cp >> 6); r += (char)(0x80 | (cp & 63)); }
          else if (cp < 0x10000) { r += (char)(0xE0 | cp >> 12); r += (char)(0x80 | (cp >> 6 & 63)); r += (char)(0x80 | (cp & 63)); }
          else { r += (char)(0xF0 | cp >> 18); r += (char)(0x80 | (cp >> 12 & 63)); r += (char)(0x80 | (cp >> 6 & 63)); r += (char)(0x80 | (cp & 63)); } }
        else r += e; i++; }
      else r += s[i++];
    }
    i++; return r;
  }
};
static J parse(const std::string& s) { JP p(s); return p.val(); }
static std::string q(const std::string& s) {
  std::string r = "\""; char b[8];
  for (unsigned char c : s) { if (c == '"') r += "\\\""; else if (c == '\\') r += "\\\\"; else if (c == '\n') r += "\\n"; else if (c == '\r') r += "\\r"; else if (c == '\t') r += "\\t";
    else if (c < 0x20) { snprintf(b, 8, "\\u%04x", c); r += b; } else r += (char)c; }
  return r + "\"";
}
static std::string dump(const J& v) {
  switch (v.t) {
    case J::Null: return "null"; case J::Bool: return v.b ? "true" : "false";
    case J::Num: { char b[32]; if (v.n == (long long)v.n) snprintf(b, 32, "%lld", (long long)v.n); else snprintf(b, 32, "%.17g", v.n); return b; }
    case J::Str: return q(v.s);
    case J::Arr: { std::string r = "["; for (size_t i = 0; i < v.a.size(); i++) { if (i) r += ","; r += dump(v.a[i]); } return r + "]"; }
    default: { std::string r = "{"; for (size_t i = 0; i < v.o.size(); i++) { if (i) r += ","; r += q(v.o[i].first) + ":" + dump(v.o[i].second); } return r + "}"; }
  }
}

// =============================================================================================== COM callbacks
template <class I, class A, class B>
struct Cb : I {
  std::function<HRESULT(A, B)> f; ULONG rc = 1;
  explicit Cb(std::function<HRESULT(A, B)> g) : f(std::move(g)) {}
  HRESULT STDMETHODCALLTYPE QueryInterface(REFIID, void** p) override { *p = this; AddRef(); return S_OK; }
  ULONG STDMETHODCALLTYPE AddRef() override { return ++rc; }
  ULONG STDMETHODCALLTYPE Release() override { ULONG r = --rc; if (!r) delete this; return r; }
  HRESULT STDMETHODCALLTYPE Invoke(A a, B b) override { return f(a, b); }
};
template <class I, class A, class B> I* cb(std::function<HRESULT(A, B)> f) { return new Cb<I, A, B>(std::move(f)); }
#define EV(Iface, Args) cb<Iface, ICoreWebView2*, Args*>
template <class I>
struct Cb1 : I {
  std::function<HRESULT(HRESULT)> f; ULONG rc = 1;
  explicit Cb1(std::function<HRESULT(HRESULT)> g) : f(std::move(g)) {}
  HRESULT STDMETHODCALLTYPE QueryInterface(REFIID, void** p) override { *p = this; AddRef(); return S_OK; }
  ULONG STDMETHODCALLTYPE AddRef() override { return ++rc; }
  ULONG STDMETHODCALLTYPE Release() override { ULONG r = --rc; if (!r) delete this; return r; }
  HRESULT STDMETHODCALLTYPE Invoke(HRESULT h) override { return f(h); }
};

// =============================================================================================== the app
static HWND gWnd, gPageHost;
static std::wstring gExeDir, gData;
static ICoreWebView2Environment* gEnv;
static int gNextId = 1, gNextTile = 1;
static bool gFull; static int gFullTile; static WINDOWPLACEMENT gPlace{sizeof(WINDOWPLACEMENT)};
static std::string gEngine;
static J gSettings, gJar, gCostume;       // gCostume: the persona every un-jarred site sees, or null
static std::unordered_set<uint64_t> T_B, T_T, T_A, T_P; static std::map<std::string, std::string> T_CSS; static std::string gTableStats;
static std::string gInject;               // ui/inject.js
static std::map<std::string, std::vector<std::string>> gSeenOrigins;   // site -> origins with storage this session

// what the cat has saved, kept across runs: blocked, ads, scripts, media, bytes, cookies burnt, tags licked, since
enum { S_BLK, S_ADS, S_SCR, S_MED, S_BYTES, S_CK, S_PRM, S_SINCE };
static long long gStat[8]; static bool gStatDirty;
static std::string readStore(const std::wstring& p);                                   // the seal, below
static void writeStore(const std::wstring& p, const std::string& s, const char* store);
static void loadStats() {
  std::string s = readStore(gData + L"\\stats.txt"); const char* p = s.c_str(); char* e;
  for (int i = 0; i < 8; i++) { long long v = strtoll(p, &e, 10); if (e == p) break; gStat[i] = v; p = e; }
  if (!gStat[S_SINCE]) { gStat[S_SINCE] = (long long)time(nullptr); gStatDirty = true; }
}
static void saveStats() {
  std::string s; for (int i = 0; i < 8; i++) s += std::to_string(gStat[i]) + (i < 7 ? " " : "\n");
  writeStore(gData + L"\\stats.txt", s, "stats"); gStatDirty = false;
}

struct Tab {
  int id, tile = 0; ICoreWebView2Controller* ctl = nullptr; ICoreWebView2* wv = nullptr;
  std::string url, title, fav, site, navUrl, scriptId; bool loading = false, back = false, fwd = false;
  std::string ghostOf; bool ghost = false;  // a ghost: the address that would not load while offline, shown as a synthetic page
  std::unordered_set<std::string> hissed;   // addresses blocked on the current page
};
static std::vector<Tab*> gTabs;
static Tab* tabById(int id) { for (auto t : gTabs) if (t->id == id) return t; return nullptr; }

// a tile: one face and the tabs that belong to it. cur is where it is drawn, to is where it is heading (page-host
// coordinates); the two differ while tiles slide into place.
struct Tile {
  int id; HWND host = nullptr; ICoreWebView2Controller* ctl = nullptr; ICoreWebView2* ui = nullptr; bool ready = false;
  int cssH = 78, active = 0; bool overlay = false, barsAway = false, game = false;
  RECT cur{}, to{}; double zoom = 1, zoomTo = 1, zoomSet = 0; int sentCaption = -1, sentTiles = -1, sentMax = -1;
};
static std::vector<Tile*> gTiles; static int gFocus, gPrevFocus; static ULONGLONG gFocusAt;
static Tile* tileById(int id) { for (auto t : gTiles) if (t->id == id) return t; return nullptr; }
static Tile* focused() { Tile* t = tileById(gFocus); return t ? t : (gTiles.empty() ? nullptr : gTiles[0]); }
static Tile* tileOf(Tab* t) { return t ? tileById(t->tile) : nullptr; }
static Tab* activeIn(Tile* T) {
  if (!T) return nullptr; Tab* t = tabById(T->active); if (t && t->tile == T->id) return t;
  for (auto x : gTabs) if (x->tile == T->id) return x; return nullptr;
}
static Tab* active() { return activeIn(focused()); }

static void toTile(Tile* T, const std::string& json) { if (T && T->ui && T->ready) T->ui->PostWebMessageAsJson(w16(json).c_str()); }
static void toUi(const std::string& json) { for (auto T : gTiles) toTile(T, json); }      // every face
static void toTabUi(Tab* t, const std::string& json) { toTile(tileOf(t), json); }          // the face that shows this tab

// the bookshelf: its own small view in the bottom-right corner, a knob when rolled up, a strip along the bottom when not
static HWND gShelfHost; static ICoreWebView2Controller* gShelfCtl; static ICoreWebView2* gShelf; static bool gShelfReady;
static bool gShelfOpen; static int gShelfW;     // gShelfW: current width in pixels while it rolls
static void toShelf(const std::string& json) { if (gShelf && gShelfReady) gShelf->PostWebMessageAsJson(w16(json).c_str()); }
static int dpiOf(HWND h) {
  typedef UINT(WINAPI* F)(HWND); static F f = (F)GetProcAddress(GetModuleHandleW(L"user32.dll"), "GetDpiForWindow");
  return f ? (int)f(h) : 96;
}
static int px(int css) { return MulDiv(css, dpiOf(gWnd), 96); }
// the window has no title bar of its own (the tab row is the title bar); a thin strip on top is left uncovered so the
// top edge can still be dragged to resize
static int grip() { return (IsZoomed(gWnd) || gFull) ? 0 : std::max(3, px(4)); }
static bool lightTheme() { return gSettings["theme"].s == "light"; }
// a colour of the theme the faces wear (the studio behind the logo), or Meowzer's own
static COLORREF themeColor(const char* k, COLORREF dark, COLORREF light) {
  const std::string& v = gSettings["themeVars"][k].s;
  if (v.size() == 7 && v[0] == '#') { unsigned long x = strtoul(v.c_str() + 1, nullptr, 16); return RGB(x >> 16 & 255, x >> 8 & 255, x & 255); }
  return lightTheme() ? light : dark;
}
static std::string themeVarsParam() {   // VARS order of ui/themes.js
  static const char* K[] = {"canvas", "surface", "surface2", "border", "fg", "muted", "accent", "pink", "good", "bad", "warn"};
  std::string s; for (auto k : K) { const std::string& v = gSettings["themeVars"][k].s; if (v.size() != 7 || v[0] != '#') return {}; s += (s.empty() ? "" : ".") + v.substr(1); }
  return s;
}
static void toShelfTheme() {
  toShelf("{\"t\":\"theme\",\"theme\":" + q(gSettings["theme"].s.empty() ? "dark" : gSettings["theme"].s) + ",\"vars\":" + dump(gSettings["themeVars"]) + "}");
}

// ------------------------------------------------------------------------------------------- meowcore
// ꟻX programs flush their output when they end, so meowcore runs in batches: write the script, read the answer.
static std::string runCore(const std::string& script) {
  SECURITY_ATTRIBUTES sa{sizeof sa, nullptr, TRUE};
  HANDLE inR, inW, outR, outW;
  CreatePipe(&inR, &inW, &sa, 0); CreatePipe(&outR, &outW, &sa, 0);
  SetHandleInformation(inW, HANDLE_FLAG_INHERIT, 0); SetHandleInformation(outR, HANDLE_FLAG_INHERIT, 0);
  STARTUPINFOW si{sizeof si}; si.dwFlags = STARTF_USESTDHANDLES; si.hStdInput = inR; si.hStdOutput = outW; si.hStdError = outW;
  PROCESS_INFORMATION pi{};
  std::wstring cmd = L"\"" + gExeDir + L"\\meowcore.exe\"";
  if (!CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, TRUE, CREATE_NO_WINDOW, nullptr, gExeDir.c_str(), &si, &pi)) {
    CloseHandle(inR); CloseHandle(inW); CloseHandle(outR); CloseHandle(outW); return "! meowcore.exe would not start";
  }
  CloseHandle(inR); CloseHandle(outW);
  std::thread wr([inW, script] { DWORD n; size_t off = 0; while (off < script.size()) { if (!WriteFile(inW, script.data() + off, (DWORD)std::min<size_t>(script.size() - off, 1 << 16), &n, nullptr)) break; off += n; } CloseHandle(inW); });
  std::string out; char buf[65536]; DWORD n;
  while (ReadFile(outR, buf, sizeof buf, &n, nullptr) && n) out.append(buf, n);
  wr.join(); WaitForSingleObject(pi.hProcess, 5000);
  CloseHandle(outR); CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
  return out;
}

// ------------------------------------------------------------------------------------------- the seal
// What Meowzer keeps on disk (history, the jar, the shelf, the stats, the route log) can be sealed: ChaCha run by
// meowcore (ꟻX @chacha), an HMAC-SHA256 tag so a file that was changed is refused, under a 64-byte key that Windows
// protects for this user account (DPAPI). Sealed file: "MEOWSEAL1", rounds, nonce(12), tag(32), ciphertext.
// This protects what is stored, not what travels; pages already travel under HTTPS, and under the route below.
static std::string gSealKey;
static std::string hexOf(const std::string& b) { static const char* H = "0123456789abcdef"; std::string s; s.reserve(b.size() * 2); for (unsigned char c : b) { s += H[c >> 4]; s += H[c & 15]; } return s; }
static std::string unhex(const std::string& h) {
  auto v = [](char c) { return c <= '9' ? c - '0' : (c | 32) - 'a' + 10; };
  std::string b; b.reserve(h.size() / 2); for (size_t i = 0; i + 1 < h.size(); i += 2) b += (char)(v(h[i]) << 4 | v(h[i + 1])); return b;
}
static std::string randomBytes(size_t n) { std::string b(n, 0); BCryptGenRandom(nullptr, (PUCHAR)b.data(), (ULONG)n, BCRYPT_USE_SYSTEM_PREFERRED_RNG); return b; }
static std::string hmac256(const std::string& key, const std::string& msg) {
  BCRYPT_ALG_HANDLE alg; std::string out(32, 0);
  if (BCryptOpenAlgorithmProvider(&alg, BCRYPT_SHA256_ALGORITHM, nullptr, BCRYPT_ALG_HANDLE_HMAC_FLAG) != 0) return {};
  BCRYPT_HASH_HANDLE h;
  if (BCryptCreateHash(alg, &h, nullptr, 0, (PUCHAR)key.data(), (ULONG)key.size(), 0) == 0) {
    BCryptHashData(h, (PUCHAR)msg.data(), (ULONG)msg.size(), 0); BCryptFinishHash(h, (PUCHAR)out.data(), 32, 0); BCryptDestroyHash(h); }
  BCryptCloseAlgorithmProvider(alg, 0); return out;
}
static bool sameBytes(const std::string& a, const std::string& b) { if (a.size() != b.size()) return false; unsigned char d = 0; for (size_t i = 0; i < a.size(); i++) d |= a[i] ^ b[i]; return !d; }
static std::string dpapi(const std::string& b, bool lock) {
  DATA_BLOB i{(DWORD)b.size(), (BYTE*)b.data()}, o{};
  BOOL ok = lock ? CryptProtectData(&i, L"Meowzer seal", nullptr, nullptr, nullptr, CRYPTPROTECT_UI_FORBIDDEN, &o) : CryptUnprotectData(&i, nullptr, nullptr, nullptr, nullptr, CRYPTPROTECT_UI_FORBIDDEN, &o);
  if (!ok) return {}; std::string r((char*)o.pbData, o.cbData); LocalFree(o.pbData); return r;
}
static const std::string& sealKey() {
  if (gSealKey.size() == 64) return gSealKey;
  gSealKey = dpapi(readFile(gData + L"\\seal.key"), false);
  if (gSealKey.size() != 64) { gSealKey = randomBytes(64); writeFile(gData + L"\\seal.key", dpapi(gSealKey, true)); }
  return gSealKey;
}
static std::string sealPrint() { return hexOf(hmac256(sealKey(), "meowzer seal fingerprint").substr(0, 4)); }
static const char SEAL_MAGIC[] = "MEOWSEAL1";
// ChaCha through meowcore, 2048 bytes a line (meowcore's lines hold 8192 characters); the same call opens what it sealed
static std::string chacha(int rounds, const std::string& key32, const std::string& nonce, const std::string& data, bool* ok) {
  std::string sc = "@chacha " + std::to_string(rounds) + " " + hexOf(key32) + " " + hexOf(nonce) + "\n";
  for (size_t i = 0; i < data.size(); i += 2048) sc += hexOf(data.substr(i, 2048)) + "\n";
  std::string out = runCore(sc + "@end\n"), r; size_t p = 0;
  while (p < out.size()) {
    size_t e = out.find('\n', p); if (e == std::string::npos) e = out.size();
    if (out.compare(p, 2, "x ") == 0) { std::string l = out.substr(p + 2, e - p - 2); while (!l.empty() && (l.back() == '\r' || l.back() == ' ')) l.pop_back(); r += unhex(l); }
    p = e + 1;
  }
  if (ok) *ok = r.size() == data.size(); return r;
}
static int sealRounds() { int r = gSettings["mask"]["seal"]["rounds"].num(20); return r == 8 || r == 12 ? r : 20; }
static bool sealWants(const char* store) {
  const J& s = gSettings["mask"]["seal"]; if (!s["on"].truthy()) return false;
  if (s["stores"].t != J::Arr) return true;
  for (auto& x : s["stores"].a) if (x.s == store) return true;
  return false;
}
static std::string sealBytes(const std::string& plain, int rounds, const std::string& key) {
  std::string nonce = randomBytes(12); bool ok;
  std::string c = chacha(rounds, key.substr(0, 32), nonce, plain, &ok); if (!ok) return {};
  std::string head = std::string(SEAL_MAGIC) + (char)rounds + nonce;
  return head + hmac256(key.substr(32), head + c) + c;
}
// a sealed file opens only if its tag matches; a plain one (from before the seal, or with it off) reads as it is
static std::string openBytes(const std::string& f, const std::string& key, bool* bad) {
  *bad = false;
  if (f.compare(0, 9, SEAL_MAGIC) != 0) return f;
  if (f.size() < 54) { *bad = true; return {}; }
  std::string head = f.substr(0, 22), c = f.substr(54);
  if (!sameBytes(hmac256(key.substr(32), head + c), f.substr(22, 32))) { *bad = true; return {}; }
  bool ok; std::string p = chacha((unsigned char)f[9], key.substr(0, 32), f.substr(10, 12), c, &ok);
  if (!ok) *bad = true; return ok ? p : std::string();
}
static std::string readStore(const std::wstring& p) {
  std::string f = readFile(p); bool bad; std::string s = openBytes(f, sealKey(), &bad);
  if (bad) CopyFileW(p.c_str(), (p + L".unreadable").c_str(), FALSE);   // another account's key, or a changed file: keep it aside
  return s;
}
// sealing runs off the window's thread; the newest write of each file wins, and leaving waits for them
static std::mutex gStoreMx; static std::map<std::wstring, int> gStoreGen; static std::atomic<int> gStoreBusy{0};
static void writeStore(const std::wstring& p, const std::string& s, const char* store) {
  int gen; { std::lock_guard<std::mutex> l(gStoreMx); gen = ++gStoreGen[p]; }
  if (!sealWants(store)) { std::lock_guard<std::mutex> l(gStoreMx); writeFile(p, s); return; }
  int rounds = sealRounds(); std::string key = sealKey(); gStoreBusy++;
  std::thread([p, s, rounds, key, gen] {
    std::string b = sealBytes(s, rounds, key);
    { std::lock_guard<std::mutex> l(gStoreMx); if (gStoreGen[p] == gen && !b.empty()) writeFile(p, b); }
    gStoreBusy--; }).detach();
}
static void storesFlush() { for (int i = 0; gStoreBusy > 0 && i < 250; i++) Sleep(20); }
struct Store { const char* name; const wchar_t* file; };
static const Store STORES[] = {{"history", L"history.json"}, {"jar", L"jar.json"}, {"shelf", L"shelf.json"}, {"stats", L"stats.txt"}, {"route", L"route.log"}};
// after the seal's settings change, or a new key: open every store and write it again the new way
static void resealAll(bool newKey) {
  storesFlush(); std::vector<std::string> plain;
  for (auto& s : STORES) plain.push_back(readStore(gData + L"\\" + s.file));
  if (newKey) { gSealKey = randomBytes(64); writeFile(gData + L"\\seal.key", dpapi(gSealKey, true)); }
  for (size_t i = 0; i < plain.size(); i++) if (!plain[i].empty()) writeStore(gData + L"\\" + STORES[i].file, plain[i], STORES[i].name);
}
static std::string sealStatus() {
  storesFlush();
  std::string s = "{\"on\":" + std::string(gSettings["mask"]["seal"]["on"].truthy() ? "true" : "false") + ",\"rounds\":" + std::to_string(sealRounds()) +
    ",\"print\":" + q(sealPrint()) + ",\"stores\":[";
  for (size_t i = 0; i < sizeof STORES / sizeof *STORES; i++) {
    std::string f = readFile(gData + L"\\" + STORES[i].file);
    s += std::string(i ? "," : "") + "{\"name\":" + q(STORES[i].name) + ",\"bytes\":" + std::to_string(f.size()) + ",\"sealed\":" + (f.compare(0, 9, SEAL_MAGIC) == 0 ? "true" : "false") + "}";
  }
  return s + "]}";
}

static void compileTable() {
  std::string script = "@table\n" + readFile(gExeDir + L"\\lists\\meowlist.txt") + "\n";
  WIN32_FIND_DATAW fd; HANDLE f = FindFirstFileW((gData + L"\\lists\\*.txt").c_str(), &fd);
  if (f != INVALID_HANDLE_VALUE) { do script += readFile(gData + L"\\lists\\" + fd.cFileName) + "\n"; while (FindNextFileW(f, &fd)); FindClose(f); }
  script += gSettings["customRules"].s + "\n@end\n";
  // the same lists compile to the same table: keep it, keyed by the hash of what went in
  char key[40]; snprintf(key, 40, "%016llx %zu\n", (unsigned long long)fnv(script), script.size());
  std::string cached = readFile(gData + L"\\table.cache"), out;
  if (cached.rfind(key, 0) == 0) out = cached.substr(strlen(key));
  else { out = runCore(script); writeFile(gData + L"\\table.cache", key + out); }
  T_B.clear(); T_T.clear(); T_A.clear(); T_P.clear(); T_CSS.clear();
  size_t p = 0;
  while (p < out.size()) {
    size_t e = out.find('\n', p); if (e == std::string::npos) e = out.size();
    std::string l = out.substr(p, e - p); p = e + 1;
    if (l.size() < 18) { if (!l.empty() && l[0] == '#') gTableStats = l; continue; }
    if (l[0] == '#') { gTableStats = l; continue; }
    uint64_t h = strtoull(l.substr(2, 16).c_str(), nullptr, 16);
    switch (l[0]) {
      case 'b': T_B.insert(h); break; case 't': T_T.insert(h); break; case 'a': T_A.insert(h); break; case 'p': T_P.insert(h); break;
      case 'c': { std::string k = h ? l.substr(2, 16) : "*"; std::string& v = T_CSS[k]; if (!v.empty()) v += ","; v += l.substr(19); break; }
    }
  }
}

// ------------------------------------------------------------------------------------------- per-site settings
static const J& jarOf(const std::string& site) { return gJar[site]; }
static int blockerOf(const std::string& site) { const J& j = jarOf(site); return j.t == J::Obj ? j["settings"]["blocker"].num(1) : gSettings["blocker"].num(1); }
static const J* personaOf(const std::string& site) {
  const J& j = jarOf(site);
  if (j.t == J::Obj) { if (j["settings"]["spoof"].truthy() && j["persona"].t == J::Obj) return &j["persona"]; return nullptr; }
  return gCostume.t == J::Obj ? &gCostume : nullptr;
}

// 0 pass, 1 hiss. Exceptions win; host and every parent domain are looked up.
static int decide(const std::string& host, bool third) {
  std::vector<uint64_t> hs; hs.push_back(fnv(host));
  for (size_t i = 0; i < host.size(); i++) if (host[i] == '.') hs.push_back(fnv(host, i + 1));
  for (auto h : hs) if (T_A.count(h)) return 0;
  for (auto h : hs) { if (T_B.count(h)) return 1; if (third && T_T.count(h)) return 1; }
  return 0;
}
static bool isTracker(const std::string& host) {
  std::string h = host; while (!h.empty() && h[0] == '.') h.erase(0, 1);
  std::vector<uint64_t> hs; hs.push_back(fnv(h));
  for (size_t i = 0; i < h.size(); i++) if (h[i] == '.') hs.push_back(fnv(h, i + 1));
  for (auto x : hs) if (T_A.count(x)) return false;
  for (auto x : hs) if (T_B.count(x) || T_T.count(x)) return true;
  return false;
}
// the cat licks tracking parameters off an address; returns how many
static int lick(std::string& url) {
  size_t qm = url.find('?'); if (qm == std::string::npos || T_P.empty()) return 0;
  size_t hash = url.find('#', qm); std::string frag = hash == std::string::npos ? "" : url.substr(hash);
  std::string query = url.substr(qm + 1, (hash == std::string::npos ? url.size() : hash) - qm - 1), kept; int n = 0;
  size_t p = 0;
  while (p <= query.size()) {
    size_t e = query.find('&', p); if (e == std::string::npos) e = query.size();
    std::string kv = query.substr(p, e - p); std::string k = kv.substr(0, kv.find('='));
    if (!kv.empty()) { if (T_P.count(fnv(k))) n++; else { if (!kept.empty()) kept += '&'; kept += kv; } }
    p = e + 1;
  }
  if (!n) return 0;
  url = url.substr(0, qm) + (kept.empty() ? "" : "?" + kept) + frag; return n;
}
// roughly what a blocked request would have cost to download, by kind
static long long bytesOf(COREWEBVIEW2_WEB_RESOURCE_CONTEXT c) {
  switch (c) {
    case COREWEBVIEW2_WEB_RESOURCE_CONTEXT_SCRIPT: return 45000;
    case COREWEBVIEW2_WEB_RESOURCE_CONTEXT_IMAGE: return 25000;
    case COREWEBVIEW2_WEB_RESOURCE_CONTEXT_MEDIA: return 600000;
    case COREWEBVIEW2_WEB_RESOURCE_CONTEXT_DOCUMENT: return 120000;
    case COREWEBVIEW2_WEB_RESOURCE_CONTEXT_STYLESHEET: case COREWEBVIEW2_WEB_RESOURCE_CONTEXT_FONT: return 20000;
    case COREWEBVIEW2_WEB_RESOURCE_CONTEXT_XML_HTTP_REQUEST: case COREWEBVIEW2_WEB_RESOURCE_CONTEXT_FETCH: return 3000;
    default: return 1500;
  }
}

// ------------------------------------------------------------------------------------------- what pages get injected
static std::string injectFor() {
  J d; d.t = J::Obj;
  d.set("def") = gCostume;
  J& sites = d.set("sites"); sites.t = J::Obj;
  for (auto& [site, j] : gJar.o) {
    J s; s.t = J::Obj;
    if (j["settings"]["spoof"].truthy()) s.set("persona") = j["persona"];
    s.set("game") = j["settings"]["game"];
    sites.o.push_back({site, s});
  }
  J& css = d.set("css"); css.t = J::Obj;
  for (auto& [k, v] : T_CSS) { J s; s.t = J::Str; s.s = v; css.o.push_back({k, s}); }
  std::string src = gInject; size_t p = src.find("const D = __MEOW_DATA__;");
  if (p != std::string::npos) src.replace(p + 10, 13, dump(d));
  return src;
}
static void applyInject(Tab* t) {
  if (!t->scriptId.empty()) { t->wv->RemoveScriptToExecuteOnDocumentCreated(w16(t->scriptId).c_str()); t->scriptId.clear(); }
  int id = t->id;
  t->wv->AddScriptToExecuteOnDocumentCreated(w16(injectFor()).c_str(),
    cb<ICoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler, HRESULT, LPCWSTR>([id](HRESULT, LPCWSTR sid) {
      if (Tab* t = tabById(id)) t->scriptId = sid ? u8(sid) : ""; return S_OK; }));
}
static void reinjectAll() { for (auto t : gTabs) if (t->wv) applyInject(t); }

// ------------------------------------------------------------------------------------------- history
// kept only on this computer, newest last; one entry per address (a revisit moves it to the end)
struct HE { std::string url, title; long long time; };
static std::vector<HE> gHist; static bool gHistDirty;
static bool historyOn() { return gSettings["history"].t != J::Bool || gSettings["history"].b; }
static void loadHistory() {
  J h = parse(readStore(gData + L"\\history.json"));
  for (auto& e : h.a) if (e.t == J::Arr && e.a.size() >= 3) gHist.push_back({e.a[0].s, e.a[1].s, (long long)e.a[2].n});
}
static void saveHistory() {
  std::string s = "[";
  for (size_t i = 0; i < gHist.size(); i++) { if (i) s += ",\n"; s += "[" + q(gHist[i].url) + "," + q(gHist[i].title) + "," + std::to_string(gHist[i].time) + "]"; }
  writeStore(gData + L"\\history.json", s + "]", "history"); gHistDirty = false;
}
static void historySoon() { gHistDirty = true; SetTimer(gWnd, 5, 2500, nullptr); }
static void remember(const std::string& url, const std::string& title) {
  if (!historyOn() || url.rfind("http", 0) != 0) return;
  for (auto it = gHist.begin(); it != gHist.end(); ++it) if (it->url == url) { gHist.erase(it); break; }
  gHist.push_back({url, title, (long long)time(nullptr)});
  if (gHist.size() > 4000) gHist.erase(gHist.begin(), gHist.begin() + (gHist.size() - 4000));
  historySoon();
}
static void retitle(const std::string& url, const std::string& title) {
  if (!gHist.empty() && gHist.back().url == url && gHist.back().title != title) { gHist.back().title = title; historySoon(); }
}
static void sendHistory(Tile* T, int reqId, std::string qs) {
  qs = lower(qs); std::string s = "{\"t\":\"history\",\"id\":" + std::to_string(reqId) + ",\"list\":["; int n = 0;
  for (auto it = gHist.rbegin(); it != gHist.rend() && n < 400; ++it) {
    if (!qs.empty() && lower(it->url).find(qs) == std::string::npos && lower(it->title).find(qs) == std::string::npos) continue;
    s += std::string(n++ ? "," : "") + "{\"url\":" + q(it->url) + ",\"title\":" + q(it->title) + ",\"time\":" + std::to_string(it->time) + "}";
  }
  toTile(T, s + "]}");
}

// ------------------------------------------------------------------------------------------- downloads
// WebView2 saves into the Downloads folder; Meowzer only hides Edge's own download bubble and shows the list itself
struct DL { int id; ICoreWebView2DownloadOperation* op = nullptr; std::string url, path, state = "progress", reason; long long got = 0, total = 0; ULONGLONG sent = 0; };
static std::vector<DL*> gDls; static int gNextDl = 1;
static std::string dlJson(DL* d) {
  return "{\"id\":" + std::to_string(d->id) + ",\"url\":" + q(d->url) + ",\"path\":" + q(d->path) + ",\"state\":" + q(d->state) +
    ",\"got\":" + std::to_string(d->got) + ",\"total\":" + std::to_string(d->total) + ",\"reason\":" + q(d->reason) + "}";
}
static void dlPush(DL* d) { toUi("{\"t\":\"dl\",\"item\":" + dlJson(d) + "}"); }
static void dlRead(DL* d) {
  if (!d->op) return;
  INT64 n = 0; d->op->get_BytesReceived(&n); d->got = n; d->op->get_TotalBytesToReceive(&n); d->total = n;
  COREWEBVIEW2_DOWNLOAD_STATE s; d->op->get_State(&s);
  if (s == COREWEBVIEW2_DOWNLOAD_STATE_COMPLETED) d->state = "done";
  else if (s == COREWEBVIEW2_DOWNLOAD_STATE_INTERRUPTED) {
    COREWEBVIEW2_DOWNLOAD_INTERRUPT_REASON r; d->op->get_InterruptReason(&r);
    if (r == COREWEBVIEW2_DOWNLOAD_INTERRUPT_REASON_USER_CANCELED) d->state = "cancelled";
    else { d->state = "failed";
      d->reason = r == COREWEBVIEW2_DOWNLOAD_INTERRUPT_REASON_FILE_MALICIOUS ? "Windows flagged it as harmful" : r == COREWEBVIEW2_DOWNLOAD_INTERRUPT_REASON_FILE_NO_SPACE ? "the disk is full" :
        r >= COREWEBVIEW2_DOWNLOAD_INTERRUPT_REASON_FILE_FAILED && r <= COREWEBVIEW2_DOWNLOAD_INTERRUPT_REASON_FILE_HASH_MISMATCH ? "could not save the file" :
        r >= COREWEBVIEW2_DOWNLOAD_INTERRUPT_REASON_NETWORK_FAILED && r <= COREWEBVIEW2_DOWNLOAD_INTERRUPT_REASON_NETWORK_INVALID_REQUEST ? "network problem" :
        r >= COREWEBVIEW2_DOWNLOAD_INTERRUPT_REASON_SERVER_FAILED && r <= COREWEBVIEW2_DOWNLOAD_INTERRUPT_REASON_SERVER_CROSS_ORIGIN_REDIRECT ? "the server refused" : "interrupted"; }
  }
  LPWSTR p = nullptr; if (SUCCEEDED(d->op->get_ResultFilePath(&p)) && p) d->path = takeStr(p);
}
static DL* dlById(int id) { for (auto d : gDls) if (d->id == id) return d; return nullptr; }
static void sendDownloads(Tile* T, int reqId) {
  std::string s = "{\"t\":\"downloads\",\"id\":" + std::to_string(reqId) + ",\"list\":[";
  for (size_t i = gDls.size(); i-- > 0;) s += dlJson(gDls[i]) + (i ? "," : "");
  toTile(T, s + "]}");
}
static void dropDl(DL* d) { gDls.erase(std::find(gDls.begin(), gDls.end(), d)); if (d->op) d->op->Release(); delete d; }
static void dlAct(const std::string& a, int id) {
  DL* d = dlById(id);
  if (a == "open" && d && d->state == "done") ShellExecuteW(gWnd, L"open", w16(d->path).c_str(), nullptr, nullptr, SW_SHOWNORMAL);
  else if (a == "folder" && d) ShellExecuteW(gWnd, L"open", L"explorer.exe", w16("/select,\"" + d->path + "\"").c_str(), nullptr, SW_SHOWNORMAL);
  else if (a == "cancel" && d && d->op && d->state == "progress") d->op->Cancel();
  else if (a == "remove" && d) { if (d->op && d->state == "progress") d->op->Cancel(); dropDl(d); }
  else if (a == "clear") { std::vector<DL*> done; for (auto x : gDls) if (x->state != "progress") done.push_back(x); for (auto x : done) dropDl(x); }
  else if (a == "downloads") { PWSTR p; if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_Downloads, 0, nullptr, &p))) { ShellExecuteW(gWnd, L"open", p, nullptr, nullptr, SW_SHOWNORMAL); CoTaskMemFree(p); } }
}

// ------------------------------------------------------------------------------------------- state to the faces
static void pushState(Tile* T) {
  if (!T) return; Tab* a = activeIn(T);
  std::string s = "{\"t\":\"state\",\"active\":" + std::to_string(a ? a->id : 0) + ",\"tabs\":["; bool first = true;
  for (auto t : gTabs) if (t->tile == T->id) { if (!first) s += ","; first = false;
    s += "{\"id\":" + std::to_string(t->id) + ",\"url\":" + q(t->url) + ",\"title\":" + q(t->title) + ",\"favicon\":" + q(t->fav) +
      ",\"loading\":" + (t->loading ? "true" : "false") + ",\"canBack\":" + (t->back ? "true" : "false") + ",\"canFwd\":" + (t->fwd ? "true" : "false") + (t->ghost ? ",\"ghost\":true" : "") + "}"; }
  s += "]}"; toTile(T, s);
  if (T == focused()) { toShelf(s); SetWindowTextW(gWnd, w16((a && !a->title.empty() ? a->title + " — " : "") + "Meowzer").c_str()); }
}
static void pushTab(Tab* t) { pushState(tileOf(t)); }

// ------------------------------------------------------------------------------------------- tiles
// A binary tree of splits. vert: the children sit side by side (the divider is vertical); r: the first child's share.
struct Node { int tile = 0; bool vert = false; double r = .5; Node *a = nullptr, *b = nullptr, *up = nullptr; RECT rc{}; };
static Node* gRoot;
static Node* leafOf(Node* n, int tile) { if (!n) return nullptr; if (!n->a) return n->tile == tile ? n : nullptr; Node* x = leafOf(n->a, tile); return x ? x : leafOf(n->b, tile); }
static int firstTile(Node* n) { while (n->a) n = n->a; return n->tile; }
static int gapPx() { return std::max(4, px(6)); }
static void arrange(Node* n, RECT rc) {
  n->rc = rc;
  if (!n->a) { if (Tile* T = tileById(n->tile)) T->to = rc; return; }
  int G = gapPx();
  if (n->vert) { int x = rc.left + (int)((rc.right - rc.left - G) * n->r + .5); arrange(n->a, {rc.left, rc.top, x, rc.bottom}); arrange(n->b, {x + G, rc.top, rc.right, rc.bottom}); }
  else { int y = rc.top + (int)((rc.bottom - rc.top - G) * n->r + .5); arrange(n->a, {rc.left, rc.top, rc.right, y}); arrange(n->b, {rc.left, y + G, rc.right, rc.bottom}); }
}
static RECT divider(Node* n) {
  int G = gapPx(); RECT a = n->a->rc;
  return n->vert ? RECT{a.right, n->rc.top, a.right + G, n->rc.bottom} : RECT{n->rc.left, a.bottom, n->rc.right, a.bottom + G};
}
static void eachSplit(Node* n, const std::function<void(Node*)>& f) { if (!n || !n->a) return; f(n); eachSplit(n->a, f); eachSplit(n->b, f); }

static void layout();
static void winState(Tile* T) {
  RECT rc; GetClientRect(gWnd, &rc);
  int cap = T->to.top == 0 && T->to.right >= rc.right - 1 ? 1 : 0, mx = IsZoomed(gWnd) ? 1 : 0, n = (int)gTiles.size();
  if (!T->ready || (cap == T->sentCaption && n == T->sentTiles && mx == T->sentMax)) return;
  T->sentCaption = cap; T->sentTiles = n; T->sentMax = mx;
  toTile(T, std::string("{\"t\":\"win\",\"max\":") + (mx ? "true" : "false") + ",\"caption\":" + (cap ? "true" : "false") + ",\"tiles\":" + std::to_string(n) + "}");
}
// work out where every tile should be; snap puts them there at once, otherwise they slide (timer 4)
static void retile(bool snap) {
  RECT rc; GetClientRect(gWnd, &rc); int g = grip();
  if (gRoot) arrange(gRoot, {0, 0, rc.right, rc.bottom - g});
  int n = (int)gTiles.size(), dpi = dpiOf(gWnd);
  for (auto T : gTiles) {
    // the face shrinks as tiles multiply and as its tile gets small
    double w = (T->to.right - T->to.left) * 96.0 / dpi, h = (T->to.bottom - T->to.top) * 96.0 / dpi;
    T->zoomTo = std::max(.66, std::min({1.0, 1 - .09 * (n - 1), w / 640, h / 420}));
    if (snap) { T->cur = T->to; T->zoom = T->zoomTo; }
    winState(T);
  }
  if (!snap) SetTimer(gWnd, 4, 15, nullptr);
  layout(); InvalidateRect(gPageHost, nullptr, TRUE);
}
static void animStep() {
  bool moving = false;
  auto ease = [&](LONG& c, LONG t) { if (c == t) return; LONG d = t - c, s = d * 3 / 10; if (!s) s = d > 0 ? 1 : -1; c += s; moving = true; };
  for (auto T : gTiles) {
    ease(T->cur.left, T->to.left); ease(T->cur.top, T->to.top); ease(T->cur.right, T->to.right); ease(T->cur.bottom, T->to.bottom);
    if (std::fabs(T->zoom - T->zoomTo) > .004) { T->zoom += (T->zoomTo - T->zoom) * .3; moving = true; } else T->zoom = T->zoomTo;
  }
  if (!moving) KillTimer(gWnd, 4);
  layout(); InvalidateRect(gPageHost, nullptr, TRUE);
}

// ------------------------------------------------------------------------------------------- layout
static void layout() {
  RECT rc; GetClientRect(gWnd, &rc); int W = rc.right, g = grip(), H = rc.bottom - g, dpi = dpiOf(gWnd);
  SetWindowPos(gPageHost, HWND_BOTTOM, 0, g, W, H, SWP_SHOWWINDOW | SWP_NOACTIVATE);
  Tile* ov = nullptr;
  for (auto T : gTiles) {
    bool hidden = gFull && T->id != gFullTile;
    RECT r = gFull ? RECT{0, 0, W, H} : T->cur;
    int tw = std::max<int>(0, r.right - r.left), th = std::max<int>(0, r.bottom - r.top);
    int top = (T->barsAway || gFull) ? 0 : std::min(th, (int)(T->cssH * dpi / 96.0 * T->zoom + .5));
    if (hidden || tw < 2 || th < 2) ShowWindow(T->host, SW_HIDE);
    else if (T->overlay) { SetWindowPos(T->host, HWND_TOP, r.left, g + r.top, tw, th, SWP_SHOWWINDOW | SWP_NOACTIVATE); ov = T; }
    else if (top > 0) SetWindowPos(T->host, HWND_TOP, r.left, g + r.top, tw, top, SWP_SHOWWINDOW | SWP_NOACTIVATE);
    else ShowWindow(T->host, SW_HIDE);
    if (T->ctl) {
      RECT b{0, 0, std::max(tw, 1), T->overlay ? std::max(th, 1) : std::max(top, 1)}; T->ctl->put_Bounds(b);
      T->ctl->put_IsVisible(IsWindowVisible(T->host));   // a face made while its tile was still zero-wide stays hidden otherwise
      if (std::fabs(T->zoom - T->zoomSet) > .001) { T->zoomSet = T->zoom; T->ctl->put_ZoomFactor(T->zoom); }
    }
    Tab* a = activeIn(T);
    for (auto t : gTabs) if (t->tile == T->id && t->ctl) {
      if (t == a && !hidden && tw > 1 && th > top) { RECT b{r.left, r.top + top, r.right, r.bottom}; t->ctl->put_Bounds(b); t->ctl->put_IsVisible(TRUE); }
      else t->ctl->put_IsVisible(FALSE);
    }
  }
  // the shelf sits in the window's bottom-right corner, under the panels; games and full screen hide it
  if (gShelfHost) {
    int k = px(17), sh = gShelfOpen || gShelfW > k ? px(44) : k;
    int sw = std::max(k, std::min(gShelfW ? gShelfW : k, W));
    Tile* br = nullptr; for (auto T : gTiles) if (T->to.right >= W - 1 && T->to.bottom >= H - 1) br = T;
    bool tiny = !br || br->to.bottom - br->to.top < px(160);
    if (gFull || (br && br->game) || !gShelfReady || tiny) ShowWindow(gShelfHost, SW_HIDE);
    else {
      SetWindowPos(gShelfHost, HWND_TOP, W - sw, g + H - sh, sw, sh, SWP_SHOWWINDOW | SWP_NOACTIVATE);
      if (ov) SetWindowPos(ov->host, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);   // panels stay above it
    }
    if (gShelfCtl) { RECT b{0, 0, sw, sh}; gShelfCtl->put_Bounds(b); gShelfCtl->put_IsVisible(IsWindowVisible(gShelfHost)); }
  }
}
// unroll or roll up the shelf a step at a time (timer 3); the view grows leftward from the corner
static void shelfStep() {
  RECT rc; GetClientRect(gWnd, &rc); int k = px(17), target = gShelfOpen ? rc.right : k;
  if (!gShelfW) gShelfW = k;
  int d = target - gShelfW, stepPx = d / 3 + (d > 0 ? px(6) : -px(6));
  if (std::abs(d) <= std::abs(stepPx) || d == 0) {
    gShelfW = target; KillTimer(gWnd, 3);
    toShelf(gShelfOpen ? "{\"t\":\"unrolled\"}" : "{\"t\":\"rolled\"}");
  } else gShelfW += stepPx;
  layout();
}

static void setFullscreen(bool on, int tile) {
  if (on == gFull) return; gFull = on; if (on) gFullTile = tile;
  LONG st = GetWindowLongW(gWnd, GWL_STYLE);
  if (on) {
    GetWindowPlacement(gWnd, &gPlace); MONITORINFO mi{sizeof mi}; GetMonitorInfoW(MonitorFromWindow(gWnd, MONITOR_DEFAULTTONEAREST), &mi);
    SetWindowLongW(gWnd, GWL_STYLE, st & ~WS_OVERLAPPEDWINDOW);
    SetWindowPos(gWnd, HWND_TOP, mi.rcMonitor.left, mi.rcMonitor.top, mi.rcMonitor.right - mi.rcMonitor.left, mi.rcMonitor.bottom - mi.rcMonitor.top, SWP_FRAMECHANGED);
  } else {
    SetWindowLongW(gWnd, GWL_STYLE, st | WS_OVERLAPPEDWINDOW); SetWindowPlacement(gWnd, &gPlace);
    SetWindowPos(gWnd, nullptr, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
  }
  retile(true);
}

// ------------------------------------------------------------------------------------------- tabs
static std::string pct(const std::string& s) {
  std::string enc; char b[4]; for (unsigned char c : s) { if (isalnum(c) || c == '-' || c == '.' || c == '_') enc += c; else { snprintf(b, 4, "%%%02X", c); enc += b; } }
  return enc;
}
static std::string newTabUrl() {
  std::string s = gSettings["search"].s; if (s.empty()) s = "https://duckduckgo.com/?q=%s";
  std::string st; for (int i = 0; i < 8; i++) st += (i ? "." : "") + std::to_string(gStat[i]);
  std::string tv = themeVarsParam();
  return "https://meowzer.ui/meowzer-ui.html?st=" + st + "&s=" + pct(s) + (tv.empty() ? "" : "&tv=" + tv) + "#ntp";
}
static const char GHOST_PAGE[] = "https://meowzer.ui/meowzer-ghost.html";
static bool gOffline;   // the faces say when Windows loses the connection
static std::string fixUrl(const std::string& u) { return u.rfind("meowzer://newtab", 0) == 0 ? newTabUrl() : u; }
static void focusTile(int id) {
  if (id == gFocus || !tileById(id)) return;
  gPrevFocus = gFocus; gFocus = id; gFocusAt = GetTickCount64();
  InvalidateRect(gPageHost, nullptr, TRUE); pushState(focused());
}
static void selectTab(int id) {
  Tab* t = tabById(id); if (!t) return; Tile* T = tileOf(t); if (!T) return;
  T->active = id; layout(); pushState(T); if (t->ctl) t->ctl->MoveFocus(COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC);
}
static void sweepSoon();
static void closeTile(int id);
static void closeTab(int id) {
  Tab* t = tabById(id); if (!t) return; int tile = t->tile;
  std::vector<Tab*> same; for (auto x : gTabs) if (x->tile == tile) same.push_back(x);
  size_t idx = std::find(same.begin(), same.end(), t) - same.begin(); same.erase(same.begin() + idx);
  gTabs.erase(std::find(gTabs.begin(), gTabs.end(), t));
  if (t->ctl) { t->ctl->Close(); t->ctl->Release(); } if (t->wv) t->wv->Release(); delete t;
  if (same.empty()) { if (gTiles.size() > 1) closeTile(tile); else PostMessageW(gWnd, WM_CLOSE, 0, 0); return; }
  Tile* T = tileById(tile);
  if (T && T->active == id) T->active = same[std::min(idx, same.size() - 1)]->id;
  layout(); pushState(T); sweepSoon();
}
static void onKey(UINT vk, bool ctrl, bool alt, bool shift);
static std::string publicSettings();
static void saveSettings();
static void createTab(const std::string& url, std::function<void(Tab*)> then = nullptr, bool select = true, int tile = 0);

static void wireTab(Tab* t) {
  ICoreWebView2* wv = t->wv; EventRegistrationToken tok; int id = t->id;
  ICoreWebView2Settings* st; wv->get_Settings(&st);
  st->put_IsStatusBarEnabled(TRUE); st->put_AreDevToolsEnabled(TRUE); st->put_IsZoomControlEnabled(TRUE);
  ICoreWebView2Settings2* st2; if (SUCCEEDED(st->QueryInterface(IID_PPV_ARGS(&st2)))) { LPWSTR ua; st2->get_UserAgent(&ua); gSettings.set("_realUA").s = takeStr(ua); st2->Release(); }
  st->Release();
  ICoreWebView2_3* w3; if (SUCCEEDED(wv->QueryInterface(IID_PPV_ARGS(&w3)))) { w3->SetVirtualHostNameToFolderMapping(L"meowzer.ui", (gExeDir + L"\\ui").c_str(), COREWEBVIEW2_HOST_RESOURCE_ACCESS_KIND_DENY_CORS); w3->Release(); }

  // where a page goes: lick its address, pick its costume and script setting before it loads
  wv->add_NavigationStarting(EV(ICoreWebView2NavigationStartingEventHandler, ICoreWebView2NavigationStartingEventArgs)([id](ICoreWebView2* wv, ICoreWebView2NavigationStartingEventArgs* a) {
    Tab* t = tabById(id); if (!t) return S_OK;
    LPWSTR u; a->get_Uri(&u); std::string url = takeStr(u);
    if (gSettings["strip"].t != J::Bool || gSettings["strip"].b) {
      int n = lick(url);
      if (n) { a->put_Cancel(TRUE); wv->Navigate(w16(url).c_str()); gStat[S_PRM] += n; gStatDirty = true;
        toTabUi(t, "{\"t\":\"licked\",\"tab\":" + std::to_string(id) + ",\"n\":" + std::to_string(n) + "}"); return S_OK; }
    }
    if (url.rfind(GHOST_PAGE, 0) != 0) { t->ghost = false; t->ghostOf.clear(); }
    t->navUrl = url; t->loading = true; t->hissed.clear();
    toTabUi(t, "{\"t\":\"navstart\",\"tab\":" + std::to_string(id) + "}");
    std::string site = siteOf(hostOf(url));
    if (site != t->site) { t->site = site; toTabUi(t, "{\"t\":\"game\",\"on\":false}"); }
    const J* P = personaOf(site);
    ICoreWebView2Settings* st; wv->get_Settings(&st);
    ICoreWebView2Settings2* st2; if (SUCCEEDED(st->QueryInterface(IID_PPV_ARGS(&st2)))) { st2->put_UserAgent(w16(P ? (*P)["ua"].s : gSettings["_realUA"].s).c_str()); st2->Release(); }
    const J& j = jarOf(site); st->put_IsScriptEnabled(j.t == J::Obj && j["settings"]["scripts"].t == J::Bool && !j["settings"]["scripts"].b ? FALSE : TRUE);
    st->Release();
    if (url.rfind("http", 0) == 0 && url.rfind("https://meowzer.ui/", 0) != 0) { std::string origin = url.substr(0, url.find('/', url.find("://") + 3)); auto& v = gSeenOrigins[site]; if (std::find(v.begin(), v.end(), origin) == v.end()) v.push_back(origin); }
    pushTab(t); return S_OK; }), &tok);
  wv->add_SourceChanged(EV(ICoreWebView2SourceChangedEventHandler, ICoreWebView2SourceChangedEventArgs)([id](ICoreWebView2* wv, ICoreWebView2SourceChangedEventArgs*) {
    Tab* t = tabById(id); if (!t) return S_OK; LPWSTR u; wv->get_Source(&u); t->url = takeStr(u);
    if (t->url.rfind(GHOST_PAGE, 0) == 0 && !t->ghostOf.empty()) { t->url = t->ghostOf; t->ghost = true; }   // the address bar keeps the real address
    else if (t->url.rfind("https://meowzer.ui/", 0) == 0) t->url = "meowzer://newtab";
    pushTab(t); return S_OK; }), &tok);
  wv->add_HistoryChanged(EV(ICoreWebView2HistoryChangedEventHandler, IUnknown)([id](ICoreWebView2* wv, IUnknown*) {
    Tab* t = tabById(id); if (!t) return S_OK; BOOL b; wv->get_CanGoBack(&b); t->back = b; wv->get_CanGoForward(&b); t->fwd = b; pushTab(t); return S_OK; }), &tok);
  wv->add_DocumentTitleChanged(EV(ICoreWebView2DocumentTitleChangedEventHandler, IUnknown)([id](ICoreWebView2* wv, IUnknown*) {
    Tab* t = tabById(id); if (!t) return S_OK; LPWSTR s; wv->get_DocumentTitle(&s); t->title = takeStr(s); retitle(t->url, t->title); pushTab(t); return S_OK; }), &tok);
  wv->add_NavigationCompleted(EV(ICoreWebView2NavigationCompletedEventHandler, ICoreWebView2NavigationCompletedEventArgs)([id](ICoreWebView2* wv, ICoreWebView2NavigationCompletedEventArgs* a) {
    Tab* t = tabById(id); if (!t) return S_OK; t->loading = false;
    BOOL ok = FALSE; a->get_IsSuccess(&ok); if (ok && !t->ghost) remember(t->url, t->title);
    // offline: a page that could not be reached comes back as a ghost (the user's GhostBrowser, minting a synthetic
    // stand-in from the address, marked as such). A mistyped address while online still shows the engine's error.
    bool ghostOn = gSettings["ghost"].t != J::Bool || gSettings["ghost"].b;
    if (!ok && ghostOn) {
      COREWEBVIEW2_WEB_ERROR_STATUS es = COREWEBVIEW2_WEB_ERROR_STATUS_UNKNOWN; a->get_WebErrorStatus(&es);
      bool netGone = es == COREWEBVIEW2_WEB_ERROR_STATUS_DISCONNECTED || (gOffline && (es == COREWEBVIEW2_WEB_ERROR_STATUS_CANNOT_CONNECT ||
        es == COREWEBVIEW2_WEB_ERROR_STATUS_TIMEOUT || es == COREWEBVIEW2_WEB_ERROR_STATUS_HOST_NAME_NOT_RESOLVED ||
        es == COREWEBVIEW2_WEB_ERROR_STATUS_CONNECTION_ABORTED || es == COREWEBVIEW2_WEB_ERROR_STATUS_CONNECTION_RESET));
      if (netGone && t->navUrl.rfind("http", 0) == 0 && t->navUrl.rfind("https://meowzer.ui/", 0) != 0) {
        std::string gone = t->navUrl; t->ghostOf = gone;
        wv->Navigate(w16(std::string(GHOST_PAGE) + "#u=" + pct(gone) + "&off=1").c_str());
        return S_OK;
      }
    }
    pushTab(t); sweepSoon(); return S_OK; }), &tok);
  ICoreWebView2_15* w15; if (SUCCEEDED(wv->QueryInterface(IID_PPV_ARGS(&w15)))) {
    w15->add_FaviconChanged(cb<ICoreWebView2FaviconChangedEventHandler, ICoreWebView2*, IUnknown*>([id](ICoreWebView2* wv, IUnknown*) {
      Tab* t = tabById(id); if (!t) return S_OK; ICoreWebView2_15* w; if (SUCCEEDED(wv->QueryInterface(IID_PPV_ARGS(&w)))) { LPWSTR f; w->get_FaviconUri(&f); t->fav = takeStr(f); w->Release(); } pushTab(t); return S_OK; }), &tok);
    w15->Release(); }
  // downloads: no Edge bubble; the face's Downloads page lists them
  ICoreWebView2_4* w4; if (SUCCEEDED(wv->QueryInterface(IID_PPV_ARGS(&w4)))) {
    w4->add_DownloadStarting(EV(ICoreWebView2DownloadStartingEventHandler, ICoreWebView2DownloadStartingEventArgs)([](ICoreWebView2*, ICoreWebView2DownloadStartingEventArgs* a) {
      a->put_Handled(TRUE);
      ICoreWebView2DownloadOperation* op = nullptr; if (FAILED(a->get_DownloadOperation(&op)) || !op) return S_OK;
      DL* d = new DL(); d->id = gNextDl++; d->op = op;
      LPWSTR u; if (SUCCEEDED(op->get_Uri(&u))) d->url = takeStr(u);
      LPWSTR p; if (SUCCEEDED(a->get_ResultFilePath(&p))) d->path = takeStr(p);
      gDls.push_back(d); dlRead(d); dlPush(d);
      int did = d->id; EventRegistrationToken tk;
      op->add_BytesReceivedChanged(cb<ICoreWebView2BytesReceivedChangedEventHandler, ICoreWebView2DownloadOperation*, IUnknown*>([did](ICoreWebView2DownloadOperation*, IUnknown*) {
        DL* d = dlById(did); if (!d) return S_OK; ULONGLONG now = GetTickCount64();
        if (now - d->sent > 250) { d->sent = now; dlRead(d); dlPush(d); } return S_OK; }), &tk);
      op->add_StateChanged(cb<ICoreWebView2StateChangedEventHandler, ICoreWebView2DownloadOperation*, IUnknown*>([did](ICoreWebView2DownloadOperation*, IUnknown*) {
        DL* d = dlById(did); if (!d) return S_OK; dlRead(d); dlPush(d); return S_OK; }), &tk);
      return S_OK; }), &tok);
    w4->Release(); }
  // popups become tabs in the same tile (keeping window.opener, so sign-in windows work)
  wv->add_NewWindowRequested(EV(ICoreWebView2NewWindowRequestedEventHandler, ICoreWebView2NewWindowRequestedEventArgs)([id](ICoreWebView2*, ICoreWebView2NewWindowRequestedEventArgs* a) {
    Tab* t = tabById(id); ICoreWebView2Deferral* d; a->GetDeferral(&d); a->AddRef();
    createTab("", [a, d](Tab* nt) { a->put_NewWindow(nt->wv); a->put_Handled(TRUE); d->Complete(); d->Release(); a->Release(); }, true, t ? t->tile : 0);
    return S_OK; }), &tok);
  wv->add_ContainsFullScreenElementChanged(EV(ICoreWebView2ContainsFullScreenElementChangedEventHandler, IUnknown)([id](ICoreWebView2* wv, IUnknown*) {
    Tab* t = tabById(id); BOOL f; wv->get_ContainsFullScreenElement(&f); setFullscreen(f, t ? t->tile : 0); return S_OK; }), &tok);
  wv->add_WindowCloseRequested(EV(ICoreWebView2WindowCloseRequestedEventHandler, IUnknown)([id](ICoreWebView2*, IUnknown*) { closeTab(id); return S_OK; }), &tok);
  // pages may only say two things: "I look like a game" and "I scrolled". Meowzer's own new-tab page may also pick the search engine.
  wv->add_WebMessageReceived(EV(ICoreWebView2WebMessageReceivedEventHandler, ICoreWebView2WebMessageReceivedEventArgs)([id](ICoreWebView2*, ICoreWebView2WebMessageReceivedEventArgs* a) {
    Tab* t = tabById(id); if (!t) return S_OK;
    LPWSTR js; if (FAILED(a->get_WebMessageAsJson(&js))) return S_OK; J m = parse(takeStr(js));
    LPWSTR src; a->get_Source(&src); bool ours = takeStr(src).rfind("https://meowzer.ui/", 0) == 0;
    if (ours && m["meow"].s == "search") {
      const std::string& u = m["url"].s;
      if (u.rfind("https://", 0) == 0 && u.find("%s") != std::string::npos && u.size() < 400) {
        gSettings.set("search").s = u; saveSettings();
        toUi("{\"t\":\"settings\",\"settings\":" + publicSettings() + "}");
      }
      return S_OK;
    }
    Tile* T = tileOf(t); if (!T || activeIn(T) != t) return S_OK;
    if (m["meow"].s == "game") toTile(T, std::string("{\"t\":\"game\",\"on\":") + (m["on"].truthy() ? "true" : "false") + "}");
    if (m["meow"].s == "scroll") toTile(T, std::string("{\"t\":\"scroll\",\"down\":") + (m["down"].truthy() ? "true" : "false") + ",\"y\":" + std::to_string(m["y"].num()) + "}");
    return S_OK; }), &tok);
  // every request: the cat decides
  ICoreWebView2_22* w22;
  if (SUCCEEDED(wv->QueryInterface(IID_PPV_ARGS(&w22)))) { w22->AddWebResourceRequestedFilterWithRequestSourceKinds(L"*", COREWEBVIEW2_WEB_RESOURCE_CONTEXT_ALL, COREWEBVIEW2_WEB_RESOURCE_REQUEST_SOURCE_KINDS_ALL); w22->Release(); }
  else wv->AddWebResourceRequestedFilter(L"*", COREWEBVIEW2_WEB_RESOURCE_CONTEXT_ALL);
  wv->add_WebResourceRequested(EV(ICoreWebView2WebResourceRequestedEventHandler, ICoreWebView2WebResourceRequestedEventArgs)([id](ICoreWebView2*, ICoreWebView2WebResourceRequestedEventArgs* a) {
    Tab* t = tabById(id); if (!t) return S_OK;
    ICoreWebView2WebResourceRequest* rq; a->get_Request(&rq);
    LPWSTR u; rq->get_Uri(&u); std::string url = takeStr(u);
    if (url.rfind("http", 0) != 0 || url == t->navUrl) { rq->Release(); return S_OK; }
    std::string host = hostOf(url), site = siteOf(host);
    bool third = !t->site.empty() && site != t->site;
    int lvl = blockerOf(t->site);
    COREWEBVIEW2_WEB_RESOURCE_CONTEXT ctx; a->get_ResourceContext(&ctx);
    bool hiss = lvl > 0 && decide(host, third);
    if (!hiss && lvl == 2 && third && (ctx == COREWEBVIEW2_WEB_RESOURCE_CONTEXT_SCRIPT || ctx == COREWEBVIEW2_WEB_RESOURCE_CONTEXT_DOCUMENT)) hiss = true;
    if (hiss) {
      ICoreWebView2WebResourceResponse* r;
      if (ctx == COREWEBVIEW2_WEB_RESOURCE_CONTEXT_XML_HTTP_REQUEST || ctx == COREWEBVIEW2_WEB_RESOURCE_CONTEXT_FETCH) {
        // scripts that get an error back for their beacons and configs often retry at once, forever; an empty,
        // successful answer (allowed across origins) quietens them
        ICoreWebView2HttpRequestHeaders* rh; rq->get_Headers(&rh); LPWSTR o = nullptr; std::string origin;
        if (SUCCEEDED(rh->GetHeader(L"Origin", &o)) && o) origin = takeStr(o);
        LPWSTR ah = nullptr; std::string allowH = "content-type";
        if (SUCCEEDED(rh->GetHeader(L"Access-Control-Request-Headers", &ah)) && ah) { std::string v = takeStr(ah); if (!v.empty()) allowH = v; }
        rh->Release();
        if (origin.empty() || origin == "null") origin = "https://" + t->site;
        IStream* body = SHCreateMemStream((const BYTE*)"{}", 2);
        gEnv->CreateWebResourceResponse(body, 200, L"OK", w16("Content-Type: application/json\r\nAccess-Control-Allow-Origin: " + origin +
          "\r\nAccess-Control-Allow-Credentials: true\r\nAccess-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS\r\nAccess-Control-Allow-Headers: " + allowH +
          "\r\nAccess-Control-Max-Age: 600").c_str(), &r);
        body->Release();
      } else gEnv->CreateWebResourceResponse(nullptr, 403, L"Hissed", L"Content-Type: text/plain", &r);
      a->put_Response(r); r->Release(); rq->Release();
      // a page that retries a blocked address in a loop is still one thing hissed at, not thousands
      if (t->hissed.insert(url).second) {
        gStat[S_BLK]++; gStat[S_BYTES] += bytesOf(ctx); gStatDirty = true;
        if (ctx == COREWEBVIEW2_WEB_RESOURCE_CONTEXT_IMAGE || ctx == COREWEBVIEW2_WEB_RESOURCE_CONTEXT_MEDIA || ctx == COREWEBVIEW2_WEB_RESOURCE_CONTEXT_DOCUMENT || ctx == COREWEBVIEW2_WEB_RESOURCE_CONTEXT_SCRIPT) gStat[S_ADS]++;
        if (ctx == COREWEBVIEW2_WEB_RESOURCE_CONTEXT_SCRIPT) gStat[S_SCR]++;
        if (ctx == COREWEBVIEW2_WEB_RESOURCE_CONTEXT_MEDIA) gStat[S_MED]++;
        toTabUi(t, "{\"t\":\"blocked\",\"tab\":" + std::to_string(id) + ",\"host\":" + q(host) + ",\"ctx\":" + std::to_string((int)ctx) + "}");
      }
      return S_OK;
    }
    ICoreWebView2HttpRequestHeaders* hd; rq->get_Headers(&hd);
    const J& j = jarOf(t->site);
    if (third && !(j.t == J::Obj && j["settings"]["allow3p"].truthy())) hd->RemoveHeader(L"Cookie");
    if (third && j.t == J::Obj && j["settings"]["referrer"].truthy()) hd->SetHeader(L"Referer", w16("https://" + t->site + "/").c_str());
    if (gSettings["gpc"].t != J::Bool || gSettings["gpc"].b) { hd->SetHeader(L"Sec-GPC", L"1"); hd->SetHeader(L"DNT", L"1"); }
    if (const J* P = personaOf(t->site)) {
      const J& fw = (*P)["firmware"];
      hd->SetHeader(L"sec-ch-ua-platform", w16("\"" + fw["platform"].s + "\"").c_str());
      hd->SetHeader(L"sec-ch-ua-mobile", fw["mobile"].truthy() ? L"?1" : L"?0");
      std::string langs; for (auto& l : (*P)["software"]["languages"].a) { if (!langs.empty()) langs += ","; langs += l.s; }
      if (!langs.empty()) hd->SetHeader(L"Accept-Language", w16(langs).c_str());
    }
    // the Mask's fuzz layer: say less to sites other than the one you are on
    const J& fz = gSettings["mask"]["fuzz"];
    if (fz["on"].truthy()) {
      int ref = fz["ref"].num(1);
      std::string scheme = t->url.rfind("http:", 0) == 0 ? "http" : "https";
      if (third && ref == 1) hd->SetHeader(L"Referer", w16(scheme + "://" + t->site + "/").c_str());
      if (third && ref == 2) hd->SetHeader(L"Referer", L"");   // removing it isn't enough: the engine puts it back
      if (fz["lang"].truthy()) {   // one language instead of the whole ranked list
        LPWSTR al = nullptr; std::string v; if (SUCCEEDED(hd->GetHeader(L"Accept-Language", &al)) && al) v = takeStr(al);
        if (v.empty()) { wchar_t loc[LOCALE_NAME_MAX_LENGTH]; if (GetUserDefaultLocaleName(loc, LOCALE_NAME_MAX_LENGTH)) v = u8(loc); }
        v = v.substr(0, v.find_first_of(",;")); if (!v.empty()) hd->SetHeader(L"Accept-Language", w16(v).c_str());
      }
      if (third && fz["hints"].truthy())   // the detailed client hints (exact versions, model, CPU) stay home
        for (auto h : {L"sec-ch-ua-full-version-list", L"sec-ch-ua-full-version", L"sec-ch-ua-platform-version", L"sec-ch-ua-arch", L"sec-ch-ua-bitness", L"sec-ch-ua-model", L"sec-ch-ua-wow64"}) hd->RemoveHeader(h);
    }
    hd->Release(); rq->Release(); return S_OK; }), &tok);
  // a click in the page makes its tile the one the window buttons and shortcuts act on
  t->ctl->add_GotFocus(cb<ICoreWebView2FocusChangedEventHandler, ICoreWebView2Controller*, IUnknown*>([id](ICoreWebView2Controller*, IUnknown*) {
    if (Tab* t = tabById(id)) focusTile(t->tile); return S_OK; }), &tok);
  // keys pressed while a page has focus
  t->ctl->add_AcceleratorKeyPressed(cb<ICoreWebView2AcceleratorKeyPressedEventHandler, ICoreWebView2Controller*, ICoreWebView2AcceleratorKeyPressedEventArgs*>([](ICoreWebView2Controller*, ICoreWebView2AcceleratorKeyPressedEventArgs* a) {
    COREWEBVIEW2_KEY_EVENT_KIND k; a->get_KeyEventKind(&k);
    if (k != COREWEBVIEW2_KEY_EVENT_KIND_KEY_DOWN && k != COREWEBVIEW2_KEY_EVENT_KIND_SYSTEM_KEY_DOWN) return S_OK;
    UINT vk; a->get_VirtualKey(&vk);
    bool ctrl = GetKeyState(VK_CONTROL) < 0, alt = GetKeyState(VK_MENU) < 0, shift = GetKeyState(VK_SHIFT) < 0;
    if ((ctrl && (vk == 'T' || vk == 'W' || vk == 'L' || vk == 'D' || vk == 'H' || vk == 'J' || vk == VK_TAB)) || (alt && (vk == VK_LEFT || vk == VK_RIGHT)) || vk == VK_F5 || vk == VK_F9 || vk == VK_F11) { a->put_Handled(TRUE); onKey(vk, ctrl, alt, shift); }
    return S_OK; }), &tok);
  applyInject(t);
}

static void createTab(const std::string& url, std::function<void(Tab*)> then, bool select, int tile) {
  Tile* T = tileById(tile); if (!T) T = focused(); if (!T) return;
  Tab* t = new Tab(); t->id = gNextId++; t->tile = T->id; t->url = url; gTabs.push_back(t);
  if (select) T->active = t->id;
  int id = t->id;
  gEnv->CreateCoreWebView2Controller(gPageHost, cb<ICoreWebView2CreateCoreWebView2ControllerCompletedHandler, HRESULT, ICoreWebView2Controller*>([id, url, then](HRESULT hr, ICoreWebView2Controller* c) {
    if (FAILED(hr) || !c) return S_OK;
    Tab* t = tabById(id); if (!t) { c->Close(); return S_OK; }   // its tile closed while it was being made
    t->ctl = c; c->AddRef(); c->get_CoreWebView2(&t->wv);
    wireTab(t); layout();
    if (!url.empty()) t->wv->Navigate(w16(fixUrl(url)).c_str());
    if (then) then(t);
    pushTab(t); return S_OK; }));
}

// ------------------------------------------------------------------------------------------- the cookie sweep
// List every cookie, ask meowcore what each one's fate is, burn what it says to burn, and clamp jarred cookies to
// their jar lifetime. Then sites that are neither open nor jarred lose their storage too.
static bool gSweepQueued;
static void sweep();
static void sweepSoon() { if (!gSweepQueued) { gSweepQueued = true; SetTimer(gWnd, 2, 600, nullptr); } }
static ICoreWebView2* anyView() { for (auto t : gTabs) if (t->wv) return t->wv; return nullptr; }
static ICoreWebView2CookieManager* cookieMgr() {
  ICoreWebView2* wv = anyView(); if (!wv) return nullptr;
  ICoreWebView2_2* w2; ICoreWebView2CookieManager* m = nullptr;
  if (SUCCEEDED(wv->QueryInterface(IID_PPV_ARGS(&w2)))) { w2->get_CookieManager(&m); w2->Release(); }
  return m;
}
struct CK { std::string name, value, domain, path, same; double expires; bool session, http, secure; ICoreWebView2Cookie* c; };
static std::vector<CK> readCookies(ICoreWebView2CookieList* list) {
  std::vector<CK> v; UINT n = 0; list->get_Count(&n);
  for (UINT i = 0; i < n; i++) {
    ICoreWebView2Cookie* c; if (FAILED(list->GetValueAtIndex(i, &c))) continue;
    CK k; LPWSTR s; c->get_Name(&s); k.name = takeStr(s); c->get_Value(&s); k.value = takeStr(s); c->get_Domain(&s); k.domain = takeStr(s); c->get_Path(&s); k.path = takeStr(s);
    c->get_Expires(&k.expires); BOOL b; c->get_IsSession(&b); k.session = b; c->get_IsHttpOnly(&b); k.http = b; c->get_IsSecure(&b); k.secure = b;
    COREWEBVIEW2_COOKIE_SAME_SITE_KIND ss; c->get_SameSite(&ss); k.same = ss == COREWEBVIEW2_COOKIE_SAME_SITE_KIND_LAX ? "Lax" : ss == COREWEBVIEW2_COOKIE_SAME_SITE_KIND_STRICT ? "Strict" : "None";
    k.c = c; v.push_back(k);
  }
  return v;
}
static void clearOrigin(const std::string& origin) {
  ICoreWebView2* wv = anyView(); if (!wv) return;
  wv->CallDevToolsProtocolMethod(L"Storage.clearDataForOrigin", w16("{\"origin\":" + q(origin) + ",\"storageTypes\":\"local_storage,indexeddb,cache_storage,service_workers,websql,shader_cache\"}").c_str(),
    cb<ICoreWebView2CallDevToolsProtocolMethodCompletedHandler, HRESULT, LPCWSTR>([](HRESULT, LPCWSTR) { return S_OK; }));
}
static void sweep() {
  ICoreWebView2CookieManager* m = cookieMgr(); if (!m) return;
  m->GetCookies(L"", cb<ICoreWebView2GetCookiesCompletedHandler, HRESULT, ICoreWebView2CookieList*>([m](HRESULT hr, ICoreWebView2CookieList* list) {
    if (FAILED(hr) || !list) { m->Release(); return S_OK; }
    auto cs = readCookies(list);
    std::string sc = "@sweep\nH " + std::to_string(gSettings["heat"].num(2)) + "\n";
    for (auto& [site, j] : gJar.o) sc += "J " + std::to_string(j["settings"]["heat"].num(2)) + " " + site + "\n";
    std::unordered_set<std::string> open;
    for (auto t : gTabs) if (!t->site.empty()) { open.insert(t->site); const J& j = jarOf(t->site); sc += std::string("O ") + (j.t == J::Obj && j["settings"]["allow3p"].truthy() ? "1 " : "0 ") + t->site + "\n"; }
    for (size_t i = 0; i < cs.size(); i++) sc += "C " + std::to_string(i) + (isTracker(cs[i].domain) ? " 1 " : " 0 ") + cs[i].domain + "\n";
    sc += "@end\n";
    std::string out = runCore(sc);
    std::string burnt = "["; int nb = 0; double now = (double)time(nullptr);
    size_t p = 0;
    while ((p = out.find("v ", p)) != std::string::npos) {
      size_t e = out.find('\n', p); std::string l = out.substr(p, e - p); p = e;
      size_t sp = l.find(' ', 2); size_t i = strtoul(l.substr(2, sp - 2).c_str(), nullptr, 10); char v = l[sp + 1];
      if (i >= cs.size()) continue;
      CK& k = cs[i];
      if (v == 'B') { m->DeleteCookie(k.c); if (nb++ < 60) burnt += std::string(nb > 1 ? "," : "") + "{\"name\":" + q(k.name) + ",\"domain\":" + q(k.domain) + "}"; }
      if (v == 'K') {   // a jarred cookie lives no longer than its jar setting
        static const int days[] = {0, 1, 7, 30, 365, 36500};
        const J& j = jarOf(siteOf(k.domain)); int life = j["settings"]["life"].num(3); if (life < 0 || life > 5) life = 3;
        if (life == 0 && !k.session) { k.c->put_Expires(-1); m->AddOrUpdateCookie(k.c); }
        else if (life > 0 && (k.session || k.expires > now + days[life] * 86400.0 + 3600)) { k.c->put_Expires(now + days[life] * 86400.0); m->AddOrUpdateCookie(k.c); }
      }
    }
    for (auto& k : cs) k.c->Release();
    if (nb) { gStat[S_CK] += nb; gStatDirty = true; toUi("{\"t\":\"sweep\",\"burnt\":" + burnt + "]}"); }
    for (auto it = gSeenOrigins.begin(); it != gSeenOrigins.end();) {
      const J& j = jarOf(it->first);
      bool keepStore = j.t == J::Obj && (j["settings"]["storage"].t != J::Bool || j["settings"]["storage"].b);
      if (!open.count(it->first) && !keepStore && gSettings["heat"].num(2) > 0) { for (auto& o : it->second) clearOrigin(o); it = gSeenOrigins.erase(it); }
      else ++it;
    }
    m->Release(); return S_OK; }));
}

// ------------------------------------------------------------------------------------------- messages from the faces
static void sendCookies(Tile* T, int reqId) {
  int tid = T ? T->id : 0;
  ICoreWebView2CookieManager* m = cookieMgr(); if (!m) { toTile(T, "{\"t\":\"cookies\",\"id\":" + std::to_string(reqId) + ",\"list\":[]}"); return; }
  m->GetCookies(L"", cb<ICoreWebView2GetCookiesCompletedHandler, HRESULT, ICoreWebView2CookieList*>([m, reqId, tid](HRESULT, ICoreWebView2CookieList* list) {
    std::string s = "{\"t\":\"cookies\",\"id\":" + std::to_string(reqId) + ",\"list\":[";
    if (list) { auto cs = readCookies(list); for (size_t i = 0; i < cs.size(); i++) { auto& k = cs[i]; if (i) s += ",";
      char e[32]; snprintf(e, 32, "%.0f", k.expires);
      s += "{\"name\":" + q(k.name) + ",\"value\":" + q(k.value) + ",\"domain\":" + q(k.domain) + ",\"path\":" + q(k.path) + ",\"expires\":" + e +
        ",\"session\":" + (k.session ? "true" : "false") + ",\"httpOnly\":" + (k.http ? "true" : "false") + ",\"secure\":" + (k.secure ? "true" : "false") + ",\"sameSite\":" + q(k.same) + "}";
      k.c->Release(); } }
    toTile(tileById(tid), s + "]}"); m->Release(); return S_OK; }));
}
static void withCookies(std::function<void(ICoreWebView2CookieManager*, std::vector<CK>&)> f) {
  ICoreWebView2CookieManager* m = cookieMgr(); if (!m) return;
  m->GetCookies(L"", cb<ICoreWebView2GetCookiesCompletedHandler, HRESULT, ICoreWebView2CookieList*>([m, f](HRESULT, ICoreWebView2CookieList* list) {
    if (list) { auto cs = readCookies(list); f(m, cs); for (auto& k : cs) k.c->Release(); }
    m->Release(); return S_OK; }));
}
static void saveJar() { writeStore(gData + L"\\jar.json", dump(gJar), "jar"); }
static std::string publicSettings() { J s = gSettings; for (auto it = s.o.begin(); it != s.o.end();) if (it->first[0] == '_') it = s.o.erase(it); else ++it; return dump(s); }
static void saveSettings() { writeFile(gData + L"\\settings.json", publicSettings()); }
static void sendInit(Tile* T) {
  RECT rc; GetClientRect(gWnd, &rc);
  bool cap = T->to.top == 0 && T->to.right >= rc.right - 1; int n = (int)gTiles.size(), mx = IsZoomed(gWnd) ? 1 : 0;
  T->sentCaption = cap; T->sentTiles = n; T->sentMax = mx;
  std::string s = "{\"t\":\"init\",\"platform\":\"desktop\",\"caption\":" + std::string(cap ? "true" : "false") + ",\"tiles\":" + std::to_string(n) +
    ",\"max\":" + (mx ? "true" : "false") + ",\"engine\":" + q(gEngine) + ",\"settings\":" + dump(gSettings) + ",\"jar\":" + dump(gJar) +
    ",\"table\":" + q(gTableStats) + ",\"totalBlocked\":" + std::to_string(gStat[S_BLK]) + "}";
  toTile(T, s); pushState(T);
  for (auto d : gDls) toTile(T, "{\"t\":\"dl\",\"item\":" + dlJson(d) + "}");
}
static void fetchLists() {
  std::vector<std::string> urls; for (auto& u : gSettings["listUrls"].a) if (u.s.rfind("https://", 0) == 0) urls.push_back(u.s);
  std::thread([urls] {
    CreateDirectoryW((gData + L"\\lists").c_str(), nullptr);
    WIN32_FIND_DATAW fd; HANDLE f = FindFirstFileW((gData + L"\\lists\\*.txt").c_str(), &fd);
    std::vector<std::wstring> stale; if (f != INVALID_HANDLE_VALUE) { do stale.push_back(fd.cFileName); while (FindNextFileW(f, &fd)); FindClose(f); }
    std::unordered_set<std::wstring> want;
    for (auto& u : urls) { char n[32]; snprintf(n, 32, "%016llx.txt", (unsigned long long)fnv(u)); std::wstring file = w16(n); want.insert(file);
      URLDownloadToFileW(nullptr, w16(u).c_str(), (gData + L"\\lists\\" + file).c_str(), 0, nullptr); }
    for (auto& s : stale) if (!want.count(s)) DeleteFileW((gData + L"\\lists\\" + s).c_str());
    PostMessageW(gWnd, WM_APP + 1, 0, 0);
  }).detach();
}

// ------------------------------------------------------------------------------------------- the route (the Mask)
// Meowzer doesn't make tunnels. It can send its pages through one that is already there: Tor (the Tor Browser or tor
// service listening on 127.0.0.1:9150 / 9050) or a proxy you name. A VPN app (Proton VPN Free and the like) moves the
// whole computer instead, so Meowzer only watches for it. Either way the probe asks am.i.mullvad.net, through the same
// route the pages take, where the traffic leaves from. The engine takes a proxy only when it starts, so changing the
// route restarts Meowzer with the same tabs.
static std::wstring gBaseArgs;          // WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS as Meowzer found it
static std::string gRouteNow = "direct"; // what this run of the engine uses
static bool validProxy(const std::string& p) {
  size_t s = p.find("://"); if (s == std::string::npos) return false;
  std::string sc = p.substr(0, s); if (sc != "socks5" && sc != "socks4" && sc != "http" && sc != "https") return false;
  size_t c = p.rfind(':'); if (c <= s + 3 || c + 1 >= p.size() || p.size() > 200) return false;
  for (size_t i = s + 3; i < c; i++) { char ch = p[i]; if (!isalnum((unsigned char)ch) && ch != '.' && ch != '-' && ch != '[' && ch != ']' && ch != ':') return false; }
  for (size_t i = c + 1; i < p.size(); i++) if (!isdigit((unsigned char)p[i])) return false;
  return true;
}
static std::string routeProxy() {
  const J& m = gSettings["mask"]; if (!m["routeOn"].truthy()) return {};
  const J& r = m["route"]; std::string px;
  if (r["mode"].s == "tor") px = "socks5://127.0.0.1:" + std::to_string(r["port"].num(9150));
  else if (r["mode"].s == "proxy") px = r["proxy"].s;
  return validProxy(px) ? px : std::string();
}
static void applyRouteArgs() {
  wchar_t buf[4096]; DWORD n = GetEnvironmentVariableW(L"WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", buf, 4096);
  gBaseArgs = n && n < 4096 ? std::wstring(buf, n) : L"";
  std::string px = routeProxy(); if (px.empty()) { gRouteNow = "direct"; return; }
  gRouteNow = px;
  // WebRTC may only use the proxy, so a call or a data channel can't show the real address around it
  std::wstring a = gBaseArgs + (gBaseArgs.empty() ? L"" : L" ") + w16("--proxy-server=" + px + " --force-webrtc-ip-handling-policy=disable_non_proxied_udp");
  SetEnvironmentVariableW(L"WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", a.c_str());
}
static void saveStats(); static void saveHistory();
static void restartForRoute() {
  J list; list.t = J::Arr;
  for (auto T : gTiles) for (auto t : gTabs) if (t->tile == T->id) {
    std::string u = t->ghost ? t->ghostOf : t->url; if (u.rfind("http", 0) != 0) continue; J s; s.t = J::Str; s.s = u; list.a.push_back(s); }
  writeFile(gData + L"\\resume.json", dump(list));
  saveStats(); if (gHistDirty) saveHistory(); storesFlush();
  SetEnvironmentVariableW(L"WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", gBaseArgs.empty() ? nullptr : gBaseArgs.c_str());   // the new run works out its own
  wchar_t exe[MAX_PATH]; GetModuleFileNameW(nullptr, exe, MAX_PATH);
  ShellExecuteW(nullptr, L"open", exe, w16("--resume " + std::to_string(GetCurrentProcessId())).c_str(), gExeDir.c_str(), SW_SHOWNORMAL);
  PostMessageW(gWnd, WM_CLOSE, 0, 0);
}
// work done off the window's thread hands its answer back here: WM_APP+2, wParam a new std::string, lParam a tile (0: all)
static void postJson(const std::string& json, int tile) { PostMessageW(gWnd, WM_APP + 2, (WPARAM) new std::string(json), tile); }
static int torPortNow() {
  WSADATA w; if (WSAStartup(MAKEWORD(2, 2), &w)) return 0; int found = 0;
  for (int port : {9150, 9050}) {
    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP); if (s == INVALID_SOCKET) continue;
    u_long nb = 1; ioctlsocket(s, FIONBIO, &nb);
    sockaddr_in a{}; a.sin_family = AF_INET; a.sin_port = htons((u_short)port); a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    connect(s, (sockaddr*)&a, sizeof a);
    fd_set wr, ex; FD_ZERO(&wr); FD_SET(s, &wr); FD_ZERO(&ex); FD_SET(s, &ex); timeval tv{0, 300000};
    bool ok = select(0, nullptr, &wr, &ex, &tv) > 0 && FD_ISSET(s, &wr); closesocket(s);
    if (ok) { found = port; break; }
  }
  WSACleanup(); return found;
}
// the probe: a hidden view on the same engine (so it takes the same route), never shown, never a tab
static HWND gProbeHost; static ICoreWebView2Controller* gProbeCtl; static ICoreWebView2* gProbe;
static ULONGLONG gProbeAt; static bool gProbeBusy; static std::vector<std::pair<int, int>> gProbeWait;
static J gRouteLog;   // the last 200 answers, kept as a store (sealed when the seal covers it)
static void probeDone(const std::string& data) {
  gProbeBusy = false; KillTimer(gWnd, 6);
  for (auto& w : gProbeWait) toTile(tileById(w.first), "{\"t\":\"probe\",\"id\":" + std::to_string(w.second) + ",\"data\":" + data + "}");
  gProbeWait.clear();
  toUi("{\"t\":\"probe\",\"data\":" + data + "}");
}
static void probeRoute(Tile* T, int req) {
  if (T && req) gProbeWait.push_back({T->id, req});
  if (gProbeBusy || !gEnv) return;
  gProbeBusy = true; SetTimer(gWnd, 6, 25000, nullptr);
  auto go = [] { gProbeAt = GetTickCount64(); gProbe->Navigate(L"https://am.i.mullvad.net/json"); };
  if (gProbe) { go(); return; }
  gProbeHost = CreateWindowExW(0, L"MeowzerHost", L"", WS_CHILD, 0, 0, 1, 1, gWnd, nullptr, GetModuleHandleW(nullptr), nullptr);
  gEnv->CreateCoreWebView2Controller(gProbeHost, cb<ICoreWebView2CreateCoreWebView2ControllerCompletedHandler, HRESULT, ICoreWebView2Controller*>([go](HRESULT hr, ICoreWebView2Controller* c) {
    if (FAILED(hr) || !c) { probeDone("{\"ok\":false,\"error\":\"the probe could not start\"}"); return S_OK; }
    gProbeCtl = c; c->AddRef(); c->get_CoreWebView2(&gProbe); c->put_IsVisible(FALSE);
    EventRegistrationToken tok;
    gProbe->add_NavigationCompleted(EV(ICoreWebView2NavigationCompletedEventHandler, ICoreWebView2NavigationCompletedEventArgs)([](ICoreWebView2* wv, ICoreWebView2NavigationCompletedEventArgs* a) {
      if (!gProbeBusy) return S_OK;   // it already timed out
      BOOL ok = FALSE; a->get_IsSuccess(&ok); long long ms = (long long)(GetTickCount64() - gProbeAt);
      if (!ok) { COREWEBVIEW2_WEB_ERROR_STATUS es; a->get_WebErrorStatus(&es);
        probeDone("{\"ok\":false,\"ms\":" + std::to_string(ms) + ",\"route\":" + q(gRouteNow) + ",\"error\":" + q(es == COREWEBVIEW2_WEB_ERROR_STATUS_DISCONNECTED ? "offline" :
          es == COREWEBVIEW2_WEB_ERROR_STATUS_CANNOT_CONNECT || es == COREWEBVIEW2_WEB_ERROR_STATUS_CONNECTION_ABORTED ? "the route would not connect" : "no answer") + "}"); return S_OK; }
      wv->ExecuteScript(L"document.body?document.body.innerText:''", cb<ICoreWebView2ExecuteScriptCompletedHandler, HRESULT, LPCWSTR>([ms](HRESULT, LPCWSTR r) {
        J body = parse(parse(r ? u8(r) : "\"\"").s);
        if (body.t != J::Obj) { probeDone("{\"ok\":false,\"error\":\"an answer Meowzer could not read\"}"); return S_OK; }
        J d; d.t = J::Obj; d.set("ok").t = J::Bool; d.set("ok").b = true;
        for (auto k : {"ip", "country", "city", "organization"}) { J& x = d.set(k); x = body[k]; }
        for (auto k : {"latitude", "longitude"}) { J& x = d.set(k); x = body[k]; }
        d.set("exit") = body["mullvad_exit_ip"]; d.set("ms").t = J::Num; d.set("ms").n = (double)ms;
        d.set("time").t = J::Num; d.set("time").n = (double)time(nullptr); d.set("route").t = J::Str; d.set("route").s = gRouteNow;
        bool listed = false; for (auto& b : body["blacklisted"]["results"].a) if (b["blacklisted"].truthy()) listed = true;
        d.set("listed").t = J::Bool; d.set("listed").b = listed;
        if (gRouteLog.t != J::Arr) gRouteLog.t = J::Arr;
        gRouteLog.a.push_back(d); if (gRouteLog.a.size() > 200) gRouteLog.a.erase(gRouteLog.a.begin());
        writeStore(gData + L"\\route.log", dump(gRouteLog), "route");
        probeDone(dump(d)); return S_OK; }));
      return S_OK; }), &tok);
    go(); return S_OK; }));
}
static void armProbeTimer() {
  int mins = gSettings["mask"]["check"].num(0);
  if (mins > 0) SetTimer(gWnd, 7, (UINT)mins * 60000, nullptr); else KillTimer(gWnd, 7);
}
static void maskReply(Tile* T, const char* t, int id, const std::string& data) { toTile(T, std::string("{\"t\":\"") + t + "\",\"id\":" + std::to_string(id) + ",\"data\":" + data + "}"); }

// ------------------------------------------------------------------------------------------- splitting and closing tiles
static void createFace(Tile* T);
static Tile* newTile() {
  Tile* T = new Tile(); T->id = gNextTile++;
  T->host = CreateWindowExW(0, L"MeowzerHost", L"", WS_CHILD | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, 0, 0, 10, 10, gWnd, nullptr, GetModuleHandleW(nullptr), nullptr);
  gTiles.push_back(T); return T;
}
// the window buttons are pressed in the top-right tile, which takes the focus with that click; they mean the tile
// that had it just before
static int lastSelected(Tile* from) {
  if (from && from->id == gFocus && GetTickCount64() - gFocusAt < 900 && tileById(gPrevFocus)) return gPrevFocus;
  return focused() ? focused()->id : 0;
}
static void splitTile(int id) {
  Tile* F = tileById(id); Node* leaf = leafOf(gRoot, id); if (!F || !leaf || gFull) return;
  RECT r = leaf->rc; int w = r.right - r.left, h = r.bottom - r.top;
  if (std::max(w, h) < px(300)) return;   // too small to halve
  Tile* N = newTile();
  leaf->a = new Node(); leaf->a->tile = F->id; leaf->a->up = leaf;
  leaf->b = new Node(); leaf->b->tile = N->id; leaf->b->up = leaf;
  leaf->tile = 0; leaf->vert = w >= h; leaf->r = .5;   // across the longest side
  N->cur = leaf->vert ? RECT{r.right, r.top, r.right, r.bottom} : RECT{r.left, r.bottom, r.right, r.bottom};   // slides in from the far edge
  gPrevFocus = gFocus; gFocus = N->id; gFocusAt = 0;
  retile(false); N->zoom = N->zoomTo;
  createFace(N); createTab("meowzer://newtab", nullptr, true, N->id);
}
static void closeTile(int id) {
  if (gTiles.size() < 2) return;
  Tile* T = tileById(id); Node* leaf = leafOf(gRoot, id); if (!T || !leaf || !leaf->up) return;
  if (gFull && gFullTile == id) setFullscreen(false, 0);
  Node* up = leaf->up; Node* sib = up->a == leaf ? up->b : up->a;
  up->tile = sib->tile; up->vert = sib->vert; up->r = sib->r; up->a = sib->a; up->b = sib->b;   // the sibling takes the parent's place
  if (up->a) { up->a->up = up; up->b->up = up; }
  delete leaf; delete sib;
  std::vector<Tab*> mine; for (auto t : gTabs) if (t->tile == id) mine.push_back(t);
  for (auto t : mine) { gTabs.erase(std::find(gTabs.begin(), gTabs.end(), t)); if (t->ctl) { t->ctl->Close(); t->ctl->Release(); } if (t->wv) t->wv->Release(); delete t; }
  if (T->ctl) { T->ctl->Close(); T->ctl->Release(); } if (T->ui) T->ui->Release();
  DestroyWindow(T->host); gTiles.erase(std::find(gTiles.begin(), gTiles.end(), T)); delete T;
  int next = tileById(gPrevFocus) ? gPrevFocus : firstTile(up);
  gFocus = next; gPrevFocus = 0; gFocusAt = 0;
  retile(false); pushState(focused()); sweepSoon();
  if (Tab* a = active()) if (a->ctl) a->ctl->MoveFocus(COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC);
}

// dragging the gaps between tiles. Where dividers meet, all of them move together.
static std::vector<Node*> gGrab;
static bool inR(const RECT& r, POINT p, int m) { return p.x >= r.left - m && p.x < r.right + m && p.y >= r.top - m && p.y < r.bottom + m; }
static std::vector<Node*> grabAt(POINT p) {
  std::vector<Node*> out; bool hit = false; int m = px(10);
  eachSplit(gRoot, [&](Node* n) { if (inR(divider(n), p, 1)) hit = true; });
  if (hit) eachSplit(gRoot, [&](Node* n) { if (inR(divider(n), p, m)) out.push_back(n); });
  return out;
}
static int grabKind(const std::vector<Node*>& g) { int k = 0; for (auto n : g) k |= n->vert ? 1 : 2; return k; }
static void dragTo(POINT p) {
  int G = gapPx(), minPx = px(140);
  for (Node* n : gGrab) {
    RECT rc = n->rc; int span = n->vert ? rc.right - rc.left - G : rc.bottom - rc.top - G; if (span <= 2 * minPx) continue;
    int at = (n->vert ? p.x - rc.left : p.y - rc.top) - G / 2;
    n->r = std::min(1.0 - (double)minPx / span, std::max((double)minPx / span, (double)at / span));
  }
  retile(true);
}

// ------------------------------------------------------------------------------------------- what a face may ask
static void onUi(Tile* T, const J& m) {
  const std::string& t = m["t"].s; Tab* a = activeIn(T);
  Tab* tt = m["tab"].t == J::Num ? tabById(m["tab"].num()) : a;
  if (tt && !tt->wv) tt = nullptr;
  if (t == "nav" && tt) tt->wv->Navigate(w16(fixUrl(m["url"].s)).c_str());
  else if (t == "back" && tt) tt->wv->GoBack();
  else if (t == "fwd" && tt) tt->wv->GoForward();
  else if (t == "reload" && tt) { if (tt->ghost) tt->wv->Navigate(w16(tt->ghostOf).c_str()); else tt->wv->Reload(); }   // a ghost tries the real page again
  else if (t == "stop" && tt) tt->wv->Stop();
  else if (t == "newtab") createTab(m["url"].s.rfind("http", 0) == 0 ? m["url"].s : "meowzer://newtab", nullptr, true, T ? T->id : 0);
  else if (t == "win") {   // the face's own window buttons and title-bar stretch
    const std::string& w = m["a"].s; POINT p; GetCursorPos(&p);
    if (w == "min") ShowWindow(gWnd, SW_MINIMIZE);
    else if (w == "max") ShowWindow(gWnd, IsZoomed(gWnd) ? SW_RESTORE : SW_MAXIMIZE);
    else if (w == "close") PostMessageW(gWnd, WM_CLOSE, 0, 0);
    else if (w == "split") splitTile(lastSelected(T));
    else if (w == "unsplit") closeTile(lastSelected(T));
    else if (w == "drag" && !gFull) { ReleaseCapture(); PostMessageW(gWnd, WM_NCLBUTTONDOWN, HTCAPTION, MAKELPARAM(p.x, p.y)); }
    else if (w == "menu") {
      HMENU sm = GetSystemMenu(gWnd, FALSE); bool z = IsZoomed(gWnd);
      EnableMenuItem(sm, SC_RESTORE, z ? MF_ENABLED : MF_GRAYED); EnableMenuItem(sm, SC_MAXIMIZE, z ? MF_GRAYED : MF_ENABLED);
      EnableMenuItem(sm, SC_MOVE, z ? MF_GRAYED : MF_ENABLED); EnableMenuItem(sm, SC_SIZE, z ? MF_GRAYED : MF_ENABLED);
      int cmd = TrackPopupMenu(sm, TPM_RETURNCMD | TPM_RIGHTBUTTON, p.x, p.y, 0, gWnd, nullptr);
      if (cmd) PostMessageW(gWnd, WM_SYSCOMMAND, cmd, 0);
    }
  }
  else if (t == "shelf") {
    gShelfOpen = m["open"].truthy();
    RECT rc; GetClientRect(gWnd, &rc);
    toShelf("{\"t\":\"width\",\"w\":" + std::to_string(MulDiv(rc.right, 96, dpiOf(gWnd))) + "}");
    SetTimer(gWnd, 3, 12, nullptr);
  }
  else if (t == "shelfSave") writeStore(gData + L"\\shelf.json", dump(m["shelf"]), "shelf");
  else if (t == "shelfFocus") { if (gShelfCtl) gShelfCtl->MoveFocus(COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC); }
  else if (!T) return;   // the rest only come from a face
  else if (t == "close") closeTab(m["tab"].num());
  else if (t == "select") selectTab(m["tab"].num());
  else if (t == "chrome") { int h = m["h"].num(78); if (m["part"].s == "top" && h > 0) T->cssH = h; layout(); }
  else if (t == "bars") { T->barsAway = m["away"].truthy(); T->game = m["game"].truthy(); layout(); }
  else if (t == "overlay") {
    bool on = m["open"].truthy(); int tid = T->id;
    if (on && !T->overlay && a && a->wv && a->ctl) {   // sibling windows can't be see-through, so the panel gets a picture of the page behind it
      IStream* st = SHCreateMemStream(nullptr, 0);
      a->wv->CapturePreview(COREWEBVIEW2_CAPTURE_PREVIEW_IMAGE_FORMAT_JPEG, st, new Cb1<ICoreWebView2CapturePreviewCompletedHandler>([st, tid](HRESULT hr) {
        Tile* T = tileById(tid);
        if (SUCCEEDED(hr) && T) {
          STATSTG ss; st->Stat(&ss, STATFLAG_NONAME); std::string bytes((size_t)ss.cbSize.QuadPart, 0);
          LARGE_INTEGER z{}; st->Seek(z, STREAM_SEEK_SET, nullptr); ULONG rd; st->Read(bytes.data(), (ULONG)bytes.size(), &rd);
          DWORD n = 0; CryptBinaryToStringA((BYTE*)bytes.data(), (DWORD)bytes.size(), CRYPT_STRING_BASE64 | CRYPT_STRING_NOCRLF, nullptr, &n);
          std::string b64(n, 0); CryptBinaryToStringA((BYTE*)bytes.data(), (DWORD)bytes.size(), CRYPT_STRING_BASE64 | CRYPT_STRING_NOCRLF, b64.data(), &n); b64.resize(n);
          int top = (T->barsAway || gFull) ? 0 : T->cssH;
          toTile(T, "{\"t\":\"backdrop\",\"top\":" + std::to_string(top) + ",\"url\":\"data:image/jpeg;base64," + b64 + "\"}");
        }
        st->Release(); if (T) { T->overlay = true; layout(); } return S_OK; }));
      return;
    }
    if (!on) toTile(T, "{\"t\":\"backdrop\",\"url\":\"\"}");
    T->overlay = on; layout();
  }
  else if (t == "core") { std::string out = runCore(m["script"].s); toTile(T, "{\"t\":\"core\",\"id\":" + std::to_string(m["id"].num()) + ",\"out\":" + q(out) + "}"); }
  else if (t == "cookies") sendCookies(T, m["id"].num());
  else if (t == "history") sendHistory(T, m["id"].num(), m["q"].s);
  else if (t == "historyDel") { for (auto it = gHist.begin(); it != gHist.end(); ++it) if (it->url == m["url"].s) { gHist.erase(it); break; } historySoon(); }
  else if (t == "historyClear") { gHist.clear(); historySoon(); }
  else if (t == "downloads") sendDownloads(T, m["id"].num());
  else if (t == "dlAct") dlAct(m["a"].s, m["id"].num());
  else if (t == "cookieDel") { J c = m["cookie"]; withCookies([c](ICoreWebView2CookieManager* mg, std::vector<CK>& cs) { for (auto& k : cs) if (k.name == c["name"].s && k.domain == c["domain"].s && k.path == c["path"].s) mg->DeleteCookie(k.c); }); }
  else if (t == "cookieSet") { J c = m["cookie"]; withCookies([c](ICoreWebView2CookieManager* mg, std::vector<CK>& cs) {
      for (auto& k : cs) if (k.name == c["name"].s && k.domain == c["domain"].s && k.path == c["path"].s) {
        k.c->put_Value(w16(c["value"].s).c_str()); k.c->put_Expires(c["session"].truthy() ? -1 : c["expires"].n); mg->AddOrUpdateCookie(k.c); } }); }
  else if (t == "burnSite") { std::string site = m["site"].s; for (auto it = gJar.o.begin(); it != gJar.o.end(); ++it) if (it->first == site) { gJar.o.erase(it); break; }
    saveJar(); reinjectAll(); for (auto o : gTiles) if (o != T) toTile(o, "{\"t\":\"jar\",\"jar\":" + dump(gJar) + "}");
    withCookies([site](ICoreWebView2CookieManager* mg, std::vector<CK>& cs) { for (auto& k : cs) if (siteOf(k.domain) == site) mg->DeleteCookie(k.c); });
    clearOrigin("https://" + site); clearOrigin("https://www." + site); }
  else if (t == "burnAll") { gSettings.set("_burnAll").b = true; withCookies([](ICoreWebView2CookieManager* mg, std::vector<CK>& cs) { for (auto& k : cs) if (gJar[siteOf(k.domain)].t != J::Obj) mg->DeleteCookie(k.c); }); }
  else if (t == "jar") { gJar = m["jar"]; if (gJar.t != J::Obj) gJar.t = J::Obj; saveJar(); reinjectAll(); sweepSoon();
    for (auto o : gTiles) if (o != T) toTile(o, "{\"t\":\"jar\",\"jar\":" + dump(gJar) + "}"); }
  else if (t == "jarChanged") { /* the face sends the whole jar right after */ }
  else if (t == "settings") {
    std::string oldSeal = dump(gSettings["mask"]["seal"]), oldCheck = dump(gSettings["mask"]["check"]), oldTheme = dump(gSettings["themeVars"]) + gSettings["theme"].s;
    std::string rua = gSettings["_realUA"].s; gSettings = m["settings"]; if (gSettings.t != J::Obj) gSettings.t = J::Obj; gSettings.set("_realUA").s = rua; saveSettings(); sweepSoon();
    if (!historyOn() && !gHist.empty()) { gHist.clear(); historySoon(); }   // turning history off forgets it
    std::string pub = publicSettings(); for (auto o : gTiles) if (o != T) toTile(o, "{\"t\":\"settings\",\"settings\":" + pub + "}");
    if (dump(gSettings["themeVars"]) + gSettings["theme"].s != oldTheme) { toShelfTheme(); InvalidateRect(gWnd, nullptr, TRUE); InvalidateRect(gPageHost, nullptr, TRUE); }
    if (dump(gSettings["mask"]["seal"]) != oldSeal) resealAll(false);
    if (dump(gSettings["mask"]["check"]) != oldCheck) armProbeTimer(); }
  else if (t == "net") {   // Windows lost or found the connection; found again, ghost tabs try their real pages
    gOffline = !m["online"].truthy();
    if (!gOffline) for (auto x : gTabs) if (x->ghost && x->wv) x->wv->Navigate(w16(x->ghostOf).c_str()); }
  else if (t == "probe") probeRoute(T, m["id"].num());
  else if (t == "tor") { int id = m["id"].num(), tid = T->id; std::thread([id, tid] { int p = torPortNow();
      postJson("{\"t\":\"tor\",\"id\":" + std::to_string(id) + ",\"data\":{\"port\":" + std::to_string(p) + "}}", tid); }).detach(); }
  else if (t == "route") {   // what the engine uses now, and what the settings ask for; apply restarts Meowzer onto it
    std::string want = routeProxy(); if (want.empty()) want = "direct";
    if (m["apply"].truthy() && want != gRouteNow) { maskReply(T, "route", m["id"].num(), "{\"restarting\":true}"); restartForRoute(); return; }
    maskReply(T, "route", m["id"].num(), "{\"now\":" + q(gRouteNow) + ",\"want\":" + q(want) + ",\"valid\":" + (validProxy(m["proxy"].s) ? "true" : "false") + "}"); }
  else if (t == "seal") {
    const std::string& op = m["op"].s; int id = m["id"].num();
    if (op == "rekey") resealAll(true);
    if (op == "sample") {   // seal something live (the route's latest answer) the same way the stores are sealed, and show it
      std::string text = m["text"].s.substr(0, 4096); int rounds = sealRounds(); ULONGLONG t0 = GetTickCount64();
      std::string b = sealBytes(text, rounds, sealKey()); long long ms = (long long)(GetTickCount64() - t0);
      bool bad; std::string back = openBytes(b, sealKey(), &bad);
      maskReply(T, "seal", id, "{\"hex\":" + q(hexOf(b.substr(54, 96))) + ",\"nonce\":" + q(b.size() > 22 ? hexOf(b.substr(10, 12)) : "") + ",\"tag\":" + q(b.size() > 54 ? hexOf(b.substr(22, 8)) : "") +
        ",\"bytes\":" + std::to_string(text.size()) + ",\"rounds\":" + std::to_string(rounds) + ",\"ms\":" + std::to_string(ms) + ",\"opens\":" + (!bad && back == text ? "true" : "false") + "}");
      return; }
    maskReply(T, "seal", id, sealStatus()); }
  else if (t == "costume") { gCostume = m["persona"]; reinjectAll(); }
  else if (t == "lists") { gSettings.set("customRules").s = m["custom"].s; J& lu = gSettings.set("listUrls"); lu = m["urls"]; saveSettings(); fetchLists(); }
}

static void onKey(UINT vk, bool ctrl, bool alt, bool shift) {
  Tile* T = focused(); Tab* a = activeIn(T); if (!T) return;
  std::vector<Tab*> mine; for (auto t : gTabs) if (t->tile == T->id) mine.push_back(t);
  if (ctrl && vk == 'T') createTab("meowzer://newtab", nullptr, true, T->id);
  else if (ctrl && vk == 'W' && a) closeTab(a->id);
  else if (ctrl && vk == 'L') { if (T->barsAway) { T->barsAway = false; layout(); } if (T->ctl) T->ctl->MoveFocus(COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC); if (T->ui) T->ui->ExecuteScript(L"document.getElementById('url')&&document.getElementById('url').focus()", nullptr); }
  else if (ctrl && (vk == 'H' || vk == 'J')) { toTile(T, std::string("{\"t\":\"open\",\"panel\":\"") + (vk == 'H' ? "history" : "downloads") + "\"}"); if (T->ctl) T->ctl->MoveFocus(COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC); }
  else if (ctrl && vk == VK_TAB && mine.size() > 1 && a) { size_t i = std::find(mine.begin(), mine.end(), a) - mine.begin(); i = shift ? (i + mine.size() - 1) % mine.size() : (i + 1) % mine.size(); selectTab(mine[i]->id); }
  else if (alt && vk == VK_LEFT && a && a->wv) a->wv->GoBack();
  else if (alt && vk == VK_RIGHT && a && a->wv) a->wv->GoForward();
  else if (vk == VK_F5 && a && a->wv) { if (a->ghost) a->wv->Navigate(w16(a->ghostOf).c_str()); else a->wv->Reload(); }
  else if (ctrl && vk == 'D') toShelf("{\"t\":\"add\"}");
  else if (vk == VK_F9) toTile(T, "{\"t\":\"bars\",\"show\":true}");
  else if (vk == VK_F11) setFullscreen(!gFull, T->id);
}

// ------------------------------------------------------------------------------------------- a tile's face
static const COREWEBVIEW2_COLOR kFaceBg{255, 0x11, 0x1b, 0x18};
static void createFace(Tile* T) {
  int tid = T->id;
  gEnv->CreateCoreWebView2Controller(T->host, cb<ICoreWebView2CreateCoreWebView2ControllerCompletedHandler, HRESULT, ICoreWebView2Controller*>([tid](HRESULT hr, ICoreWebView2Controller* c) {
    if (FAILED(hr) || !c) { if (gTiles.size() <= 1) MessageBoxW(gWnd, L"WebView2 could not start.", L"Meowzer", MB_ICONERROR); return S_OK; }
    Tile* T = tileById(tid); if (!T) { c->Close(); return S_OK; }
    T->ctl = c; c->AddRef(); c->get_CoreWebView2(&T->ui);
    ICoreWebView2Controller2* c2; if (SUCCEEDED(c->QueryInterface(IID_PPV_ARGS(&c2)))) { c2->put_DefaultBackgroundColor(kFaceBg); c2->Release(); }
    ICoreWebView2Settings* st; T->ui->get_Settings(&st);
    st->put_AreDefaultContextMenusEnabled(FALSE); st->put_IsStatusBarEnabled(FALSE); st->put_IsZoomControlEnabled(FALSE);
#ifndef MEOW_DEBUG
    st->put_AreDevToolsEnabled(FALSE);
#endif
    st->Release();
    ICoreWebView2_3* w3; if (SUCCEEDED(T->ui->QueryInterface(IID_PPV_ARGS(&w3)))) { w3->SetVirtualHostNameToFolderMapping(L"meowzer.ui", (gExeDir + L"\\ui").c_str(), COREWEBVIEW2_HOST_RESOURCE_ACCESS_KIND_DENY_CORS); w3->Release(); }
    EventRegistrationToken tok;
    T->ui->add_WebMessageReceived(EV(ICoreWebView2WebMessageReceivedEventHandler, ICoreWebView2WebMessageReceivedEventArgs)([tid](ICoreWebView2*, ICoreWebView2WebMessageReceivedEventArgs* a) {
      LPWSTR src; a->get_Source(&src); std::string s = takeStr(src);
      if (s.rfind("https://meowzer.ui/", 0) != 0) return S_OK;          // only the face may steer the browser
      LPWSTR js; if (FAILED(a->get_WebMessageAsJson(&js))) return S_OK;
      Tile* T = tileById(tid); if (T) onUi(T, parse(takeStr(js))); return S_OK; }), &tok);
    T->ui->add_NavigationStarting(EV(ICoreWebView2NavigationStartingEventHandler, ICoreWebView2NavigationStartingEventArgs)([tid](ICoreWebView2*, ICoreWebView2NavigationStartingEventArgs* a) {
      LPWSTR u; a->get_Uri(&u); std::string url = takeStr(u);
      if (url.rfind("https://meowzer.ui/", 0) != 0) { a->put_Cancel(TRUE); createTab(url, nullptr, true, tid); }   // links never open inside the face
      return S_OK; }), &tok);
    T->ui->add_NavigationCompleted(EV(ICoreWebView2NavigationCompletedEventHandler, ICoreWebView2NavigationCompletedEventArgs)([tid](ICoreWebView2*, ICoreWebView2NavigationCompletedEventArgs*) {
      if (Tile* T = tileById(tid)) { T->ready = true; sendInit(T); } return S_OK; }), &tok);
    c->add_GotFocus(cb<ICoreWebView2FocusChangedEventHandler, ICoreWebView2Controller*, IUnknown*>([tid](ICoreWebView2Controller*, IUnknown*) { focusTile(tid); return S_OK; }), &tok);
    c->add_AcceleratorKeyPressed(cb<ICoreWebView2AcceleratorKeyPressedEventHandler, ICoreWebView2Controller*, ICoreWebView2AcceleratorKeyPressedEventArgs*>([](ICoreWebView2Controller*, ICoreWebView2AcceleratorKeyPressedEventArgs* a) {
      COREWEBVIEW2_KEY_EVENT_KIND k; a->get_KeyEventKind(&k); if (k != COREWEBVIEW2_KEY_EVENT_KIND_KEY_DOWN && k != COREWEBVIEW2_KEY_EVENT_KIND_SYSTEM_KEY_DOWN) return S_OK;
      UINT vk; a->get_VirtualKey(&vk); bool ctrl = GetKeyState(VK_CONTROL) < 0, alt = GetKeyState(VK_MENU) < 0;
      if ((ctrl && (vk == VK_TAB || vk == 'D')) || (alt && (vk == VK_LEFT || vk == VK_RIGHT)) || vk == VK_F5 || vk == VK_F11) { a->put_Handled(TRUE); onKey(vk, ctrl, alt, GetKeyState(VK_SHIFT) < 0); }
      return S_OK; }), &tok);
    T->ui->Navigate(L"https://meowzer.ui/meowzer-ui.html");
    T->zoomSet = 0; layout(); return S_OK; }));
}

static void createShelf() {
  gEnv->CreateCoreWebView2Controller(gShelfHost, cb<ICoreWebView2CreateCoreWebView2ControllerCompletedHandler, HRESULT, ICoreWebView2Controller*>([](HRESULT hr, ICoreWebView2Controller* c) {
    if (FAILED(hr) || !c) return S_OK;
    gShelfCtl = c; c->AddRef(); c->get_CoreWebView2(&gShelf);
    ICoreWebView2Controller2* c2; if (SUCCEEDED(c->QueryInterface(IID_PPV_ARGS(&c2)))) { c2->put_DefaultBackgroundColor(kFaceBg); c2->Release(); }
    ICoreWebView2Settings* st; gShelf->get_Settings(&st);
    st->put_AreDefaultContextMenusEnabled(FALSE); st->put_IsStatusBarEnabled(FALSE); st->put_IsZoomControlEnabled(FALSE);
#ifndef MEOW_DEBUG
    st->put_AreDevToolsEnabled(FALSE);
#endif
    st->Release();
    ICoreWebView2_3* w3; if (SUCCEEDED(gShelf->QueryInterface(IID_PPV_ARGS(&w3)))) { w3->SetVirtualHostNameToFolderMapping(L"meowzer.ui", (gExeDir + L"\\ui").c_str(), COREWEBVIEW2_HOST_RESOURCE_ACCESS_KIND_DENY_CORS); w3->Release(); }
    EventRegistrationToken tok;
    gShelf->add_WebMessageReceived(EV(ICoreWebView2WebMessageReceivedEventHandler, ICoreWebView2WebMessageReceivedEventArgs)([](ICoreWebView2*, ICoreWebView2WebMessageReceivedEventArgs* a) {
      LPWSTR src; a->get_Source(&src); if (takeStr(src).rfind("https://meowzer.ui/", 0) != 0) return S_OK;
      LPWSTR js; if (FAILED(a->get_WebMessageAsJson(&js))) return S_OK;
      J m = parse(takeStr(js)); const std::string& t = m["t"].s;
      // the shelf may only open pages (in the tile last used) and look after itself
      if (t == "nav" || t == "newtab") { J n = m; n.set("tab") = J(); onUi(focused(), n); }
      else if (t == "shelf" || t == "shelfSave" || t == "shelfFocus") onUi(nullptr, m);
      return S_OK; }), &tok);
    gShelf->add_NavigationStarting(EV(ICoreWebView2NavigationStartingEventHandler, ICoreWebView2NavigationStartingEventArgs)([](ICoreWebView2*, ICoreWebView2NavigationStartingEventArgs* a) {
      LPWSTR u; a->get_Uri(&u); std::string url = takeStr(u);
      if (url.rfind("https://meowzer.ui/", 0) != 0) { a->put_Cancel(TRUE); if (Tab* t = active()) if (t->wv) t->wv->Navigate(w16(url).c_str()); }
      return S_OK; }), &tok);
    gShelf->add_NavigationCompleted(EV(ICoreWebView2NavigationCompletedEventHandler, ICoreWebView2NavigationCompletedEventArgs)([](ICoreWebView2*, ICoreWebView2NavigationCompletedEventArgs*) {
      gShelfReady = true;
      std::string shelf = readStore(gData + L"\\shelf.json"); if (parse(shelf).t != J::Obj) shelf = "{}";
      toShelf("{\"t\":\"init\",\"theme\":" + q(gSettings["theme"].s.empty() ? "dark" : gSettings["theme"].s) + ",\"vars\":" + dump(gSettings["themeVars"]) + ",\"shelf\":" + shelf + "}");
      pushState(focused()); layout(); return S_OK; }), &tok);
    c->add_AcceleratorKeyPressed(cb<ICoreWebView2AcceleratorKeyPressedEventHandler, ICoreWebView2Controller*, ICoreWebView2AcceleratorKeyPressedEventArgs*>([](ICoreWebView2Controller*, ICoreWebView2AcceleratorKeyPressedEventArgs* a) {
      COREWEBVIEW2_KEY_EVENT_KIND k; a->get_KeyEventKind(&k); if (k != COREWEBVIEW2_KEY_EVENT_KIND_KEY_DOWN && k != COREWEBVIEW2_KEY_EVENT_KIND_SYSTEM_KEY_DOWN) return S_OK;
      UINT vk; a->get_VirtualKey(&vk); bool ctrl = GetKeyState(VK_CONTROL) < 0;
      if ((ctrl && (vk == 'T' || vk == 'W' || vk == 'L' || vk == 'H' || vk == 'J' || vk == VK_TAB)) || vk == VK_F5 || vk == VK_F11) { a->put_Handled(TRUE); onKey(vk, ctrl, GetKeyState(VK_MENU) < 0, GetKeyState(VK_SHIFT) < 0); }
      return S_OK; }), &tok);
    gShelf->Navigate(L"https://meowzer.ui/meowzer-shelf.html");
    return S_OK; }));
}

// =============================================================================================== window
static LRESULT CALLBACK wndProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
  switch (msg) {
    case WM_SIZE: {
      if (gShelfOpen && gShelfW) { gShelfW = LOWORD(lp); toShelf("{\"t\":\"width\",\"w\":" + std::to_string(MulDiv(LOWORD(lp), 96, dpiOf(h))) + "}"); }
      if (gEnv) retile(true); return 0; }
    // no system title bar: the tab row draws it. Keep the side and bottom frame (resizing, snapping, shadow); drop the top.
    case WM_NCCALCSIZE: if (wp && !gFull) {
      NCCALCSIZE_PARAMS* p = (NCCALCSIZE_PARAMS*)lp; RECT before = p->rgrc[0];
      DefWindowProcW(h, msg, wp, lp);
      // maximised windows hang their frame off the screen; inset the top by the same amount as the bottom
      p->rgrc[0].top = before.top + (IsZoomed(h) ? before.bottom - p->rgrc[0].bottom : 0);
      return 0; } break;
    case WM_NCHITTEST: {
      LRESULT r = DefWindowProcW(h, msg, wp, lp);
      if (r == HTCLIENT && !IsZoomed(h) && !gFull) {
        POINT p{(short)LOWORD(lp), (short)HIWORD(lp)}; ScreenToClient(h, &p); RECT rc; GetClientRect(h, &rc);
        if (p.y < grip()) return p.x < px(12) ? HTTOPLEFT : p.x > rc.right - px(12) ? HTTOPRIGHT : HTTOP;
      }
      return r; }
    case WM_ERASEBKGND: {   // the thin resize strip above the tabs, in the face's colour
      RECT rc; GetClientRect(h, &rc);
      HBRUSH b = CreateSolidBrush(themeColor("surface", RGB(0x11, 0x1b, 0x18), RGB(0xf4, 0xf8, 0xf6))); FillRect((HDC)wp, &rc, b); DeleteObject(b); return 1; }
    case WM_MOVE:
      for (auto T : gTiles) if (T->ctl) T->ctl->NotifyParentWindowPositionChanged();
      for (auto t : gTabs) if (t->ctl) t->ctl->NotifyParentWindowPositionChanged();
      if (gShelfCtl) gShelfCtl->NotifyParentWindowPositionChanged();
      return 0;
    case WM_TIMER:
      if (wp == 1) { sweep(); static int beat; if (gStatDirty && ++beat % 8 == 0) saveStats(); }   // the stats reach the disk every half-minute
      if (wp == 2) { KillTimer(h, 2); gSweepQueued = false; sweep(); }
      if (wp == 3) shelfStep();
      if (wp == 4) animStep();
      if (wp == 5) { KillTimer(h, 5); if (gHistDirty) saveHistory(); }
      if (wp == 6) { if (gProbe) gProbe->Stop(); probeDone("{\"ok\":false,\"error\":\"the route took too long to answer\"}"); }
      if (wp == 7) { probeRoute(nullptr, 0); armProbeTimer(); }
      return 0;
    case WM_APP + 2: { std::string* s = (std::string*)wp; if (lp) toTile(tileById((int)lp), *s); else toUi(*s); delete s; return 0; }
    case WM_APP + 1: compileTable(); reinjectAll(); toUi("{\"t\":\"table\",\"stats\":" + q(gTableStats) + "}"); return 0;
    case WM_GETMINMAXINFO: ((MINMAXINFO*)lp)->ptMinTrackSize = {420, 320}; return 0;
    case WM_CLOSE: {   // leaving: everything still in the oven burns
      saveStats(); if (gHistDirty) saveHistory(); storesFlush();
      for (auto t : gTabs) t->site.clear();
      sweep(); DestroyWindow(h); return 0; }
    case WM_DESTROY: PostQuitMessage(0); return 0;
  }
  return DefWindowProcW(h, msg, wp, lp);
}
static LRESULT CALLBACK hostProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) { return DefWindowProcW(h, msg, wp, lp); }
// the window under every tile: its gaps are the dividers, and it rings the tile last used
static LRESULT CALLBACK pageProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
  switch (msg) {
    case WM_ERASEBKGND: {
      RECT rc; GetClientRect(h, &rc); HDC dc = (HDC)wp; bool light = lightTheme();
      HBRUSH b = CreateSolidBrush(light ? themeColor("border", 0, RGB(0xc9, 0xd8, 0xd2)) : themeColor("canvas", RGB(0x0b, 0x12, 0x10), 0)); FillRect(dc, &rc, b); DeleteObject(b);
      Tile* F = focused();
      if (gTiles.size() > 1 && !gFull && F) {
        RECT r = F->cur; int w = std::max(2, px(2));
        RECT s[4] = {{r.left - w, r.top - w, r.right + w, r.top}, {r.left - w, r.bottom, r.right + w, r.bottom + w}, {r.left - w, r.top, r.left, r.bottom}, {r.right, r.top, r.right + w, r.bottom}};
        HBRUSH a = CreateSolidBrush(themeColor("accent", RGB(0xff, 0x8c, 0x42), RGB(0xe8, 0x69, 0x0f)));
        for (auto& x : s) FillRect(dc, &x, a); DeleteObject(a);
      }
      return 1; }
    case WM_SETCURSOR: if (LOWORD(lp) == HTCLIENT) {
      POINT p; GetCursorPos(&p); ScreenToClient(h, &p);
      int k = grabKind(gGrab.empty() ? grabAt(p) : gGrab);
      if (k) { SetCursor(LoadCursor(nullptr, k == 3 ? IDC_SIZEALL : k == 1 ? IDC_SIZEWE : IDC_SIZENS)); return TRUE; }
    } break;
    case WM_LBUTTONDOWN: { POINT p{(short)LOWORD(lp), (short)HIWORD(lp)}; gGrab = grabAt(p); if (!gGrab.empty()) { SetCapture(h); KillTimer(gWnd, 4); } return 0; }
    case WM_MOUSEMOVE: if (!gGrab.empty()) { POINT p{(short)LOWORD(lp), (short)HIWORD(lp)}; dragTo(p); } return 0;
    case WM_LBUTTONUP: if (!gGrab.empty()) { gGrab.clear(); ReleaseCapture(); } return 0;
    case WM_CAPTURECHANGED: gGrab.clear(); return 0;
  }
  return DefWindowProcW(h, msg, wp, lp);
}

typedef HRESULT(STDAPICALLTYPE* CreateEnvFn)(PCWSTR, PCWSTR, ICoreWebView2EnvironmentOptions*, ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler*);
typedef HRESULT(STDAPICALLTYPE* VersionFn)(PCWSTR, LPWSTR*);

int WINAPI wWinMain(HINSTANCE inst, HINSTANCE, LPWSTR cmdLine, int show) {
  { typedef BOOL(WINAPI* Dpi)(HANDLE); auto f = (Dpi)GetProcAddress(GetModuleHandleW(L"user32.dll"), "SetProcessDpiAwarenessContext"); if (f) f((HANDLE)-4); }
  CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
  wchar_t path[MAX_PATH]; GetModuleFileNameW(nullptr, path, MAX_PATH); PathRemoveFileSpecW(path); gExeDir = path;
  PWSTR la; SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, nullptr, &la); gData = std::wstring(la) + L"\\Meowzer4"; CoTaskMemFree(la);
  { wchar_t d[MAX_PATH]; DWORD n = GetEnvironmentVariableW(L"MEOWZER_DATA", d, MAX_PATH); if (n && n < MAX_PATH) gData = d; }   // a separate profile, for tests
  CreateDirectoryW(gData.c_str(), nullptr); CreateDirectoryW((gData + L"\\lists").c_str(), nullptr);
  gSettings = parse(readFile(gData + L"\\settings.json")); if (gSettings.t != J::Obj) gSettings.t = J::Obj;
  gJar = parse(readStore(gData + L"\\jar.json")); if (gJar.t != J::Obj) gJar.t = J::Obj;
  loadStats(); if (historyOn()) loadHistory();
  gRouteLog = parse(readStore(gData + L"\\route.log")); if (gRouteLog.t != J::Arr) gRouteLog.t = J::Arr;
  gInject = readFile(gExeDir + L"\\ui\\inject.js");
  compileTable();
  applyRouteArgs();

  WNDCLASSW wc{}; wc.lpfnWndProc = wndProc; wc.hInstance = inst; wc.lpszClassName = L"Meowzer4"; wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
  wc.hIcon = LoadIconW(inst, MAKEINTRESOURCEW(1)); wc.hbrBackground = CreateSolidBrush(RGB(0x0b, 0x12, 0x10)); RegisterClassW(&wc);
  WNDCLASSW hc{}; hc.lpfnWndProc = hostProc; hc.hInstance = inst; hc.lpszClassName = L"MeowzerHost"; hc.hbrBackground = wc.hbrBackground; RegisterClassW(&hc);
  WNDCLASSW pc{}; pc.lpfnWndProc = pageProc; pc.hInstance = inst; pc.lpszClassName = L"MeowzerPages"; pc.hCursor = LoadCursor(nullptr, IDC_ARROW); RegisterClassW(&pc);
  gWnd = CreateWindowExW(0, L"Meowzer4", L"Meowzer", WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN, CW_USEDEFAULT, CW_USEDEFAULT, 1280, 860, nullptr, nullptr, inst, nullptr);
  gPageHost = CreateWindowExW(0, L"MeowzerPages", L"", WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, 0, 0, 10, 10, gWnd, nullptr, inst, nullptr);
  gShelfHost = CreateWindowExW(0, L"MeowzerHost", L"", WS_CHILD | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, 0, 0, 10, 10, gWnd, nullptr, inst, nullptr);
  Tile* first = newTile(); gRoot = new Node(); gRoot->tile = first->id; gFocus = first->id;
  SetWindowPos(gWnd, nullptr, 0, 0, 0, 0, SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER);   // apply the custom frame
  ShowWindow(gWnd, show); UpdateWindow(gWnd);

  HMODULE loader = LoadLibraryW((gExeDir + L"\\WebView2Loader.dll").c_str());
  auto create = loader ? (CreateEnvFn)GetProcAddress(loader, "CreateCoreWebView2EnvironmentWithOptions") : nullptr;
  auto ver = loader ? (VersionFn)GetProcAddress(loader, "GetAvailableCoreWebView2BrowserVersionString") : nullptr;
  if (!create) { MessageBoxW(gWnd, L"WebView2Loader.dll is missing next to Meowzer.exe.", L"Meowzer", MB_ICONERROR); return 1; }
  LPWSTR v = nullptr; if (ver && SUCCEEDED(ver(nullptr, &v)) && v) { gEngine = "WebView2 " + u8(v); CoTaskMemFree(v); }
  else { MessageBoxW(gWnd, L"Meowzer needs the WebView2 runtime, which comes with Windows 10 and 11.\nGet it from Microsoft: go.microsoft.com/fwlink/p/?LinkId=2124703", L"Meowzer", MB_ICONERROR); return 1; }
  std::string firstUrl = u8(cmdLine); while (!firstUrl.empty() && (firstUrl.back() == ' ' || firstUrl.back() == '"')) firstUrl.pop_back(); while (!firstUrl.empty() && firstUrl[0] == '"') firstUrl.erase(0, 1);
  // started again by the Mask onto a new route: wait for the old run to let go of the engine, then reopen its tabs
  std::vector<std::string> resume; bool resuming = firstUrl.rfind("--resume ", 0) == 0;
  if (resuming) {
    DWORD pid = (DWORD)strtoul(firstUrl.c_str() + 9, nullptr, 10); firstUrl.clear();
    if (HANDLE ph = OpenProcess(SYNCHRONIZE, FALSE, pid)) { WaitForSingleObject(ph, 15000); CloseHandle(ph); }
    J r = parse(readFile(gData + L"\\resume.json")); DeleteFileW((gData + L"\\resume.json").c_str());
    for (auto& u : r.a) if (u.s.rfind("http", 0) == 0) resume.push_back(u.s);
  }
  // the old run's engine processes can outlive it by a moment, holding the profile; try again for a few seconds
  static std::function<void(int)> start;
  start = [create, firstUrl, resume](int tries) {
    create(nullptr, (gData + L"\\engine").c_str(), nullptr, cb<ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler, HRESULT, ICoreWebView2Environment*>([firstUrl, resume, tries](HRESULT hr, ICoreWebView2Environment* env) {
      if (FAILED(hr)) { if (tries < 12) { Sleep(500); start(tries + 1); } else MessageBoxW(gWnd, L"WebView2 could not start.", L"Meowzer", MB_ICONERROR); return S_OK; }
      gEnv = env; env->AddRef();
      retile(true);
      createFace(focused()); createShelf();
      if (resume.empty()) createTab(firstUrl.empty() ? "meowzer://newtab" : (firstUrl.find("://") == std::string::npos ? "https://" + firstUrl : firstUrl), nullptr, true, gFocus);
      for (size_t i = 0; i < resume.size(); i++) createTab(resume[i], nullptr, i == 0, gFocus);
      SetTimer(gWnd, 1, 4000, nullptr);
      armProbeTimer(); if (gSettings["mask"]["routeOn"].truthy()) SetTimer(gWnd, 7, 3000, nullptr);   // a fresh route gets checked soon after it starts
      return S_OK; }));
  };
  start(resuming ? 0 : 10);
  MSG msg; while (GetMessageW(&msg, nullptr, 0, 0)) { TranslateMessage(&msg); DispatchMessageW(&msg); }
  CoUninitialize(); return 0;
}
