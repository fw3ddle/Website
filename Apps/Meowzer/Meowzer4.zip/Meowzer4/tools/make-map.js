// make-map.js — turns Natural Earth's 1:110m countries (world-atlas countries-110m.json, public domain) into
// ui/worldmap.js: one SVG path per country, already projected, so Meowzer never fetches a map.
//   node tools/make-map.js <countries-110m.json>
const fs = require('fs'), path = require('path');
const topo = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const [sx, sy] = topo.transform.scale, [tx, ty] = topo.transform.translate;
// arcs are delta-encoded, quantized positions
const arcs = topo.arcs.map(a => { let x = 0, y = 0; return a.map(([dx, dy]) => { x += dx; y += dy; return [x * sx + tx, y * sy + ty]; }); });
const W = 1000, TOP = 84, BOT = -57;                       // equirectangular, without Antarctica
const H = Math.round(W / 360 * (TOP - BOT));
const proj = ([lon, lat]) => [((lon + 180) / 360 * W), ((TOP - lat) / (TOP - BOT) * H)];
const ring = idx => { const pts = []; idx.forEach(i => { const a = i < 0 ? arcs[~i].slice().reverse() : arcs[i]; (pts.length ? a.slice(1) : a).forEach(p => pts.push(p)); }); return pts; };
const out = [];
for (const g of topo.objects.countries.geometries) {
  if (!g.arcs || g.id === '010') continue;                 // Antarctica
  const polys = g.type === 'Polygon' ? [g.arcs] : g.arcs;
  let d = '', best = null, bestA = -1;
  for (const poly of polys) for (const [k, r] of poly.entries()) {
    const pts = ring(r).map(proj); let prev = null, s = '', off = 0, lastX = null;
    // a ring that crosses the 180° line (Russia, Fiji) would draw a line across the whole map; carry on past the
    // edge instead, where the view clips it
    for (const [x0, y] of pts) {
      if (lastX !== null) { if (x0 - lastX > W / 2) off -= W; else if (lastX - x0 > W / 2) off += W; }
      lastX = x0; const x = x0 + off;
      const q = x.toFixed(1) + ' ' + y.toFixed(1); if (q === prev) continue; s += (s ? 'L' : 'M') + q; prev = q; }
    d += s + 'Z';
    if (k === 0) { let a = 0; for (let i = 0; i < pts.length; i++) { const [x1, y1] = pts[i], [x2, y2] = pts[(i + 1) % pts.length]; a += x1 * y2 - x2 * y1; }
      a = Math.abs(a); if (a > bestA) { bestA = a; best = pts; } }
  }
  // a label point: the middle of the biggest piece's box
  const xs = best.map(p => p[0]), ys = best.map(p => p[1]);
  out.push([g.id || '', g.properties.name, d, Math.round((Math.min(...xs) + Math.max(...xs)) / 2), Math.round((Math.min(...ys) + Math.max(...ys)) / 2)]);
}
out.sort((a, b) => a[1].localeCompare(b[1]));
const js = '// worldmap.js — made by tools/make-map.js from Natural Earth 1:110m (public domain). [iso numeric, name, path, label x, label y]\n' +
  'window.WORLD={w:' + W + ',h:' + H + ',c:' + JSON.stringify(out) + '};\n';
fs.writeFileSync(path.join(__dirname, '..', 'ui', 'worldmap.js'), js);
console.log(out.length + ' countries, ' + js.length + ' bytes, ' + W + 'x' + H);
