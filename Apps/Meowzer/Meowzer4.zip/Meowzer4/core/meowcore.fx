// meowcore.fx — Meowzer's brain, written in ꟻX (Forge 0.28 "Omni").
//
// The page engine (WebView2 / WebKit / GeckoView) draws pages. Every decision about what a page may do is made
// here: which hosts the cat hisses at, which query parameters get licked off, what happens to a cookie, how a
// saved cookie is decorated, and which made-up machine a site gets to see.
//
// ꟻX programs talk through standard input and output, and a compiled program flushes its output when it ends.
// So the hosts run meowcore in batches: they write a script of commands, read the answers, and the process ends.
// Per-request work is never a round trip: `@table` compiles the filter lists into a flat table of 64-bit FNV-1a
// hashes once, and the host looks hashes up in memory (the hash is defined below and nowhere else).
//
// Commands, one per line:
//   @table ... @end            filter rules in between; prints the table (see `rule`)
//   @hash TEXT                 prints the FNV-1a 64 hash of TEXT, lowercased (hosts self-test against it)
//   @verdict MODE JAR 3P TRK   cookie verdict: K keep, S session (burn when the site is left), B burn now
//   @decorate SEED BITS        a decoration for a jarred cookie; BITS are its site settings
//   @persona SEED FAMILY       a coherent made-up device (FAMILY 0 win, 1 mac, 2 linux, 3 android, 4 ios, 9 any)
//   @site HOST                 the site (registrable domain) of HOST, by a small public-suffix table
//   @sweep ... @end            what to do with every cookie the engine holds (see `sweep`)
//   @chacha R KEY NONCE ... @end   ChaCha-R keystream XOR over hex lines (the seal on what Meowzer stores)

const LINE = 8192;
let ln: [u8; 8192];
let n = 0;

// ---------------------------------------------------------------------------------------------- reading lines
fn readline() -> int {
    n = 0;
    let c = getc();
    if c < 0 { give -1; }
    while c >= 0 && c != '\n' {
        if c != '\r' && n < LINE { ln[n] = c; n++; }
        c = getc();
    }
    if n >= 3 && ln[0] == 0xEF && ln[1] == 0xBB && ln[2] == 0xBF {   // a byte-order mark: drop it
        repeat i in 3..n { ln[i - 3] = ln[i]; }
        n -= 3;
    }
    give n;
}

fn lower(c) -> int {
    if c >= 'A' && c <= 'Z' { give c + 32; }
    give c;
}

// ---------------------------------------------------------------------------------------------- writing
let dig: [u8; 24];
fn putnum(v) -> int {
    if v < 0 { putc('-'); v = 0 - v; }
    let k = 0;
    if v == 0 { putc('0'); give 0; }
    while v > 0 { dig[k] = '0' + v % 10; v = v / 10; k++; }
    while k > 0 { k--; putc(dig[k]); }
    give 0;
}

fn puthex(h) -> int {
    repeat i in 0..16 {
        let d = (h >> (60 - 4 * i)) & 15;
        if d < 10 { putc('0' + d); } else { putc('a' + d - 10); }
    }
    give 0;
}

// ---------------------------------------------------------------------------------------------- the hash
// FNV-1a, 64 bits, over the lowercased bytes ln[a..b). Every host implements exactly this.
fn hash(a, b) -> int {
    let h = 0xcbf2_9ce4_8422_2325;
    let i = a;
    while i < b { h = (h ^ lower(ln[i])) *% 0x100_0000_01b3; i++; }
    give h;
}

// ---------------------------------------------------------------------------------------------- numbers in a line
let at = 0;
fn skipsp() -> int { while at < n && ln[at] == ' ' { at++; } give at; }
fn num() -> int {
    skipsp();
    let neg = 0;
    if at < n && ln[at] == '-' { neg = 1; at++; }
    let v = 0;
    while at < n && ln[at] >= '0' && ln[at] <= '9' && v < 100_000_000_000_000 { v = v * 10 + ln[at] - '0'; at++; }
    if neg == 1 { give 0 - v; }
    give v;
}

// ---------------------------------------------------------------------------------------------- keywords
// One text, many words: KW[off .. off+len).
const KW = "third-party~third-partyremoveparam=domain=@table@end@hash@verdict@decorate@persona@site3p@sweep@chacha";
const K_3P = 0;      const L_3P = 11;
const K_N3P = 11;    const L_N3P = 12;
const K_RP = 23;     const L_RP = 12;
const K_DOM = 35;    const L_DOM = 7;
const K_TABLE = 42;  const L_TABLE = 6;
const K_END = 48;    const L_END = 4;
const K_HASH = 52;   const L_HASH = 5;
const K_VERD = 57;   const L_VERD = 8;
const K_DECO = 65;   const L_DECO = 9;
const K_PERS = 74;   const L_PERS = 8;
const K_SITE = 82;   const L_SITE = 5;
const K_3PS = 87;    const L_3PS = 2;
const K_SWEEP = 89;  const L_SWEEP = 6;
const K_CHA = 95;    const L_CHA = 7;

fn word(pos, off, len) -> int {
    if pos + len > n { give 0; }
    repeat i in 0..len { if lower(ln[pos + i]) != KW[off + i] { give 0; } }
    give 1;
}
// is the word somewhere in ln[a..b)?
fn findw(a, b, off, len) -> int {
    let i = a;
    while i + len <= b { if word(i, off, len) == 1 { give i; } i++; }
    give -1;
}

// ---------------------------------------------------------------------------------------------- the filter compiler
// Output lines:  b HASH  block this host and its subdomains, first or third party
//                t HASH  block it only when it is loaded by another site
//                a HASH  never block it (exceptions win)
//                p HASH  remove this query parameter from every address
//                c HASH SELECTOR   hide SELECTOR on pages of that site (HASH 0: everywhere)
let nb = 0; let nt = 0; let na = 0; let np = 0; let nc = 0; let nskip = 0; let nrules = 0;

fn hostch(c) -> int {
    if c >= 'a' && c <= 'z' { give 1; }
    if c >= 'A' && c <= 'Z' { give 1; }
    if c >= '0' && c <= '9' { give 1; }
    if c == '.' || c == '-' || c == '_' { give 1; }
    give 0;
}

// ln[a..] holds a host; returns its end, or -1 if it is not a plain host (wildcards, paths we don't do).
fn hostend(a) -> int {
    let i = a;
    while i < n && hostch(ln[i]) == 1 { i++; }
    if i == a { give -1; }
    if i < n && ln[i] != '^' && ln[i] != '$' && ln[i] != '|' && ln[i] != ' ' && ln[i] != '/' { give -1; }
    if i < n && ln[i] == '/' && i + 1 < n { give -1; }
    if ln[a] == '.' || ln[i - 1] == '.' { give -1; }
    give i;
}

fn emit(kind, h) -> int { putc(kind); putc(' '); puthex(h); putc('\n'); give 0; }

fn rule() -> int {
    if n == 0 { give 0; }
    if ln[0] == '!' || ln[0] == '[' || ln[0] == '#' && (n < 2 || ln[1] != '#') { give 0; }
    nrules++;
    // cosmetic: [domain]##selector
    let i = 0;
    while i + 1 < n && !(ln[i] == '#' && ln[i + 1] == '#') { i++; }
    if i + 1 < n {
        if i + 2 >= n || ln[i + 2] == '+' || ln[i + 2] == '^' { nskip++; give 0; }
        let dh = 0;
        if i > 0 {
            let j = 0;
            while j < i && ln[j] != ',' { j++; }
            if j < i || ln[0] == '~' { nskip++; give 0; }   // several or negated domains: not yet
            dh = hash(0, i);
        }
        putc('c'); putc(' '); puthex(dh); putc(' ');
        repeat k in i + 2..n { putc(ln[k]); }
        putc('\n'); nc++;
        give 0;
    }
    let allow = 0;
    let s = 0;
    if n >= 2 && ln[0] == '@' && ln[1] == '@' { allow = 1; s = 2; }
    // options
    let dollar = -1;
    repeat w in s..n { if ln[w] == '$' { dollar = w; } }
    let oend = n;
    if dollar < 0 { dollar = n; }
    if findw(dollar, oend, K_DOM, L_DOM) >= 0 { nskip++; give 0; }
    let rp = findw(dollar, oend, K_RP, L_RP);
    if rp >= 0 && dollar == s {
        // $removeparam=name with no host: a global parameter rule
        let a = rp + L_RP;
        let b = a;
        while b < n && ln[b] != ',' && ln[b] != '|' { b++; }
        if b > a && ln[a] != '/' && allow == 0 { emit('p', hash(a, b)); np++; give 0; }
        nskip++; give 0;
    }
    if rp >= 0 { nskip++; give 0; }
    let third = 0;
    if findw(dollar, oend, K_3PS, L_3PS) >= 0 { third = 1; }
    if findw(dollar, oend, K_3P, L_3P) >= 0 && findw(dollar, oend, K_N3P, L_N3P) < 0 { third = 1; }
    // ||host^
    if s + 2 <= n && ln[s] == '|' && ln[s + 1] == '|' {
        let e1 = hostend(s + 2);
        if e1 < 0 { nskip++; give 0; }
        let h = hash(s + 2, e1);
        if allow == 1 { emit('a', h); na++; give 0; }
        if third == 1 { emit('t', h); nt++; } else { emit('b', h); nb++; }
        give 0;
    }
    // hosts file: 0.0.0.0 host / 127.0.0.1 host
    if allow == 0 && ln[0] >= '0' && ln[0] <= '9' {
        let q = 0;
        while q < n && ln[q] != ' ' && ln[q] != '\t' { q++; }
        while q < n && (ln[q] == ' ' || ln[q] == '\t') { q++; }
        if q < n {
            let e2 = hostend(q);
            if e2 > 0 && e2 == n || e2 > 0 && ln[e2] == ' ' {
                if !(e2 - q == 9 && ln[q] == 'l' && ln[q + 1] == 'o') { emit('b', hash(q, e2)); nb++; give 0; }
            }
        }
        nskip++; give 0;
    }
    // a bare host
    if allow == 0 && dollar == n {
        let e3 = hostend(0);
        if e3 == n {
            let dots = 0;
            repeat r in 0..n { if ln[r] == '.' { dots++; } }
            if dots > 0 { emit('b', hash(0, n)); nb++; give 0; }
        }
    }
    nskip++;
    give 0;
}

fn table() -> int {
    while readline() >= 0 {
        if word(0, K_END, L_END) == 1 { break; }
        rule();
    }
    puts("# rules "); putnum(nrules);
    puts(" block "); putnum(nb);
    puts(" third "); putnum(nt);
    puts(" allow "); putnum(na);
    puts(" params "); putnum(np);
    puts(" cosmetic "); putnum(nc);
    puts(" skipped "); putnum(nskip);
    putc('\n');
    give 0;
}

// ---------------------------------------------------------------------------------------------- cookies
// MODE: the site's oven heat. 0 raw (a normal browser), 1 warm, 2 bake (default), 3 scorch (no cookies at all).
// JAR: the user pulled this site's cookie into the jar.  3P: set by another site.  TRK: the host is in the table.
fn verdict(mode, jar, third, trk) -> int {
    if mode >= 3 { give 'B'; }
    if trk == 1 && !(mode == 0 && jar == 1) { give 'B'; }
    if jar == 1 {
        if third == 0 { give 'K'; }
        if mode == 0 { give 'K'; }
        give 'B';
    }
    if third == 1 && mode >= 1 { give 'B'; }
    if mode == 0 { give 'K'; }
    give 'S';
}

// ---------------------------------------------------------------------------------------------- decorating
// BITS (from the host, one site's settings):
//   0-2 lifetime (0 session, 1 day, 2 week, 3 month, 4 year, 5 forever)   3-4 heat mode
//   5 third-party allowed   6 spoofing on   7 scripts off   8-9 blocker (0 off, 1 normal, 2 strict)
//   10 referrer trimmed     11 storage kept
// The settings decide what the decoration MEANS (icing = lifetime, paw stamp = spoofing, chips = third party,
// crust = heat, cracks = strict blocker); the dice decide how it looks (shape wobble, sprinkles, name).
fluct die = 500 +- 500;

fn roll(k) -> int { give die % k; }

fn decorate(sd, bits) -> int {
    seed(sd);
    let life = bits & 7;
    let heat = (bits >> 3) & 3;
    let shape = roll(6);                 // round, scalloped, heart, fish, paw, star
    let wob = roll(5);
    let icing = life;                    // the colour of the icing tells how long it lasts
    let swirl = roll(4);
    let sprinkles = 6 + roll(18);
    let palette = roll(8);
    let stamp = (bits >> 6) & 1;         // a paw print: this site sees a made-up machine
    let chips = 0;
    if ((bits >> 5) & 1) == 1 { chips = 3 + roll(6); }
    let crust = heat;
    let cracks = 0;
    if ((bits >> 8) & 3) == 2 { cracks = 1 + roll(3); }
    let nm1 = roll(24);
    let nm2 = roll(24);
    puts("deco");
    each emitn(shape, wob, icing, swirl, sprinkles, palette, stamp, chips, crust, cracks, nm1, nm2);
    putc(' ');
    // sprinkle positions: polar, radius 0..99, angle 0..359, colour 0..5
    repeat k in 0..sprinkles {
        putnum(roll(100)); putc(','); putnum(roll(360)); putc(','); putnum(roll(6));
        if k + 1 < sprinkles { putc(';'); }
    }
    putc('\n');
    give 0;
}

fn emitn(v) -> int { putc(' '); putnum(v); give 0; }

// ---------------------------------------------------------------------------------------------- personas
// A made-up machine has to hang together: a Mac does not report an NVIDIA card and 6 cores, a phone has a
// phone-sized screen and touch points. Each field is an index into a table the hosts share (ui/personas.js),
// chosen only among values that are common for that family, so a persona blends in rather than standing out.
fn pick(k) -> int { give die % k; }
const CW = [4, 6, 8, 8, 12, 16];  const MW = [8, 8, 16, 16, 32];  const DW = [100, 100, 125, 150];
const CM = [8, 8, 10, 12];        const MM = [8, 16, 16, 24, 32];
const CL = [4, 8, 8, 12, 16];     const ML = [8, 16, 16, 32];     const GL = [0, 1, 5, 6];
const TZL = [0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8];
const MA = [4, 6, 8, 8, 12];      const DA = [275, 300, 350, 263];

fn persona(sd, fam) -> int {
    seed(sd);
    if fam == 8 {                        // any desktop: a costume that fits a desktop-sized window
        let r8 = pick(100);
        fam = 0;
        if r8 >= 75 { fam = 1; }
        if r8 >= 93 { fam = 2; }
    }
    if fam == 7 {                        // any phone
        fam = 3;
        if pick(100) >= 70 { fam = 4; }
    }
    if fam < 0 || fam > 4 {
        let r = pick(100);               // roughly what the web sees
        fam = 0;
        if r >= 62 { fam = 3; }
        if r >= 62 && r < 70 { fam = 1; }
        if r >= 70 && r < 73 { fam = 2; }
        if r >= 90 { fam = 4; }
    }
    let cores = 8; let mem = 8; let gpu = 0; let screen = 0; let dpr = 100; let touch = 0;
    let osv = 0; let arch = 0; let bits = 64; let conn = 0;
    if fam == 0 {
        cores = CW[pick(6)];
        mem = MW[pick(5)];
        gpu = pick(8);                    // 0-7: Intel UHD/Iris Xe, NVIDIA GTX/RTX, AMD Radeon
        screen = pick(6);                 // 0-5: 1366x768 .. 2560x1440
        dpr = DW[pick(4)];
        osv = pick(2);                    // Windows 10 / 11 (both report 10.0 in the UA)
    }
    if fam == 1 {
        cores = CM[pick(4)];
        mem = MM[pick(5)];
        gpu = 8 + pick(4);                // 8-11: Apple M1 .. M4
        screen = 6 + pick(4);             // 6-9: 1440x900 .. 1728x1117
        dpr = 200;
        osv = pick(4);
        arch = 1;
    }
    if fam == 2 {
        cores = CL[pick(5)];
        mem = ML[pick(4)];
        gpu = GL[pick(4)];   // Mesa Intel or AMD
        screen = 2 + pick(4);
        osv = 0;
    }
    if fam == 3 {
        cores = 8;
        mem = MA[pick(5)];
        gpu = 12 + pick(4);               // 12-15: Adreno, Mali, Xclipse, PowerVR
        screen = 10 + pick(5);            // 10-14: 360x800 .. 412x915
        dpr = DA[pick(4)];
        touch = 5;
        osv = pick(4);                    // Android 12 .. 15
        arch = 1;
        conn = 1 + pick(2);
    }
    if fam == 4 {
        cores = 6;
        mem = 4 + pick(2) * 2;
        gpu = 16;                         // Apple GPU
        screen = 15 + pick(4);            // 15-18: 375x812 .. 430x932
        dpr = 300;
        touch = 5;
        osv = pick(3);                    // iOS 17 / 18 / 19
        arch = 1;
        conn = 1 + pick(2);
    }
    let tz = pick(12);                    // index into personas.js time zones
    let lang = TZL[tz];                  // the language follows the clock, with English as a common second
    if pick(5) == 0 { lang = 0; }
    let rtt = 25 + pick(8) * 25;
    let down = 10 + pick(10) * 10;
    let battery = 30 + pick(70);
    let charging = pick(2);
    let noise = pick(1000) * 1000 + pick(1000);          // canvas / audio noise seed
    // the extras a fingerprinter also collects, kept plausible for the family
    let fonts = pick(64) * 64 + pick(64);             // which of the family's optional fonts are "installed" (bit mask)
    let cams = 1; let mics = 1; let spk = 1 + pick(2);
    if fam == 0 || fam == 2 { cams = pick(3); if cams > 1 { cams = 1; } mics = 1 + pick(2); }
    if fam >= 3 { cams = 2 + pick(2); mics = 1 + pick(3); spk = 1; }
    let quota = 0;                        // index into personas.js disk sizes
    if fam <= 2 { quota = 2 + pick(4); } else { quota = pick(4); }
    let scheme = 0; if pick(10) < 4 { scheme = 1; }          // 1: prefers dark
    let motion = 0; if pick(20) == 0 { motion = 1; }          // 1: prefers reduced motion
    let glat = pick(1001) - 500;          // geolocation jitter around the time zone's city, 1/1000 degree
    let glon = pick(1001) - 500;
    let bar = 0;                          // taskbar / menu bar height the screen loses
    if fam == 0 { bar = 40 + pick(2) * 8; }
    if fam == 1 { bar = 25 + pick(2) * 8; }
    if fam == 2 { bar = 27 + pick(3) * 5; }
    let depth = 24; if fam == 1 || fam == 4 { depth = 30; }
    let batt = 1;                         // has a battery at all (desktops do not)
    if fam == 0 || fam == 2 { batt = pick(2); }
    let tex = 16384; if fam >= 3 { tex = 8192 - (pick(2) * 4096); if fam == 4 { tex = 16384; } }
    let voices = pick(3);                 // 0 few, 1 some, 2 many speech voices
    puts("persona");
    each emitn(fam, cores, mem, gpu, screen, dpr, touch, osv, arch, bits, conn, tz, lang, rtt, down, battery, charging, noise);
    each emitn(fonts, cams, mics, spk, quota, scheme, motion, glat, glon, bar, depth, batt, tex, voices);
    putc('\n');
    give 0;
}

// ---------------------------------------------------------------------------------------------- sites
// The registrable domain: the last two labels, or three under the second-level suffixes in SFX.
const SFX = "|co.uk|org.uk|ac.uk|gov.uk|co.jp|ne.jp|or.jp|com.au|net.au|org.au|co.nz|com.br|com.mx|co.in|co.za|com.tr|com.cn|com.tw|co.kr|github.io|blogspot.com|herokuapp.com|vercel.app|netlify.app|pages.dev|";

fn issuffix(a, b) -> int {
    // is ln[a..b) one of SFX's entries?
    let w = b - a;
    let i = 0;
    while i + w + 1 < len(SFX) {
        if SFX[i] == '|' && SFX[i + w + 1] == '|' {
            let ok = 1;
            repeat k in 0..w { if lower(ln[a + k]) != SFX[i + 1 + k] { ok = 0; } }
            if ok == 1 { give 1; }
        }
        i++;
    }
    give 0;
}

fn site(a, b) -> int {
    // returns the start of the site in ln[a..b)
    let d1 = -1; let d2 = -1; let d3 = -1;
    let i = b - 1;
    while i >= a {
        if ln[i] == '.' {
            if d1 < 0 { d1 = i; } else if d2 < 0 { d2 = i; } else if d3 < 0 { d3 = i; }
        }
        i--;
    }
    if d1 < 0 { give a; }
    if d2 < 0 { give a; }
    if issuffix(d2 + 1, b) == 1 { if d3 < 0 { give a; } give d3 + 1; }
    give d2 + 1;
}

// ---------------------------------------------------------------------------------------------- the sweep
// Every few seconds a host lists every cookie the engine holds and asks what to do with each:
//   @sweep
//   H MODE               the heat for sites that are not in the jar (default 2, bake)
//   J MODE SITE          a site in the jar, with its own heat
//   O ALLOW3P SITE       a site open in some tab; ALLOW3P 1 if its jar settings let third parties keep cookies
//   C I TRK DOMAIN       cookie number I, set for DOMAIN; TRK 1 if the domain is in the blocker table
//   @end
// Answers: one `v I K|S|B` per cookie (K keep, S leave it for now, B burn it), then `# kept .. spared .. burnt ..`.
// A cookie belongs to the site of its domain. Cookies of jarred sites follow that site's heat. Cookies of other
// sites live only while their site is open in a tab (that is the oven), unless an open site lets third parties
// keep cookies; trackers burn at any heat but raw-in-the-jar.
const HT = 8192;
let hk: [int; 8192];
let hv: [int; 8192];
let hu: [u8; 8192];
let hcount = 0;

fn slot(h) -> int {
    let i = h & (HT - 1);
    while hu[i] == 1 && hk[i] != h { i = (i + 1) & (HT - 1); }
    give i;
}
// value bits: 0-2 jar heat + 1 (0 = not in the jar), 3 open, 4 open and allows third parties
fn hor(h, v) -> int {
    let i = slot(h);
    if hu[i] == 0 {
        if hcount >= HT / 2 { give 0; }
        hu[i] = 1; hk[i] = h; hv[i] = 0; hcount++;
    }
    hv[i] = hv[i] | v;
    give 0;
}
fn hget(h) -> int {
    let i = slot(h);
    if hu[i] == 0 { give 0; }
    give hv[i];
}

// the site hash of ln[a..n), a leading dot ignored
fn sitehash(a) -> int {
    while a < n && ln[a] == '.' { a++; }
    give hash(site(a, n), n);
}

fn sweep() -> int {
    let heat = 2;
    let any3p = 0;
    let kept = 0; let spared = 0; let burnt = 0;
    while readline() >= 0 {
        if word(0, K_END, L_END) == 1 { break; }
        if n < 3 { continue; }
        let op = ln[0];
        at = 1;
        if op == 'H' { heat = clamp(num(), 0, 3); continue; }
        if op == 'J' { let m = clamp(num(), 0, 3); skipsp(); hor(sitehash(at), m + 1); continue; }
        if op == 'O' {
            let al = num(); skipsp();
            if al == 1 { any3p = 1; hor(sitehash(at), 24); } else { hor(sitehash(at), 8); }
            continue;
        }
        if op == 'C' {
            let id = num(); let trk = num(); skipsp();
            let v = hget(sitehash(at));
            let jar = v & 7;
            let r = 'B';
            if jar > 0 {
                r = verdict(jar - 1, 1, 0, trk);
            } else if (v & 8) != 0 {
                r = verdict(heat, 0, 0, trk);
            } else if any3p == 1 && trk == 0 {
                r = 'S';
            } else {
                r = verdict(heat, 0, 1, trk);
            }
            if r == 'K' { kept++; } else if r == 'S' { spared++; } else { burnt++; }
            puts("v "); putnum(id); putc(' '); putc(r); putc('\n');
        }
    }
    puts("# kept "); putnum(kept); puts(" spared "); putnum(spared); puts(" burnt "); putnum(burnt); putc('\n');
    give 0;
}

// ---------------------------------------------------------------------------------------------- the seal: ChaCha
// @chacha ROUNDS KEYHEX NONCEHEX, then lines of hex bytes, then @end. Each line comes back as "x HEX": its bytes
// XORed with the ChaCha keystream (RFC 8439 layout: 256-bit key, 96-bit nonce, 32-bit block counter from 1). The
// stream runs on across lines, and the same key and nonce turn the output back into the input. ROUNDS is 8, 12 or
// 20 (ChaCha20 is the standard; 12 and 8 are its faster, thinner-margin siblings).
const M32 = 0xFFFF_FFFF;
let cs: [int; 16];
let cx: [int; 16];
let ckey: [int; 8];
let cnon: [int; 3];
let ck: [u8; 64];
let ctr = 1; let cpos = 64; let crounds = 20;

fn hexv(c) -> int {
    if c >= '0' && c <= '9' { give c - '0'; }
    if c >= 'a' && c <= 'f' { give c - 'a' + 10; }
    if c >= 'A' && c <= 'F' { give c - 'A' + 10; }
    give 0;
}
// the little-endian 32-bit word in the 8 hex digits at ln[p..p+8)
fn le32(p) -> int {
    let v = 0;
    repeat i in 0..4 { v = v | ((hexv(ln[p + 2 * i]) * 16 + hexv(ln[p + 2 * i + 1])) << (8 * i)); }
    give v;
}
fn rotl(x, k) -> int { give ((x << k) & M32) | (x >> (32 - k)); }
fn qr(a, b, c, d) -> int {
    cx[a] = (cx[a] + cx[b]) & M32; cx[d] = rotl(cx[d] ^ cx[a], 16);
    cx[c] = (cx[c] + cx[d]) & M32; cx[b] = rotl(cx[b] ^ cx[c], 12);
    cx[a] = (cx[a] + cx[b]) & M32; cx[d] = rotl(cx[d] ^ cx[a], 8);
    cx[c] = (cx[c] + cx[d]) & M32; cx[b] = rotl(cx[b] ^ cx[c], 7);
    give 0;
}
fn chablock() -> int {
    cs[0] = 0x6170_7865; cs[1] = 0x3320_646e; cs[2] = 0x7962_2d32; cs[3] = 0x6b20_6574;   // "expand 32-byte k"
    repeat ki in 0..8 { cs[4 + ki] = ckey[ki]; }
    cs[12] = ctr & M32; cs[13] = cnon[0]; cs[14] = cnon[1]; cs[15] = cnon[2];
    repeat si in 0..16 { cx[si] = cs[si]; }
    let r = 0;
    while r < crounds {
        qr(0, 4, 8, 12); qr(1, 5, 9, 13); qr(2, 6, 10, 14); qr(3, 7, 11, 15);
        qr(0, 5, 10, 15); qr(1, 6, 11, 12); qr(2, 7, 8, 13); qr(3, 4, 9, 14);
        r += 2;
    }
    repeat i in 0..16 {
        let w = (cx[i] + cs[i]) & M32;
        repeat j in 0..4 { ck[4 * i + j] = (w >> (8 * j)) & 255; }
    }
    ctr++; cpos = 0;
    give 0;
}
fn hex2(b) -> int {
    let hi = (b >> 4) & 15; let lo = b & 15;
    if hi < 10 { putc('0' + hi); } else { putc('a' + hi - 10); }
    if lo < 10 { putc('0' + lo); } else { putc('a' + lo - 10); }
    give 0;
}
fn chacha() -> int {
    at = L_CHA; crounds = num();
    if crounds != 8 && crounds != 12 { crounds = 20; }
    let p = skipsp(); let ok = 1;
    if p + 64 > n { ok = 0; }
    if ok == 1 { repeat ki in 0..8 { ckey[ki] = le32(p + 8 * ki); } at = p + 64; p = skipsp(); }
    if ok == 1 && p + 24 > n { ok = 0; }
    if ok == 1 { repeat ni in 0..3 { cnon[ni] = le32(p + 8 * ni); } }
    ctr = 1; cpos = 64;
    while readline() >= 0 {
        if word(0, K_END, L_END) == 1 { break; }
        if ok == 0 { continue; }
        putc('x'); putc(' ');
        let bi = 0;
        while bi + 1 < n {
            if cpos >= 64 { chablock(); }
            hex2((hexv(ln[bi]) * 16 + hexv(ln[bi + 1])) ^ ck[cpos]);
            cpos++; bi += 2;
        }
        putc('\n');
    }
    if ok == 0 { putc('!'); putc(' '); putc('k'); putc('e'); putc('y'); putc('\n'); }
    give 0;
}

// ---------------------------------------------------------------------------------------------- main
fn main() -> int {
    while readline() >= 0 {
        if n == 0 { continue; }
        if word(0, K_TABLE, L_TABLE) == 1 { table(); continue; }
        if word(0, K_SWEEP, L_SWEEP) == 1 { sweep(); continue; }
        if word(0, K_CHA, L_CHA) == 1 { chacha(); continue; }
        if word(0, K_HASH, L_HASH) == 1 {
            let a = L_HASH;
            while a < n && ln[a] == ' ' { a++; }
            puts("hash "); puthex(hash(a, n)); putc('\n');
            continue;
        }
        if word(0, K_VERD, L_VERD) == 1 {
            at = L_VERD;
            let m = num(); let j = num(); let t = num(); let k = num();
            putc(verdict(m, j, t, k)); putc('\n');
            continue;
        }
        if word(0, K_DECO, L_DECO) == 1 { at = L_DECO; let s = num(); let b = num(); decorate(s, b); continue; }
        if word(0, K_PERS, L_PERS) == 1 { at = L_PERS; let s2 = num(); let f = num(); persona(s2, f); continue; }
        if word(0, K_SITE, L_SITE) == 1 {
            let a2 = L_SITE;
            while a2 < n && ln[a2] == ' ' { a2++; }
            let st = site(a2, n);
            puts("site ");
            repeat k2 in st..n { putc(lower(ln[k2])); }
            puts(" "); puthex(hash(st, n)); putc('\n');
            continue;
        }
        puts("? unknown command\n");
    }
    give 0;
}
