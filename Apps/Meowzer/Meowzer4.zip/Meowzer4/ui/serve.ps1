# Local web server for Meowzer 4 UI preview. Required: browsers block 3D model loading from file://.
# Usage: powershell -ExecutionPolicy Bypass -File serve.ps1 [-Port 8680]
param([int]$Port = 8680)
$root = $PSScriptRoot
$types = @{ '.html' = 'text/html; charset=utf-8'; '.js' = 'text/javascript; charset=utf-8'; '.png' = 'image/png'; '.jpg' = 'image/jpeg'
  '.ogg' = 'audio/ogg'; '.wav' = 'audio/wav'; '.json' = 'application/json'; '.css' = 'text/css'; '.glb' = 'model/gltf-binary'; '.svg' = 'image/svg+xml'; '.webp' = 'image/webp' }
$http = [System.Net.HttpListener]::new()
$http.Prefixes.Add("http://localhost:$Port/")
$http.Start()
Write-Host "Meowzer UI running at http://localhost:$Port/  (Ctrl+C to stop)"
while ($http.IsListening) {
  $ctx = $http.GetContext()
  try {
    $rel = [Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath.TrimStart('/'))
    if (-not $rel) { $rel = 'meowzer-ui.html' }
    $path = [IO.Path]::GetFullPath((Join-Path $root $rel))
    if ($path.StartsWith($root) -and (Test-Path $path -PathType Leaf)) {
      $bytes = [IO.File]::ReadAllBytes($path)
      $ext = [IO.Path]::GetExtension($path).ToLower()
      $ctx.Response.ContentType = if ($types[$ext]) { $types[$ext] } else { 'application/octet-stream' }
      if ($ext -eq '.html' -or $ext -eq '.js') { $ctx.Response.Headers.Add('Cache-Control', 'no-cache') }
      $ctx.Response.ContentLength64 = $bytes.Length
      $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    } else { $ctx.Response.StatusCode = 404 }
  } catch { } finally { $ctx.Response.Close() }
}
