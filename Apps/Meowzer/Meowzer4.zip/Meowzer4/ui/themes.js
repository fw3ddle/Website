// themes.js — the theme studio behind the Meowzer logo (it isn't announced anywhere; the logo just opens it).
// Two pages: Static themes (a palette) and Dynamic ones (a palette that moves: drifting hues, a breathing tide,
// day following the clock, an aurora, a heartbeat). Each page generates themes from seeds, shows them as little
// browser thumbnails in a scrolling grid, and lets you pick, re-roll or delete them. Everything lives in
// S.settings.themes, so every tile and every new tab wears the same theme.
'use strict';
const THEME = (() => {
  const VARS = ['canvas', 'surface', 'surface2', 'border', 'fg', 'muted', 'accent', 'pink', 'good', 'bad', 'warn'];
  const NIGHT = { canvas: '#0b1210', surface: '#111b18', surface2: '#1a2824', border: '#2a3c36', fg: '#e8f1ee', muted: '#8aa39b', accent: '#ff8c42', pink: '#ff6fae', good: '#4fd8a6', bad: '#ff5a5f', warn: '#ffc04d' };
  const DAY = { canvas: '#ffffff', surface: '#f4f8f6', surface2: '#e6efeb', border: '#c9d8d2', fg: '#15211d', muted: '#5b6f68', accent: '#e8690f', pink: '#d63384', good: '#1b7a55', bad: '#c42b1c', warn: '#b7791f' };
  const BUILTIN = [{ id: 'b-night', name: 'Meowzer Night', mode: 'dark', v: NIGHT, builtin: 1 }, { id: 'b-day', name: 'Meowzer Day', mode: 'light', v: DAY, builtin: 1 }];
  const HARM = { triad: [0, 120, 240], split: [0, 150, 210], analog: [0, 32, -32], tetrad: [0, 90, 180], comp: [0, 180, 200], mono: [0, 14, -14] };
  const HARM_NAME = { any: 'Any harmony', triad: 'Triad', split: 'Split complement', analog: 'Analogous', tetrad: 'Square', comp: 'Complement', mono: 'One hue' };
  const KINDS = { drift: 'Drift — hues wander', tide: 'Tide — light breathes', daylight: 'Daylight — follows your clock', aurora: 'Aurora — colours trade places', pulse: 'Pulse — a slow heartbeat' };

  // ---------------------------------------------------------------- colour
  const hsl = (h, s, l) => { h = ((h % 360) + 360) % 360; s /= 100; l /= 100; const k = n => (n + h / 30) % 12, a = s * Math.min(l, 1 - l);
    const f = n => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1))); return '#' + [f(0), f(8), f(4)].map(v => Math.round(v * 255).toString(16).padStart(2, '0')).join(''); };
  const rgb = hex => [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16));
  const toHsl = hex => { const [r, g, b] = rgb(hex).map(v => v / 255), M = Math.max(r, g, b), m = Math.min(r, g, b); let h = 0, s = 0; const l = (M + m) / 2;
    if (M !== m) { const d = M - m; s = l > .5 ? d / (2 - M - m) : d / (M + m); h = M === r ? (g - b) / d + (g < b ? 6 : 0) : M === g ? (b - r) / d + 2 : (r - g) / d + 4; h *= 60; } return [h, s * 100, l * 100]; };
  const lum = hex => { const [r, g, b] = rgb(hex).map(v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }); return .2126 * r + .7152 * g + .0722 * b; };
  const contrast = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + .05) / (Math.min(x, y) + .05); };
  const mix = (a, b, t) => '#' + rgb(a).map((v, i) => Math.round(v + (rgb(b)[i] - v) * t).toString(16).padStart(2, '0')).join('');
  // nudge a colour's lightness until it reads against the background
  const legible = (c, bg, want) => { let [h, s, l] = toHsl(c); const dark = lum(bg) < .2; let n = 0; while (contrast(hsl(h, s, l), bg) < want && n++ < 40) l += dark ? 1.5 : -1.5; return hsl(h, s, l); };

  // ---------------------------------------------------------------- seeds and names
  const rngOf = seed => { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; };
  const newSeed = () => (crypto.getRandomValues(new Uint32Array(1))[0] >>> 0);
  const HUEWORD = [[15, 'Ember'], [35, 'Amber'], [55, 'Honey'], [80, 'Lime'], [120, 'Fern'], [155, 'Mint'], [180, 'Lagoon'], [200, 'Tide'], [220, 'Harbor'], [245, 'Dusk'], [270, 'Iris'], [295, 'Orchid'], [320, 'Rose'], [345, 'Coral'], [360, 'Ember']];
  const NOUN_D = ['Night', 'Hollow', 'Den', 'Deep', 'Velvet', 'Lantern', 'Midnight', 'Cellar', 'Burrow', 'Nebula'];
  const NOUN_L = ['Morning', 'Paper', 'Meadow', 'Linen', 'Porch', 'Daylight', 'Chalk', 'Window', 'Cloud', 'Sill'];
  const hueWord = h => HUEWORD.find(([x]) => h <= x)[1];

  // ---------------------------------------------------------------- the generator
  // opts: {harmony: 'any'|key of HARM, mode: 'any'|'dark'|'light'}; the same seed and opts always give the same theme
  function genStatic(seed, opts) {
    const R = rngOf(seed); opts = opts || {};
    const harmony = opts.harmony && opts.harmony !== 'any' ? opts.harmony : Object.keys(HARM)[Math.floor(R() * 6)];
    const mode = opts.mode === 'dark' || opts.mode === 'light' ? opts.mode : (R() < .7 ? 'dark' : 'light');
    const h0 = R() * 360, off = HARM[harmony], tintH = h0 + (R() < .5 ? 0 : off[1]) + (R() * 20 - 10), tintS = 8 + R() * 18;
    const v = {};
    if (mode === 'dark') {
      const L = 5 + R() * 4;
      v.canvas = hsl(tintH, tintS, L); v.surface = hsl(tintH, tintS, L + 3.5); v.surface2 = hsl(tintH, tintS, L + 8); v.border = hsl(tintH, tintS * .9, L + 17);
      v.fg = hsl(tintH, 12, 93); v.muted = hsl(tintH, 12, 63);
    } else {
      const L = 97 + R() * 2.5;
      v.canvas = hsl(tintH, tintS, Math.min(100, L + 1)); v.surface = hsl(tintH, tintS, L - 3); v.surface2 = hsl(tintH, tintS, L - 8); v.border = hsl(tintH, tintS * .9, L - 18);
      v.fg = hsl(tintH, 18, 11); v.muted = hsl(tintH, 12, 38);
    }
    const sat = 70 + R() * 25, lit = mode === 'dark' ? 60 + R() * 8 : 40 + R() * 7;
    v.accent = legible(hsl(h0 + off[0], sat, lit), v.surface, 3);
    v.pink = legible(hsl(h0 + off[1], sat - 5, lit + (mode === 'dark' ? 4 : -2)), v.surface, 3);
    v.good = legible(hsl(h0 + off[2], sat - 15, lit), v.surface, 3);
    v.bad = legible(hsl(355 + R() * 10, 75, mode === 'dark' ? 63 : 45), v.surface, 3);
    v.warn = legible(hsl(38 + R() * 10, 90, mode === 'dark' ? 62 : 42), v.surface, 2.5);
    v.muted = legible(v.muted, v.surface, 4);
    const name = hueWord(((h0 % 360) + 360) % 360) + ' ' + (mode === 'dark' ? NOUN_D : NOUN_L)[Math.floor(R() * 10)];
    return { id: 's' + seed.toString(36), seed, name, mode, harmony, opts: { harmony: opts.harmony || 'any', mode: opts.mode || 'any' }, v };
  }
  function genDynamic(seed, opts) {
    const R = rngOf(seed ^ 0x9E3779B9); opts = opts || {};
    const kind = opts.kind && opts.kind !== 'any' ? opts.kind : Object.keys(KINDS)[Math.floor(R() * 5)];
    const base = genStatic(seed, { harmony: opts.harmony || 'any', mode: kind === 'daylight' ? 'dark' : (opts.mode || 'any') });
    const d = { id: 'd' + seed.toString(36), seed, kind, name: base.name.split(' ')[0] + ' ' + { drift: 'Drift', tide: 'Tide', daylight: 'Sundial', aurora: 'Aurora', pulse: 'Pulse' }[kind],
      mode: base.mode, v: base.v, speed: 1, span: 40 + Math.round(R() * 80), opts: { kind: opts.kind || 'any' } };
    if (kind === 'daylight') d.day = genStatic(seed, { harmony: base.harmony, mode: 'light' }).v;
    return d;
  }

  // ---------------------------------------------------------------- applying
  const root = document.documentElement;
  const setVars = v => { VARS.forEach(k => root.style.setProperty('--' + k, v[k])); root.style.setProperty('--accent2', v.pink);
    root.style.setProperty('--grad', 'linear-gradient(90deg,' + v.accent + ',' + v.pink + ' 50%,' + v.good + ')'); };
  const clearVars = () => { VARS.concat(['accent2', 'grad']).forEach(k => root.style.removeProperty('--' + k)); };
  let raf = 0, last = 0, live = null;
  // a dynamic theme at time t (seconds): the base palette with its accents moved
  function frame(d, t) {
    const s = (d.speed || 1), v = Object.assign({}, d.v), shift = (c, dh, dl) => { const [h, S, L] = toHsl(c); return hsl(h + dh, S, Math.max(3, Math.min(98, L + (dl || 0)))); };
    if (d.kind === 'drift') { const a = Math.sin(t * .05 * s) * d.span / 2; ['accent', 'pink', 'good'].forEach((k, i) => v[k] = shift(v[k], a * (1 - i * .3))); }
    else if (d.kind === 'tide') { const a = Math.sin(t * .12 * s); const dl = (d.mode === 'dark' ? 1 : -1) * (1.5 + 1.5 * a);
      ['canvas', 'surface', 'surface2'].forEach(k => v[k] = shift(v[k], 0, dl)); v.accent = shift(v.accent, a * 8); }
    else if (d.kind === 'daylight') { const now = new Date(), hr = now.getHours() + now.getMinutes() / 60 + (t * s * 0 /* real clock */);
      const sun = Math.max(0, Math.min(1, (Math.sin((hr - 6) / 24 * Math.PI * 2) + .25) / .9)); VARS.forEach(k => v[k] = mix(d.v[k], d.day[k], sun)); }
    else if (d.kind === 'aurora') { const p = (t * .03 * s) % 3, ks = ['accent', 'pink', 'good'], c = ks.map(k => d.v[k]); const i = Math.floor(p), f = p - i;
      ks.forEach((k, j) => v[k] = mix(c[(j + i) % 3], c[(j + i + 1) % 3], f)); }
    else if (d.kind === 'pulse') { const b = Math.pow(Math.max(0, Math.sin(t * 1.1 * s)), 12); v.accent = shift(v.accent, 0, b * (d.mode === 'dark' ? 12 : -10)); v.pink = shift(v.pink, 0, b * 6); }
    return v;
  }
  function loop(ts) {
    raf = requestAnimationFrame(loop);
    if (!live || document.hidden || ts - last < (live.kind === 'daylight' ? 30000 : 66)) return;   // ~15 frames a second; the sundial once a half-minute
    last = ts; setVars(frame(live, ts / 1000));
  }
  function stopLive() { live = null; if (raf) cancelAnimationFrame(raf); raf = 0; }
  function current() {
    const T = S.settings.themes || {}; const sel = T.sel;
    if (!sel) return null;
    return (sel.type === 'dynamic' ? (T.dynamic || []) : BUILTIN.concat(T.static || [])).find(x => x.id === sel.id) || null;
  }
  // put the chosen theme on this face; called at start and whenever settings arrive from another tile
  let worn = '';
  function apply() {
    const T = S.settings.themes || {}, th = current();
    const key = JSON.stringify([T.sel, th && th.v, th && th.speed, S.settings.theme]);
    if (key === worn) return; worn = key;           // settings arrive from other tiles often; don't restart the motion for nothing
    stopLive();
    if (!th) { clearVars(); root.dataset.theme = S.settings.theme || 'dark'; return; }
    root.dataset.theme = th.mode === 'light' ? 'light' : 'dark';
    setVars(th.v);
    if (T.sel.type === 'dynamic') { live = th; last = 0; raf = requestAnimationFrame(loop); }
  }
  // choose: remember it, tell the host the resting colours (window edges, new tabs, the shelf)
  function choose(type, id) {
    const T = S.settings.themes = S.settings.themes || { static: [], dynamic: [] };
    T.sel = type ? { type, id } : null;
    const th = current();
    S.settings.theme = th ? (th.mode === 'light' ? 'light' : 'dark') : (S.settings.theme || 'dark');
    S.settings.themeVars = th ? th.v : null;
    apply(); saveSettings();
  }

  // ---------------------------------------------------------------- the pages
  const thumb = (v, kind) => '<div class="tth' + (kind ? ' k-' + kind : '') + '" style="' + VARS.map(k => '--t' + k + ':' + v[k]).join(';') + '">' +
    '<i class="t1"><b></b><b></b></i><i class="t2"><u></u><b></b><b></b></i><i class="t3"><b></b><b></b><b></b><s></s></i></div>';
  function card(th, type) {
    const T = S.settings.themes || {}, on = T.sel && T.sel.type === type && T.sel.id === th.id;
    return '<div class="tcard' + (on ? ' on' : '') + '" data-id="' + th.id + '" tabindex="0" title="' + esc(th.name) + (th.kind ? ' · ' + KINDS[th.kind] : '') + '">' + thumb(th.v, th.kind) +
      '<div class="tnm"><span>' + esc(th.name) + '</span>' + (th.builtin ? '<small>built in</small>' :
      '<span class="tact"><button data-t="reroll" title="Generate again with the same settings">↻</button><button data-t="del" title="Delete">✕</button></span>') + '</div></div>';
  }
  function page(p, type) {
    const T = S.settings.themes = S.settings.themes || { static: [], dynamic: [] };
    const list = type === 'static' ? (T.static = T.static || []) : (T.dynamic = T.dynamic || []);
    const g = T['gen_' + type] = T['gen_' + type] || { harmony: 'any', mode: 'any', kind: 'any' };
    const opt = (id, o, cur) => '<select class="inp sm" id="' + id + '">' + Object.entries(o).map(([k, n]) => '<option value="' + k + '"' + (k === cur ? ' selected' : '') + '>' + n + '</option>').join('') + '</select>';
    const sel = current(), dynSel = type === 'dynamic' && T.sel && T.sel.type === 'dynamic' ? sel : null;
    p.innerHTML = head('', type === 'static' ? 'Static themes' : 'Dynamic themes') +
      '<div class="row tgen">' + (type === 'dynamic' ? opt('tk', Object.assign({ any: 'Any motion' }, KINDS), g.kind) : '') +
      opt('th', HARM_NAME, g.harmony) + opt('tm', { any: 'Dark or light', dark: 'Dark', light: 'Light' }, g.mode) +
      '<button class="btn" id="tg1">✦ Generate</button><button class="btn sm" id="tg6">×6</button></div>' +
      (type === 'dynamic' ? '<div class="row"><label>Speed <small>· of the theme you are wearing</small></label><input type="range" id="tsp" min="0.2" max="4" step="0.1" value="' + (dynSel ? dynSel.speed : 1) + '"' + (dynSel ? '' : ' disabled') + '></div>' : '') +
      '<div class="tgrid" id="tgrid">' + (type === 'static' ? BUILTIN.map(b => card(b, 'static')).join('') : '') + list.map(th => card(th, type)).join('') +
      (list.length ? '' : '<div class="tempty">Nothing generated yet — press ✦ Generate.</div>') + '</div>' +
      '<div class="row"><small class="muted">' + list.length + ' ' + type + ' theme' + (list.length === 1 ? '' : 's') + ' · click one to wear it' + (T.sel ? '' : ' · wearing the default') + '</small>' +
      (T.sel ? '<button class="btn sm" id="toff">Back to default</button>' : '') + (list.length ? '<button class="btn sm d" id="tclr">Delete all</button>' : '') + '</div>';
    const redraw = () => open(type === 'static' ? 'tstatic' : 'tdynamic');
    const gen = n => { const opts = { harmony: $('#th', p).value, mode: $('#tm', p).value, kind: type === 'dynamic' ? $('#tk', p).value : undefined };
      Object.assign(g, opts); for (let i = 0; i < n; i++) list.unshift(type === 'static' ? genStatic(newSeed(), opts) : genDynamic(newSeed(), opts));
      if (list.length > 60) list.length = 60; saveSettings(); redraw(); };
    $('#tg1', p).onclick = () => gen(1); $('#tg6', p).onclick = () => gen(6);
    if ($('#toff', p)) $('#toff', p).onclick = () => { choose(null); redraw(); };
    if ($('#tclr', p)) $('#tclr', p).onclick = () => { if (!confirm('Delete every generated ' + type + ' theme?')) return; if (T.sel && T.sel.type === type) choose(null); list.length = 0; saveSettings(); redraw(); };
    if ($('#tsp', p)) $('#tsp', p).oninput = e => { if (dynSel) { dynSel.speed = +e.target.value; if (live) live.speed = dynSel.speed; clearTimeout(page.t); page.t = setTimeout(saveSettings, 400); } };
    $('#tgrid', p).onclick = e => {
      const c = e.target.closest('.tcard'); if (!c) return; const id = c.dataset.id, i = list.findIndex(x => x.id === id);
      const act = e.target.closest('[data-t]');
      if (act && act.dataset.t === 'del' && i >= 0) { list.splice(i, 1); if (T.sel && T.sel.id === id) choose(null); else saveSettings(); redraw(); return; }
      if (act && act.dataset.t === 'reroll' && i >= 0) { const old = list[i], fresh = type === 'static' ? genStatic(newSeed(), old.opts) : genDynamic(newSeed(), old.opts);
        list[i] = fresh; if (T.sel && T.sel.id === id) choose(type, fresh.id); else saveSettings(); redraw(); return; }
      choose(type, id); redraw();
    };
    $('#tgrid', p).onkeydown = e => { if (e.key === 'Enter' && e.target.classList.contains('tcard')) e.target.click();
      if (e.key === 'Delete' && e.target.classList.contains('tcard')) { const b = e.target.querySelector('[data-t=del]'); if (b) b.click(); } };
    const on = $('.tcard.on', p); if (on) on.scrollIntoView({ block: 'nearest' });
  }
  // the new-tab page has no settings; the host hands it the resting colours as &tv=hex.hex.… in VARS order
  if (location.hash === '#ntp' && QS.get('tv')) {
    const hx = QS.get('tv').split('.'); if (hx.length === VARS.length && hx.every(h => /^[0-9a-f]{6}$/i.test(h))) {
      const v = {}; VARS.forEach((k, i) => v[k] = '#' + hx[i]); setVars(v); root.dataset.theme = lum(v.canvas) > .4 ? 'light' : 'dark'; } }
  const css = document.createElement('style');
  css.textContent = `
.tgen{flex-wrap:wrap;justify-content:flex-start}.tgen .btn{margin-left:auto}.tgen .btn+.btn{margin-left:0}
.inp.sm{padding:4px 6px;font-size:11px}.pbody input[type=range]{accent-color:var(--accent)}
.tgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;max-height:340px;overflow:auto;padding:2px 6px 2px 2px;scrollbar-width:thin;scrollbar-color:var(--border) transparent}
.tgrid::-webkit-scrollbar{width:8px}.tgrid::-webkit-scrollbar-thumb{background:var(--border);border-radius:4px}.tgrid::-webkit-scrollbar-thumb:hover{background:var(--muted)}
.tcard{border:1px solid var(--border);border-radius:10px;overflow:hidden;cursor:pointer;background:var(--surface2);outline:0;transition:transform .12s,border-color .12s}
.tcard:hover,.tcard:focus-visible{transform:translateY(-2px);border-color:var(--muted)}
.tcard.on{border-color:var(--accent);box-shadow:0 0 0 2px var(--accent)}
.tnm{display:flex;align-items:center;gap:4px;padding:5px 8px;font-size:11px;font-weight:700}.tnm>span:first-child{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tnm small{font-weight:400}.tact button{color:var(--muted);padding:0 4px;font-size:13px;border-radius:4px}.tact button:hover{color:var(--fg);background:var(--surface)}
.tact button[data-t=del]:hover{color:var(--bad)}
.tth{height:84px;background:var(--tcanvas);display:flex;flex-direction:column;position:relative}
.tth i{display:flex;align-items:center;gap:4px;padding:0 6px}
.tth .t1{height:16px;background:var(--tsurface);border-bottom:1px solid var(--tborder)}.tth .t1 b{width:34px;height:8px;border-radius:3px;background:var(--tsurface2)}.tth .t1 b:first-child{border-bottom:2px solid var(--taccent)}
.tth .t2{height:18px;background:var(--tsurface)}.tth .t2 u{flex:1;height:9px;border-radius:5px;background:var(--tcanvas);border:1px solid var(--tborder)}.tth .t2 b{width:9px;height:9px;border-radius:50%;background:var(--taccent)}.tth .t2 b+b{background:var(--tpink)}
.tth .t3{flex:1;flex-direction:column;align-items:flex-start;justify-content:center;gap:5px;padding:0 12px}.tth .t3 b{height:5px;border-radius:3px;background:var(--tfg);width:70%}
.tth .t3 b+b{background:var(--tmuted);width:50%}.tth .t3 b+b+b{width:60%}.tth .t3 s{position:absolute;right:10px;bottom:10px;width:30px;height:10px;border-radius:5px;background:linear-gradient(90deg,var(--taccent),var(--tpink),var(--tgood))}
.tth[class*=k-]::after{content:'';position:absolute;inset:0;pointer-events:none}
.tth.k-drift .t3 s,.tth.k-aurora .t3 s{animation:tdr 6s linear infinite}.tth.k-tide{animation:ttd 5s ease-in-out infinite}.tth.k-pulse .t2 b:first-of-type{animation:tpu 1.6s ease-in infinite}
.tth.k-daylight::after{background:linear-gradient(180deg,transparent 40%,rgba(255,200,120,.18));animation:ttd 8s ease-in-out infinite}
@keyframes tdr{to{filter:hue-rotate(360deg)}}@keyframes ttd{50%{filter:brightness(1.18)}}@keyframes tpu{0%,70%,100%{transform:scale(1)}80%{transform:scale(1.5)}}
.tempty{grid-column:1/-1;padding:30px;text-align:center;color:var(--muted);border:1px dashed var(--border);border-radius:10px}
@media (prefers-reduced-motion:reduce){.tth,.tth *,.tth::after{animation:none!important}}`;
  document.head.appendChild(css);
  if (location.hash !== '#ntp') setTimeout(apply, 0);   // if the settings came before this file did
  return { apply, choose, genStatic, genDynamic, page, current, VARS };
})();
function pThemeStatic(p) { THEME.page(p, 'static'); }
function pThemeDynamic(p) { THEME.page(p, 'dynamic'); }
