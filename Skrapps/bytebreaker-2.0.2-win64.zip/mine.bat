@echo off
setlocal enableDelayedExpansion
Rem ###################################################
Rem ## Edit these. Coins: etc ethw ltc doge pepe btc ##
Rem ###################################################
set "COIN=etc"
set "POOL=etc.2miners.com:1010"
set "WALLET=0xYOUR_WALLET_ADDRESS"
set "WORKER=rig1"
set "EXTRA="
Rem For a CPU coin, e.g.:  set "COIN=pepe"  set "POOL=pool.pepeluck.com:3032"  set "EXTRA=--cpu-threads 4"
Rem For split mining (up to 3 coins) use the control page instead: run bytebreaker.exe with no arguments.
Rem ###################################################
cd /d %~dp0
:LOOP
echo Starting Bytebreaker v2 (%COIN%)...
bytebreaker.exe --coin !COIN! --pool !POOL! --wallet !WALLET! --worker !WORKER! --watchdog exit --no-browser !EXTRA!
if %ERRORLEVEL% == 42 (
    echo Watchdog restart in 10 seconds...
    timeout /t 10
    goto LOOP
)
pause
