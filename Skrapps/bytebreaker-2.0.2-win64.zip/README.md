# ꟻ Bytebreaker v2.0.2

**An open-source, zero-dev-fee multi-coin miner with split mining, address validation and a built-in control page.**

Bytebreaker connects to the pool you choose, hashes, and submits shares — nothing else. No developer
fee, no telemetry, no closed binaries: it is ~6 000 lines of Go with **zero third-party dependencies**
plus one OpenCL kernel, so anyone can read it, rebuild it and know exactly what runs on their rig.

```
bytebreaker.exe                                                   → control page at http://127.0.0.1:4025
bytebreaker.exe --coin etc  --pool etc.2miners.com:1010 --wallet 0x…   --worker rig1
bytebreaker.exe --coin ltc  --pool litecoinpool.org:3333 --wallet L…  --cpu-threads 4
bytebreaker.exe --list-coins        bytebreaker.exe --list-devices
```

## v2.0.2 — the "every share rejected" fix, verified pool lists, auto-pick

- **Every ETC share rejected (`Invalid share`, 2Miners and every other ETC pool).** Ethereum
  Classic is *Etchash* (ECIP-1099): the pool's seed hash still follows the 30 000-block
  schedule, but the DAG is the one of `block ÷ 60 000`. v2.0.1 decoded the seed to epoch 848 and
  built *that* epoch's 7.8 GB DAG; Etchash wants epoch 424's 4.4 GB DAG generated from the same
  seed. Every hash was internally consistent and wrong, so the CPU re-check passed and the pool
  refused all 46 shares of a 2-hour session. Fixed by `ethash.Variant` (the coin picks the
  mapping) and pinned by two end-to-end tests: the real engine against a pool verifying as ETC
  does must be *accepted*, and the old mapping must be *rejected* (`invalid mix hash`).
- **Diagnosable rejects.** Export records now carry the stratum dialect, job id/header, DAG
  epoch, the pool's raw error object, round-trip time and share difficulty; the console shouts
  when a pool has rejected everything and accepted nothing.
- **eth-proxy pools that don't push work** get an `eth_getWork` poll every 4 s of job silence
  instead of every 45 s — a stale header is also "Invalid share" on most pools.
- **Pool lists re-verified online (2026-10-03)** against each pool's own docs — ports, SSL ports,
  regional servers (2Miners eu/us/asia, HeroMiners 15 regions, Nanopool 7, Kryptex 7, F2Pool 4),
  fees, payout schemes, minimum payouts, login formats (`wallet/worker` on Kryptex, `c=DOGE`
  on multipools — applied automatically). Pools that need a site account are marked and never
  auto-picked. Presets that could not be verified were removed rather than guessed.
- **⚡ best pool** (next to the preset dropdown): pings every known server for the coin from
  your PC, twice, and ranks them by what you keep — `(1 − fee) × (1 − stale loss from latency)`
  — then fills the best one in with the runner-up as failover. The full table stays visible.
- **Auto-pick · profitability & efficiency**: estimates what each coin earns on *your*
  hardware (hashrate measured by this miner when it has run, else a CPU micro-benchmark /
  GPU estimate), with network hashrate, block reward and price fetched from whattomine.com
  **only when you click**, pool fee applied, and — if you enter watts and $/kWh — power cost
  and profit per day. GPU memory vs DAG size is checked. One click applies the winner to slot 1.
- Honest numbers: at today's ETC hashrate and price a single mid-range GPU earns a few cents a
  day *before* electricity, and the CPU coins (LTC/DOGE/PEP/BTC) are petahash ASIC networks that
  pay a CPU fractions of a cent. The table says so instead of hiding it.

## v2.0.1 — fixes from the first real-hardware run

- **No shares ever found on ETC (WoolyPooly and pools like it).** `mining.set_difficulty` has two
  conventions in the wild: NiceHash multipliers (`2`, `4`…) and plain hashes-per-share
  (`4000000000` = 4G). v2.0.0 always assumed the first, so a 4G target became 1.7×10¹⁹ hashes —
  the console showed `share target 17180131.33T` and the GPU hashed for nothing. Both are now
  detected by magnitude and the log says which one was used.
- **Valid Dogecoin addresses rejected.** A Base58 address containing a `1` followed by
  bech32-alphabet characters was misread as bech32. bech32 is now only recognised by a known
  chain prefix (`bc1…`, `ltc1…`).
- **"Is it stalling?"** Every slot now shows `share target … → next share ≈ …` (target ÷ your
  hashrate), in red when that is more than a day (e.g. Bitcoin on a CPU), and the 30-second
  console summary includes it. Silence now has a number next to it.
- Protocol in use is shown per slot; `TESTING.md` + `bytebreaker.example.json` added.

## What's new in v2

| Feature | Details |
|---|---|
| **More coins** | Ethereum Classic & ETHW (Ethash, **GPU**) · Litecoin, Dogecoin, Pepecoin (Scrypt, **CPU**) · Bitcoin (SHA-256d, CPU/test) |
| **Split mining** | Up to **3 slots** at once, each its own coin, pool(s), wallet and worker — e.g. one GPU coin + two CPU coins |
| **Address check** | Every wallet address is validated *before* mining: EIP-55 checksum (ETC/ETHW), Base58Check + bech32 (LTC/DOGE/PEPE/BTC), wrong-network detection, plain-language reasons. Live ✓/✗ in the UI |
| **Test connection** | One click dials the pool (TCP/TLS), reports latency and whether it answers stratum, with friendly error text |
| **Auto worker** | Blank worker name → derived from the machine's hostname |
| **Per-coin dropdowns** | Coin picker → pool presets for that coin → editable pool address, protocol, TLS, failover pool |
| **Rejected-jobs export** | Every rejected/stale/hardware-invalid share is logged with pool reason, raw error, dialect, job, header, epoch, nonce, difficulty and latency; export as CSV or JSON. `TESTING.md` § 5 explains how to read it |
| **⚡ best pool** | Pings every known server for the coin from your PC and ranks by `(1 − fee) × (1 − stale loss)`; fills in the winner + failover |
| **Auto-pick** | Per-coin earnings on *your* hardware (measured/benchmarked hashrate, live network data on click, fee, optional power cost), DAG-vs-VRAM check, one-click apply |
| **Not-mineable coins are told the truth** | Cardano (proof-of-stake) and Stellar (no PoW) appear in the list with an explanation instead of a fake miner |

Everything from v1 stays: GPU Ethash with the known-answer self-test, CPU re-verification of every share
before it is sent, auto protocol detection, TLS, failover + fail-back, watchdog, local-only UI.

## Quick start (Windows)

1. Unzip anywhere. Your existing GPU driver provides OpenCL; nothing else to install.
2. Double-click `bytebreaker.exe` → the control page opens in your browser.
3. In **Slot 1** pick a coin, pick a pool preset (or type any `host:port`), press **⚡ Test connection**,
   paste your wallet (it turns green when valid), press **auto** for a worker name, tick **enabled**.
4. Optionally fill Slot 2 and 3 with other coins. Press **▶ Start mining**.
5. Watch the console: `logged in` → `share found` → `ACCEPTED`. Press **Save config** to keep the setup;
   tick **autostart** to mine on launch.

`mine.bat` / `mine.sh` show the classic batch-file way with an automatic restart loop.

> **Antivirus.** Every miner trips Windows Defender's "CoinMiner" heuristic — lolMiner and TRM
> included. Bytebreaker has no hidden behaviour (§ *Trust*), but Defender can't know that. Add the folder
> as an exclusion or build from source (§ *Building*).

## The coins, honestly

| Coin | Algorithm | Where it runs | Reality check |
|---|---|---|---|
| ETC | Etchash (ECIP-1099) | **GPU** (OpenCL) | Real GPU mining. DAG ≈ 4.4 GB today → 6 GB+ card. Fixed in v2.0.2 |
| ETHW | Ethash | **GPU** (OpenCL) | DAG ≈ 7.7 GB → 8 GB+ card |
| LTC, DOGE, PEP | Scrypt (1024,1,1) | **CPU** threads | Verified-correct and pool-accepted, but all three are ~2.5–3 PH/s ASIC networks (Pepecoin is merge-mined by Litecoin ASICs): a CPU earns fractions of a cent. Here to learn, test and drive pool configs with. **GPU Scrypt is the next increment** — the algorithm and pool plumbing are done and tested |
| BTC | SHA-256d | CPU (testing) | Will not earn: Bitcoin needs ASICs (that is what a Bitaxe is). Included for testing, solo-lottery experiments, and Bitaxe-style pool configs |
| ADA, XLM | — | — | Not mineable (proof-of-stake / no proof-of-work). Listed only to say so |

Not yet: RandomX (Monero), KawPow (Ravencoin), dual mining. The engine, stratum clients and UI are
algorithm-agnostic; a new coin is a hash function + verification test + registry entry.

## Split mining

Each slot is fully independent (own pool connection, wallet, worker, stats). Rules the UI enforces:
- a GPU can run **one** Ethash coin at a time (assign different GPUs to different slots if you have several);
- CPU coins share the CPU — set threads per slot;
- at most 3 slots.
A typical split: **Slot 1** ETC on the GPU, **Slot 2** Pepecoin on 4 CPU threads, **Slot 3** a test pool.

## Trust: how you know it's clean

- **Read it.** The whole program is in this repository; there is no obfuscation and no binary blob.
- **Only stdlib.** `go.mod` has no dependencies — nothing is pulled from the internet at build time.
- **Only your pool.** While mining, the one outbound connection is the address you typed. Two buttons
  make other connections, only when you press them, and say so: **⚡ best pool** dials the pools in the
  list, and **Analyse this computer** fetches `whattomine.com/coins.json` + `asic.json` for network
  hashrates and prices. Nothing about you is sent either way. The control page listens on
  `127.0.0.1` only and refuses foreign `Host` headers (DNS-rebinding guard).
- **Verified maths.** `go test ./...` checks: Ethash against the go-ethereum vectors and real mainnet block 22;
  the Etchash seed→DAG mapping against ECIP-1099 / core-geth and the current ETC epoch;
  Scrypt against RFC 7914; SHA-256d against the Bitcoin genesis block; header assembly against real Bitcoin
  block 1; address checksums against the EIP-55 spec, the Bitcoin genesis address and BIP-173.
- **Verified plumbing.** The full miner runs end-to-end in the test-suite against verifying mock pools
  (`tools/mockpool` for Ethash, `tools/mockbtcpool` for Scrypt/SHA-256d) with **zero rejected shares**;
  the Ethash GPU kernel runs through a CPU emulator (`emu/`) that executes the real kernel source.
- **Belt and braces.** Every share is recomputed on the CPU before submission; GPUs pass a known-answer
  self-test after each DAG build. A bad card shows up as *Invalid (HW)*, never as a bad share sent to the pool.

Algorithms were implemented from their specifications (RFC 7914, the Ethash spec, Bitcoin's header
format) — not copied from other miners.

## Command line

```
--coin ID            etc | ethw | ltc | doge | pepe | btc        --list-coins
--pool host:port     repeat for failover                          --tls
--wallet ADDR        validated before mining (--user is an alias)
--worker NAME        blank = auto from hostname                    --pass x
--devices 0,1        GPUs for GPU coins (default all)              --cpu-threads N (CPU coins, 0 = auto)
--worksize N  --kernel auto|local|nv|amd|intel|khr                 Ethash tuning
--watchdog exit      exit 42 on GPU hang (for restart loops)       --list-devices
--port 4025  --no-ui  --no-browser  --config FILE  --verbose  --version
```
The CLI configures **one** slot; use the control page (or `bytebreaker.json`) for split mining.

## Building

```
go 1.22+
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -ldflags="-s -w" -o bytebreaker.exe ./cmd/bytebreaker
go build -o bytebreaker ./cmd/bytebreaker              # Linux (cgo, for dlopen of libOpenCL)
go test -short ./...                                   # ~1 min incl. emulated-GPU tests
./build.sh                                             # release archives + checksums into dist/
```

Test pools for development (no real coins involved):
```
go run ./tools/mockbtcpool -algo scrypt  -diff 5e-7 -listen 127.0.0.1:3334   # LTC/DOGE/PEPE-style
go run ./tools/mockbtcpool -algo sha256d -diff 2e-3 -listen 127.0.0.1:3335   # BTC-style
go run ./tools/mockpool    -proto ethproxy -tiny -diff 3000                   # ETC-style
```

## Layout

```
cmd/bytebreaker        CLI + UI launcher
internal/address       wallet address validation (EIP-55, Base58Check, bech32)
internal/coins         coin registry: algorithm, hardware, address rules, verified pool presets + regional servers
internal/autopick      ⚡ best pool (ping + fee ranking) and the profitability plan (whattomine.com on click)
internal/ethash        Ethash/Etchash + Keccak (verified; Variant = seed→DAG epoch mapping)
internal/scrypt        Scrypt(1024,1,1) (RFC 7914 verified)
internal/sha256d       double SHA-256 (genesis verified)
internal/btcstratum    Bitcoin-family stratum: coinbase → merkle → header (block-1 verified)
internal/btcminer      CPU backend for scrypt / sha256d (CPU re-verification of every share)
internal/stratum       Ethash stratum (eth-proxy + EthereumStratum), failover, fail-back
internal/gpu, cl       OpenCL Ethash miner + runtime-loaded binding; kernels/ethash.cl
internal/engine        Ethash engine (jobs, DAG cache, verification, watchdog)
internal/rig           split-mining supervisor: up to 3 slots, GPU-clash rules
internal/probe         test-connection ping, auto worker name
internal/rejectlog     rejected/stale/invalid share log + CSV/JSON export
internal/ui            local control page + JSON API
tools/mockpool, mockbtcpool   verifying test pools
emu/                   CPU emulator for the OpenCL API (runs the real kernel in tests)
```

## Troubleshooting

| Message | Meaning |
|---|---|
| `wallet address rejected — …` | typo / wrong network / bad checksum; the reason says which. Fix before mining |
| `✗ connection refused` on Test | wrong port or pool down; check the preset note or the pool site |
| `no OpenCL GPU found` | GPU coins need a driver with OpenCL; CPU coins still work |
| `slots N and M both use the GPU` | two Ethash coins claimed the same GPU — assign different GPUs or run one |
| `Invalid share` / `Job not found` for a **few** shares | the pool changed jobs while a share was in flight (a few are normal); many → high latency, press **⚡ best pool** |
| **Every** share rejected, none accepted | algorithm/pool mismatch, not luck — the console says so after 3. Check coin vs pool (ETC pools are Etchash), then `TESTING.md` § 5 |
| `INVALID … failed CPU re-verification` | a candidate was wrong before it left your machine — overclock / memory error |

## License

MIT — see `LICENSE`. Mining uses real electricity and only ever pays the wallet address you enter.
