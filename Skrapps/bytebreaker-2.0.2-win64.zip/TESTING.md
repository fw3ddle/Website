# Testing Bytebreaker

The addresses below are the project owner's real payout addresses, so any test share that
lands on a real pool pays the right account. (The UI's **example** button deliberately
generates a *format-only* dummy address instead, so other people's test shares don't come here.)

```
etc:  0xE160d7e295045e22eAF487C0506d5Dd11421dA6b
doge: DSR7WeXvc5zMB5dbwaSKkJsRiV1eDCngKt
btc:  bc1qyd6dml8s60kkwrcp80d9phlylgt2wkrzjqpeey
```

All three are checked by the address validator's regression tests (`internal/address`).
`bytebreaker.example.json` is a ready-to-use three-slot config using them — copy it to
`bytebreaker.json` next to the executable (or load it via **Save config** after editing).

## 1. Unit + integration tests (no network, no real coins)

```
go test -short ./...          # ~1 min; includes the emulated-GPU Ethash tests
go test ./...                 # + the 1 GiB real-size DAG / mainnet block-22 test (~4 min)
```

What they prove: Ethash (go-ethereum vectors + mainnet block 22), Scrypt (RFC 7914),
SHA-256d (Bitcoin genesis), Bitcoin-family header assembly (real Bitcoin block 1), addresses
(EIP-55 spec, Bitcoin genesis address, BIP-173, and the three addresses above), both stratum
dialects, both `mining.set_difficulty` conventions, failover/reconnect, and full mining
sessions against verifying mock pools with zero rejected shares.

## 1b. The Etchash regression test (the v2.0.1 ETC bug)

```
go test ./tools/mockpool -run 'Etchash|EthashVariant' -v
```

`TestEtchashSharesAcceptedByEtchashPool` runs the real engine against a mock pool that
verifies **exactly as an Ethereum Classic pool does** (seed epoch 390 → DAG epoch 195, real
cache sizes) and requires accepted shares. `TestEthashVariantIsRejectedByEtchashPool` runs the
*old* v2.0.1 mapping against the same pool and requires every share to be rejected with
`invalid mix hash` — the same thing 2Miners reported as `Invalid share`. If either test ever
changes outcome, the DAG mapping has been broken again.

## 2. Mock pools (real protocol, fake coins)

Verifying test pools ship with the source and the Windows zip. Each one rebuilds every
submitted share from scratch and only accepts it if the proof-of-work is genuinely valid.

```
# Ethash, WoolyPooly-style difficulty (the convention that caused the v2.0.0 "stall"):
go run ./tools/mockpool -proto ethstratum -rawdiff -diff 4000000000 -listen 127.0.0.1:3336
# Ethash, NiceHash-style difficulty:
go run ./tools/mockpool -proto ethstratum -diff 4000000000 -listen 127.0.0.1:3336
# Ethash, eth-proxy dialect (2Miners / HeroMiners / Nanopool style):
go run ./tools/mockpool -proto ethproxy -diff 4000000000 -listen 127.0.0.1:3333
# Etchash — verifies like an ETC pool (half-size DAG for the announced seed). Point an ETC slot at it:
go run ./tools/mockpool -proto ethproxy -algo etchash -epoch 848 -diff 4000000000 -listen 127.0.0.1:3333
# Scrypt (LTC/DOGE/PEPE style) and SHA-256d (BTC style):
go run ./tools/mockbtcpool -algo scrypt  -diff 5e-7 -listen 127.0.0.1:3334
go run ./tools/mockbtcpool -algo sha256d -diff 2e-3 -listen 127.0.0.1:3335
```

Then point a slot at `127.0.0.1:<port>` with the matching coin. On a real GPU use the
default DAG; on a machine without a GPU set `BYTEBREAKER_TINY_DAG=1` (32 KiB DAG, test only)
and lower `-diff` (e.g. `-rawdiff -diff 120000`).

## 3. Real pools — what to expect

| Slot | Expected behaviour |
|---|---|
| ETC on a GPU (RX 6700 XT ≈ 38 MH/s) | pool share target ≈ 4G hashes → **one share every ~1–2 min**; the status card shows `next share ≈ 1.8 min` |
| BTC on CPU (≈ 40 MH/s SHA-256d) | solo.ckpool.org's minimum difficulty means **days per share** — the card will say so in red. This is Bitcoin needing ASICs, not a stall |
| LTC/DOGE on CPU | vardiff climbs past what a CPU hits → few/no shares; use Pepecoin or a low-diff pool for CPU tests |

If a slot shows a hashrate, `CONNECTED`, and a sane `next share ≈` but no shares after ~5× that
time, export the reject log and check the `reason` column.

## 4. Reading the status card

- **share target N hashes → next share ≈ T** — T = target ÷ hashrate. Red means T > 1 day: the
  hardware is far too slow for that pool/coin and it is not a bug.
- **rejected / stale / invalid** — see the export; `invalid` means a candidate failed CPU
  re-verification *before* submission (overclock/memory), never a bad share sent to the pool.

## 5. Reading a reject export (§ Rejects)

Since v2.0.2 every record carries the dialect, job id, header, DAG epoch, the pool's raw error
object, round-trip time and share difficulty. The first question is always **what fraction**:

| Pattern | Meaning | What to do |
|---|---|---|
| **100 % rejected, 0 accepted**, hashes verify locally | the miner and the pool disagree on the *algorithm*, not on luck. v2.0.1 did this on ETC: it built the Ethash DAG for the seed's epoch (848 → 7.8 GB) where Etchash wants the DAG of epoch 424 (4.4 GB). Every hash was self-consistent and wrong | fixed in v2.0.2 (`internal/ethash.Variant`). If it ever recurs: check the coin/algorithm (ETC = etchash, ETHW = ethash), then the `epoch` and `protocol` columns |
| a few % `Invalid share` / `Stale` / `Job not found` | shares that arrived after the pool moved to a new block; 2Miners-style pools say `Invalid share` for these too | normal under ~2–3 %. More → high latency: press **⚡ best pool** |
| `Low difficulty share` | share met the miner's target but not the pool's → the difficulty convention was misread | report with the export; v2.0.1 fixed the known case (hashes-per-share vs NiceHash multiplier) |
| `Duplicate share` | the same nonce sent twice (reconnect replay) | harmless once; many → report |
| `kind = invalid` | the GPU produced a wrong hash and the CPU caught it *before* sending | overclock/memory error; lower clocks |
| `Not subscribed` / `Unauthorized worker` | pool wants a different login format (`wallet/worker`, account name, `c=COIN` password) | pick the preset — its note says the format; the auto-pick fills it in |

The 2026-10-03 export that found the Etchash bug: 46 records over 2 h 15 min, all `rejected`
/ `Invalid share`, nonces walking a 64-bit counter, `jobId` empty (eth-proxy dialect — now
recorded as the header hash) — a textbook 100 %-pattern.
