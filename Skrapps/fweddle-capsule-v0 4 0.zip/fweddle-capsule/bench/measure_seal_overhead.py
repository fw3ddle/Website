#!/usr/bin/env python3
"""Measure exactly what sealing does to storage, and verify reversibility.

Usage:  python3 bench/measure_seal_overhead.py [path-to-fweddle-binary]
Creates ./exp, seals six fixture files, reports byte-exact metadata overhead,
allocated-disk deltas, and round-trip integrity, then unseals everything.
"""
import sys as _sys
import hashlib
import json
import os
import random
import re
import subprocess
import sys

FWEDDLE = os.path.abspath(_sys.argv[1] if len(_sys.argv) > 1 else "build/fweddle")
EXP = os.path.abspath("exp")


def run(*args, cwd=None):
    result = subprocess.run([FWEDDLE, *args], capture_output=True, text=True, cwd=cwd)
    if result.returncode != 0:
        raise RuntimeError(f"{args}: {result.stderr.strip()}")
    return result.stdout


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def du_bytes(path):
    out = subprocess.run(["du", "-s", "--block-size=1", path],
                         capture_output=True, text=True, check=True)
    return int(out.stdout.split()[0])


def xattr_bytes(path):
    total = 0
    names = []
    try:
        names = os.listxattr(path)
    except OSError:
        return 0, 0
    for name in names:
        if name.startswith("user.fweddle."):
            total += len(name.encode()) + len(os.getxattr(path, name))
    return total, len([n for n in names if n.startswith("user.fweddle.")])


def make_fixtures():
    os.makedirs(EXP, exist_ok=True)
    rng = random.Random(42)
    fixtures = {
        "tiny.txt": b"a very small mortal file's soul\n",
        "article.md": ("# Notes\n" + ("lorem ipsum dolor sit amet, consectetur "
                       "adipiscing elit, sed do eiusmod tempor incididunt.\n") * 90).encode(),
        "data.json": json.dumps({"rows": [{"id": i, "v": rng.random()}
                                          for i in range(1200)]}, indent=1).encode(),
        "photo.jpg": bytes(rng.getrandbits(8) for _ in range(1 * 1024 * 1024)),
        "build.bin": bytes(rng.getrandbits(8) for _ in range(5 * 1024 * 1024)),
        "empty.dat": b"",
    }
    for name, payload in fixtures.items():
        with open(os.path.join(EXP, name), "wb") as handle:
            handle.write(payload)
    return list(fixtures)


def main():
    names = make_fixtures()
    pre = {}
    for name in names:
        path = os.path.join(EXP, name)
        pre[name] = {"bytes": os.path.getsize(path), "sha": sha256(path)}

    du_before = du_bytes(EXP)
    view_before = run("--root", EXP, "view", EXP)

    rows = []
    for name in names:
        path = os.path.join(EXP, name)
        run("--root", EXP, "seal", path)
        capsule = path + ".fweddle"
        sidecar = os.path.join(EXP, "." + name + ".fweddle.fwmeta")
        with open(sidecar, "r", encoding="utf-8") as handle:
            meta = handle.read()
        uuid = re.search(r'"hunt_uuid": "([0-9a-f-]+)"', meta).group(1)
        negator = int(re.search(r'"negative_magnitude": (-?\d+)', meta).group(1))
        registry = os.path.join(EXP, ".fweddle", "registry", uuid + ".json")
        xbytes, xcount = xattr_bytes(capsule)
        rows.append({
            "name": name,
            "pre_bytes": pre[name]["bytes"],
            "capsule_bytes": os.path.getsize(capsule),
            "capsule_sha_matches": sha256(capsule) == pre[name]["sha"],
            "negator": negator,
            "sidecar_bytes": os.path.getsize(sidecar),
            "registry_bytes": os.path.getsize(registry),
            "xattr_bytes": xbytes,
            "xattr_count": xcount,
        })

    du_after = du_bytes(EXP)
    view_after = run("--root", EXP, "view", EXP)

    # Round trip every capsule and verify the bytes.
    survivors = 0
    for name in names:
        run("--root", EXP, "unseal", os.path.join(EXP, name + ".fweddle"))
        if sha256(os.path.join(EXP, name)) == pre[name]["sha"] and \
                os.path.getsize(os.path.join(EXP, name)) == pre[name]["bytes"]:
            survivors += 1

    report = {
        "rows": rows,
        "du_before": du_before,
        "du_after": du_after,
        "du_delta": du_after - du_before,
        "view_before": view_before,
        "view_after": view_after,
        "roundtrip_ok": survivors,
        "roundtrip_total": len(names),
        "total_pre_bytes": sum(r["pre_bytes"] for r in rows),
        "total_overhead_bytes": sum(r["sidecar_bytes"] + r["registry_bytes"] +
                                    r["xattr_bytes"] for r in rows),
    }
    json.dump(report, sys.stdout, indent=1)


if __name__ == "__main__":
    main()
