# Changelog

## 0.4.0 — 2026-08-26

### Added
- **Reference engine** (`src/refs.cpp`, EXPERIMENTAL): reference-backed
  capsules. `fweddle refs analyze FILE [--invert]` chunks a file, replaces
  every hunk that already exists under `--root` with a **pointer** (source path
  + offset), stores every unique hunk **resident** (inline), and writes a
  manifest to `<root>/.fweddle/refs/<name>.fwref.json`. `fweddle refs
  reconstruct FILE` rebuilds the original purely from the manifest — reading
  referenced hunks live and verifying every hunk **and** the whole file against
  recorded SHA-256 — writing `<FILE>.rebuilt`. New C ABI operations
  `fw_ref_analyze` and `fw_ref_reconstruct` bring the ABI to **eleven
  operations**. The target is never modified; a moved or edited source makes
  reconstruction fail loudly rather than emit wrong bytes.
- **Inversion pass**: `--invert` searches a missed hunk's bitwise inverse.
  Implemented and measurable; on real data it rescues essentially nothing (the
  inverse of random content is still random, and content-defined chunking
  re-cuts inverted data differently). Kept honest by measuring, not assuming.
- **Reference-engine test suite** (`tests/test_refs.cpp`): all-pointer
  reconstruction of a duplicate, a concatenation reconstructed 1:1, a unique
  file that is fully resident (manifest larger than the original) yet still
  1:1, dangling-reference detection in an isolated corpus, and the inversion
  path.
- **Expanded emoji lexicon** (now 54 mappings): documents 📄 (`.rtf .odt .tex
  .pages`), executables ⚙️ (`.exe .dll .so .msi .sh .bat`), Apple bundles 🍎
  (`.app .dmg .ipa .pkg`), disc images 💿 (`.iso .img`), raster edits 🖌️
  (`.psd .xcf .kra`), vector/design 🎨 (`.ai .sketch .fig .eps`), and more
  images 🖼️ (`.bmp .tiff .tif .heic .ico`). Added to both the built-in map and
  `config/lexicon.json`.

### Honest boundary
- Reference-backed capsules only save space where redundancy genuinely exists:
  measured −202,766 bytes on a duplicated 200 KiB file, but +50,216 bytes
  (a *larger* manifest) on a unique 48 KiB file. No reversible scheme can
  shrink arbitrary files; correctness never depends on the savings.

## 0.3.0 — 2026-08-26

### Added
- **Emote restyling** (`src/emotes.cpp`): the user lexicon now lives as the
  **fwemotes file** in the root — `fwemotes.json` (mortal) or
  `fwemotes.json.fweddle` (sealed) — and is honored in either state, since
  sealing preserves the raster. New CLI family: `fweddle emotes
  [list | set EXT EMOJI | unset EXT | edit | seal | unseal]`, where `edit`
  opens `$VISUAL`/`$EDITOR`. New C ABI operations: `fw_emote_set` (upsert or
  remove one mapping, with an automatic break-edit-reseal round trip when the
  lexicon is sealed) and `fw_emote_report` (the effective lexicon table with
  user entries and the active source marked).
- **Emote-lexicon test suite** (`tests/test_emotes.cpp`): resolution order,
  sealed-lexicon reads, the sealed round trip, the mortal/sealed ambiguity
  guard (`FW_COLLISION`), legacy-location compatibility, and explicit
  `--lexicon` precedence.

### Release
- `release/README.md` documents what ships and how to produce Windows and
  Android artifacts; `cross/windows-mingw.cmake` gives the one-command
  `fweddle.exe` cross-build; `bench/measure_seal_overhead.py` reproduces the
  measured storage costs of sealing. No placeholder `.exe`/`.apk`/`.ipa`
  files ship: a release folder is a trust surface.

### Changed
- Implicit lexicon resolution is now dynamic per lookup:
  `fwemotes.json` → `fwemotes.json.fweddle` → `.fweddle/lexicon.json`
  (legacy) → built-ins. An explicit `--lexicon` still overrides everything.

## 0.2.0 — 2026-08-26

### Added
- **Hunk engine** (`src/hunks.cpp`): content-defined chunking (gear CDC,
  2–64 KiB, ≈10 KiB expected) with SHA-256 over every hunk and every whole
  raster, committed atomically to `.fweddle/hunks/ledger.json`. Strictly
  observational — no user file is ever written, moved, relinked, or deleted.
- **Echo reports**: `fweddle scan [DIR]` and `fweddle echoes [FILE]`, plus the
  matching C ABI operations `fw_hunk_scan` and `fw_hunk_echoes`. Redundancy is
  notated as negative magnitudes (the echo negator), extending the capsule
  negator's theme.
- **Hunk-engine test suite** (`tests/test_hunks.cpp`): FIPS SHA-256 vectors,
  hunk tiling invariants, exact-duplicate and shifted-duplicate detection,
  deterministic rescans, the read-only guarantee, and seal interplay.
- `src/internal.hpp`: shared plumbing (runtime lock, root, error slot, atomic
  writer) between the capsule core and sibling modules.

### Fixed
- `fw_exorcise` / `unseal` failed with `FW_NOT_FOUND` when given a bare
  display name with no directory prefix (`fweddle unseal 'test🍀📄'`): a stale
  `std::error_code` from the regular-file probe leaked into the
  current-directory branch of `resolve_capsule_or_display`. Regression-tested
  in `tests/test_core.cpp`.

## 0.1.0

- Initial release: seal / view / unseal / rename-view / resurrect, three
  metadata stores, emoji lexicon, collision naming, the 1 GiB haiku, and
  transactional rollback.
