# Cross-compile Fweddle for Windows x86-64 with mingw-w64.
#
# Host prerequisites (Debian/Ubuntu):
#   sudo apt install mingw-w64
#
# Usage, from the repository root:
#   cmake -S . -B build-win -DCMAKE_BUILD_TYPE=Release \
#         -DCMAKE_TOOLCHAIN_FILE=cross/windows-mingw.cmake
#   cmake --build build-win --parallel
#
# Produces build-win/fweddle.exe and build-win/libfweddle_core.a. The Windows
# build uses the portable sidecar + registry stores (no xattrs), as documented
# in the main README. Console emoji need a UTF-8 codepage (`chcp 65001`) or
# Windows Terminal.
#
# This file is standard CMake cross-compilation boilerplate. It has been
# authored and reviewed but not runtime-tested from this repository's build
# sandbox, which has no mingw toolchain; treat the first .exe you produce as a
# candidate and run the test suite on a Windows machine before shipping it.

set(CMAKE_SYSTEM_NAME Windows)
set(CMAKE_SYSTEM_PROCESSOR x86_64)

set(CMAKE_C_COMPILER x86_64-w64-mingw32-gcc)
set(CMAKE_CXX_COMPILER x86_64-w64-mingw32-g++)
set(CMAKE_RC_COMPILER x86_64-w64-mingw32-windres)

set(CMAKE_FIND_ROOT_PATH /usr/x86_64-w64-mingw32)
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)

# Static runtimes so fweddle.exe carries no MinGW DLL dependencies.
set(CMAKE_EXE_LINKER_FLAGS_INIT "-static -static-libgcc -static-libstdc++")
