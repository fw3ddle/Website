# Release artifacts

## What ships here

| Folder | Contents | Built with |
| --- | --- | --- |
| `linux-x86_64/` | `fweddle` (CLI), `libfweddle_core.a`, `SHA256SUMS` | GCC 13, C++17, `-O2`, stripped |

Verify integrity:

```sh
cd linux-x86_64 && sha256sum -c SHA256SUMS
```

## Windows — producing `fweddle.exe`

The source is Windows-clean (the xattr layer compiles to the portable
sidecar + registry stores), but this repository's build sandbox has no mingw
toolchain, so no `.exe` ships prebuilt. On any Linux machine:

```sh
sudo apt install mingw-w64
cmake -S . -B build-win -DCMAKE_BUILD_TYPE=Release \
      -DCMAKE_TOOLCHAIN_FILE=cross/windows-mingw.cmake
cmake --build build-win --parallel
```

Then run the three test suites on a real Windows machine before shipping the
result into `release/windows-x86_64/`, and regenerate its `SHA256SUMS`.

## Android — native binary vs `.apk`

A native `fweddle` binary or `libfweddle_core` for Android cross-compiles with
the NDK's official toolchain file:

```sh
cmake -S . -B build-android -DCMAKE_BUILD_TYPE=Release \
      -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK/build/cmake/android.toolchain.cmake \
      -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-24
cmake --build build-android --parallel
```

An **`.apk` is not a binary** — it is a signed application package (manifest,
resources, Dalvik/ART code) produced by an Android app project. The Fweddle
story on Android, per the main README, is an adapter app (for example a
Storage Access Framework provider) that links `libfweddle_core`; the core
keeps a C ABI precisely so that app can be a thin shell.

## iOS — why there is no `.ipa`

iOS does not run standalone CLI executables, and an **`.ipa`** is a signed app
bundle that only Xcode plus Apple signing certificates can produce, on macOS.
The path mirrors Android: an app embedding `libfweddle_core`, built and signed
with Apple's toolchain. Nothing outside that toolchain can substitute for it.

## Why there are no placeholder binaries

A release folder is a trust surface. A file named `.exe`, `.apk`, or `.ipa`
that is not a real, working, correctly signed artifact is worse than an absent
one — so this project ships only binaries that were actually built, and says
plainly how to produce the rest.
