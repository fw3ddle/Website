#ifndef FWEDDLE_FWEDDLE_HPP
#define FWEDDLE_FWEDDLE_HPP

#include <cstddef>

#if defined(_WIN32) && defined(FWEDDLE_SHARED)
#  if defined(FWEDDLE_BUILDING)
#    define FWEDDLE_API __declspec(dllexport)
#  else
#    define FWEDDLE_API __declspec(dllimport)
#  endif
#else
#  define FWEDDLE_API
#endif

// Eleven filesystem-safe operations form the public ABI. Every function
// returns a fw_status value. Successful path/name results are UTF-8 strings
// written to the caller-owned output buffer.
enum fw_status {
    FW_OK = 0,
    FW_INVALID_ARGUMENT = 1,
    FW_NOT_INITIALIZED = 2,
    FW_NOT_FOUND = 3,
    FW_ALREADY_CAPSULED = 4,
    FW_IO_ERROR = 5,
    FW_BAD_METADATA = 6,
    FW_BUFFER_TOO_SMALL = 7,
    FW_COLLISION = 8
};

extern "C" {

// 1. Initializes the process-wide core. Passing nullptr for root uses the
// current directory. Passing nullptr for lexicon_path uses built-in mappings
// and optionally <root>/.fweddle/lexicon.json when present.
FWEDDLE_API int fw_init(const char* root, const char* lexicon_path);

// 2. Renames a mortal file to *.fweddle and writes reversible metadata.
FWEDDLE_API int fw_capsule(const char* path, char* out_path, std::size_t out_capacity);

// 3. Projects a capsule as basename + clover + soul emoji.
FWEDDLE_API int fw_display_name(const char* capsule_path,
                                char* out_name,
                                std::size_t out_capacity);

// 4. Resolves either a real capsule path or a projected display path and
// restores a mortal filename.
FWEDDLE_API int fw_exorcise(const char* capsule_or_display_path,
                            char* out_path,
                            std::size_t out_capacity);

// 5. Finds a relocated capsule by Hunt_UUID/backlink and refreshes its local
// registry record.
FWEDDLE_API int fw_resurrect(const char* hunt_uuid,
                             const char* search_root,
                             char* out_path,
                             std::size_t out_capacity);

// 6. Splits every regular file beneath search_root (nullptr = the init root)
// into content-defined hunks, hashes each with SHA-256, and atomically
// rewrites the hunk ledger at <root>/.fweddle/hunks/ledger.json. Strictly
// observational: no user file is written, moved, or deleted. out_path
// receives the ledger path.
FWEDDLE_API int fw_hunk_scan(const char* search_root,
                             char* out_path,
                             std::size_t out_capacity);

// 7. Writes a UTF-8 echo report notating where identical hunks recur.
// target may be a file path for a single-file report or nullptr for the
// root-wide summary. Requires a prior fw_hunk_scan.
FWEDDLE_API int fw_hunk_echoes(const char* target,
                               char* out_report,
                               std::size_t out_capacity);

// 8. Upserts one extension→emoji mapping in the user lexicon (the fwemotes
// file in the root). Passing nullptr or "" as emoji removes the mapping. If
// the lexicon is currently sealed, the seal is broken, the mortal JSON is
// edited atomically, and a fresh capsule is sealed — a compound operation.
// out_path receives the lexicon's final path (mortal or capsule).
FWEDDLE_API int fw_emote_set(const char* extension,
                             const char* emoji,
                             char* out_path,
                             std::size_t out_capacity);

// 9. Writes a UTF-8 table of the effective lexicon: built-in defaults merged
// with the active user lexicon, entries the user changed marked, and the
// active source (mortal, sealed, legacy, explicit, or built-in only) named.
FWEDDLE_API int fw_emote_report(char* out_report, std::size_t out_capacity);

// 10. EXPERIMENTAL. Chunks target and searches corpus_root (nullptr = the
// init root) for identical hunks, writing a reference manifest under
// <root>/.fweddle/refs/. Hunks found elsewhere become pointers; unique hunks
// are stored resident. If invert is non-zero, misses are also searched for as
// their bitwise inverse. The target is never modified. out_report receives a
// UTF-8 summary including the true reconstructable fraction and net storage.
FWEDDLE_API int fw_ref_analyze(const char* target,
                               const char* corpus_root,
                               int invert,
                               char* out_report,
                               std::size_t out_capacity);

// 11. EXPERIMENTAL. Rebuilds a target from its manifest (a target path or an
// explicit *.fwref.json), reading referenced hunks live and hash-verifying
// every hunk and the whole result. A moved or edited source is detected and
// the call fails rather than emitting wrong bytes. Writes <target>.rebuilt and
// returns its path in out_path.
FWEDDLE_API int fw_ref_reconstruct(const char* target_or_manifest,
                                   char* out_path,
                                   std::size_t out_capacity);

// Diagnostic accessor. The pointer remains valid until the next call on the
// same thread.
FWEDDLE_API const char* fw_last_error();

}

#endif
