#include "fweddle/fweddle.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <regex>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace {

constexpr std::size_t kPathBuffer = 32768;
constexpr std::size_t kReportBuffer = 1U << 20U;

void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}

std::uint64_t mix64(std::uint64_t value) {
    value += 0x9E3779B97F4A7C15ULL;
    value = (value ^ (value >> 30U)) * 0xBF58476D1CE4E5B9ULL;
    value = (value ^ (value >> 27U)) * 0x94D049BB133111EBULL;
    return value ^ (value >> 31U);
}

std::vector<unsigned char> pseudo_random_bytes(std::uint64_t seed, std::size_t size) {
    std::vector<unsigned char> bytes;
    bytes.reserve(size);
    std::uint64_t state = seed;
    while (bytes.size() < size) {
        state = mix64(state);
        for (int shift = 56; shift >= 0 && bytes.size() < size; shift -= 8) {
            bytes.push_back(static_cast<unsigned char>(state >> shift));
        }
    }
    return bytes;
}

void write_bytes(const fs::path& path, const std::vector<unsigned char>& bytes) {
    fs::create_directories(path.parent_path());
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    require(static_cast<bool>(output), "could not create fixture " + path.string());
    output.write(reinterpret_cast<const char*>(bytes.data()),
                 static_cast<std::streamsize>(bytes.size()));
}

void write_text(const fs::path& path, const std::string& text) {
    fs::create_directories(path.parent_path());
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    require(static_cast<bool>(output), "could not create fixture " + path.string());
    output << text;
}

std::vector<unsigned char> read_bytes(const fs::path& path) {
    std::ifstream input(path, std::ios::binary);
    require(static_cast<bool>(input), "could not read " + path.string());
    return std::vector<unsigned char>(std::istreambuf_iterator<char>(input), {});
}

std::string read_text(const fs::path& path) {
    std::ifstream input(path, std::ios::binary);
    require(static_cast<bool>(input), "could not read " + path.string());
    return std::string(std::istreambuf_iterator<char>(input), {});
}

// ---------------------------------------------------------------------------
// Independent line-based reading of the ledger, deliberately not sharing code
// with the production parser.
// ---------------------------------------------------------------------------

struct ParsedFile {
    std::string rel;
    std::uint64_t bytes = 0;
    std::string whole;
};

struct ParsedSite {
    std::size_t file = 0;
    std::uint64_t offset = 0;
};

struct ParsedHunk {
    std::string hash;
    std::uint64_t length = 0;
    std::vector<ParsedSite> sites;
};

struct ParsedLedger {
    std::vector<ParsedFile> files;
    std::vector<ParsedHunk> hunks;
};

ParsedLedger parse_ledger_text(const std::string& text) {
    ParsedLedger ledger;
    std::istringstream lines(text);
    std::string line;
    int section = 0;
    const std::regex file_line("^\\s*\\[\"(.*)\", ([0-9]+), \"([0-9a-f]{64})\"\\],?$");
    const std::regex hunk_line("^\\s*\\[\"([0-9a-f]{64})\", ([0-9]+), \\[(.*)\\]\\],?$");
    const std::regex site_pattern("\\[([0-9]+),([0-9]+)\\]");
    while (std::getline(lines, line)) {
        if (line.find("\"files\":") != std::string::npos) {
            section = 1;
            continue;
        }
        if (line.find("\"hunks\":") != std::string::npos) {
            section = 2;
            continue;
        }
        std::smatch match;
        if (section == 1 && std::regex_match(line, match, file_line)) {
            ledger.files.push_back(
                {match[1].str(), std::stoull(match[2].str()), match[3].str()});
        } else if (section == 2 && std::regex_match(line, match, hunk_line)) {
            ParsedHunk hunk;
            hunk.hash = match[1].str();
            hunk.length = std::stoull(match[2].str());
            const std::string body = match[3].str();
            for (std::sregex_iterator it(body.begin(), body.end(), site_pattern), end;
                 it != end; ++it) {
                hunk.sites.push_back(
                    {std::stoull((*it)[1].str()), std::stoull((*it)[2].str())});
            }
            ledger.hunks.push_back(std::move(hunk));
        }
    }
    return ledger;
}

std::uint64_t header_number(const std::string& text, const std::string& key) {
    const std::regex pattern("\\\"" + key + "\\\": ([0-9]+)");
    std::smatch match;
    require(std::regex_search(text, match, pattern), "ledger header missing " + key);
    return std::stoull(match[1].str());
}

std::size_t file_id(const ParsedLedger& ledger, const std::string& rel) {
    for (std::size_t i = 0; i < ledger.files.size(); ++i) {
        if (ledger.files[i].rel == rel) return i;
    }
    throw std::runtime_error("ledger has no file " + rel);
}

std::uint64_t shared_bytes(const ParsedLedger& ledger, std::size_t left, std::size_t right) {
    std::uint64_t total = 0;
    for (const ParsedHunk& hunk : ledger.hunks) {
        std::uint64_t count_left = 0;
        std::uint64_t count_right = 0;
        for (const ParsedSite& site : hunk.sites) {
            if (site.file == left) ++count_left;
            if (site.file == right) ++count_right;
        }
        total += hunk.length * std::min(count_left, count_right);
    }
    return total;
}

void check_tiling(const ParsedLedger& ledger,
                  std::size_t id,
                  std::uint64_t cdc_min,
                  std::uint64_t cdc_max) {
    std::vector<std::pair<std::uint64_t, std::uint64_t>> spans;
    for (const ParsedHunk& hunk : ledger.hunks) {
        for (const ParsedSite& site : hunk.sites) {
            if (site.file == id) spans.emplace_back(site.offset, hunk.length);
        }
    }
    std::sort(spans.begin(), spans.end());
    const std::uint64_t bytes = ledger.files[id].bytes;
    if (bytes == 0) {
        require(spans.empty(), "empty file has hunks: " + ledger.files[id].rel);
        return;
    }
    require(!spans.empty(), "non-empty file has no hunks: " + ledger.files[id].rel);
    std::uint64_t cursor = 0;
    for (std::size_t i = 0; i < spans.size(); ++i) {
        require(spans[i].first == cursor,
                "hunks do not tile " + ledger.files[id].rel);
        require(spans[i].second <= cdc_max, "hunk exceeds cdc_max");
        if (i + 1 < spans.size()) {
            require(spans[i].second >= cdc_min, "interior hunk below cdc_min");
        }
        cursor += spans[i].second;
    }
    require(cursor == bytes, "hunks do not cover " + ledger.files[id].rel);
}

std::string strip_scanned_ns(std::string text) {
    const std::size_t start = text.find("\"scanned_ns\"");
    require(start != std::string::npos, "ledger missing scanned_ns");
    const std::size_t stop = text.find('\n', start);
    return text.erase(start, stop - start + 1);
}

int call_echoes(const char* target, std::string& report) {
    std::vector<char> buffer(kReportBuffer);
    const int status = fw_hunk_echoes(target, buffer.data(), buffer.size());
    if (status == FW_OK) report = buffer.data();
    return status;
}

}  // namespace

int main() {
    const auto nonce = std::chrono::high_resolution_clock::now().time_since_epoch().count();
    const fs::path root = fs::temp_directory_path() / ("fweddle-hunk-test-" + std::to_string(nonce));
    try {
        fs::create_directories(root);
        require(fw_init(root.u8string().c_str(), nullptr) == FW_OK,
                std::string("fw_init: ") + fw_last_error());

        // Before any scan, echoes must report a missing ledger.
        std::string report;
        require(call_echoes(nullptr, report) == FW_NOT_FOUND,
                "echoes without a ledger should be FW_NOT_FOUND");

        // Fixtures. The vectors directory pins the SHA-256 implementation to
        // the standard test vectors; the rest exercises the chunker.
        write_text(root / "vectors" / "abc.txt", "abc");
        write_bytes(root / "vectors" / "empty.bin", {});
        write_text(root / "vectors" / "million.txt", std::string(1000000, 'a'));
        const std::vector<unsigned char> original = pseudo_random_bytes(1, 200 * 1024);
        write_bytes(root / "a.bin", original);
        write_bytes(root / "copies" / "b.bin", original);
        std::vector<unsigned char> shifted = pseudo_random_bytes(2, 64);
        shifted.insert(shifted.end(), original.begin(), original.end());
        write_bytes(root / "shift.bin", shifted);

        // Snapshot for the read-only guarantee.
        const std::vector<fs::path> watched = {
            root / "a.bin", root / "copies" / "b.bin", root / "shift.bin",
            root / "vectors" / "abc.txt", root / "vectors" / "million.txt"};
        std::map<std::string, fs::file_time_type> stamps;
        for (const fs::path& path : watched) {
            stamps[path.u8string()] = fs::last_write_time(path);
        }
        std::set<std::string> before;
        for (const auto& entry : fs::directory_iterator(root)) {
            before.insert(entry.path().filename().u8string());
        }

        // Scan.
        std::array<char, kPathBuffer> ledger_path{};
        require(fw_hunk_scan(nullptr, ledger_path.data(), ledger_path.size()) == FW_OK,
                std::string("fw_hunk_scan: ") + fw_last_error());
        require(fs::equivalent(fs::u8path(ledger_path.data()),
                               root / ".fweddle" / "hunks" / "ledger.json"),
                "ledger landed in the wrong place");
        const std::string first_text = read_text(fs::u8path(ledger_path.data()));

        // SHA-256 standard vectors, observed through the ledger.
        require(first_text.find("ba7816bf8f01cfea414140de5dae2223"
                                "b00361a396177a9cb410ff61f20015ad") != std::string::npos,
                "SHA-256(\"abc\") vector missing");
        require(first_text.find("e3b0c44298fc1c149afbf4c8996fb924"
                                "27ae41e4649b934ca495991b7852b855") != std::string::npos,
                "SHA-256(\"\") vector missing");
        require(first_text.find("cdc76e5c9914fb9281a1c7e284d73e67"
                                "f1809a48a497200e046d39ccc7112cd0") != std::string::npos,
                "SHA-256(10^6 x 'a') vector missing");

        const ParsedLedger ledger = parse_ledger_text(first_text);
        require(ledger.files.size() == 6, "expected six files in the ledger");
        const std::uint64_t cdc_min = header_number(first_text, "cdc_min");
        const std::uint64_t cdc_max = header_number(first_text, "cdc_max");
        for (std::size_t id = 0; id < ledger.files.size(); ++id) {
            check_tiling(ledger, id, cdc_min, cdc_max);
        }

        // Exact duplicates: identical whole hashes, identical hunk coverage.
        const std::size_t id_a = file_id(ledger, "a.bin");
        const std::size_t id_b = file_id(ledger, "copies/b.bin");
        const std::size_t id_shift = file_id(ledger, "shift.bin");
        require(ledger.files[id_a].whole == ledger.files[id_b].whole,
                "copies disagree on the whole-file hash");
        require(shared_bytes(ledger, id_a, id_b) == original.size(),
                "exact copy does not share every byte");

        // Shift resistance: content-defined boundaries resynchronize after a
        // 64-byte prefix, so most of the raster still matches.
        const std::uint64_t drift = shared_bytes(ledger, id_a, id_shift);
        require(drift >= (original.size() * 6) / 10,
                "shifted copy shares too little: " + std::to_string(drift));

        // Determinism: a rescan differs only in scanned_ns.
        std::array<char, kPathBuffer> second_path{};
        require(fw_hunk_scan(nullptr, second_path.data(), second_path.size()) == FW_OK,
                std::string("second fw_hunk_scan: ") + fw_last_error());
        const std::string second_text = read_text(fs::u8path(second_path.data()));
        require(strip_scanned_ns(first_text) == strip_scanned_ns(second_text),
                "rescan produced a different ledger");

        // Reports.
        require(call_echoes(nullptr, report) == FW_OK,
                std::string("global echoes: ") + fw_last_error());
        require(report.find("redundancy_negator:  -") != std::string::npos,
                "global report is missing the redundancy negator");
        require(call_echoes("a.bin", report) == FW_OK,
                std::string("file echoes: ") + fw_last_error());
        require(report.find("copies/b.bin") != std::string::npos,
                "file report does not name its twin");
        require(report.find("echo_negator:    -") != std::string::npos,
                "file report is missing the echo negator");
        require(call_echoes("no-such-file.bin", report) == FW_NOT_FOUND,
                "unknown target should be FW_NOT_FOUND");

        // Read-only guarantee: nothing watched moved, changed, or grew, and
        // the only new top-level entry is .fweddle.
        for (const fs::path& path : watched) {
            require(fs::last_write_time(path) == stamps[path.u8string()],
                    "scan touched " + path.string());
        }
        require(read_bytes(root / "a.bin") == original, "scan mutated a.bin");
        std::set<std::string> after;
        for (const auto& entry : fs::directory_iterator(root)) {
            after.insert(entry.path().filename().u8string());
        }
        std::set<std::string> added;
        std::set_difference(after.begin(), after.end(), before.begin(), before.end(),
                            std::inserter(added, added.begin()));
        require(added == std::set<std::string>{".fweddle"},
                "scan created something other than .fweddle");

        // Seal interplay: a sealed copy still echoes its unsealed twin, and
        // sidecars stay out of the ledger.
        std::array<char, kPathBuffer> capsule{};
        require(fw_capsule((root / "copies" / "b.bin").u8string().c_str(),
                           capsule.data(), capsule.size()) == FW_OK,
                std::string("fw_capsule: ") + fw_last_error());
        require(fw_hunk_scan(nullptr, second_path.data(), second_path.size()) == FW_OK,
                std::string("post-seal fw_hunk_scan: ") + fw_last_error());
        const ParsedLedger sealed = parse_ledger_text(read_text(fs::u8path(second_path.data())));
        const std::size_t id_capsule = file_id(sealed, "copies/b.bin.fweddle");
        require(sealed.files[id_capsule].whole == ledger.files[id_a].whole,
                "sealed copy lost its whole-file identity");
        for (const ParsedFile& entry : sealed.files) {
            require(entry.rel != "copies/b.bin", "mortal name lingered after sealing");
            require(entry.rel.find(".fwmeta") == std::string::npos,
                    "a sidecar leaked into the ledger");
            require(entry.rel.rfind(".fweddle/", 0) != 0,
                    "ledger descended into .fweddle");
        }
        require(call_echoes("a.bin", report) == FW_OK,
                std::string("post-seal echoes: ") + fw_last_error());
        require(report.find("copies/b.bin.fweddle") != std::string::npos,
                "post-seal report does not name the capsule");

        // Round-trip regression: the capsule still unseals byte-for-byte.
        std::array<char, kPathBuffer> mortal{};
        require(fw_exorcise(capsule.data(), mortal.data(), mortal.size()) == FW_OK,
                std::string("fw_exorcise: ") + fw_last_error());
        require(read_bytes(fs::u8path(mortal.data())) == original,
                "unsealed bytes differ from the original");

        std::error_code ec;
        fs::remove_all(root, ec);
        std::cout << "all hunk engine tests passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "test failure: " << error.what() << '\n';
        std::error_code ec;
        fs::remove_all(root, ec);
        return 1;
    }
}
