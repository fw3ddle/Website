#include "fweddle/fweddle.hpp"

#include <array>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <regex>
#include <stdexcept>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace {

constexpr std::size_t kBuffer = 32768;

void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}

void write_bytes(const fs::path& path, const std::vector<unsigned char>& bytes) {
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    require(static_cast<bool>(output), "could not create fixture");
    output.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
}

std::vector<unsigned char> read_bytes(const fs::path& path) {
    std::ifstream input(path, std::ios::binary);
    require(static_cast<bool>(input), "could not read fixture");
    return std::vector<unsigned char>(std::istreambuf_iterator<char>(input), {});
}

std::string read_text(const fs::path& path) {
    std::ifstream input(path, std::ios::binary);
    return std::string(std::istreambuf_iterator<char>(input), {});
}

std::string extract_uuid(const std::string& json) {
    const std::regex pattern("\\\"hunt_uuid\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"");
    std::smatch match;
    require(std::regex_search(json, match, pattern), "metadata has no Hunt_UUID");
    return match[1].str();
}

std::string call_capsule(const fs::path& path) {
    std::array<char, kBuffer> output{};
    const int status = fw_capsule(path.u8string().c_str(), output.data(), output.size());
    require(status == FW_OK, std::string("fw_capsule: ") + fw_last_error());
    return output.data();
}

std::string call_display(const fs::path& path) {
    std::array<char, kBuffer> output{};
    const int status = fw_display_name(path.u8string().c_str(), output.data(), output.size());
    require(status == FW_OK, std::string("fw_display_name: ") + fw_last_error());
    return output.data();
}

std::string call_exorcise(const fs::path& path) {
    std::array<char, kBuffer> output{};
    const int status = fw_exorcise(path.u8string().c_str(), output.data(), output.size());
    require(status == FW_OK, std::string("fw_exorcise: ") + fw_last_error());
    return output.data();
}

}  // namespace

int main() {
    const auto nonce = std::chrono::high_resolution_clock::now().time_since_epoch().count();
    const fs::path root = fs::temp_directory_path() / ("fweddle-test-" + std::to_string(nonce));
    try {
        fs::create_directories(root);
        const fs::path lexicon = root / "lexicon.json";
        {
            std::ofstream output(lexicon);
            output << "{\".pdf\":\"📄\",\".bin\":\"🧪\"}\n";
        }
        require(fw_init(root.u8string().c_str(), lexicon.u8string().c_str()) == FW_OK,
                std::string("fw_init: ") + fw_last_error());

        const std::vector<unsigned char> first_bytes = {0x00, 0x46, 0x57, 0x45, 0x44, 0x44, 0x4c, 0x45, 0xff};
        const fs::path first = root / "test.pdf";
        write_bytes(first, first_bytes);
        const fs::path first_capsule = fs::u8path(call_capsule(first));
        require(first_capsule.filename() == "test.pdf.fweddle", "first capsule name is wrong");
        require(!fs::exists(first), "mortal source survived sealing");
        require(read_bytes(first_capsule) == first_bytes, "physical bytes changed during sealing");
        require(call_display(first_capsule) == "test🍀📄", "first projection is wrong");

        {
            std::ofstream output(lexicon, std::ios::trunc);
            output << "{\".pdf\":\"📚\",\".bin\":\"🧪\"}\n";
        }
        require(call_display(first_capsule) == "test🍀📚", "runtime lexicon reload failed");
        {
            std::ofstream output(lexicon, std::ios::trunc);
            output << "{\".pdf\":\"📄\",\".bin\":\"🧪\"}\n";
        }

        std::array<char, 2> tiny{};
        const int tiny_status = fw_exorcise(first_capsule.u8string().c_str(), tiny.data(), tiny.size());
        require(tiny_status == FW_BUFFER_TOO_SMALL, "small output buffer returned wrong status");
        require(fs::exists(first_capsule), "small output buffer mutated the capsule");

        const std::vector<unsigned char> second_bytes = {1, 2, 3, 4, 5};
        write_bytes(first, second_bytes);
        const fs::path second_capsule = fs::u8path(call_capsule(first));
        require(second_capsule.filename() == "test (2).pdf.fweddle", "collision numbering is wrong");
        require(call_display(second_capsule) == "test (2)🍀📄", "collision projection is wrong");

        const fs::path display_path = root / fs::u8path("test (2)🍀📄");
        const fs::path second_mortal = fs::u8path(call_exorcise(display_path));
        require(second_mortal.filename() == "test (2).pdf", "display-name exorcism restored wrong name");
        require(read_bytes(second_mortal) == second_bytes, "physical bytes changed during exorcism");

        // Regression (v0.2.0): a bare display name with no directory prefix
        // must resolve against the current directory. v0.1.0 leaked a stale
        // std::error_code into that branch and always reported FW_NOT_FOUND.
        const std::vector<unsigned char> bare_bytes = {9, 9, 9};
        const fs::path bare = root / "bare.bin";
        write_bytes(bare, bare_bytes);
        const fs::path bare_capsule = fs::u8path(call_capsule(bare));
        require(bare_capsule.filename() == "bare.bin.fweddle", "bare capsule name is wrong");
        const fs::path previous_cwd = fs::current_path();
        fs::current_path(root);
        std::array<char, kBuffer> bare_out{};
        const int bare_status = fw_exorcise("bare🍀🧪", bare_out.data(), bare_out.size());
        fs::current_path(previous_cwd);
        require(bare_status == FW_OK,
                std::string("bare display-name exorcism: ") + fw_last_error());
        require(read_bytes(root / "bare.bin") == bare_bytes,
                "bare display-name exorcism changed bytes");

        const fs::path first_sidecar = root / ".test.pdf.fweddle.fwmeta";
        const std::string uuid = extract_uuid(read_text(first_sidecar));
        const fs::path moved_dir = root / "moved";
        fs::create_directories(moved_dir);
        const fs::path moved_capsule = moved_dir / "wandering.fweddle";
        fs::rename(first_capsule, moved_capsule);

        std::array<char, kBuffer> resurrected{};
        const int resurrect_status = fw_resurrect(uuid.c_str(), root.u8string().c_str(),
                                                  resurrected.data(), resurrected.size());
        require(resurrect_status == FW_OK, std::string("fw_resurrect: ") + fw_last_error());
        require(fs::equivalent(fs::u8path(resurrected.data()), moved_capsule), "resurrection found wrong file");
        require(fs::exists(moved_dir / ".wandering.fweddle.fwmeta"), "resurrection did not restore sidecar");
        require(call_display(moved_capsule) == "test🍀📄", "relocated projection lost its identity");

        const fs::path final_mortal = fs::u8path(call_exorcise(moved_capsule));
        require(final_mortal.filename() == "test.pdf", "relocated exorcism restored wrong name");
        require(read_bytes(final_mortal) == first_bytes, "relocated file bytes changed");

        std::error_code ec;
        fs::remove_all(root, ec);
        std::cout << "all fweddle tests passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "test failure: " << error.what() << '\n';
        std::error_code ec;
        fs::remove_all(root, ec);
        return 1;
    }
}
