#include "fweddle/fweddle.hpp"

#include <array>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace {

constexpr std::size_t kBuffer = 32768;

void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}

void write_text(const fs::path& path, const std::string& text) {
    fs::create_directories(path.parent_path());
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    require(static_cast<bool>(output), "could not create fixture " + path.string());
    output << text;
}

std::string call_capsule(const fs::path& path) {
    std::array<char, kBuffer> output{};
    const int status = fw_capsule(path.u8string().c_str(), output.data(), output.size());
    require(status == FW_OK, std::string("fw_capsule: ") + fw_last_error());
    return output.data();
}

std::string call_display(const std::string& path) {
    std::array<char, kBuffer> output{};
    const int status = fw_display_name(path.c_str(), output.data(), output.size());
    require(status == FW_OK, std::string("fw_display_name: ") + fw_last_error());
    return output.data();
}

std::string call_exorcise(const fs::path& path) {
    std::array<char, kBuffer> output{};
    const int status = fw_exorcise(path.u8string().c_str(), output.data(), output.size());
    require(status == FW_OK, std::string("fw_exorcise: ") + fw_last_error());
    return output.data();
}

int call_set(const char* extension, const char* emoji, std::string& out) {
    std::array<char, kBuffer> output{};
    const int status = fw_emote_set(extension, emoji, output.data(), output.size());
    if (status == FW_OK) out = output.data();
    return status;
}

std::string call_report() {
    std::vector<char> output(1U << 20U);
    const int status = fw_emote_report(output.data(), output.size());
    require(status == FW_OK, std::string("fw_emote_report: ") + fw_last_error());
    return output.data();
}

bool ends_with(const std::string& value, const std::string& suffix) {
    return value.size() >= suffix.size() &&
           value.compare(value.size() - suffix.size(), suffix.size(), suffix) == 0;
}

}  // namespace

int main() {
    const auto nonce = std::chrono::high_resolution_clock::now().time_since_epoch().count();
    const fs::path root = fs::temp_directory_path() / ("fweddle-emote-test-" + std::to_string(nonce));
    try {
        fs::create_directories(root);
        require(fw_init(root.u8string().c_str(), nullptr) == FW_OK,
                std::string("fw_init: ") + fw_last_error());
        const fs::path mortal = root / "fwemotes.json";
        const fs::path sealed = root / "fwemotes.json.fweddle";

        // 1. With no user lexicon at all, the report names the built-ins.
        std::string report = call_report();
        require(report.find("built-in defaults only") != std::string::npos,
                "fresh report does not name the built-in source");
        require(report.find(".pdf") != std::string::npos &&
                    report.find("📄") != std::string::npos,
                "fresh report is missing the built-in .pdf mapping");
        require(report.find("(user)") == std::string::npos,
                "fresh report claims user entries");

        // 2. Removing from nothing succeeds without conjuring a file.
        std::string path;
        require(call_set(".ghost", nullptr, path) == FW_OK,
                std::string("no-op unset: ") + fw_last_error());
        require(!fs::exists(mortal), "no-op unset conjured a fwemotes file");

        // 3. Bad inputs are rejected.
        require(call_set(nullptr, "💥", path) == FW_INVALID_ARGUMENT,
                "null extension was accepted");
        require(call_set("bad ext", "💥", path) == FW_INVALID_ARGUMENT,
                "whitespace extension was accepted");

        // 4. A first mapping creates the mortal fwemotes file.
        require(call_set(".zzz", "🦄", path) == FW_OK,
                std::string("set .zzz: ") + fw_last_error());
        require(fs::equivalent(fs::u8path(path), mortal), "set wrote to the wrong place");
        report = call_report();
        require(report.find("fwemotes.json (mortal)") != std::string::npos,
                "report does not name the mortal source");
        require(report.find("🦄   (user)") != std::string::npos,
                "report does not mark the user mapping");

        // 5. Projections honor it, including normalization and overriding a
        // built-in.
        write_text(root / "spirit.zzz", "a small spirit\n");
        const std::string spirit_capsule = call_capsule(root / "spirit.zzz");
        require(call_display(spirit_capsule) == "spirit🍀🦄",
                "user mapping not honored in a projection");
        write_text(root / "test.pdf", "papers please\n");
        const std::string pdf_capsule = call_capsule(root / "test.pdf");
        require(call_set("pdf", "📚", path) == FW_OK,
                std::string("set pdf (no dot): ") + fw_last_error());
        require(call_display(pdf_capsule) == "test🍀📚",
                "built-in override not honored");

        // 6. Unset falls back to the built-in.
        require(call_set(".pdf", "", path) == FW_OK,
                std::string("unset .pdf: ") + fw_last_error());
        require(call_display(pdf_capsule) == "test🍀📄",
                "unset did not fall back to the built-in");

        // 7. Seal the lexicon: it keeps working, because the raster is the
        // same JSON, and it appears in the world as a capsule of its own.
        const std::string lexicon_capsule = call_capsule(mortal);
        require(ends_with(lexicon_capsule, "fwemotes.json.fweddle"),
                "lexicon capsule has the wrong name");
        require(call_display(spirit_capsule) == "spirit🍀🦄",
                "sealed lexicon was not honored");
        require(call_display(lexicon_capsule) == "fwemotes🍀🧩",
                "lexicon capsule projection is wrong");
        report = call_report();
        require(report.find("fwemotes.json.fweddle (sealed)") != std::string::npos,
                "report does not name the sealed source");

        // 8. Editing while sealed performs the break-edit-reseal round trip.
        require(call_set(".zzz", "🐙", path) == FW_OK,
                std::string("set while sealed: ") + fw_last_error());
        require(ends_with(path, "fwemotes.json.fweddle"), "round trip did not reseal");
        require(!fs::exists(mortal), "round trip left a mortal copy behind");
        require(fs::exists(sealed), "round trip lost the capsule");
        require(call_display(spirit_capsule) == "spirit🍀🐙",
                "round-trip mapping not honored");

        // 9. Ambiguity guard: a stray mortal next to the capsule blocks edits,
        // and passive reads prefer the mortal file.
        write_text(mortal, "{\n  \".zzz\": \"🍩\"\n}\n");
        require(call_set(".zzz", "🌊", path) == FW_COLLISION,
                "ambiguous fwemotes state was not rejected");
        require(call_display(spirit_capsule) == "spirit🍀🍩",
                "passive read did not prefer the mortal file");
        fs::remove(mortal);
        require(call_display(spirit_capsule) == "spirit🍀🐙",
                "sealed lexicon did not resume after the stray was removed");

        // 10. Legacy location still works, and fwemotes outranks it.
        call_exorcise(fs::u8path(lexicon_capsule));
        fs::remove(mortal);
        write_text(root / ".fweddle" / "lexicon.json", "{\n  \".zzz\": \"🌵\"\n}\n");
        require(call_display(spirit_capsule) == "spirit🍀🌵",
                "legacy lexicon location was not honored");
        report = call_report();
        require(report.find(".fweddle/lexicon.json (legacy)") != std::string::npos,
                "report does not name the legacy source");
        write_text(mortal, "{\n  \".zzz\": \"🚀\"\n}\n");
        require(call_display(spirit_capsule) == "spirit🍀🚀",
                "fwemotes did not outrank the legacy location");

        // 11. An explicit --lexicon outranks everything.
        write_text(root / "explicit.json", "{\n  \".zzz\": \"🗿\"\n}\n");
        require(fw_init(root.u8string().c_str(),
                        (root / "explicit.json").u8string().c_str()) == FW_OK,
                std::string("explicit fw_init: ") + fw_last_error());
        require(call_display(spirit_capsule) == "spirit🍀🗿",
                "explicit lexicon did not outrank fwemotes");
        report = call_report();
        require(report.find("(explicit --lexicon)") != std::string::npos,
                "report does not name the explicit source");

        std::error_code ec;
        fs::remove_all(root, ec);
        std::cout << "all emote lexicon tests passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "test failure: " << error.what() << '\n';
        std::error_code ec;
        fs::remove_all(root, ec);
        return 1;
    }
}
