#include "fweddle/fweddle.hpp"

#include <array>
#include <chrono>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <regex>
#include <stdexcept>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace {

constexpr std::size_t kBuffer = 32768;
constexpr std::size_t kReport = 1U << 20U;

void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}

std::uint64_t mix64(std::uint64_t value) {
    value += 0x9E3779B97F4A7C15ULL;
    value = (value ^ (value >> 30U)) * 0xBF58476D1CE4E5B9ULL;
    value = (value ^ (value >> 27U)) * 0x94D049BB133111EBULL;
    return value ^ (value >> 31U);
}

std::vector<unsigned char> noise(std::uint64_t seed, std::size_t size) {
    std::vector<unsigned char> out;
    out.reserve(size);
    std::uint64_t state = seed;
    while (out.size() < size) {
        state = mix64(state);
        for (int shift = 56; shift >= 0 && out.size() < size; shift -= 8) {
            out.push_back(static_cast<unsigned char>(state >> shift));
        }
    }
    return out;
}

void write_bytes(const fs::path& path, const std::vector<unsigned char>& bytes) {
    fs::create_directories(path.parent_path());
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    require(static_cast<bool>(output), "could not create " + path.string());
    output.write(reinterpret_cast<const char*>(bytes.data()),
                 static_cast<std::streamsize>(bytes.size()));
}

std::vector<unsigned char> read_bytes(const fs::path& path) {
    std::ifstream input(path, std::ios::binary);
    require(static_cast<bool>(input), "could not read " + path.string());
    return std::vector<unsigned char>(std::istreambuf_iterator<char>(input), {});
}

std::string analyze(const fs::path& target, bool invert) {
    std::vector<char> report(kReport);
    const int status = fw_ref_analyze(target.u8string().c_str(), nullptr, invert ? 1 : 0,
                                      report.data(), report.size());
    require(status == FW_OK, std::string("fw_ref_analyze: ") + fw_last_error());
    return report.data();
}

fs::path reconstruct_ok(const fs::path& target) {
    std::array<char, kBuffer> output{};
    const int status = fw_ref_reconstruct(target.u8string().c_str(), output.data(), output.size());
    require(status == FW_OK, std::string("fw_ref_reconstruct: ") + fw_last_error());
    return fs::u8path(output.data());
}

std::uint64_t field(const std::string& report, const std::string& name) {
    const std::regex pattern(name + ":\\s*(\\d+)");
    std::smatch match;
    require(std::regex_search(report, match, pattern), "report missing " + name);
    return std::stoull(match[1].str());
}

}  // namespace

int main() {
    const auto nonce = std::chrono::high_resolution_clock::now().time_since_epoch().count();
    const fs::path root = fs::temp_directory_path() / ("fweddle-ref-test-" + std::to_string(nonce));
    try {
        fs::create_directories(root);
        require(fw_init(root.u8string().c_str(), nullptr) == FW_OK,
                std::string("fw_init: ") + fw_last_error());

        // A corpus of two "source" files with distinctive content.
        const std::vector<unsigned char> block_a = noise(1001, 96 * 1024);
        const std::vector<unsigned char> block_b = noise(2002, 96 * 1024);
        write_bytes(root / "sources" / "alpha.bin", block_a);
        write_bytes(root / "sources" / "beta.bin", block_b);

        // --- Case 1: target is an exact copy of a source file ---------------
        // Every hunk exists in the corpus, so the manifest is all pointers and
        // reconstruction is byte-exact.
        write_bytes(root / "copy.bin", block_a);
        std::string report = analyze(root / "copy.bin", false);
        require(report.find("EXPERIMENTAL") != std::string::npos, "missing experimental marker");
        require(field(report, "resident_bytes") == 0, "exact copy should have no resident bytes");
        require(field(report, "referenced_bytes") == block_a.size(),
                "exact copy should be fully referenced");
        require(field(report, "manifest_bytes") < block_a.size(),
                "all-pointer manifest should beat the original size");
        fs::path rebuilt = reconstruct_ok(root / "copy.bin");
        require(read_bytes(rebuilt) == block_a, "exact-copy reconstruction is not 1:1");

        // --- Case 2: target is a concatenation of both sources --------------
        std::vector<unsigned char> concat = block_a;
        concat.insert(concat.end(), block_b.begin(), block_b.end());
        write_bytes(root / "concat.bin", concat);
        report = analyze(root / "concat.bin", false);
        require(field(report, "referenced_bytes") >= (concat.size() * 8) / 10,
                "concatenation should be mostly referenced");
        rebuilt = reconstruct_ok(root / "concat.bin");
        require(read_bytes(rebuilt) == concat, "concatenation reconstruction is not 1:1");

        // --- Case 3: a unique random file -----------------------------------
        // Nothing to point to, so it is essentially all resident and the
        // manifest is LARGER than the original — but reconstruction is still
        // exactly 1:1. Correctness must not depend on savings.
        const std::vector<unsigned char> unique = noise(9999, 40 * 1024);
        write_bytes(root / "unique.bin", unique);
        report = analyze(root / "unique.bin", false);
        require(field(report, "resident_bytes") == unique.size(),
                "unique file should be fully resident");
        require(field(report, "manifest_bytes") > unique.size(),
                "hex-resident manifest should exceed the original");
        require(report.find("larger than the original") != std::string::npos,
                "report should admit it is larger");
        rebuilt = reconstruct_ok(root / "unique.bin");
        require(read_bytes(rebuilt) == unique, "unique-file reconstruction is not 1:1");

        // --- Case 4: the inversion path actually works (contrived) ----------
        // A sub-chunk-size file is a single hunk. If the corpus contains its
        // exact bitwise inverse (also a single hunk), --invert finds it and
        // reconstruction inverts it back. Without --invert it is resident.
        // This proves the path runs; the prose explains why it almost never
        // helps on real data (the inverse of random content is still random,
        // and content-defined chunking re-cuts inverted content differently).
        const std::vector<unsigned char> small = noise(4242, 1000);
        std::vector<unsigned char> inverse(small.size());
        for (std::size_t i = 0; i < small.size(); ++i) {
            inverse[i] = static_cast<unsigned char>(~small[i]);
        }
        write_bytes(root / "invsrc" / "mirror.bin", inverse);
        write_bytes(root / "small.bin", small);

        report = analyze(root / "small.bin", false);
        require(field(report, "resident_bytes") == small.size(),
                "without --invert the mirrored file should be resident");

        report = analyze(root / "small.bin", true);
        require(field(report, "inverted_bytes") == small.size(),
                "with --invert the whole file should resolve as an inverse pointer");
        require(field(report, "resident_bytes") == 0,
                "with --invert there should be nothing resident");
        rebuilt = reconstruct_ok(root / "small.bin");
        require(read_bytes(rebuilt) == small, "inverted reconstruction is not 1:1");

        // --- Case 5: dangling reference is detected, not silently wrong -----
        // Isolated root with exactly one source, so the pointer must target
        // it. Corrupt that source, then reconstruction must fail rather than
        // emit wrong bytes. (In the shared root above, identical content lives
        // in several files, so a pointer legitimately targets whichever copy
        // is indexed first — which is why this case needs its own corpus.)
        const fs::path droot = root / "isolated";
        fs::create_directories(droot);
        const std::vector<unsigned char> block_c = noise(7777, 96 * 1024);
        write_bytes(droot / "only-source.bin", block_c);
        write_bytes(droot / "clone.bin", block_c);
        require(fw_init(droot.u8string().c_str(), nullptr) == FW_OK,
                std::string("isolated fw_init: ") + fw_last_error());
        report = analyze(droot / "clone.bin", false);
        require(field(report, "resident_bytes") == 0, "isolated clone should be all pointers");
        std::vector<unsigned char> tampered = block_c;
        tampered[500] ^= 0xFF;
        write_bytes(droot / "only-source.bin", tampered);
        std::array<char, kBuffer> out{};
        const int dangling = fw_ref_reconstruct((droot / "clone.bin").u8string().c_str(),
                                                out.data(), out.size());
        require(dangling != FW_OK, "a changed source must make reconstruction fail");

        std::error_code ec;
        fs::remove_all(root, ec);
        std::cout << "all reference engine tests passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "test failure: " << error.what() << '\n';
        std::error_code ec;
        fs::remove_all(root, ec);
        return 1;
    }
}
