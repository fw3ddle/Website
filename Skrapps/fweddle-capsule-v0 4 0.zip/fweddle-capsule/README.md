# Fweddle Capsule 🍀

> A reversible, **byte-preserving** metadata layer for ordinary files — plus a
> dedup engine that only *observes*. Seal a file into a *capsule*, view it under
> a whimsical emoji projection, unseal it back to the exact original bytes, and
> let the hunk engine notate where the same content already exists. Nothing in a
> file's raster is ever rewritten.

![version](https://img.shields.io/badge/version-0.4.0-blue)
![standard](https://img.shields.io/badge/C%2B%2B-17-00599C)
![platforms](https://img.shields.io/badge/platforms-Linux%20%7C%20macOS%20%7C%20Windows-lightgrey)
![status](https://img.shields.io/badge/status-experimental-orange)

---

## What it is

Sealing `test.pdf` creates the real file `test.pdf.fweddle` and records a signed
**negator** equal to `-physical_bytes` alongside the original identity. The capsule
is then *projected* — never renamed on disk — as:

```text
test🍀📄
```

Separately, `scan` breaks every regular file in a tree into content-defined
**hunks**, hashes them, and `echoes` notates where identical hunks recur — also
expressed as negative magnitudes. And the emoji vocabulary itself is yours to
restyle: the **fwemotes** file holds your mappings, and can be sealed into a
capsule of its own — still honored, because its raster is still the same JSON.

Three ideas do all the work:

- **The raster is sacred.** The file's actual byte sequence is copied and preserved,
  never rewritten. Sealing and unsealing are lossless round-trips.
- **The negative size is metadata, not a filesystem lie.** `negative_magnitude`
  is stored as a signed integer in the capsule's metadata and validated on every
  read (`negative_magnitude == -physical_bytes`). Fweddle does **not** pretend a
  filesystem can report a negative `st_size`.
- **Dedup only observes.** The hunk engine notates duplication in a ledger; it
  never rewrites, relinks, or deletes anything to collapse it.

```mermaid
flowchart LR
    M["test.pdf<br/>mortal file"]
    C["test.pdf.fweddle<br/>real bytes — never rewritten<br/>+ negator = -physical_bytes"]
    P["projection<br/>basename + clover + soul emoji"]
    M -- "seal · fw_capsule" --> C
    C -. "fw_display_name" .-> P
    C -- "unseal · fw_exorcise" --> M
```

---

## Features in v0.4.0

| Area | What you get |
| --- | --- |
| **Core library** | A C++17 static library exposing a stable C ABI with eleven operations. |
| **CLI** | Sealing, projected directory views, reverse exorcism, projected renaming, `Hunt_UUID` recovery, hunk scans, echo reports, and emote restyling. |
| **Hunk engine** | Content-defined chunking (gear-based CDC, 2–64 KiB) plus SHA-256 over every regular file, committed to one atomic ledger. |
| **Echo reports** | Root-wide and per-file notations of where identical content recurs, expressed as negative magnitudes. |
| **Emote restyling** | `emotes list / set / unset / edit / seal / unseal`: a user lexicon (`fwemotes.json`) that is honored mortal **or** sealed, editable from the CLI, your `$EDITOR`, or the C ABI. |
| **Reference engine** | *(experimental, new)* `refs analyze / reconstruct`: replace hunks that exist elsewhere with verified pointers, store unique hunks inline, and rebuild the file 1:1 — or fail loudly if a source moved. Real savings only where real redundancy exists. |
| **Three metadata stores** | An atomic per-root registry, a portable adjacent sidecar, and (where supported) extended attributes. |
| **Extended attributes** | Original identity, signed negator, provenance, `Hunt_UUID`, and an Ouroboros backlink under `user.fweddle.*`. |
| **Collision handling** | Windows-style suffixes: `test`, `test (2)`, `test (3)`, … for both capsule and restored names. |
| **Emoji lexicon** | A hot-loaded JSON map from extension → *soul* emoji, now spanning 54 mappings (documents 📄, executables ⚙️, Apple bundles 🍎, disc images 💿, raster edits 🖌️, vector/design 🎨, images 🖼️, and more). Unknown extensions fall back to `📦`. |
| **Easter egg** | Files larger than 1 GiB receive one of 256 deterministic haiku, keyed to their `Hunt_UUID`. |
| **Transactional** | Sealing rolls back if persistent metadata cannot be committed; the ledger is replaced atomically. |

---

## Build

Requires CMake ≥ 3.16 and a C++17 compiler.

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
ctest --test-dir build --output-on-failure
```

This produces the `fweddle` CLI and the `libfweddle_core.a` static library, and
runs three suites: the capsule round-trip tests, the hunk-engine tests (which
pin SHA-256 to the FIPS test vectors and verify that hunks tile every file
exactly), and the emote-lexicon tests. A prebuilt Linux x86-64 pair with `SHA256SUMS` is included under
`release/linux-x86_64/`.

---

## Quickstart — try the alchemy

```sh
printf 'the bytes stay put\n' > test.pdf

# Seal: creates test.pdf.fweddle, bytes untouched
./build/fweddle --lexicon config/lexicon.json seal test.pdf
# test.pdf  ->  test.pdf.fweddle

# View: capsules appear under their emoji projection
./build/fweddle --lexicon config/lexicon.json view .
# test🍀📄

# Unseal: restores the original file, byte-for-byte
./build/fweddle --lexicon config/lexicon.json unseal 'test🍀📄'
# test🍀📄  ->  test.pdf
```

`unseal` accepts **either** the real capsule path (`test.pdf.fweddle`) **or** the
projected emoji name (`test🍀📄`).

To drop the emoji pair and give the file a new base name, express it as a
projected rename (this currently performs the reverse exorcism, so `NEW_BASE`
must omit `🍀`):

```sh
./build/fweddle --lexicon config/lexicon.json rename-view . 'test🍀📄' report
# restores the bytes as report.pdf
```

Then let the hunk engine notate what recurs (the lexicon is only needed for
projections, so these commands don't take it):

```sh
mkdir -p backups && cp test.pdf backups/test-2025.pdf
./build/fweddle scan
./build/fweddle echoes test.pdf
```

And restyle the vocabulary itself — then seal the lexicon so it lives in the
view like everything else:

```sh
./build/fweddle emotes set .json 📄
./build/fweddle emotes seal
# demo/fwemotes.json  ->  demo/fwemotes.json.fweddle
# projected as  fwemotes🍀📄

./build/fweddle view .
# fwemotes🍀📄
# test🍀📄
```

---

## Command reference

Global flags come **before** the subcommand:

| Flag | Meaning |
| --- | --- |
| `--root DIR` | Root directory for the registry, ledger, and lexicon lookup. Defaults to the current directory. |
| `--lexicon FILE` | Path to a JSON emoji lexicon. Overrides the built-in map and `<root>/.fweddle/lexicon.json`. |

| Command | Arguments | Description |
| --- | --- | --- |
| `seal` | `FILE...` | Seals one or more mortal files into `*.fweddle` capsules and writes reversible metadata. |
| `view` | `[DIR]` | Lists a directory, showing capsules under their emoji projection. Hides the `.fweddle/` folder and `.fwmeta` sidecars. Defaults to `--root`. |
| `unseal` | `CAPSULE_OR_EMOJI_NAME...` | Restores original files from a real capsule path or a projected display name. |
| `rename-view` | `DIR OLD_NAME NEW_BASE` | Resolves a projection, unseals it, and applies a new base name. `NEW_BASE` must omit `🍀`. |
| `resurrect` | `UUID [SEARCH_ROOT]` | Locates a relocated capsule by `Hunt_UUID` / backlink and refreshes its registry record. |
| `scan` | `[DIR]` | Splits every regular file into content-defined hunks, hashes them, and atomically rewrites the ledger under `--root`. Prints the root-wide echo summary. Defaults to `--root`. |
| `echoes` | `[FILE]` | Notates where identical hunks recur: the root-wide summary with no argument, or a per-file report. Requires a prior `scan`. |
| `emotes` | `[list]` · `set EXT EMOJI` · `unset EXT` · `edit` · `seal` · `unseal` | Manages the fwemotes user lexicon: show the effective table, upsert or remove a mapping, open it in `$VISUAL`/`$EDITOR`, or toggle its seal. `set`/`unset` work even while sealed via an automatic break-edit-reseal round trip. |
| `refs analyze` | `FILE [--invert]` | *(experimental)* Chunks `FILE`, points every hunk that already exists under `--root`, stores unique hunks inline, and writes a manifest to `<root>/.fweddle/refs/`. With `--invert`, misses are also searched as their bitwise inverse. Reports the reconstructable fraction and net-vs-original bytes. Never modifies `FILE`. |
| `refs reconstruct` | `FILE` | *(experimental)* Rebuilds `FILE` from its manifest, reading referenced hunks live and hash-verifying every hunk and the whole result. Writes `<FILE>.rebuilt`; fails rather than emit wrong bytes if a source moved or changed. |

---

## The hunk engine — dedup that only observes

`scan` walks a tree and splits every regular file into **hunks** using
content-defined chunking: a gear-based rolling fingerprint decides where each
hunk ends (minimum 2 KiB, ≈10 KiB expected, maximum 64 KiB), so identical
content produces identical hunks even when it sits at different offsets. Every
hunk — and every whole raster — is hashed with SHA-256, and the result is
committed in one atomic write to the ledger:

```text
.fweddle/hunks/ledger.json
```

`echoes` reads the ledger back and notates recurrence. In keeping with the
house style, redundancy is expressed negatively: the **echo negator** is the
count of a file's bytes that also exist somewhere else, and the root-wide
**redundancy negator** is the total weight the tree carries more than once.

```text
$ fweddle --root demo scan
hunk ledger  ->  demo/.fweddle/hunks/ledger.json
🍀 hunk ledger for demo
   files: 3   hunk sites: 29   distinct hunks: 15
   physical_bytes:      307230
   redundancy_negator:  -153600   (bytes carried more than once)

   perfect doppelgängers:
     backups/report-2025.pdf  ≡  report.pdf   (153600 bytes)

   loudest echoes:
     -153600   backups/report-2025.pdf  ↔  report.pdf   (14 hunks)

$ fweddle --root demo echoes report.pdf
🍀 echoes for report.pdf
   physical_bytes:  153600
   echo_negator:    -153600   (100.0% of this raster recurs)
   self_echo:       0
   perfect doppelgänger of: backups/report-2025.pdf
   shared with:
     -153600   backups/report-2025.pdf   (14 hunks)
```

Rules the engine lives by:

- **It only reads.** No user file is written, moved, relinked, or deleted —
  the ledger is the engine's sole output, and it replaces atomically.
- **Capsules are scanned like any other file.** Because sealing preserves the
  raster, a sealed copy is still reported as the perfect doppelgänger of its
  unsealed twin.
- **Fweddle's own artifacts stay out.** `.fweddle/` internals, `.fwmeta`
  sidecars, and symlinks are skipped.
- **Every scan is a full, deterministic pass.** The same bytes cut into the
  same hunks on every platform; two scans of an unchanged tree differ only in
  their timestamp.

Current limitations, stated plainly: the ledger is a single JSON document that
grows with the tree (roughly one line per distinct hunk), scans are not yet
incremental, reports cap their lists at the twelve loudest entries, and the CLI
allots 1 MiB for report text.

---

## Reference-backed capsules (experimental)

The hunk engine only *notates* redundancy. The reference engine acts on it: it
can replace a file's content with **pointers** to where that content already
exists, and rebuild the file from those pointers alone.

```sh
fweddle --root demo refs analyze backups/photo-copy.jpg
fweddle --root demo refs reconstruct backups/photo-copy.jpg   # -> …/photo-copy.jpg.rebuilt
```

`analyze` chunks the target the same way the hunk engine does, searches the
corpus for identical hunks, and writes a manifest under
`<root>/.fweddle/refs/`. Every hunk found elsewhere becomes a **pointer**
(source path + offset); every hunk that is unique is stored **resident** (its
bytes, inline). `reconstruct` walks the manifest, reads each referenced hunk
*live* from its source, verifies every hunk **and** the whole file against
recorded SHA-256 hashes, and writes `<target>.rebuilt`.

### What it can and cannot do

This is deduplication taken to its logical end, and it obeys deduplication's
limits. Three of them are worth stating plainly, because the design enforces
them rather than papering over them:

1. **Unique bytes have nowhere to point.** A hunk that exists nowhere else
   must be stored resident. Arbitrary or already-compressed files therefore do
   not shrink — by a simple counting argument, no reversible scheme can shrink
   *all* files. Only redundancy that genuinely exists is exploitable.
2. **Pointers into ordinary files can dangle.** References point into files
   that can be edited or deleted, which would destroy the data. So
   reconstruction never trusts a pointer: it re-hashes every hunk it reads and
   fails loudly if a source has changed, rather than emitting wrong bytes. For
   the same reason the engine never deletes your original — it only writes a
   separate `.rebuilt` file you can compare.
3. **"Invert and search again" does not beat entropy.** When a hunk is not
   found, `--invert` searches for its bitwise inverse instead. This is
   implemented and measurable, but the inverse of random content is still
   random content — the same near-zero chance of matching — and content-defined
   chunking re-cuts inverted data at different boundaries, so on real files it
   rescues essentially nothing. It is a real code path, kept honest by
   measuring it rather than assuming it.

### Measured, on real files

A 200 KiB file that is duplicated elsewhere in the tree:

```
original_bytes:     204800
hunks:              14   (referenced 14, resident 0)
referenced_bytes:   204800   (100.0% found elsewhere → pointer)
manifest_bytes:     2034
net vs original:    -202766   (a real saving)
```

A genuinely unique 48 KiB file — nothing to point to:

```
original_bytes:     49152
hunks:              6   (referenced 0, resident 6)
resident_bytes:     49152   (100.0% unique → stored inline; nowhere to point)
manifest_bytes:     99368
net vs original:    +50216   (larger than the original — mostly resident)
```

Both reconstruct **byte-for-byte** (`cmp` clean). The manifest is tiny when the
content is redundant and *larger than the original* when it is not — and it is
honest about which case you are in. Correctness never depends on the savings;
only the savings do.

---



For the capsule `test.pdf.fweddle`, Fweddle writes to as many of the following as
the platform allows. Any single store is enough to recover the original.

**1. Per-root registry (authoritative anchor)**

```text
.fweddle/registry/<Hunt_UUID>.json
```

Written atomically, one record per capsule, keyed by the capsule's deterministic
`Hunt_UUID`.

**2. Portable sidecar (cross-platform fallback)**

```text
.test.pdf.fweddle.fwmeta
```

A hidden file adjacent to the capsule. Move it *with* the capsule on filesystems
that do not preserve extended attributes.

**3. Extended attributes (where supported)**

On filesystems with user xattrs, the capsule also carries the full identity under
the `user.fweddle.*` namespace:

| Group | Keys |
| --- | --- |
| Identity | `original_name`, `mortal_name`, `original_base`, `assigned_base`, `extension` |
| Negator | `negator`, `physical_bytes` |
| Provenance | `captured_ns`, `crc64` |
| Recovery | `hunt_uuid`, `backlink` |

When xattrs survive a relocation but the sidecar is lost, `resurrect` recreates
the missing sidecar and refreshes the registry:

```sh
./build/fweddle resurrect 01234567-89ab-5def-8123-456789abcdef /place/to/search
```

### The signed negator

The negator is the conceptual heart of Fweddle:

```
negative_magnitude = -physical_bytes
```

It is stored as a signed integer (`user.fweddle.negator`, and in the sidecar and
registry JSON) and re-validated whenever a capsule is read. If the negator does
not equal the negation of the recorded byte count, the metadata is rejected as
corrupt. The value is bookkeeping — a signed shadow of the file's real size — not
a claim that the file occupies negative space on the drive. The hunk engine's
echo negator extends the same idea: the capsule negator says what a file weighs;
the echo negator says how much of that weight is already carried elsewhere.

---

## The emoji lexicon

A capsule's projection is `basename` + 🍀 (clover separator) + a **soul emoji**
chosen from the file's extension. The lexicon is a plain JSON map, re-read on
every lookup; unknown extensions fall back to `📦`.

Resolution order:

1. An explicit `--lexicon FILE`.
2. `<root>/fwemotes.json` — the mortal user lexicon.
3. `<root>/fwemotes.json.fweddle` — the same lexicon, sealed.
4. `<root>/.fweddle/lexicon.json` — the legacy hidden location.
5. The built-in defaults.

A few of the shipped mappings (`config/lexicon.json`):

| Extension | Soul |
| --- | --- |
| `.pdf` `.doc` `.docx` | 📄 |
| `.txt` `.md` | 📝 |
| `.png` `.jpg` `.gif` `.webp` | 🖼️ |
| `.mp4` `.mov` `.mkv` | 🎞️ |
| `.zip` `.7z` `.tar` | 🗜️ |
| `.cpp` `.hpp` | ⚙️ |
| *(anything else)* | 📦 |

### Restyling — the fwemotes file

Your mappings live in **`fwemotes.json`** at the root, layered over the
built-ins:

```text
$ fweddle emotes set .zzz 🦄
.zzz  ->  🦄   committed to fwemotes.json

$ fweddle emotes list
🍀 emote lexicon — source: fwemotes.json (mortal)
   .json  🧩
   .pdf   📄
   .zzz   🦄   (user)
   fallback  📦
```

`emotes edit` opens the file in `$VISUAL` / `$EDITOR` — the CLI-native "pop-up
window". A real GUI dialog would mean adopting a toolkit dependency, which this
core deliberately avoids; instead, `fw_emote_set` and `fw_emote_report` exist
precisely so a future GUI can be a thin shell over the same ABI.

The delightful part: the lexicon is an ordinary file, so it can be **sealed**.
Because sealing never rewrites bytes, the capsule's raster is still the same
JSON, and projections keep honoring it while it sits in the view as a capsule
of its own:

```text
$ fweddle emotes seal
fwemotes.json  ->  fwemotes.json.fweddle
projected as  fwemotes🍀🧩

$ fweddle view .
fwemotes🍀🧩
spirit🍀🦄
```

Want it to read `fwemotes🍀📄` instead? The lexicon can restyle *itself*:
`fweddle emotes set .json 📄`.

Mutating a sealed lexicon would rewrite a capsule's raster — forbidden — so
`emotes set`, `unset`, and `edit` perform an automatic round trip: break the
seal, edit the mortal JSON atomically, seal a fresh capsule. Each step is
individually atomic and narrated; if a reseal fails, the mapping is already
safe in the mortal file and the error says so. If both `fwemotes.json` and
`fwemotes.json.fweddle` somehow exist at once, edits refuse (`FW_COLLISION`)
until you resolve the ambiguity — passive lookups prefer the mortal file.

### Easter egg — the 1 GiB haiku

Seal a file larger than 1 GiB and its metadata gains a deterministic three-line
haiku, selected as one of 256 possibilities from the capsule's `Hunt_UUID`. The
same file always yields the same poem.

---

## Deliberate safety boundary

Fweddle is intentionally conservative about what it touches. The core does **not**:

- write MFT / journal slack, registry hive internals, PNG chunks, neighboring
  timestamps, or syscall tables — those would corrupt unrelated state and
  contradict byte preservation;
- expose a negative `st_size` — the negative value lives in capsule metadata, not
  in the filesystem;
- reclaim duplicated space — the hunk engine notates; collapsing echoes by
  rewriting, relinking, or deleting rasters would break byte preservation and is
  deferred to a separate, explicitly opt-in tool;
- inject itself into every application's `readdir`. This release ships opt-in
  `fweddle view` instead. A later FUSE / WinFsp / macFUSE adapter can call this
  same core, unchanged, to make projections transparent in Explorer / Finder.

The release library is hundreds of kilobytes, not 12 KB: portable
`std::filesystem`, JSON handling, SHA-256, recovery, and validation all carry
real weight. A 12 KB edition would require a separate, platform-specific,
no-STL core with a smaller feature set.

---

## C API

Include `fweddle/fweddle.hpp` and link `libfweddle_core.a`. Every function returns
an `fw_status` (as `int`). Output buffers are **caller-owned** and receive UTF-8
paths, display names, or report text. The symbols are `extern "C"`, so the ABI is
callable from C and other languages; the shipped header itself is C++.

| Function | Purpose |
| --- | --- |
| `fw_init(root, lexicon_path)` | Initializes the process-wide core. `nullptr` root ⇒ current directory; `nullptr` lexicon ⇒ built-in map (plus `<root>/.fweddle/lexicon.json` if present). |
| `fw_capsule(path, out, cap)` | Renames a mortal file to `*.fweddle` and writes reversible metadata. |
| `fw_display_name(capsule, out, cap)` | Projects a capsule as `basename` + clover + soul emoji. |
| `fw_exorcise(capsule_or_display, out, cap)` | Resolves a real capsule path or a projected display path and restores the mortal filename. |
| `fw_resurrect(uuid, search_root, out, cap)` | Finds a relocated capsule by `Hunt_UUID` / backlink and refreshes its registry record. |
| `fw_hunk_scan(search_root, out, cap)` | Chunks and hashes every regular file beneath `search_root` (`nullptr` ⇒ the init root) and atomically rewrites `<root>/.fweddle/hunks/ledger.json`. |
| `fw_hunk_echoes(target, out, cap)` | Writes a UTF-8 echo report — root-wide for `nullptr`, per-file otherwise. |
| `fw_emote_set(ext, emoji, out, cap)` | Upserts one mapping in the fwemotes lexicon (`nullptr`/`""` emoji removes it), handling the sealed round trip. Returns the lexicon's final path. |
| `fw_emote_report(out, cap)` | Writes the effective lexicon table: built-ins merged with the user file, user entries marked, active source named. |
| `fw_ref_analyze(target, corpus_root, invert, out, cap)` | *(experimental)* Chunks `target`, points hunks found under `corpus_root` (`nullptr` ⇒ init root), stores unique hunks resident, and writes a manifest. `invert` also searches misses as their bitwise inverse. `target` is never modified. |
| `fw_ref_reconstruct(target_or_manifest, out, cap)` | *(experimental)* Rebuilds a target from its manifest, hash-verifying every hunk and the whole file. Writes `<target>.rebuilt` and returns its path; fails rather than produce wrong bytes. |
| `fw_last_error()` | Human-readable message for the last failure on the calling thread. |

### Status codes

| Code | Value | Meaning |
| --- | --- | --- |
| `FW_OK` | 0 | Success. |
| `FW_INVALID_ARGUMENT` | 1 | A null or malformed argument. |
| `FW_NOT_INITIALIZED` | 2 | `fw_init` has not run. |
| `FW_NOT_FOUND` | 3 | The target file, capsule, or ledger does not exist. |
| `FW_ALREADY_CAPSULED` | 4 | The path is already a capsule. |
| `FW_IO_ERROR` | 5 | A filesystem read/write failed. |
| `FW_BAD_METADATA` | 6 | Metadata or the ledger is missing, corrupt, or failed validation. |
| `FW_BUFFER_TOO_SMALL` | 7 | The caller's output buffer was too small. |
| `FW_COLLISION` | 8 | No collision-free name could be allocated. |

### Minimal example (C++, using the C ABI)

```cpp
#include "fweddle/fweddle.hpp"
#include <cstdio>
#include <vector>

int main() {
    if (fw_init(nullptr, "config/lexicon.json") != FW_OK) {
        std::fprintf(stderr, "init: %s\n", fw_last_error());
        return 1;
    }

    char capsule[4096];
    if (fw_capsule("test.pdf", capsule, sizeof capsule) != FW_OK) {
        std::fprintf(stderr, "seal: %s\n", fw_last_error());
        return 1;
    }
    std::printf("sealed    -> %s\n", capsule);  // test.pdf.fweddle

    char shown[4096];
    fw_display_name(capsule, shown, sizeof shown);
    std::printf("projected -> %s\n", shown);    // test🍀📄

    char ledger[4096];
    fw_hunk_scan(nullptr, ledger, sizeof ledger);
    std::vector<char> report(1 << 20);
    if (fw_hunk_echoes(nullptr, report.data(), report.size()) == FW_OK) {
        std::printf("%s", report.data());       // the root-wide echo summary
    }

    char restored[4096];
    fw_exorcise(shown, restored, sizeof restored);
    std::printf("restored  -> %s\n", restored); // test.pdf
    return 0;
}
```

---

## Platform support

| Platform | Extended attributes | Notes |
| --- | --- | --- |
| **Linux** | ✅ `user.fweddle.*` | Full metadata in xattrs, sidecar, and registry. |
| **macOS** | ⚠️ requested | The same keys are requested; the sidecar remains authoritative on volumes that reject them. |
| **Windows / Android / other** | ❌ | The portable sidecar and registry work without xattrs. Transparent Explorer / Finder / Storage-Access views require a separate signed platform adapter. |

The hunk engine has no platform-specific code: it needs only `std::filesystem`
and works the same everywhere, including on filesystems without xattrs.

Prebuilt binaries ship for Linux x86-64 only; `release/README.md` documents how
to produce `fweddle.exe` (via `cross/windows-mingw.cmake`) and Android builds,
and why `.apk`/`.ipa` are app packages that must come from a platform adapter
app linking `libfweddle_core`, not from this repository directly.

---

## Project layout

```text
fweddle-capsule/
├── CMakeLists.txt
├── README.md
├── config/
│   └── lexicon.json           # extension → soul-emoji map
├── include/
│   └── fweddle/
│       └── fweddle.hpp         # public C ABI (eleven operations)
├── src/
│   ├── main.cpp                # CLI
│   ├── fweddle.cpp             # capsule core
│   ├── hunks.cpp               # hunk engine: CDC, SHA-256, ledger, echoes
│   ├── emotes.cpp             # emote restyling: fwemotes upserts + report
│   ├── refs.cpp               # reference-backed capsules (experimental)
│   └── internal.hpp            # shared plumbing between the modules
├── tests/
│   ├── test_core.cpp           # capsule round-trip suite (ctest)
│   ├── test_hunks.cpp          # hunk engine suite: SHA-256 vectors, tiling,
│   │                           #   duplicate/shift detection, read-only check
│   ├── test_emotes.cpp         # emote suite: resolution order, sealed reads,
│   │                           #   round trips, ambiguity guard, legacy/explicit
│   └── test_refs.cpp           # reference engine: pointer/resident, dangling,
│                               #   whole-hash guard, inversion path
├── bench/
│   └── measure_seal_overhead.py  # reproduces the storage-cost measurements
├── cross/
│   └── windows-mingw.cmake     # one-command fweddle.exe cross-build
└── release/
    ├── README.md               # what ships, how to build the rest, and why
    └── linux-x86_64/
        ├── fweddle             # prebuilt CLI
        ├── libfweddle_core.a   # prebuilt static library
        └── SHA256SUMS
```

---

## Roadmap

- A FUSE / WinFsp / macFUSE adapter so projections appear transparently in the OS
  file manager, calling the existing core without changing the capsule format.
- Opt-in reclamation as a separate tool: collapsing echoes via filesystem
  reflinks where supported, never by rewriting rasters in place. *(The
  experimental reference engine is the safe first step — it proves 1:1
  reconstruction from pointers via a manifest; in-place reflink collapse
  remains future work.)*
- Promoting the reference engine past experimental: pointing into a managed,
  refcounted hunk store rather than into mutable user files, so references
  cannot dangle by construction.
- Incremental scanning and a compact binary ledger for very large trees.
- A small graphical front-end for emote editing — `fw_emote_set` and
  `fw_emote_report` make it a thin shell over the existing ABI.
- An optional no-STL, platform-specific core for size-constrained builds.

---

## Glossary

| Term | Meaning |
| --- | --- |
| **Capsule** | The real `*.fweddle` file created by sealing. |
| **Raster** | The file's actual byte sequence — copied and preserved, never rewritten. |
| **Mortal file** | The ordinary, un-sealed original (e.g. `test.pdf`). |
| **Negator** | The stored signed integer `-physical_bytes`; capsule metadata, not a filesystem size. |
| **Projection** | The emoji display name (`basename` + 🍀 + soul emoji); a view, not a rename. |
| **Soul emoji** | The per-extension emoji from the lexicon. |
| **Fwemotes** | The user lexicon (`fwemotes.json`), honored mortal or sealed, layered over the built-ins. |
| **Hunk** | A content-defined slice of a raster (2–64 KiB), identified by its SHA-256. |
| **Echo** | The recurrence of one hunk at more than one site. |
| **Echo negator** | The bytes of a file that also exist elsewhere, expressed negatively. |
| **Ledger** | The atomic record of every hunk and site, at `.fweddle/hunks/ledger.json`. |
| **Doppelgänger** | A file whose whole-raster SHA-256 matches another file's. |
| **Hunt_UUID** | The capsule's deterministic identifier; the registry key and recovery handle. |
| **Backlink** | An Ouroboros pointer used together with `Hunt_UUID` for `resurrect`. |
| **Sidecar** | The adjacent `.<name>.fwmeta` fallback file for platforms without xattrs. |
| **Registry** | The atomic per-root store at `.fweddle/registry/<Hunt_UUID>.json`. |
| **Reference-backed capsule** | *(experimental)* A file described by a manifest of pointers plus resident bytes, reconstructable 1:1. |
| **Pointer hunk** | A hunk stored as a reference (source path + offset) because identical content exists elsewhere. |
| **Resident hunk** | A hunk whose bytes are stored inline in the manifest because they exist nowhere else. |
| **Manifest** | The `*.fwref.json` description of a target's hunks, under `.fweddle/refs/`, used to reconstruct it. |

---

## License

No license file ships with this release. Add one before distributing.
