// The reference engine (EXPERIMENTAL): reference-backed capsules.
//
// `fw_ref_analyze` chunks a target file, searches a corpus for identical
// hunks, and writes a manifest that stores a *pointer* for every hunk found
// elsewhere and the raw bytes ("resident") for every hunk that is not. It can
// optionally run an inversion pass over the misses.
//
// `fw_ref_reconstruct` rebuilds the original purely from the manifest:
// referenced hunks are read live from their source files and hash-verified,
// resident hunks come from the manifest, and the whole result is checked
// against the recorded SHA-256. A moved or edited source is detected and the
// reconstruction fails loudly rather than producing wrong bytes.
//
// Honest limits, enforced by the design rather than hidden by it:
//   * A hunk that exists nowhere else has nowhere to point, so it is stored
//     resident. Arbitrary files therefore do not shrink; only redundancy does.
//   * References point into ordinary files that can change. That is a data-loss
//     trap unless verified, so reconstruction verifies every hunk and never
//     trusts a stale pointer.
// This module never modifies or deletes the target; it only writes a manifest
// and, on reconstruct, a separate <target>.rebuilt file.

#include "fweddle/fweddle.hpp"

#include "internal.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <map>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace {

constexpr std::uint32_t kMinHunk = 2048;
constexpr std::uint32_t kMaxHunk = 65536;
constexpr std::uint32_t kMaskBits = 13;
constexpr std::uint64_t kBoundaryMask = (1ULL << kMaskBits) - 1ULL;
constexpr int kManifestSchema = 1;

// --- gear table (deterministic) -------------------------------------------

std::uint64_t mix64(std::uint64_t value) {
    value += 0x9E3779B97F4A7C15ULL;
    value = (value ^ (value >> 30U)) * 0xBF58476D1CE4E5B9ULL;
    value = (value ^ (value >> 27U)) * 0x94D049BB133111EBULL;
    return value ^ (value >> 31U);
}

const std::array<std::uint64_t, 256>& gear_table() {
    static const std::array<std::uint64_t, 256> table = [] {
        std::array<std::uint64_t, 256> built{};
        for (std::size_t i = 0; i < built.size(); ++i) {
            built[i] = mix64(0xF3EDD1E5EA1C10FEULL + i);
        }
        return built;
    }();
    return table;
}

// --- SHA-256 (FIPS 180-4), one-shot ----------------------------------------

struct Sha256 {
    std::uint32_t state[8];
    std::uint64_t length = 0;
    unsigned char block[64];
    std::size_t buffered = 0;

    Sha256() { reset(); }

    void reset() {
        static const std::uint32_t initial[8] = {
            0x6a09e667U, 0xbb67ae85U, 0x3c6ef372U, 0xa54ff53aU,
            0x510e527fU, 0x9b05688cU, 0x1f83d9abU, 0x5be0cd19U};
        std::memcpy(state, initial, sizeof state);
        length = 0;
        buffered = 0;
    }

    static std::uint32_t rotr(std::uint32_t value, unsigned amount) {
        return (value >> amount) | (value << (32U - amount));
    }

    void compress(const unsigned char* chunk) {
        static const std::uint32_t k[64] = {
            0x428a2f98U, 0x71374491U, 0xb5c0fbcfU, 0xe9b5dba5U, 0x3956c25bU,
            0x59f111f1U, 0x923f82a4U, 0xab1c5ed5U, 0xd807aa98U, 0x12835b01U,
            0x243185beU, 0x550c7dc3U, 0x72be5d74U, 0x80deb1feU, 0x9bdc06a7U,
            0xc19bf174U, 0xe49b69c1U, 0xefbe4786U, 0x0fc19dc6U, 0x240ca1ccU,
            0x2de92c6fU, 0x4a7484aaU, 0x5cb0a9dcU, 0x76f988daU, 0x983e5152U,
            0xa831c66dU, 0xb00327c8U, 0xbf597fc7U, 0xc6e00bf3U, 0xd5a79147U,
            0x06ca6351U, 0x14292967U, 0x27b70a85U, 0x2e1b2138U, 0x4d2c6dfcU,
            0x53380d13U, 0x650a7354U, 0x766a0abbU, 0x81c2c92eU, 0x92722c85U,
            0xa2bfe8a1U, 0xa81a664bU, 0xc24b8b70U, 0xc76c51a3U, 0xd192e819U,
            0xd6990624U, 0xf40e3585U, 0x106aa070U, 0x19a4c116U, 0x1e376c08U,
            0x2748774cU, 0x34b0bcb5U, 0x391c0cb3U, 0x4ed8aa4aU, 0x5b9cca4fU,
            0x682e6ff3U, 0x748f82eeU, 0x78a5636fU, 0x84c87814U, 0x8cc70208U,
            0x90befffaU, 0xa4506cebU, 0xbef9a3f7U, 0xc67178f2U};
        std::uint32_t w[64];
        for (int t = 0; t < 16; ++t) {
            w[t] = (static_cast<std::uint32_t>(chunk[4 * t]) << 24U) |
                   (static_cast<std::uint32_t>(chunk[4 * t + 1]) << 16U) |
                   (static_cast<std::uint32_t>(chunk[4 * t + 2]) << 8U) |
                   static_cast<std::uint32_t>(chunk[4 * t + 3]);
        }
        for (int t = 16; t < 64; ++t) {
            const std::uint32_t s0 = rotr(w[t - 15], 7) ^ rotr(w[t - 15], 18) ^ (w[t - 15] >> 3U);
            const std::uint32_t s1 = rotr(w[t - 2], 17) ^ rotr(w[t - 2], 19) ^ (w[t - 2] >> 10U);
            w[t] = w[t - 16] + s0 + w[t - 7] + s1;
        }
        std::uint32_t a = state[0], b = state[1], c = state[2], d = state[3];
        std::uint32_t e = state[4], f = state[5], g = state[6], h = state[7];
        for (int t = 0; t < 64; ++t) {
            const std::uint32_t big_s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
            const std::uint32_t choose = (e & f) ^ (~e & g);
            const std::uint32_t temp1 = h + big_s1 + choose + k[t] + w[t];
            const std::uint32_t big_s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
            const std::uint32_t majority = (a & b) ^ (a & c) ^ (b & c);
            const std::uint32_t temp2 = big_s0 + majority;
            h = g; g = f; f = e; e = d + temp1; d = c; c = b; b = a; a = temp1 + temp2;
        }
        state[0] += a; state[1] += b; state[2] += c; state[3] += d;
        state[4] += e; state[5] += f; state[6] += g; state[7] += h;
    }

    void update(const unsigned char* data, std::size_t size) {
        length += size;
        if (buffered > 0) {
            const std::size_t wanted = 64 - buffered;
            const std::size_t taken = size < wanted ? size : wanted;
            std::memcpy(block + buffered, data, taken);
            buffered += taken;
            data += taken;
            size -= taken;
            if (buffered == 64) { compress(block); buffered = 0; }
        }
        while (size >= 64) { compress(data); data += 64; size -= 64; }
        if (size > 0) { std::memcpy(block, data, size); buffered = size; }
    }

    std::array<unsigned char, 32> finish() {
        const std::uint64_t bits = length * 8ULL;
        const unsigned char one = 0x80, zero = 0x00;
        update(&one, 1);
        while (buffered != 56) { update(&zero, 1); }
        unsigned char trailer[8];
        for (int i = 0; i < 8; ++i) trailer[i] = static_cast<unsigned char>(bits >> (56 - 8 * i));
        update(trailer, 8);
        std::array<unsigned char, 32> digest{};
        for (int i = 0; i < 8; ++i) {
            digest[4 * i] = static_cast<unsigned char>(state[i] >> 24U);
            digest[4 * i + 1] = static_cast<unsigned char>(state[i] >> 16U);
            digest[4 * i + 2] = static_cast<unsigned char>(state[i] >> 8U);
            digest[4 * i + 3] = static_cast<unsigned char>(state[i]);
        }
        return digest;
    }
};

std::string hex_of(const unsigned char* data, std::size_t size) {
    static const char* alphabet = "0123456789abcdef";
    std::string out;
    out.reserve(size * 2);
    for (std::size_t i = 0; i < size; ++i) {
        out.push_back(alphabet[data[i] >> 4U]);
        out.push_back(alphabet[data[i] & 0x0FU]);
    }
    return out;
}

std::string sha_hex(const unsigned char* data, std::size_t size) {
    Sha256 hasher;
    hasher.update(data, size);
    const auto digest = hasher.finish();
    return hex_of(digest.data(), digest.size());
}

std::optional<std::vector<unsigned char>> hex_to_bytes(const std::string& hex) {
    if (hex.size() % 2 != 0) return std::nullopt;
    std::vector<unsigned char> out;
    out.reserve(hex.size() / 2);
    const auto nibble = [](char c) -> int {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        return -1;
    };
    for (std::size_t i = 0; i < hex.size(); i += 2) {
        const int hi = nibble(hex[i]);
        const int lo = nibble(hex[i + 1]);
        if (hi < 0 || lo < 0) return std::nullopt;
        out.push_back(static_cast<unsigned char>((hi << 4) | lo));
    }
    return out;
}

// --- chunking --------------------------------------------------------------

struct HunkRecord {
    std::uint64_t offset = 0;
    std::uint32_t length = 0;
    std::string sha;
};

std::vector<HunkRecord> chunk_buffer(const std::vector<unsigned char>& data) {
    std::vector<HunkRecord> out;
    const auto& gear = gear_table();
    std::uint64_t fingerprint = 0;
    std::size_t start = 0;
    for (std::size_t i = 0; i < data.size(); ++i) {
        fingerprint = (fingerprint << 1U) + gear[data[i]];
        const std::uint32_t length = static_cast<std::uint32_t>(i + 1 - start);
        const bool boundary =
            (length >= kMinHunk && (fingerprint & kBoundaryMask) == 0) || length == kMaxHunk;
        if (boundary) {
            out.push_back({start, length, sha_hex(data.data() + start, length)});
            start = i + 1;
            fingerprint = 0;
        }
    }
    if (start < data.size()) {
        const std::uint32_t length = static_cast<std::uint32_t>(data.size() - start);
        out.push_back({start, length, sha_hex(data.data() + start, length)});
    }
    return out;
}

// --- file helpers ----------------------------------------------------------

std::optional<std::vector<unsigned char>> read_all(const fs::path& path) {
    std::ifstream input(path, std::ios::binary);
    if (!input) return std::nullopt;
    std::vector<unsigned char> data(std::istreambuf_iterator<char>(input), {});
    if (!input.good() && !input.eof()) return std::nullopt;
    return data;
}

std::optional<std::vector<unsigned char>> read_span(const fs::path& path,
                                                    std::uint64_t offset,
                                                    std::uint32_t length) {
    std::ifstream input(path, std::ios::binary);
    if (!input) return std::nullopt;
    input.seekg(static_cast<std::streamoff>(offset));
    if (!input) return std::nullopt;
    std::vector<unsigned char> data(length);
    input.read(reinterpret_cast<char*>(data.data()), static_cast<std::streamsize>(length));
    if (static_cast<std::uint32_t>(input.gcount()) != length) return std::nullopt;
    return data;
}

bool read_file_text(const fs::path& path, std::string& text) {
    std::ifstream input(path, std::ios::binary);
    if (!input) return false;
    std::ostringstream buffer;
    buffer << input.rdbuf();
    if (!input.good() && !input.eof()) return false;
    text = buffer.str();
    return true;
}

bool is_sidecar_name(const std::string& name) {
    return !name.empty() && name.front() == '.' && name.size() >= 7 &&
           name.compare(name.size() - 7, 7, ".fwmeta") == 0;
}

// --- corpus index ----------------------------------------------------------

struct SourceSite {
    std::string rel;
    std::uint64_t offset = 0;
    std::uint32_t length = 0;
};

// hash -> first place that hash was seen in the corpus.
std::map<std::string, SourceSite> build_index(const fs::path& corpus_root,
                                              const fs::path& target_abs) {
    std::map<std::string, SourceSite> index;
    std::error_code ec;
    fs::recursive_directory_iterator iterator(
        corpus_root, fs::directory_options::skip_permission_denied, ec);
    if (ec) return index;
    const fs::recursive_directory_iterator end;
    for (; iterator != end; iterator.increment(ec)) {
        if (ec) { ec.clear(); continue; }
        const auto& entry = *iterator;
        if (entry.is_directory(ec) && entry.path().filename() == ".fweddle") {
            iterator.disable_recursion_pending();
            continue;
        }
        if (!entry.is_regular_file(ec) || entry.is_symlink(ec)) continue;
        if (is_sidecar_name(entry.path().filename().string())) continue;
        if (fs::equivalent(entry.path(), target_abs, ec)) continue;
        const auto bytes = read_all(entry.path());
        if (!bytes) continue;
        const std::string rel =
            entry.path().lexically_relative(corpus_root).lexically_normal().generic_u8string();
        for (const HunkRecord& hunk : chunk_buffer(*bytes)) {
            auto it = index.find(hunk.sha);
            if (it == index.end()) {
                index.emplace(hunk.sha, SourceSite{rel, hunk.offset, hunk.length});
            }
        }
    }
    return index;
}

// --- manifest --------------------------------------------------------------

std::string escape(const std::string& value) {
    std::ostringstream out;
    for (unsigned char c : value) {
        switch (c) {
            case '\\': out << "\\\\"; break;
            case '"': out << "\\\""; break;
            case '\n': out << "\\n"; break;
            case '\r': out << "\\r"; break;
            case '\t': out << "\\t"; break;
            default:
                if (c < 0x20) {
                    static const char* alphabet = "0123456789abcdef";
                    out << "\\u00" << alphabet[c >> 4U] << alphabet[c & 0x0FU];
                } else {
                    out << static_cast<char>(c);
                }
        }
    }
    return out.str();
}

struct ManifestHunk {
    char kind = 'R';  // 'R' resident, 'P' pointer, 'I' inverted pointer
    std::string sha;  // sha of the ORIGINAL hunk
    std::uint32_t length = 0;
    std::string hex;  // resident only
    std::string src;  // pointer/inverted only
    std::uint64_t offset = 0;
};

struct Manifest {
    std::string target;
    std::string original_path;  // absolute, generic
    std::string whole_sha256;
    std::uint64_t bytes = 0;
    std::string corpus_root;  // absolute, generic
    std::int64_t analyzed_ns = 0;
    std::uint64_t referenced_bytes = 0;
    std::uint64_t resident_bytes = 0;
    std::uint64_t inverted_bytes = 0;
    std::vector<ManifestHunk> hunks;
};

std::string emit_manifest(const Manifest& m) {
    std::ostringstream out;
    out << "{\n"
        << "  \"schema\": " << kManifestSchema << ",\n"
        << "  \"kind\": \"fwref\",\n"
        << "  \"algo\": \"sha256\",\n"
        << "  \"cdc_min\": " << kMinHunk << ",\n"
        << "  \"cdc_mask_bits\": " << kMaskBits << ",\n"
        << "  \"cdc_max\": " << kMaxHunk << ",\n"
        << "  \"target\": \"" << escape(m.target) << "\",\n"
        << "  \"original_path\": \"" << escape(m.original_path) << "\",\n"
        << "  \"whole_sha256\": \"" << m.whole_sha256 << "\",\n"
        << "  \"bytes\": " << m.bytes << ",\n"
        << "  \"corpus_root\": \"" << escape(m.corpus_root) << "\",\n"
        << "  \"analyzed_ns\": " << m.analyzed_ns << ",\n"
        << "  \"referenced_bytes\": " << m.referenced_bytes << ",\n"
        << "  \"resident_bytes\": " << m.resident_bytes << ",\n"
        << "  \"inverted_bytes\": " << m.inverted_bytes << ",\n"
        << "  \"hunks\": [";
    for (std::size_t i = 0; i < m.hunks.size(); ++i) {
        const ManifestHunk& h = m.hunks[i];
        out << (i == 0 ? "" : ",") << "\n    [\"" << h.kind << "\", \"" << h.sha << "\", "
            << h.length << ", ";
        if (h.kind == 'R') {
            out << "\"" << h.hex << "\"]";
        } else {
            out << "\"" << escape(h.src) << "\", " << h.offset << "]";
        }
    }
    out << (m.hunks.empty() ? "" : "\n  ") << "]\n}\n";
    return out.str();
}

// A small hand-written scanner, matching the ledger's style.
struct Scanner {
    const std::string& text;
    std::size_t pos = 0;
    explicit Scanner(const std::string& source) : text(source) {}
    void skip_ws() {
        while (pos < text.size() &&
               (text[pos] == ' ' || text[pos] == '\n' || text[pos] == '\r' || text[pos] == '\t'))
            ++pos;
    }
    bool eat(char wanted) { skip_ws(); if (pos < text.size() && text[pos] == wanted) { ++pos; return true; } return false; }
    bool peek(char wanted) { skip_ws(); return pos < text.size() && text[pos] == wanted; }
    bool string_value(std::string& out) {
        skip_ws();
        if (pos >= text.size() || text[pos] != '"') return false;
        ++pos;
        out.clear();
        while (pos < text.size()) {
            const char c = text[pos++];
            if (c == '"') return true;
            if (c != '\\') { out.push_back(c); continue; }
            if (pos >= text.size()) return false;
            const char escaped = text[pos++];
            switch (escaped) {
                case '\\': out.push_back('\\'); break;
                case '"': out.push_back('"'); break;
                case 'n': out.push_back('\n'); break;
                case 'r': out.push_back('\r'); break;
                case 't': out.push_back('\t'); break;
                case 'u': {
                    if (pos + 4 > text.size()) return false;
                    unsigned value = 0;
                    for (int i = 0; i < 4; ++i) {
                        const char hh = text[pos++];
                        value <<= 4U;
                        if (hh >= '0' && hh <= '9') value |= static_cast<unsigned>(hh - '0');
                        else if (hh >= 'a' && hh <= 'f') value |= static_cast<unsigned>(hh - 'a' + 10);
                        else if (hh >= 'A' && hh <= 'F') value |= static_cast<unsigned>(hh - 'A' + 10);
                        else return false;
                    }
                    if (value < 0x80U) out.push_back(static_cast<char>(value));
                    else if (value < 0x800U) {
                        out.push_back(static_cast<char>(0xC0U | (value >> 6U)));
                        out.push_back(static_cast<char>(0x80U | (value & 0x3FU)));
                    } else {
                        out.push_back(static_cast<char>(0xE0U | (value >> 12U)));
                        out.push_back(static_cast<char>(0x80U | ((value >> 6U) & 0x3FU)));
                        out.push_back(static_cast<char>(0x80U | (value & 0x3FU)));
                    }
                    break;
                }
                default: return false;
            }
        }
        return false;
    }
    bool u64_value(std::uint64_t& out) {
        skip_ws();
        const std::size_t start = pos;
        while (pos < text.size() && text[pos] >= '0' && text[pos] <= '9') ++pos;
        if (pos == start) return false;
        try { out = std::stoull(text.substr(start, pos - start)); } catch (...) { return false; }
        return true;
    }
    bool i64_value(std::int64_t& out) {
        skip_ws();
        const std::size_t start = pos;
        if (pos < text.size() && text[pos] == '-') ++pos;
        const std::size_t digits = pos;
        while (pos < text.size() && text[pos] >= '0' && text[pos] <= '9') ++pos;
        if (pos == digits) return false;
        try { out = std::stoll(text.substr(start, pos - start)); } catch (...) { return false; }
        return true;
    }
    bool key(const char* name) { std::string parsed; return string_value(parsed) && parsed == name && eat(':'); }
    // Skip a string value we do not need.
    bool skip_string() { std::string ignore; return string_value(ignore); }
    bool skip_u64() { std::uint64_t ignore; return u64_value(ignore); }
};

bool parse_manifest(const std::string& text, Manifest& m, std::string& error) {
    Scanner s(text);
    const auto fail = [&error](const char* what) { error = what; return false; };
    std::uint64_t schema = 0;
    std::string kind, algo;
    if (!s.eat('{')) return fail("manifest is not an object");
    if (!s.key("schema") || !s.u64_value(schema) || !s.eat(',')) return fail("bad schema");
    if (schema != static_cast<std::uint64_t>(kManifestSchema)) return fail("unsupported schema");
    if (!s.key("kind") || !s.string_value(kind) || !s.eat(',') || kind != "fwref")
        return fail("not a fwref manifest");
    if (!s.key("algo") || !s.string_value(algo) || !s.eat(',') || algo != "sha256")
        return fail("unsupported hash algorithm");
    if (!s.key("cdc_min") || !s.skip_u64() || !s.eat(',')) return fail("bad cdc_min");
    if (!s.key("cdc_mask_bits") || !s.skip_u64() || !s.eat(',')) return fail("bad cdc_mask_bits");
    if (!s.key("cdc_max") || !s.skip_u64() || !s.eat(',')) return fail("bad cdc_max");
    if (!s.key("target") || !s.string_value(m.target) || !s.eat(',')) return fail("bad target");
    if (!s.key("original_path") || !s.string_value(m.original_path) || !s.eat(','))
        return fail("bad original_path");
    if (!s.key("whole_sha256") || !s.string_value(m.whole_sha256) || !s.eat(','))
        return fail("bad whole_sha256");
    if (!s.key("bytes") || !s.u64_value(m.bytes) || !s.eat(',')) return fail("bad bytes");
    if (!s.key("corpus_root") || !s.string_value(m.corpus_root) || !s.eat(','))
        return fail("bad corpus_root");
    if (!s.key("analyzed_ns") || !s.i64_value(m.analyzed_ns) || !s.eat(',')) return fail("bad analyzed_ns");
    if (!s.key("referenced_bytes") || !s.u64_value(m.referenced_bytes) || !s.eat(','))
        return fail("bad referenced_bytes");
    if (!s.key("resident_bytes") || !s.u64_value(m.resident_bytes) || !s.eat(','))
        return fail("bad resident_bytes");
    if (!s.key("inverted_bytes") || !s.u64_value(m.inverted_bytes) || !s.eat(','))
        return fail("bad inverted_bytes");
    if (!s.key("hunks") || !s.eat('[')) return fail("bad hunks array");
    if (!s.peek(']')) {
        do {
            ManifestHunk h;
            std::string tag;
            std::uint64_t length = 0;
            if (!s.eat('[') || !s.string_value(tag) || !s.eat(',') || !s.string_value(h.sha) ||
                !s.eat(',') || !s.u64_value(length) || !s.eat(','))
                return fail("bad hunk head");
            h.length = static_cast<std::uint32_t>(length);
            if (tag == "R") {
                h.kind = 'R';
                if (!s.string_value(h.hex) || !s.eat(']')) return fail("bad resident hunk");
            } else if (tag == "P" || tag == "I") {
                h.kind = tag == "P" ? 'P' : 'I';
                if (!s.string_value(h.src) || !s.eat(',') || !s.u64_value(h.offset) || !s.eat(']'))
                    return fail("bad pointer hunk");
            } else {
                return fail("unknown hunk kind");
            }
            m.hunks.push_back(std::move(h));
        } while (s.eat(','));
    }
    if (!s.eat(']') || !s.eat('}')) return fail("unterminated hunks array");
    return true;
}

// --- manifest location ------------------------------------------------------

std::string mangle_rel(const fs::path& corpus_root, const fs::path& target_abs) {
    std::error_code ec;
    fs::path rel = target_abs.lexically_relative(corpus_root);
    std::string text = rel.lexically_normal().generic_u8string();
    if (text.empty() || text.rfind("..", 0) == 0) {
        text = target_abs.filename().u8string();
    }
    std::string out;
    for (char c : text) out.push_back((c == '/' || c == '\\') ? '_' : c);
    return out;
}

fs::path manifest_path_for(const fs::path& root,
                           const fs::path& corpus_root,
                           const fs::path& target_abs) {
    return root / ".fweddle" / "refs" / (mangle_rel(corpus_root, target_abs) + ".fwref.json");
}

std::string percent(std::uint64_t part, std::uint64_t whole) {
    char buffer[32];
    const double value = whole == 0 ? 0.0
                                    : 100.0 * static_cast<double>(part) / static_cast<double>(whole);
    std::snprintf(buffer, sizeof buffer, "%.1f", value);
    return buffer;
}

}  // namespace

extern "C" {

int fw_ref_analyze(const char* target,
                   const char* corpus_root,
                   int invert,
                   char* out_report,
                   std::size_t out_capacity) {
    auto lock = fweddle_detail::lock_runtime();
    try {
        if (target == nullptr || *target == '\0') {
            fweddle_detail::set_last_error("target path is empty");
            return FW_INVALID_ARGUMENT;
        }
        const fs::path root = fweddle_detail::runtime_root_locked();
        std::error_code ec;
        const fs::path corpus =
            corpus_root == nullptr ? root : fs::absolute(fs::u8path(corpus_root), ec);
        if (ec || !fs::is_directory(corpus, ec)) {
            fweddle_detail::set_last_error("corpus root is not a readable directory");
            return FW_INVALID_ARGUMENT;
        }
        const fs::path target_abs = fs::absolute(fs::u8path(target), ec);
        if (ec || !fs::is_regular_file(target_abs, ec)) {
            fweddle_detail::set_last_error("target is not a regular file");
            return FW_NOT_FOUND;
        }
        const auto data = read_all(target_abs);
        if (!data) {
            fweddle_detail::set_last_error("cannot read target");
            return FW_IO_ERROR;
        }

        Manifest manifest;
        manifest.bytes = data->size();
        manifest.whole_sha256 = sha_hex(data->data(), data->size());
        manifest.corpus_root = corpus.lexically_normal().generic_u8string();
        manifest.original_path = target_abs.lexically_normal().generic_u8string();
        {
            const fs::path rel = target_abs.lexically_relative(corpus);
            const std::string text = rel.lexically_normal().generic_u8string();
            manifest.target = (text.empty() || text.rfind("..", 0) == 0)
                                  ? target_abs.filename().u8string()
                                  : text;
        }
        const auto now = std::chrono::system_clock::now().time_since_epoch();
        manifest.analyzed_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(now).count();

        const std::map<std::string, SourceSite> index = build_index(corpus, target_abs);
        const std::vector<HunkRecord> hunks = chunk_buffer(*data);

        for (const HunkRecord& hunk : hunks) {
            ManifestHunk out;
            out.sha = hunk.sha;
            out.length = hunk.length;
            const auto direct = index.find(hunk.sha);
            if (direct != index.end()) {
                out.kind = 'P';
                out.src = direct->second.rel;
                out.offset = direct->second.offset;
                manifest.referenced_bytes += hunk.length;
                manifest.hunks.push_back(std::move(out));
                continue;
            }
            if (invert != 0) {
                std::vector<unsigned char> inverted(hunk.length);
                for (std::uint32_t i = 0; i < hunk.length; ++i) {
                    inverted[i] = static_cast<unsigned char>(~(*data)[hunk.offset + i]);
                }
                const std::string inv_sha = sha_hex(inverted.data(), inverted.size());
                const auto found = index.find(inv_sha);
                if (found != index.end()) {
                    out.kind = 'I';
                    out.src = found->second.rel;
                    out.offset = found->second.offset;
                    manifest.inverted_bytes += hunk.length;
                    manifest.hunks.push_back(std::move(out));
                    continue;
                }
            }
            out.kind = 'R';
            out.hex = hex_of(data->data() + hunk.offset, hunk.length);
            manifest.resident_bytes += hunk.length;
            manifest.hunks.push_back(std::move(out));
        }

        const fs::path manifest_path = manifest_path_for(root, corpus, target_abs);
        const std::string body = emit_manifest(manifest);
        std::string write_error;
        if (!fweddle_detail::atomic_write_file(manifest_path, body, write_error)) {
            fweddle_detail::set_last_error("cannot write manifest: " + write_error);
            return FW_IO_ERROR;
        }
        const std::uint64_t manifest_bytes = body.size();
        const std::int64_t delta =
            static_cast<std::int64_t>(manifest_bytes) - static_cast<std::int64_t>(manifest.bytes);

        std::size_t referenced_hunks = 0, resident_hunks = 0, inverted_hunks = 0;
        for (const ManifestHunk& h : manifest.hunks) {
            if (h.kind == 'P') ++referenced_hunks;
            else if (h.kind == 'I') ++inverted_hunks;
            else ++resident_hunks;
        }

        std::ostringstream out;
        out << "🍀 reference analysis — " << manifest.target << "   (EXPERIMENTAL)\n";
        out << "   original_bytes:     " << manifest.bytes << "\n";
        out << "   hunks:              " << manifest.hunks.size() << "   (referenced "
            << referenced_hunks << ", resident " << resident_hunks;
        if (invert != 0) out << ", inverted " << inverted_hunks;
        out << ")\n";
        out << "   referenced_bytes:   " << manifest.referenced_bytes << "   ("
            << percent(manifest.referenced_bytes, manifest.bytes) << "% found elsewhere → pointer)\n";
        if (invert != 0) {
            out << "   inverted_bytes:     " << manifest.inverted_bytes << "   ("
                << percent(manifest.inverted_bytes, manifest.bytes)
                << "% found only as bitwise inverse)\n";
        }
        out << "   resident_bytes:     " << manifest.resident_bytes << "   ("
            << percent(manifest.resident_bytes, manifest.bytes)
            << "% unique → stored inline; nowhere to point)\n";
        out << "   manifest_bytes:     " << manifest_bytes << "\n";
        out << "   net vs original:    " << (delta <= 0 ? "" : "+") << delta << "   "
            << (delta < 0 ? "(a real saving)" : "(larger than the original — mostly resident)") << "\n";
        out << "   manifest:           " << manifest_path.u8string() << "\n";
        out << "   reconstruct with:   fweddle refs reconstruct " << manifest.target << "\n";

        fweddle_detail::clear_last_error();
        return fweddle_detail::copy_result_buffer(out.str(), out_report, out_capacity);
    } catch (const std::exception& failure) {
        fweddle_detail::set_last_error(failure.what());
        return FW_IO_ERROR;
    }
}

int fw_ref_reconstruct(const char* target_or_manifest, char* out_path, std::size_t out_capacity) {
    auto lock = fweddle_detail::lock_runtime();
    try {
        if (target_or_manifest == nullptr || *target_or_manifest == '\0') {
            fweddle_detail::set_last_error("target or manifest path is empty");
            return FW_INVALID_ARGUMENT;
        }
        const fs::path root = fweddle_detail::runtime_root_locked();
        std::error_code ec;

        // Resolve the manifest: an explicit *.fwref.json path, or a target
        // resolved under the root's refs directory.
        fs::path manifest_file;
        const fs::path given = fs::u8path(target_or_manifest);
        const std::string given_name = given.filename().string();
        if (given_name.size() >= 11 &&
            given_name.compare(given_name.size() - 11, 11, ".fwref.json") == 0 &&
            fs::is_regular_file(given, ec)) {
            manifest_file = fs::absolute(given, ec);
        } else {
            const fs::path target_abs = fs::absolute(given, ec);
            manifest_file = manifest_path_for(root, root, target_abs);
        }
        std::string text;
        if (!read_file_text(manifest_file, text)) {
            fweddle_detail::set_last_error("no manifest at " + manifest_file.string() +
                                           "; run: fweddle refs analyze <file>");
            return FW_NOT_FOUND;
        }
        Manifest manifest;
        std::string error;
        if (!parse_manifest(text, manifest, error)) {
            fweddle_detail::set_last_error("manifest is unreadable (" + error + ")");
            return FW_BAD_METADATA;
        }

        const fs::path corpus_root = fs::u8path(manifest.corpus_root);
        std::vector<unsigned char> rebuilt;
        rebuilt.reserve(manifest.bytes);
        for (std::size_t i = 0; i < manifest.hunks.size(); ++i) {
            const ManifestHunk& h = manifest.hunks[i];
            std::vector<unsigned char> piece;
            if (h.kind == 'R') {
                const auto decoded = hex_to_bytes(h.hex);
                if (!decoded) {
                    fweddle_detail::set_last_error("resident hunk " + std::to_string(i) +
                                                   " is not valid hex");
                    return FW_BAD_METADATA;
                }
                piece = *decoded;
            } else {
                const fs::path source = corpus_root / fs::u8path(h.src);
                const auto span = read_span(source, h.offset, h.length);
                if (!span) {
                    fweddle_detail::set_last_error(
                        "reference to " + h.src + "@" + std::to_string(h.offset) +
                        " could not be read (source moved, shrank, or is gone)");
                    return FW_NOT_FOUND;
                }
                piece = *span;
                if (h.kind == 'I') {
                    for (unsigned char& byte : piece) byte = static_cast<unsigned char>(~byte);
                }
            }
            // Verify every hunk against its recorded SHA before trusting it.
            if (sha_hex(piece.data(), piece.size()) != h.sha) {
                fweddle_detail::set_last_error(
                    "hunk " + std::to_string(i) + " failed verification (" +
                    (h.kind == 'R' ? "resident data corrupt"
                                   : "source " + h.src + " changed since analysis") + ")");
                return FW_BAD_METADATA;
            }
            rebuilt.insert(rebuilt.end(), piece.begin(), piece.end());
        }

        if (sha_hex(rebuilt.data(), rebuilt.size()) != manifest.whole_sha256) {
            fweddle_detail::set_last_error("reconstruction did not match the original SHA-256");
            return FW_BAD_METADATA;
        }

        const fs::path original = fs::u8path(manifest.original_path);
        const fs::path out_file(original.u8string() + ".rebuilt");
        {
            std::ofstream output(out_file, std::ios::binary | std::ios::trunc);
            if (!output) {
                fweddle_detail::set_last_error("cannot open output " + out_file.string());
                return FW_IO_ERROR;
            }
            output.write(reinterpret_cast<const char*>(rebuilt.data()),
                         static_cast<std::streamsize>(rebuilt.size()));
            if (!output) {
                fweddle_detail::set_last_error("cannot write output " + out_file.string());
                return FW_IO_ERROR;
            }
        }
        fweddle_detail::clear_last_error();
        return fweddle_detail::copy_result_buffer(out_file.u8string(), out_path, out_capacity);
    } catch (const std::exception& failure) {
        fweddle_detail::set_last_error(failure.what());
        return FW_IO_ERROR;
    }
}

}  // extern "C"
