#include "fweddle/fweddle.hpp"

#include <algorithm>
#include <array>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace {

constexpr std::size_t kResultCapacity = 32768;

struct Options {
    fs::path root = fs::current_path();
    std::string lexicon;
    int command_index = 1;
};

void usage() {
    std::cout
        << "Fweddle Capsule 0.4.0\n\n"
        << "Usage:\n"
        << "  fweddle [--root DIR] [--lexicon FILE] seal FILE...\n"
        << "  fweddle [--root DIR] [--lexicon FILE] view [DIR]\n"
        << "  fweddle [--root DIR] [--lexicon FILE] unseal CAPSULE_OR_EMOJI_NAME...\n"
        << "  fweddle [--root DIR] [--lexicon FILE] rename-view DIR OLD_NAME NEW_BASE\n"
        << "  fweddle [--root DIR] [--lexicon FILE] resurrect UUID [SEARCH_ROOT]\n"
        << "  fweddle [--root DIR] [--lexicon FILE] scan [DIR]\n"
        << "  fweddle [--root DIR] [--lexicon FILE] echoes [FILE]\n"
        << "  fweddle [--root DIR] emotes [list]\n"
        << "  fweddle [--root DIR] emotes set EXT EMOJI\n"
        << "  fweddle [--root DIR] emotes unset EXT\n"
        << "  fweddle [--root DIR] emotes edit | seal | unseal\n"
        << "  fweddle [--root DIR] refs analyze FILE [--invert]     (experimental)\n"
        << "  fweddle [--root DIR] refs reconstruct FILE            (experimental)\n";
}

bool parse_options(int argc, char** argv, Options& options) {
    int index = 1;
    while (index < argc) {
        const std::string arg = argv[index];
        if (arg == "--root") {
            if (index + 1 >= argc) return false;
            options.root = fs::u8path(argv[index + 1]);
            index += 2;
        } else if (arg == "--lexicon") {
            if (index + 1 >= argc) return false;
            options.lexicon = argv[index + 1];
            index += 2;
        } else {
            break;
        }
    }
    options.command_index = index;
    return index < argc;
}

int report_error(const std::string& action, int status) {
    std::cerr << action << " failed (" << status << "): " << fw_last_error() << '\n';
    return 1;
}

int initialize(const Options& options) {
    const char* lexicon = options.lexicon.empty() ? nullptr : options.lexicon.c_str();
    const std::string root = options.root.u8string();
    const int status = fw_init(root.c_str(), lexicon);
    return status == FW_OK ? 0 : report_error("init", status);
}

int seal_files(int argc, char** argv, int first) {
    if (first >= argc) return 2;
    int result = 0;
    for (int index = first; index < argc; ++index) {
        std::array<char, kResultCapacity> output{};
        const int status = fw_capsule(argv[index], output.data(), output.size());
        if (status != FW_OK) {
            result = report_error(std::string("seal ") + argv[index], status);
        } else {
            std::cout << argv[index] << "  ->  " << output.data() << '\n';
        }
    }
    return result;
}

int unseal_files(int argc, char** argv, int first) {
    if (first >= argc) return 2;
    int result = 0;
    for (int index = first; index < argc; ++index) {
        std::array<char, kResultCapacity> output{};
        const int status = fw_exorcise(argv[index], output.data(), output.size());
        if (status != FW_OK) {
            result = report_error(std::string("unseal ") + argv[index], status);
        } else {
            std::cout << argv[index] << "  ->  " << output.data() << '\n';
        }
    }
    return result;
}

bool is_sidecar(const fs::path& path) {
    const std::string name = path.filename().string();
    return !name.empty() && name.front() == '.' &&
           name.size() >= 7 && name.compare(name.size() - 7, 7, ".fwmeta") == 0;
}

int view_directory(const fs::path& directory) {
    std::error_code ec;
    if (!fs::is_directory(directory, ec)) {
        std::cerr << "view failed: not a directory\n";
        return 1;
    }
    struct Item {
        fs::file_time_type time;
        std::string name;
    };
    std::vector<Item> items;
    for (const auto& entry : fs::directory_iterator(directory, fs::directory_options::skip_permission_denied, ec)) {
        if (ec || entry.path().filename() == ".fweddle" || is_sidecar(entry.path())) continue;
        std::string name = entry.path().filename().u8string();
        if (entry.is_regular_file(ec) && name.size() >= 8 &&
            name.compare(name.size() - 8, 8, ".fweddle") == 0) {
            std::array<char, kResultCapacity> display{};
            if (fw_display_name(entry.path().u8string().c_str(), display.data(), display.size()) == FW_OK) {
                name = display.data();
            }
        }
        items.push_back({entry.last_write_time(ec), name});
    }
    std::sort(items.begin(), items.end(), [](const Item& left, const Item& right) {
        if (left.name == right.name) return left.time < right.time;
        return left.name < right.name;
    });
    for (const auto& item : items) {
        std::cout << item.name << '\n';
    }
    return 0;
}

int rename_view(int argc, char** argv, int first) {
    if (first + 2 >= argc) return 2;
    const fs::path directory = fs::u8path(argv[first]);
    const fs::path old_display = directory / fs::u8path(argv[first + 1]);
    const std::string new_base = argv[first + 2];
    if (new_base.find("🍀") != std::string::npos) {
        std::cerr << "rename-view currently performs the reverse exorcism; NEW_BASE must omit 🍀\n";
        return 1;
    }
    std::array<char, kResultCapacity> restored{};
    const int status = fw_exorcise(old_display.u8string().c_str(), restored.data(), restored.size());
    if (status != FW_OK) return report_error("rename-view", status);

    fs::path mortal = fs::u8path(restored.data());
    const fs::path renamed = mortal.parent_path() / (new_base + mortal.extension().string());
    if (renamed != mortal) {
        std::error_code ec;
        if (fs::exists(renamed, ec)) {
            std::cerr << "rename-view failed: target already exists: " << renamed << '\n';
            return 1;
        }
        fs::rename(mortal, renamed, ec);
        if (ec) {
            std::cerr << "rename-view restored the file but could not apply the new base: "
                      << ec.message() << '\n';
            return 1;
        }
        mortal = renamed;
    }
    std::cout << old_display.u8string() << "  ->  " << mortal.u8string() << '\n';
    return 0;
}

int emotes_command(const Options& options, int argc, char** argv, int first) {
    const std::string sub = first < argc ? argv[first] : "list";
    const fs::path mortal = options.root / "fwemotes.json";
    const fs::path sealed = options.root / "fwemotes.json.fweddle";
    std::error_code ec;
    const bool has_mortal = fs::is_regular_file(mortal, ec);
    const bool has_sealed = fs::is_regular_file(sealed, ec);

    if (sub == "list") {
        std::vector<char> report(1U << 20U);
        const int status = fw_emote_report(report.data(), report.size());
        if (status != FW_OK) return report_error("emotes list", status);
        std::cout << report.data();
        return 0;
    }
    if (sub == "set" || sub == "unset") {
        const bool removing = sub == "unset";
        if (first + 1 >= argc || (!removing && first + 2 >= argc)) return 2;
        const char* extension = argv[first + 1];
        const char* emoji = removing ? nullptr : argv[first + 2];
        std::array<char, kResultCapacity> output{};
        const int status = fw_emote_set(extension, emoji, output.data(), output.size());
        if (status != FW_OK) return report_error("emotes " + sub, status);
        if (removing) {
            std::cout << extension << "  ->  (builtin / 📦)   committed to "
                      << output.data() << '\n';
        } else {
            std::cout << extension << "  ->  " << emoji << "   committed to "
                      << output.data() << '\n';
        }
        return 0;
    }
    if (sub == "seal") {
        if (has_sealed) {
            std::cerr << "fwemotes is already sealed: " << sealed.u8string() << '\n';
            return 1;
        }
        if (!has_mortal) {
            std::cerr << "no fwemotes file yet; try: fweddle emotes set .pdf 📄\n";
            return 1;
        }
        std::array<char, kResultCapacity> capsule{};
        const int status = fw_capsule(mortal.u8string().c_str(), capsule.data(), capsule.size());
        if (status != FW_OK) return report_error("emotes seal", status);
        std::cout << mortal.u8string() << "  ->  " << capsule.data() << '\n';
        std::array<char, kResultCapacity> shown{};
        if (fw_display_name(capsule.data(), shown.data(), shown.size()) == FW_OK) {
            std::cout << "projected as  " << shown.data() << '\n';
        }
        return 0;
    }
    if (sub == "unseal") {
        if (!has_sealed) {
            std::cerr << (has_mortal ? "fwemotes is not sealed\n"
                                     : "no fwemotes file yet; try: fweddle emotes set .pdf 📄\n");
            return 1;
        }
        std::array<char, kResultCapacity> restored{};
        const int status = fw_exorcise(sealed.u8string().c_str(), restored.data(), restored.size());
        if (status != FW_OK) return report_error("emotes unseal", status);
        std::cout << sealed.u8string() << "  ->  " << restored.data() << '\n';
        return 0;
    }
    if (sub == "edit") {
        if (has_mortal && has_sealed) {
            std::cerr << "both " << mortal.u8string() << " and " << sealed.u8string()
                      << " exist; unseal or remove one first\n";
            return 1;
        }
        const char* visual = std::getenv("VISUAL");
        const char* fallback = std::getenv("EDITOR");
        const char* editor = visual != nullptr && *visual != '\0' ? visual
                             : fallback != nullptr && *fallback != '\0' ? fallback
                                                                        : nullptr;
        if (editor == nullptr) {
            std::cerr << "set $VISUAL or $EDITOR, or edit the file directly: "
                      << (has_sealed ? sealed : mortal).u8string() << '\n';
            return 1;
        }
        fs::path target = mortal;
        if (has_sealed) {
            std::array<char, kResultCapacity> restored{};
            const int status = fw_exorcise(sealed.u8string().c_str(), restored.data(),
                                           restored.size());
            if (status != FW_OK) return report_error("emotes edit", status);
            target = fs::u8path(restored.data());
            std::cout << "seal broken for editing: " << target.u8string() << '\n';
        } else if (!has_mortal) {
            std::ofstream skeleton(target, std::ios::binary | std::ios::trunc);
            skeleton << "{\n}\n";
        }
        const std::string plain = target.u8string();
        if (plain.find('"') != std::string::npos) {
            std::cerr << "cannot safely pass this path to the editor\n";
            return 1;
        }
        const std::string command = std::string(editor) + " \"" + plain + "\"";
        if (std::system(command.c_str()) != 0) {
            std::cerr << "editor did not exit cleanly"
                      << (has_sealed ? "; fwemotes left unsealed at " + plain : "") << '\n';
            return 1;
        }
        std::vector<char> report(1U << 20U);
        if (fw_emote_report(report.data(), report.size()) != FW_OK) {
            std::cerr << "fwemotes did not validate (" << fw_last_error()
                      << "); left unsealed at " << plain << " for another pass\n";
            return 1;
        }
        if (has_sealed) {
            std::array<char, kResultCapacity> capsule{};
            const int status = fw_capsule(target.u8string().c_str(), capsule.data(),
                                          capsule.size());
            if (status != FW_OK) return report_error("emotes edit reseal", status);
            std::cout << "resealed: " << capsule.data() << '\n';
        }
        if (fw_emote_report(report.data(), report.size()) == FW_OK) {
            std::cout << report.data();
        }
        return 0;
    }
    return 2;
}

int refs_command(const Options& options, int argc, char** argv, int first) {
    if (first >= argc) return 2;
    const std::string sub = argv[first];
    if (sub == "analyze") {
        if (first + 1 >= argc) return 2;
        const char* target = argv[first + 1];
        int invert = 0;
        for (int i = first + 2; i < argc; ++i) {
            if (std::string(argv[i]) == "--invert") invert = 1;
        }
        std::vector<char> report(1U << 20U);
        const std::string corpus = options.root.u8string();
        const int status = fw_ref_analyze(target, corpus.c_str(), invert, report.data(),
                                          report.size());
        if (status != FW_OK) return report_error("refs analyze", status);
        std::cout << report.data();
        return 0;
    }
    if (sub == "reconstruct") {
        if (first + 1 >= argc) return 2;
        std::array<char, kResultCapacity> output{};
        const int status = fw_ref_reconstruct(argv[first + 1], output.data(), output.size());
        if (status != FW_OK) return report_error("refs reconstruct", status);
        std::cout << "rebuilt (verified 1:1)  ->  " << output.data() << '\n';
        return 0;
    }
    return 2;
}

}  // namespace

int main(int argc, char** argv) {
    Options options;
    if (!parse_options(argc, argv, options)) {
        usage();
        return 2;
    }
    if (initialize(options) != 0) return 1;

    const std::string command = argv[options.command_index];
    const int first = options.command_index + 1;
    if (command == "seal") {
        const int status = seal_files(argc, argv, first);
        if (status == 2) usage();
        return status;
    }
    if (command == "view") {
        return view_directory(first < argc ? fs::u8path(argv[first]) : options.root);
    }
    if (command == "unseal") {
        const int status = unseal_files(argc, argv, first);
        if (status == 2) usage();
        return status;
    }
    if (command == "rename-view") {
        const int status = rename_view(argc, argv, first);
        if (status == 2) usage();
        return status;
    }
    if (command == "scan") {
        std::array<char, kResultCapacity> output{};
        const char* directory = first < argc ? argv[first] : nullptr;
        const int status = fw_hunk_scan(directory, output.data(), output.size());
        if (status != FW_OK) return report_error("scan", status);
        std::cout << "hunk ledger  ->  " << output.data() << '\n';
        std::vector<char> report(1U << 20U);
        if (fw_hunk_echoes(nullptr, report.data(), report.size()) == FW_OK) {
            std::cout << report.data();
        }
        return 0;
    }
    if (command == "echoes") {
        std::vector<char> report(1U << 20U);
        const char* target = first < argc ? argv[first] : nullptr;
        const int status = fw_hunk_echoes(target, report.data(), report.size());
        if (status != FW_OK) return report_error("echoes", status);
        std::cout << report.data();
        return 0;
    }
    if (command == "refs") {
        const int status = refs_command(options, argc, argv, first);
        if (status == 2) usage();
        return status;
    }
    if (command == "emotes") {
        const int status = emotes_command(options, argc, argv, first);
        if (status == 2) usage();
        return status;
    }
    if (command == "resurrect") {
        if (first >= argc) {
            usage();
            return 2;
        }
        const char* search_root = first + 1 < argc ? argv[first + 1] : nullptr;
        std::array<char, kResultCapacity> output{};
        const int status = fw_resurrect(argv[first], search_root, output.data(), output.size());
        if (status != FW_OK) return report_error("resurrect", status);
        std::cout << output.data() << '\n';
        return 0;
    }
    usage();
    return 2;
}
