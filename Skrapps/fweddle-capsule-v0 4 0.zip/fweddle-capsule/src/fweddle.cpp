#include "fweddle/fweddle.hpp"

#include "internal.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cctype>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <limits>
#include <map>
#include <mutex>
#include <optional>
#include <random>
#include <regex>
#include <sstream>
#include <string>
#include <system_error>
#include <vector>

#if defined(__linux__)
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/xattr.h>
#elif defined(__APPLE__)
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/xattr.h>
#endif

namespace fs = std::filesystem;

namespace {

constexpr const char* kCapsuleSuffix = ".fweddle";
constexpr const char* kClover = "🍀";
constexpr const char* kFallbackEmoji = "📦";
constexpr std::uint64_t kOneGiB = 1024ULL * 1024ULL * 1024ULL;

struct Metadata {
    int schema = 1;
    std::string hunt_uuid;
    std::string original_name;
    std::string mortal_name;
    std::string original_base;
    std::string assigned_base;
    std::string extension;
    std::int64_t negative_magnitude = 0;
    std::uint64_t physical_bytes = 0;
    std::int64_t captured_ns = 0;
    std::string crc64;
    std::string haiku;
};

struct Runtime {
    fs::path root;
    fs::path lexicon_path;
    bool lexicon_was_explicit = false;
    bool initialized = false;
};

Runtime g_runtime;
std::mutex g_mutex;
thread_local std::string g_last_error;

const std::map<std::string, std::string>& builtin_lexicon() {
    static const std::map<std::string, std::string> lexicon = {
        {".pdf", "📄"}, {".doc", "📄"},  {".docx", "📄"},
        {".txt", "📝"}, {".md", "📝"},   {".png", "🖼️"},
        {".jpg", "🖼️"}, {".jpeg", "🖼️"}, {".gif", "🖼️"},
        {".webp", "🖼️"}, {".svg", "🎨"}, {".mp3", "💿"},
        {".wav", "🎵"}, {".flac", "🎵"}, {".mp4", "🎞️"},
        {".mov", "🎞️"}, {".mkv", "🎞️"}, {".zip", "🗜️"},
        {".7z", "🗜️"},  {".tar", "🗜️"}, {".json", "🧩"},
        {".html", "🌐"}, {".css", "🎨"},  {".js", "⚡"},
        {".cpp", "⚙️"}, {".hpp", "⚙️"},
        // Extended palette.
        {".rtf", "📄"}, {".odt", "📄"}, {".tex", "📄"}, {".pages", "📄"},
        {".exe", "⚙️"}, {".dll", "⚙️"}, {".so", "⚙️"}, {".msi", "⚙️"},
        {".sh", "⚙️"},  {".bat", "⚙️"},
        {".app", "🍎"}, {".dmg", "🍎"}, {".ipa", "🍎"}, {".pkg", "🍎"},
        {".iso", "💿"}, {".img", "💿"},
        {".psd", "🖌️"}, {".xcf", "🖌️"}, {".kra", "🖌️"},
        {".ai", "🎨"},  {".sketch", "🎨"}, {".fig", "🎨"}, {".eps", "🎨"},
        {".bmp", "🖼️"}, {".tiff", "🖼️"}, {".tif", "🖼️"}, {".heic", "🖼️"},
        {".ico", "🖼️"}
    };
    return lexicon;
}

void set_error(const std::string& message) {
    g_last_error = message;
}

std::string lower_ascii(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return value;
}

bool ends_with(const std::string& value, const std::string& suffix) {
    return value.size() >= suffix.size() &&
           value.compare(value.size() - suffix.size(), suffix.size(), suffix) == 0;
}

std::string json_escape(const std::string& value) {
    std::ostringstream out;
    for (unsigned char c : value) {
        switch (c) {
            case '\\': out << "\\\\"; break;
            case '"': out << "\\\""; break;
            case '\n': out << "\\n"; break;
            case '\r': out << "\\r"; break;
            case '\t': out << "\\t"; break;
            default:
                if (c < 0x20) {
                    out << "\\u" << std::hex << std::setw(4) << std::setfill('0')
                        << static_cast<int>(c) << std::dec;
                } else {
                    out << static_cast<char>(c);
                }
        }
    }
    return out.str();
}

std::string json_unescape(const std::string& value) {
    std::string out;
    out.reserve(value.size());
    for (std::size_t i = 0; i < value.size(); ++i) {
        if (value[i] != '\\' || i + 1 >= value.size()) {
            out.push_back(value[i]);
            continue;
        }
        const char next = value[++i];
        switch (next) {
            case '\\': out.push_back('\\'); break;
            case '"': out.push_back('"'); break;
            case 'n': out.push_back('\n'); break;
            case 'r': out.push_back('\r'); break;
            case 't': out.push_back('\t'); break;
            default:
                out.push_back('\\');
                out.push_back(next);
                break;
        }
    }
    return out;
}

std::optional<std::string> json_string(const std::string& json, const std::string& key) {
    const std::regex pattern("\\\"" + key + "\\\"\\s*:\\s*\\\"((?:\\\\.|[^\\\"])*)\\\"");
    std::smatch match;
    if (!std::regex_search(json, match, pattern)) {
        return std::nullopt;
    }
    return json_unescape(match[1].str());
}

std::optional<std::int64_t> json_i64(const std::string& json, const std::string& key) {
    const std::regex pattern("\\\"" + key + "\\\"\\s*:\\s*(-?[0-9]+)");
    std::smatch match;
    if (!std::regex_search(json, match, pattern)) {
        return std::nullopt;
    }
    try {
        return std::stoll(match[1].str());
    } catch (...) {
        return std::nullopt;
    }
}

std::optional<std::uint64_t> json_u64(const std::string& json, const std::string& key) {
    const std::regex pattern("\\\"" + key + "\\\"\\s*:\\s*([0-9]+)");
    std::smatch match;
    if (!std::regex_search(json, match, pattern)) {
        return std::nullopt;
    }
    try {
        return std::stoull(match[1].str());
    } catch (...) {
        return std::nullopt;
    }
}

std::string metadata_json(const Metadata& meta, const std::optional<fs::path>& known_path = std::nullopt) {
    std::ostringstream out;
    out << "{\n"
        << "  \"schema\": " << meta.schema << ",\n"
        << "  \"hunt_uuid\": \"" << json_escape(meta.hunt_uuid) << "\",\n"
        << "  \"original_name\": \"" << json_escape(meta.original_name) << "\",\n"
        << "  \"mortal_name\": \"" << json_escape(meta.mortal_name) << "\",\n"
        << "  \"original_base\": \"" << json_escape(meta.original_base) << "\",\n"
        << "  \"assigned_base\": \"" << json_escape(meta.assigned_base) << "\",\n"
        << "  \"extension\": \"" << json_escape(meta.extension) << "\",\n"
        << "  \"negative_magnitude\": " << meta.negative_magnitude << ",\n"
        << "  \"physical_bytes\": " << meta.physical_bytes << ",\n"
        << "  \"captured_ns\": " << meta.captured_ns << ",\n"
        << "  \"crc64\": \"" << json_escape(meta.crc64) << "\",\n"
        << "  \"haiku\": \"" << json_escape(meta.haiku) << "\"";
    if (known_path) {
        out << ",\n  \"last_known_path\": \""
            << json_escape(known_path->generic_string()) << "\"";
    }
    out << "\n}\n";
    return out.str();
}

bool valid_metadata(const Metadata& meta) {
    const auto is_leaf = [](const std::string& value) {
        const fs::path path = fs::u8path(value);
        return !value.empty() && path == path.filename() && value != "." && value != "..";
    };
    static const std::regex uuid_pattern(
        "^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$");
    static const std::regex crc_pattern("^[0-9a-f]{16}$");
    if (!std::regex_match(meta.hunt_uuid, uuid_pattern) ||
        !std::regex_match(meta.crc64, crc_pattern) ||
        !is_leaf(meta.original_name) || !is_leaf(meta.mortal_name) ||
        !is_leaf(meta.original_base) || !is_leaf(meta.assigned_base) ||
        meta.extension.find('/') != std::string::npos ||
        meta.extension.find('\\') != std::string::npos ||
        meta.mortal_name != meta.assigned_base + meta.extension ||
        meta.physical_bytes > static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max())) {
        return false;
    }
    return meta.negative_magnitude == -static_cast<std::int64_t>(meta.physical_bytes);
}

bool parse_metadata(const std::string& json, Metadata& meta) {
    const auto uuid = json_string(json, "hunt_uuid");
    const auto original_name = json_string(json, "original_name");
    const auto mortal_name = json_string(json, "mortal_name");
    const auto original_base = json_string(json, "original_base");
    const auto assigned_base = json_string(json, "assigned_base");
    const auto extension = json_string(json, "extension");
    const auto negative = json_i64(json, "negative_magnitude");
    const auto bytes = json_u64(json, "physical_bytes");
    const auto captured = json_i64(json, "captured_ns");
    const auto crc = json_string(json, "crc64");
    if (!uuid || !original_name || !mortal_name || !original_base || !assigned_base ||
        !extension || !negative || !bytes || !captured || !crc) {
        return false;
    }
    meta.hunt_uuid = *uuid;
    meta.original_name = *original_name;
    meta.mortal_name = *mortal_name;
    meta.original_base = *original_base;
    meta.assigned_base = *assigned_base;
    meta.extension = *extension;
    meta.negative_magnitude = *negative;
    meta.physical_bytes = *bytes;
    meta.captured_ns = *captured;
    meta.crc64 = *crc;
    meta.haiku = json_string(json, "haiku").value_or("");
    return valid_metadata(meta);
}

bool read_text(const fs::path& path, std::string& text) {
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        return false;
    }
    std::ostringstream buffer;
    buffer << input.rdbuf();
    if (!input.good() && !input.eof()) {
        return false;
    }
    text = buffer.str();
    return true;
}

fs::path unique_temp_for(const fs::path& target) {
    static std::mt19937_64 rng(std::random_device{}());
    std::ostringstream suffix;
    suffix << ".tmp-" << std::hex << rng();
    return fs::path(target.string() + suffix.str());
}

bool atomic_write(const fs::path& target, const std::string& data, std::string& error) {
    std::error_code ec;
    fs::create_directories(target.parent_path(), ec);
    if (ec) {
        error = "cannot create metadata directory: " + ec.message();
        return false;
    }
    const fs::path temporary = unique_temp_for(target);
    {
        std::ofstream output(temporary, std::ios::binary | std::ios::trunc);
        if (!output) {
            error = "cannot open temporary metadata file";
            return false;
        }
        output.write(data.data(), static_cast<std::streamsize>(data.size()));
        output.flush();
        if (!output) {
            error = "cannot flush temporary metadata file";
            output.close();
            fs::remove(temporary, ec);
            return false;
        }
    }
    fs::rename(temporary, target, ec);
    if (ec) {
        std::error_code remove_ec;
        fs::remove(target, remove_ec);
        ec.clear();
        fs::rename(temporary, target, ec);
    }
    if (ec) {
        error = "cannot commit metadata: " + ec.message();
        std::error_code cleanup_ec;
        fs::remove(temporary, cleanup_ec);
        return false;
    }
    return true;
}

fs::path sidecar_for(const fs::path& capsule) {
    return capsule.parent_path() / ("." + capsule.filename().string() + ".fwmeta");
}

fs::path registry_for(const std::string& uuid) {
    return g_runtime.root / ".fweddle" / "registry" / (uuid + ".json");
}

#if defined(__linux__)
bool set_xattr(const fs::path& path, const std::string& name, const std::string& value) {
    return ::setxattr(path.c_str(), name.c_str(), value.data(), value.size(), 0) == 0;
}

std::optional<std::string> get_xattr(const fs::path& path, const std::string& name) {
    const ssize_t length = ::getxattr(path.c_str(), name.c_str(), nullptr, 0);
    if (length < 0) {
        return std::nullopt;
    }
    std::string value(static_cast<std::size_t>(length), '\0');
    if (length > 0 && ::getxattr(path.c_str(), name.c_str(), value.data(), value.size()) < 0) {
        return std::nullopt;
    }
    return value;
}

void remove_xattr(const fs::path& path, const std::string& name) {
    ::removexattr(path.c_str(), name.c_str());
}
#elif defined(__APPLE__)
bool set_xattr(const fs::path& path, const std::string& name, const std::string& value) {
    return ::setxattr(path.c_str(), name.c_str(), value.data(), value.size(), 0, 0) == 0;
}

std::optional<std::string> get_xattr(const fs::path& path, const std::string& name) {
    const ssize_t length = ::getxattr(path.c_str(), name.c_str(), nullptr, 0, 0, 0);
    if (length < 0) {
        return std::nullopt;
    }
    std::string value(static_cast<std::size_t>(length), '\0');
    if (length > 0 && ::getxattr(path.c_str(), name.c_str(), value.data(), value.size(), 0, 0) < 0) {
        return std::nullopt;
    }
    return value;
}

void remove_xattr(const fs::path& path, const std::string& name) {
    ::removexattr(path.c_str(), name.c_str(), 0);
}
#else
bool set_xattr(const fs::path&, const std::string&, const std::string&) {
    return false;
}

std::optional<std::string> get_xattr(const fs::path&, const std::string&) {
    return std::nullopt;
}

void remove_xattr(const fs::path&, const std::string&) {}
#endif

const std::array<const char*, 11>& xattr_names() {
    static const std::array<const char*, 11> names = {
        "user.fweddle.original_name",
        "user.fweddle.mortal_name",
        "user.fweddle.original_base",
        "user.fweddle.assigned_base",
        "user.fweddle.extension",
        "user.fweddle.negator",
        "user.fweddle.physical_bytes",
        "user.fweddle.captured_ns",
        "user.fweddle.crc64",
        "user.fweddle.hunt_uuid",
        "user.fweddle.backlink"
    };
    return names;
}

void write_xattrs(const fs::path& path, const Metadata& meta) {
    set_xattr(path, "user.fweddle.original_name", meta.original_name);
    set_xattr(path, "user.fweddle.mortal_name", meta.mortal_name);
    set_xattr(path, "user.fweddle.original_base", meta.original_base);
    set_xattr(path, "user.fweddle.assigned_base", meta.assigned_base);
    set_xattr(path, "user.fweddle.extension", meta.extension);
    set_xattr(path, "user.fweddle.negator", std::to_string(meta.negative_magnitude));
    set_xattr(path, "user.fweddle.physical_bytes", std::to_string(meta.physical_bytes));
    set_xattr(path, "user.fweddle.captured_ns", std::to_string(meta.captured_ns));
    set_xattr(path, "user.fweddle.crc64", meta.crc64);
    set_xattr(path, "user.fweddle.hunt_uuid", meta.hunt_uuid);
    set_xattr(path, "user.fweddle.backlink", meta.hunt_uuid);
}

void purge_xattrs(const fs::path& path) {
    for (const char* name : xattr_names()) {
        remove_xattr(path, name);
    }
}

bool metadata_from_xattrs(const fs::path& path, Metadata& meta) {
    const auto uuid = get_xattr(path, "user.fweddle.hunt_uuid");
    const auto backlink = get_xattr(path, "user.fweddle.backlink");
    const auto original_name = get_xattr(path, "user.fweddle.original_name");
    const auto mortal_name = get_xattr(path, "user.fweddle.mortal_name");
    const auto original_base = get_xattr(path, "user.fweddle.original_base");
    const auto assigned_base = get_xattr(path, "user.fweddle.assigned_base");
    const auto extension = get_xattr(path, "user.fweddle.extension");
    const auto negative = get_xattr(path, "user.fweddle.negator");
    const auto bytes = get_xattr(path, "user.fweddle.physical_bytes");
    const auto captured = get_xattr(path, "user.fweddle.captured_ns");
    const auto crc = get_xattr(path, "user.fweddle.crc64");
    if (!uuid || !backlink || *uuid != *backlink || !original_name || !mortal_name ||
        !original_base || !assigned_base || !extension || !negative || !bytes ||
        !captured || !crc) {
        return false;
    }
    try {
        meta.hunt_uuid = *uuid;
        meta.original_name = *original_name;
        meta.mortal_name = *mortal_name;
        meta.original_base = *original_base;
        meta.assigned_base = *assigned_base;
        meta.extension = *extension;
        meta.negative_magnitude = std::stoll(*negative);
        meta.physical_bytes = std::stoull(*bytes);
        meta.captured_ns = std::stoll(*captured);
        meta.crc64 = *crc;
    } catch (...) {
        return false;
    }
    return valid_metadata(meta);
}

bool read_metadata(const fs::path& capsule, Metadata& meta) {
    std::string contents;
    if (read_text(sidecar_for(capsule), contents) && parse_metadata(contents, meta)) {
        return true;
    }
    return metadata_from_xattrs(capsule, meta);
}

std::uint64_t crc64_first_64(const fs::path& path) {
    constexpr std::uint64_t polynomial = 0x42F0E1EBA9EA3693ULL;
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        throw std::runtime_error("cannot open file to compute Hunt_UUID");
    }
    std::array<unsigned char, 64> buffer{};
    input.read(reinterpret_cast<char*>(buffer.data()), static_cast<std::streamsize>(buffer.size()));
    const std::streamsize count = input.gcount();
    std::uint64_t crc = 0;
    for (std::streamsize i = 0; i < count; ++i) {
        crc ^= static_cast<std::uint64_t>(buffer[static_cast<std::size_t>(i)]) << 56U;
        for (int bit = 0; bit < 8; ++bit) {
            crc = (crc & 0x8000000000000000ULL) ? (crc << 1U) ^ polynomial : (crc << 1U);
        }
    }
    return crc;
}

std::uint64_t splitmix64(std::uint64_t value) {
    value += 0x9E3779B97F4A7C15ULL;
    value = (value ^ (value >> 30U)) * 0xBF58476D1CE4E5B9ULL;
    value = (value ^ (value >> 27U)) * 0x94D049BB133111EBULL;
    return value ^ (value >> 31U);
}

std::uint64_t stable_file_identity(const fs::path& path) {
#if defined(__linux__) || defined(__APPLE__)
    struct stat info {};
    if (::stat(path.c_str(), &info) == 0) {
        return splitmix64(static_cast<std::uint64_t>(info.st_ino) ^
                          (static_cast<std::uint64_t>(info.st_dev) << 1U));
    }
#endif
    return splitmix64(std::hash<std::string>{}(path.generic_string()));
}

std::string hex64(std::uint64_t value) {
    std::ostringstream out;
    out << std::hex << std::setw(16) << std::setfill('0') << value;
    return out.str();
}

std::string hunt_uuid(const fs::path& path,
                      std::uint64_t bytes,
                      std::int64_t timestamp_ns,
                      std::uint64_t crc) {
    const std::uint64_t first = splitmix64(stable_file_identity(path) ^ crc ^
                                           static_cast<std::uint64_t>(timestamp_ns));
    const std::uint64_t second = splitmix64(bytes ^ (crc << 1U) ^
                                            std::hash<std::string>{}(path.generic_string()));
    std::string raw = hex64(first) + hex64(second);
    // Mark this as a deterministic, RFC-4122-shaped identifier.
    raw[12] = '5';
    const int variant = (std::stoi(raw.substr(16, 1), nullptr, 16) & 0x3) | 0x8;
    raw[16] = "0123456789abcdef"[variant];
    return raw.substr(0, 8) + "-" + raw.substr(8, 4) + "-" + raw.substr(12, 4) +
           "-" + raw.substr(16, 4) + "-" + raw.substr(20, 12);
}

std::string make_haiku(const std::string& uuid) {
    static const std::array<const char*, 8> first = {
        "Silent bytes drift", "Green circuits remember", "A small ghost waits",
        "Raster moonlight hums", "Cold folders flower", "The filename dreams",
        "Soft sectors shimmer", "Hidden clovers turn"
    };
    static const std::array<const char*, 8> second = {
        "through a door without weight", "beneath the numbered rain",
        "inside a borrowed name", "where old extensions sleep",
        "across the patient disk", "under electric moss",
        "between two timestamps", "past the edge of the file"
    };
    static const std::array<const char*, 4> third = {
        "The bytes remain", "Nothing is erased", "Spring returns the name", "Clover closes the loop"
    };
    const std::uint64_t seed = std::hash<std::string>{}(uuid);
    return std::string(first[seed & 7U]) + "\n" + second[(seed >> 3U) & 7U] + "\n" +
           third[(seed >> 6U) & 3U];
}

std::string slurp_or_throw(const fs::path& path) {
    std::string value;
    if (!read_text(path, value)) {
        throw std::runtime_error("cannot read lexicon: " + path.string());
    }
    return value;
}

constexpr const char* kFwemotesName = "fwemotes.json";

// When no --lexicon was given, the user lexicon is resolved fresh on every
// lookup so it may change form between calls: the mortal fwemotes.json wins,
// then its sealed capsule (whose raster is still the same JSON, because
// sealing never rewrites bytes), then the legacy hidden location.
fs::path implicit_lexicon_source() {
    const fs::path mortal = g_runtime.root / kFwemotesName;
    const fs::path sealed = g_runtime.root / (std::string(kFwemotesName) + kCapsuleSuffix);
    const fs::path legacy = g_runtime.root / ".fweddle" / "lexicon.json";
    std::error_code ec;
    if (fs::is_regular_file(mortal, ec)) {
        return mortal;
    }
    if (fs::is_regular_file(sealed, ec)) {
        return sealed;
    }
    if (fs::is_regular_file(legacy, ec)) {
        return legacy;
    }
    return {};
}

std::map<std::string, std::string> current_lexicon() {
    std::map<std::string, std::string> lexicon = builtin_lexicon();
    fs::path source;
    if (g_runtime.lexicon_was_explicit) {
        source = g_runtime.lexicon_path;
        std::error_code ec;
        if (!fs::exists(source, ec)) {
            throw std::runtime_error("lexicon does not exist: " + source.string());
        }
    } else {
        source = implicit_lexicon_source();
        if (source.empty()) {
            return lexicon;
        }
    }
    const std::string json = slurp_or_throw(source);
    if (json.find('{') == std::string::npos || json.find('}') == std::string::npos) {
        throw std::runtime_error("lexicon is not a JSON object");
    }
    const std::regex pair_pattern("\\\"((?:\\\\.|[^\\\"])*)\\\"\\s*:\\s*\\\"((?:\\\\.|[^\\\"])*)\\\"");
    std::size_t count = 0;
    for (std::sregex_iterator it(json.begin(), json.end(), pair_pattern), end; it != end; ++it) {
        std::string extension = lower_ascii(json_unescape((*it)[1].str()));
        if (!extension.empty() && extension.front() != '.') {
            extension.insert(extension.begin(), '.');
        }
        lexicon[extension] = json_unescape((*it)[2].str());
        ++count;
    }
    if (count == 0 && json.find_first_not_of(" \t\r\n{}") != std::string::npos) {
        throw std::runtime_error("lexicon contains no valid string mappings");
    }
    return lexicon;
}

std::string emoji_for(const std::string& extension) {
    const auto lexicon = current_lexicon();
    const auto found = lexicon.find(lower_ascii(extension));
    return found == lexicon.end() ? kFallbackEmoji : found->second;
}

std::string display_name(const Metadata& meta) {
    return meta.assigned_base + kClover + emoji_for(meta.extension);
}

int copy_result(const std::string& value, char* output, std::size_t capacity) {
    if (output == nullptr || capacity == 0) {
        set_error("output buffer is null or empty");
        return FW_INVALID_ARGUMENT;
    }
    if (value.size() + 1 > capacity) {
        set_error("output buffer needs at least " + std::to_string(value.size() + 1) + " bytes");
        return FW_BUFFER_TOO_SMALL;
    }
    std::memcpy(output, value.c_str(), value.size() + 1);
    return FW_OK;
}

int validate_output(const std::string& value, char* output, std::size_t capacity) {
    if (output == nullptr || capacity == 0) {
        set_error("output buffer is null or empty");
        return FW_INVALID_ARGUMENT;
    }
    if (value.size() + 1 > capacity) {
        set_error("output buffer needs at least " + std::to_string(value.size() + 1) + " bytes");
        return FW_BUFFER_TOO_SMALL;
    }
    return FW_OK;
}

void ensure_initialized() {
    if (g_runtime.initialized) {
        return;
    }
    g_runtime.root = fs::current_path();
    g_runtime.lexicon_path = g_runtime.root / ".fweddle" / "lexicon.json";
    g_runtime.lexicon_was_explicit = false;
    g_runtime.initialized = true;
}

std::pair<fs::path, Metadata> prepare_capsule(const fs::path& input) {
    std::error_code ec;
    fs::path source = fs::absolute(input, ec);
    if (ec) {
        throw std::runtime_error("cannot resolve source path: " + ec.message());
    }
    if (!fs::is_regular_file(source, ec) || ec) {
        throw std::runtime_error("source is not a regular file: " + source.string());
    }
    if (fs::is_symlink(fs::symlink_status(source, ec))) {
        throw std::runtime_error("symbolic links are not sealed; pass the real file instead");
    }
    if (ends_with(source.filename().string(), kCapsuleSuffix)) {
        throw std::logic_error("already-capsuled");
    }

    const std::uintmax_t raw_size = fs::file_size(source, ec);
    if (ec || raw_size > static_cast<std::uintmax_t>(std::numeric_limits<std::int64_t>::max())) {
        throw std::runtime_error("file size cannot be represented as signed capsule metadata");
    }
    const auto now = std::chrono::system_clock::now().time_since_epoch();
    const auto captured_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(now).count();
    const std::uint64_t crc = crc64_first_64(source);

    const std::string filename = source.filename().string();
    const std::string extension = source.extension().string();
    const std::string original_base = source.stem().string();
    std::string assigned_base = original_base;
    std::string mortal_name = filename;
    fs::path capsule = fs::path(source.string() + kCapsuleSuffix);

    if (fs::exists(capsule, ec) || fs::exists(sidecar_for(capsule), ec)) {
        bool found = false;
        for (std::uint64_t number = 2; number < 1000000; ++number) {
            assigned_base = original_base + " (" + std::to_string(number) + ")";
            mortal_name = assigned_base + extension;
            capsule = source.parent_path() / (mortal_name + kCapsuleSuffix);
            const fs::path mortal = source.parent_path() / mortal_name;
            if (!fs::exists(capsule, ec) && !fs::exists(sidecar_for(capsule), ec) &&
                !fs::exists(mortal, ec)) {
                found = true;
                break;
            }
        }
        if (!found) {
            throw std::runtime_error("could not allocate a collision-free capsule name");
        }
    }

    Metadata meta;
    meta.original_name = filename;
    meta.mortal_name = mortal_name;
    meta.original_base = original_base;
    meta.assigned_base = assigned_base;
    meta.extension = extension;
    meta.physical_bytes = static_cast<std::uint64_t>(raw_size);
    meta.negative_magnitude = -static_cast<std::int64_t>(raw_size);
    meta.captured_ns = captured_ns;
    meta.crc64 = hex64(crc);
    meta.hunt_uuid = hunt_uuid(source, meta.physical_bytes, captured_ns, crc);
    if (meta.physical_bytes > kOneGiB) {
        meta.haiku = make_haiku(meta.hunt_uuid);
    }
    return {capsule, meta};
}

bool write_registry(const fs::path& capsule, const Metadata& meta, std::string& error) {
    return atomic_write(registry_for(meta.hunt_uuid), metadata_json(meta, capsule), error);
}

fs::path choose_exorcised_path(const fs::path& capsule, const Metadata& meta) {
    std::error_code ec;
    fs::path target = capsule.parent_path() / meta.mortal_name;
    if (!fs::exists(target, ec)) {
        return target;
    }
    for (std::uint64_t number = 2; number < 1000000; ++number) {
        const std::string name = meta.original_base + " (" + std::to_string(number) + ")" + meta.extension;
        target = capsule.parent_path() / name;
        if (!fs::exists(target, ec)) {
            return target;
        }
    }
    throw std::runtime_error("could not allocate a collision-free mortal name");
}

std::optional<fs::path> resolve_capsule_or_display(const fs::path& input) {
    std::error_code ec;
    fs::path absolute = fs::absolute(input, ec);
    if (!ec && fs::is_regular_file(absolute, ec) &&
        !fs::is_symlink(fs::symlink_status(absolute, ec))) {
        return absolute;
    }
    ec.clear();
    const fs::path directory = input.has_parent_path() ? fs::absolute(input.parent_path(), ec)
                                                       : fs::current_path();
    if (ec || !fs::is_directory(directory, ec)) {
        return std::nullopt;
    }
    const std::string wanted = input.filename().string();
    for (const auto& entry : fs::directory_iterator(directory, fs::directory_options::skip_permission_denied, ec)) {
        if (ec || !entry.is_regular_file(ec) || entry.is_symlink(ec)) {
            continue;
        }
        if (!ends_with(entry.path().filename().string(), kCapsuleSuffix)) {
            continue;
        }
        Metadata meta;
        if (read_metadata(entry.path(), meta) && display_name(meta) == wanted) {
            return entry.path();
        }
    }
    return std::nullopt;
}

int exception_status(const std::exception& error) {
    set_error(error.what());
    return FW_IO_ERROR;
}

}  // namespace

extern "C" {

int fw_init(const char* root, const char* lexicon_path) {
    std::lock_guard<std::mutex> guard(g_mutex);
    try {
        std::error_code ec;
        fs::path resolved_root = root == nullptr ? fs::current_path() : fs::absolute(fs::u8path(root), ec);
        if (ec || !fs::is_directory(resolved_root, ec)) {
            set_error("root is not a readable directory");
            return FW_INVALID_ARGUMENT;
        }
        g_runtime.root = resolved_root;
        g_runtime.lexicon_was_explicit = lexicon_path != nullptr;
        g_runtime.lexicon_path = lexicon_path == nullptr
                                     ? resolved_root / ".fweddle" / "lexicon.json"
                                     : fs::absolute(fs::u8path(lexicon_path), ec);
        if (ec) {
            set_error("cannot resolve lexicon path: " + ec.message());
            return FW_INVALID_ARGUMENT;
        }
        g_runtime.initialized = true;
        (void)current_lexicon();
        g_last_error.clear();
        return FW_OK;
    } catch (const std::exception& error) {
        g_runtime.initialized = false;
        return exception_status(error);
    }
}

int fw_capsule(const char* path, char* out_path, std::size_t out_capacity) {
    std::lock_guard<std::mutex> guard(g_mutex);
    if (path == nullptr || *path == '\0') {
        set_error("capsule path is empty");
        return FW_INVALID_ARGUMENT;
    }
    try {
        ensure_initialized();
        auto prepared = prepare_capsule(fs::u8path(path));
        const fs::path source = fs::absolute(fs::u8path(path));
        const fs::path capsule = prepared.first;
        const Metadata& meta = prepared.second;
        const int output_status = validate_output(capsule.u8string(), out_path, out_capacity);
        if (output_status != FW_OK) {
            return output_status;
        }
        std::error_code ec;
        fs::rename(source, capsule, ec);
        if (ec) {
            set_error("native rename failed: " + ec.message());
            return FW_IO_ERROR;
        }

        write_xattrs(capsule, meta);
        std::string write_error;
        if (!atomic_write(sidecar_for(capsule), metadata_json(meta), write_error) ||
            !write_registry(capsule, meta, write_error)) {
            purge_xattrs(capsule);
            std::error_code cleanup_ec;
            fs::remove(sidecar_for(capsule), cleanup_ec);
            fs::remove(registry_for(meta.hunt_uuid), cleanup_ec);
            fs::rename(capsule, source, cleanup_ec);
            set_error("capsule transaction rolled back: " + write_error);
            return FW_IO_ERROR;
        }
        g_last_error.clear();
        return copy_result(capsule.u8string(), out_path, out_capacity);
    } catch (const std::logic_error& error) {
        set_error(error.what());
        return FW_ALREADY_CAPSULED;
    } catch (const std::exception& error) {
        return exception_status(error);
    }
}

int fw_display_name(const char* capsule_path, char* out_name, std::size_t out_capacity) {
    std::lock_guard<std::mutex> guard(g_mutex);
    if (capsule_path == nullptr || *capsule_path == '\0') {
        set_error("capsule path is empty");
        return FW_INVALID_ARGUMENT;
    }
    try {
        ensure_initialized();
        Metadata meta;
        const fs::path capsule = fs::absolute(fs::u8path(capsule_path));
        if (!read_metadata(capsule, meta)) {
            set_error("capsule metadata is missing or invalid: " + capsule.string());
            return FW_BAD_METADATA;
        }
        g_last_error.clear();
        return copy_result(display_name(meta), out_name, out_capacity);
    } catch (const std::exception& error) {
        return exception_status(error);
    }
}

int fw_exorcise(const char* capsule_or_display_path, char* out_path, std::size_t out_capacity) {
    std::lock_guard<std::mutex> guard(g_mutex);
    if (capsule_or_display_path == nullptr || *capsule_or_display_path == '\0') {
        set_error("capsule or display path is empty");
        return FW_INVALID_ARGUMENT;
    }
    try {
        ensure_initialized();
        const auto capsule = resolve_capsule_or_display(fs::u8path(capsule_or_display_path));
        if (!capsule) {
            set_error("capsule was not found");
            return FW_NOT_FOUND;
        }
        Metadata meta;
        if (!read_metadata(*capsule, meta)) {
            set_error("capsule metadata is missing or invalid");
            return FW_BAD_METADATA;
        }
        const fs::path mortal = choose_exorcised_path(*capsule, meta);
        const int output_status = validate_output(mortal.u8string(), out_path, out_capacity);
        if (output_status != FW_OK) {
            return output_status;
        }
        std::error_code ec;
        fs::rename(*capsule, mortal, ec);
        if (ec) {
            set_error("native rename failed: " + ec.message());
            return FW_IO_ERROR;
        }
        purge_xattrs(mortal);
        fs::remove(sidecar_for(*capsule), ec);
        ec.clear();
        fs::remove(registry_for(meta.hunt_uuid), ec);
        g_last_error.clear();
        return copy_result(mortal.u8string(), out_path, out_capacity);
    } catch (const std::exception& error) {
        return exception_status(error);
    }
}

int fw_resurrect(const char* hunt_uuid_value,
                 const char* search_root,
                 char* out_path,
                 std::size_t out_capacity) {
    std::lock_guard<std::mutex> guard(g_mutex);
    if (hunt_uuid_value == nullptr || *hunt_uuid_value == '\0') {
        set_error("Hunt_UUID is empty");
        return FW_INVALID_ARGUMENT;
    }
    try {
        ensure_initialized();
        std::error_code ec;
        const fs::path root = search_root == nullptr ? g_runtime.root
                                                     : fs::absolute(fs::u8path(search_root), ec);
        if (ec || !fs::is_directory(root, ec)) {
            set_error("search root is not a readable directory");
            return FW_INVALID_ARGUMENT;
        }
        const std::string wanted(hunt_uuid_value);
        fs::recursive_directory_iterator iterator(root, fs::directory_options::skip_permission_denied, ec);
        const fs::recursive_directory_iterator end;
        for (; iterator != end; iterator.increment(ec)) {
            if (ec) {
                ec.clear();
                continue;
            }
            const auto& entry = *iterator;
            if (entry.is_directory(ec) && entry.path().filename() == ".fweddle") {
                iterator.disable_recursion_pending();
                continue;
            }
            if (!entry.is_regular_file(ec) || entry.is_symlink(ec)) {
                continue;
            }
            Metadata meta;
            const auto backlink = get_xattr(entry.path(), "user.fweddle.backlink");
            bool matched = backlink && *backlink == wanted && metadata_from_xattrs(entry.path(), meta);
            if (!matched && ends_with(entry.path().filename().string(), kCapsuleSuffix) &&
                read_metadata(entry.path(), meta) && meta.hunt_uuid == wanted) {
                matched = true;
            }
            if (!matched) {
                continue;
            }
            const int output_status = validate_output(entry.path().u8string(), out_path, out_capacity);
            if (output_status != FW_OK) {
                return output_status;
            }
            std::string write_error;
            if (!fs::exists(sidecar_for(entry.path()), ec) &&
                !atomic_write(sidecar_for(entry.path()), metadata_json(meta), write_error)) {
                set_error("found backlink but could not restore sidecar: " + write_error);
                return FW_IO_ERROR;
            }
            if (!write_registry(entry.path(), meta, write_error)) {
                set_error("found backlink but could not refresh registry: " + write_error);
                return FW_IO_ERROR;
            }
            g_last_error.clear();
            return copy_result(entry.path().u8string(), out_path, out_capacity);
        }
        set_error("no backlink matched Hunt_UUID " + wanted);
        return FW_NOT_FOUND;
    } catch (const std::exception& error) {
        return exception_status(error);
    }
}

const char* fw_last_error() {
    return g_last_error.c_str();
}

}  // extern "C"

namespace fweddle_detail {

std::unique_lock<std::mutex> lock_runtime() {
    return std::unique_lock<std::mutex>(g_mutex);
}

std::filesystem::path runtime_root_locked() {
    ensure_initialized();
    return g_runtime.root;
}

void set_last_error(const std::string& message) {
    set_error(message);
}

void clear_last_error() {
    g_last_error.clear();
}

bool atomic_write_file(const std::filesystem::path& target,
                       const std::string& data,
                       std::string& error) {
    return atomic_write(target, data, error);
}

int copy_result_buffer(const std::string& value, char* output, std::size_t capacity) {
    return copy_result(value, output, capacity);
}

std::map<std::string, std::string> effective_lexicon_locked() {
    return current_lexicon();
}

std::map<std::string, std::string> builtin_lexicon_map() {
    return builtin_lexicon();
}

std::filesystem::path implicit_lexicon_source_locked() {
    return implicit_lexicon_source();
}

bool lexicon_is_explicit_locked() {
    return g_runtime.lexicon_was_explicit;
}

std::filesystem::path explicit_lexicon_path_locked() {
    return g_runtime.lexicon_path;
}

}  // namespace fweddle_detail
