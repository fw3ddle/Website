#ifndef FWEDDLE_INTERNAL_HPP
#define FWEDDLE_INTERNAL_HPP

#include <cstddef>
#include <filesystem>
#include <map>
#include <mutex>
#include <string>

// Shared plumbing between the core translation unit (fweddle.cpp) and sibling
// modules such as the hunk engine (hunks.cpp). This is not part of the public
// ABI and may change between releases.
namespace fweddle_detail {

// Acquires the process-wide operation lock. Every public entry point holds
// this for its full duration, so sibling modules must do the same.
std::unique_lock<std::mutex> lock_runtime();

// Requires the runtime lock. Performs the same lazy initialization as the
// core operations, then returns the configured root directory.
std::filesystem::path runtime_root_locked();

// Route diagnostics through the same thread-local slot that fw_last_error()
// reads.
void set_last_error(const std::string& message);
void clear_last_error();

// The core's temp-file-then-rename writer, reused so every persistent
// artifact commits the same way.
bool atomic_write_file(const std::filesystem::path& target,
                       const std::string& data,
                       std::string& error);

// The core's caller-owned-buffer convention: UTF-8, NUL-terminated,
// FW_BUFFER_TOO_SMALL when the value does not fit.
int copy_result_buffer(const std::string& value, char* output, std::size_t capacity);

// Lexicon plumbing for the emotes module. All of these require the runtime
// lock. effective_lexicon_locked may throw if an explicit or user lexicon is
// present but unreadable.
std::map<std::string, std::string> effective_lexicon_locked();
std::map<std::string, std::string> builtin_lexicon_map();
std::filesystem::path implicit_lexicon_source_locked();
bool lexicon_is_explicit_locked();
std::filesystem::path explicit_lexicon_path_locked();

}  // namespace fweddle_detail

#endif
