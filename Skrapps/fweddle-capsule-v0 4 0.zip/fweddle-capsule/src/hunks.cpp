// The hunk engine: observational deduplication for Fweddle Capsule.
//
// `fw_hunk_scan` splits every regular file beneath a root into content-defined
// hunks, hashes each hunk with SHA-256, and writes a single atomic ledger to
// <root>/.fweddle/hunks/ledger.json. `fw_hunk_echoes` reads that ledger back
// and notates where identical content recurs, expressed — in keeping with the
// house style — as negative magnitudes.
//
// The engine is strictly read-only with respect to user files: it never
// rewrites, relinks, moves, or deletes a raster. The only thing it writes is
// the ledger.

#include "fweddle/fweddle.hpp"

#include "internal.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <map>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace {

// ---------------------------------------------------------------------------
// Tunables. These are recorded in the ledger header so a future schema can
// tell how an old ledger was cut.
// ---------------------------------------------------------------------------

constexpr std::uint32_t kMinHunk = 2048;
constexpr std::uint32_t kMaxHunk = 65536;
constexpr std::uint32_t kMaskBits = 13;  // expected gap after the minimum: 8 KiB
constexpr std::uint64_t kBoundaryMask = (1ULL << kMaskBits) - 1ULL;
constexpr int kLedgerSchema = 1;
constexpr std::size_t kTopList = 12;

// ---------------------------------------------------------------------------
// Gear table for the rolling fingerprint, generated deterministically so the
// same bytes cut into the same hunks on every platform.
// ---------------------------------------------------------------------------

std::uint64_t mix64(std::uint64_t value) {
    value += 0x9E3779B97F4A7C15ULL;
    value = (value ^ (value >> 30U)) * 0xBF58476D1CE4E5B9ULL;
    value = (value ^ (value >> 27U)) * 0x94D049BB133111EBULL;
    return value ^ (value >> 31U);
}

const std::array<std::uint64_t, 256>& gear_table() {
    static const std::array<std::uint64_t, 256> table = [] {
        std::array<std::uint64_t, 256> built{};
        for (std::size_t i = 0; i < built.size(); ++i) {
            built[i] = mix64(0xF3EDD1E5EA1C10FEULL + i);
        }
        return built;
    }();
    return table;
}

// ---------------------------------------------------------------------------
// SHA-256 (FIPS 180-4), streaming. Verified against the standard test vectors
// in tests/test_hunks.cpp.
// ---------------------------------------------------------------------------

struct Sha256 {
    std::uint32_t state[8];
    std::uint64_t length = 0;  // bytes fed so far
    unsigned char block[64];
    std::size_t buffered = 0;

    Sha256() { reset(); }

    void reset() {
        static const std::uint32_t initial[8] = {
            0x6a09e667U, 0xbb67ae85U, 0x3c6ef372U, 0xa54ff53aU,
            0x510e527fU, 0x9b05688cU, 0x1f83d9abU, 0x5be0cd19U};
        std::memcpy(state, initial, sizeof state);
        length = 0;
        buffered = 0;
    }

    static std::uint32_t rotr(std::uint32_t value, unsigned amount) {
        return (value >> amount) | (value << (32U - amount));
    }

    void compress(const unsigned char* chunk) {
        static const std::uint32_t k[64] = {
            0x428a2f98U, 0x71374491U, 0xb5c0fbcfU, 0xe9b5dba5U, 0x3956c25bU,
            0x59f111f1U, 0x923f82a4U, 0xab1c5ed5U, 0xd807aa98U, 0x12835b01U,
            0x243185beU, 0x550c7dc3U, 0x72be5d74U, 0x80deb1feU, 0x9bdc06a7U,
            0xc19bf174U, 0xe49b69c1U, 0xefbe4786U, 0x0fc19dc6U, 0x240ca1ccU,
            0x2de92c6fU, 0x4a7484aaU, 0x5cb0a9dcU, 0x76f988daU, 0x983e5152U,
            0xa831c66dU, 0xb00327c8U, 0xbf597fc7U, 0xc6e00bf3U, 0xd5a79147U,
            0x06ca6351U, 0x14292967U, 0x27b70a85U, 0x2e1b2138U, 0x4d2c6dfcU,
            0x53380d13U, 0x650a7354U, 0x766a0abbU, 0x81c2c92eU, 0x92722c85U,
            0xa2bfe8a1U, 0xa81a664bU, 0xc24b8b70U, 0xc76c51a3U, 0xd192e819U,
            0xd6990624U, 0xf40e3585U, 0x106aa070U, 0x19a4c116U, 0x1e376c08U,
            0x2748774cU, 0x34b0bcb5U, 0x391c0cb3U, 0x4ed8aa4aU, 0x5b9cca4fU,
            0x682e6ff3U, 0x748f82eeU, 0x78a5636fU, 0x84c87814U, 0x8cc70208U,
            0x90befffaU, 0xa4506cebU, 0xbef9a3f7U, 0xc67178f2U};

        std::uint32_t w[64];
        for (int t = 0; t < 16; ++t) {
            w[t] = (static_cast<std::uint32_t>(chunk[4 * t]) << 24U) |
                   (static_cast<std::uint32_t>(chunk[4 * t + 1]) << 16U) |
                   (static_cast<std::uint32_t>(chunk[4 * t + 2]) << 8U) |
                   static_cast<std::uint32_t>(chunk[4 * t + 3]);
        }
        for (int t = 16; t < 64; ++t) {
            const std::uint32_t s0 = rotr(w[t - 15], 7) ^ rotr(w[t - 15], 18) ^ (w[t - 15] >> 3U);
            const std::uint32_t s1 = rotr(w[t - 2], 17) ^ rotr(w[t - 2], 19) ^ (w[t - 2] >> 10U);
            w[t] = w[t - 16] + s0 + w[t - 7] + s1;
        }

        std::uint32_t a = state[0], b = state[1], c = state[2], d = state[3];
        std::uint32_t e = state[4], f = state[5], g = state[6], h = state[7];
        for (int t = 0; t < 64; ++t) {
            const std::uint32_t big_s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
            const std::uint32_t choose = (e & f) ^ (~e & g);
            const std::uint32_t temp1 = h + big_s1 + choose + k[t] + w[t];
            const std::uint32_t big_s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
            const std::uint32_t majority = (a & b) ^ (a & c) ^ (b & c);
            const std::uint32_t temp2 = big_s0 + majority;
            h = g;
            g = f;
            f = e;
            e = d + temp1;
            d = c;
            c = b;
            b = a;
            a = temp1 + temp2;
        }
        state[0] += a;
        state[1] += b;
        state[2] += c;
        state[3] += d;
        state[4] += e;
        state[5] += f;
        state[6] += g;
        state[7] += h;
    }

    void update(const unsigned char* data, std::size_t size) {
        length += size;
        if (buffered > 0) {
            const std::size_t wanted = 64 - buffered;
            const std::size_t taken = size < wanted ? size : wanted;
            std::memcpy(block + buffered, data, taken);
            buffered += taken;
            data += taken;
            size -= taken;
            if (buffered == 64) {
                compress(block);
                buffered = 0;
            }
        }
        while (size >= 64) {
            compress(data);
            data += 64;
            size -= 64;
        }
        if (size > 0) {
            std::memcpy(block, data, size);
            buffered = size;
        }
    }

    std::array<unsigned char, 32> finish() {
        const std::uint64_t bits = length * 8ULL;
        const unsigned char one = 0x80;
        const unsigned char zero = 0x00;
        update(&one, 1);
        while (buffered != 56) {
            update(&zero, 1);
        }
        unsigned char trailer[8];
        for (int i = 0; i < 8; ++i) {
            trailer[i] = static_cast<unsigned char>(bits >> (56 - 8 * i));
        }
        update(trailer, 8);
        std::array<unsigned char, 32> digest{};
        for (int i = 0; i < 8; ++i) {
            digest[4 * i] = static_cast<unsigned char>(state[i] >> 24U);
            digest[4 * i + 1] = static_cast<unsigned char>(state[i] >> 16U);
            digest[4 * i + 2] = static_cast<unsigned char>(state[i] >> 8U);
            digest[4 * i + 3] = static_cast<unsigned char>(state[i]);
        }
        return digest;
    }
};

std::string hex_digest(const std::array<unsigned char, 32>& digest) {
    static const char* alphabet = "0123456789abcdef";
    std::string out;
    out.reserve(64);
    for (unsigned char byte : digest) {
        out.push_back(alphabet[byte >> 4U]);
        out.push_back(alphabet[byte & 0x0FU]);
    }
    return out;
}

// ---------------------------------------------------------------------------
// Ledger model.
// ---------------------------------------------------------------------------

struct LedgerFile {
    std::string rel;
    std::uint64_t bytes = 0;
    std::string whole;  // SHA-256 of the entire raster
};

struct HunkSite {
    std::uint32_t file = 0;
    std::uint64_t offset = 0;
};

struct LedgerHunk {
    std::string hash;
    std::uint32_t length = 0;
    std::vector<HunkSite> sites;
};

struct Ledger {
    int schema = kLedgerSchema;
    std::string root;  // absolute scan root, generic form
    std::int64_t scanned_ns = 0;
    std::uint64_t skipped = 0;  // unreadable files, counted and moved past
    std::vector<LedgerFile> files;
    std::vector<LedgerHunk> hunks;
};

struct HunkRecord {
    std::uint64_t offset = 0;
    std::uint32_t length = 0;
    std::string hash;
};

// ---------------------------------------------------------------------------
// Single-pass content-defined chunking: the gear fingerprint decides where a
// hunk ends while the same sweep feeds both the per-hunk and whole-raster
// hashes. The file is only ever read.
// ---------------------------------------------------------------------------

bool hunk_file(const fs::path& path,
               std::vector<HunkRecord>& hunks,
               std::string& whole_hex,
               std::uint64_t& total_bytes,
               std::string& error) {
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        error = "cannot open " + path.string();
        return false;
    }
    const auto& gear = gear_table();
    std::vector<unsigned char> buffer(1U << 20U);
    Sha256 whole;
    Sha256 current;
    std::uint64_t fingerprint = 0;
    std::uint64_t position = 0;
    std::uint64_t hunk_start = 0;
    std::uint32_t hunk_length = 0;

    while (input) {
        input.read(reinterpret_cast<char*>(buffer.data()),
                   static_cast<std::streamsize>(buffer.size()));
        const std::streamsize got = input.gcount();
        if (got <= 0) {
            break;
        }
        const std::size_t count = static_cast<std::size_t>(got);
        whole.update(buffer.data(), count);
        std::size_t segment_start = 0;
        for (std::size_t i = 0; i < count; ++i) {
            fingerprint = (fingerprint << 1U) + gear[buffer[i]];
            ++hunk_length;
            const bool boundary =
                (hunk_length >= kMinHunk && (fingerprint & kBoundaryMask) == 0) ||
                hunk_length == kMaxHunk;
            if (boundary) {
                current.update(buffer.data() + segment_start, i + 1 - segment_start);
                hunks.push_back({hunk_start, hunk_length, hex_digest(current.finish())});
                current.reset();
                hunk_start = position + i + 1;
                hunk_length = 0;
                fingerprint = 0;
                segment_start = i + 1;
            }
        }
        if (segment_start < count) {
            current.update(buffer.data() + segment_start, count - segment_start);
        }
        position += count;
    }
    if (input.bad()) {
        error = "read failure in " + path.string();
        return false;
    }
    if (hunk_length > 0) {
        hunks.push_back({hunk_start, hunk_length, hex_digest(current.finish())});
    }
    total_bytes = position;
    whole_hex = hex_digest(whole.finish());
    return true;
}

// ---------------------------------------------------------------------------
// Directory walk: same skip rules as the rest of the core — no symlinks, no
// `.fweddle` internals, no `.fwmeta` sidecars. Capsules are deliberately
// included; a sealed copy still echoes its unsealed twin.
// ---------------------------------------------------------------------------

bool is_sidecar_name(const std::string& name) {
    return !name.empty() && name.front() == '.' && name.size() >= 7 &&
           name.compare(name.size() - 7, 7, ".fwmeta") == 0;
}

bool collect_regular_files(const fs::path& scan_root,
                           std::vector<fs::path>& out,
                           std::string& error) {
    std::error_code ec;
    fs::recursive_directory_iterator iterator(
        scan_root, fs::directory_options::skip_permission_denied, ec);
    if (ec) {
        error = "cannot open scan root: " + ec.message();
        return false;
    }
    const fs::recursive_directory_iterator end;
    for (; iterator != end; iterator.increment(ec)) {
        if (ec) {
            ec.clear();
            continue;
        }
        const auto& entry = *iterator;
        if (entry.is_directory(ec) && entry.path().filename() == ".fweddle") {
            iterator.disable_recursion_pending();
            continue;
        }
        if (!entry.is_regular_file(ec) || entry.is_symlink(ec)) {
            continue;
        }
        if (is_sidecar_name(entry.path().filename().string())) {
            continue;
        }
        out.push_back(entry.path());
    }
    std::sort(out.begin(), out.end(), [](const fs::path& left, const fs::path& right) {
        return left.generic_u8string() < right.generic_u8string();
    });
    return true;
}

bool build_ledger(const fs::path& scan_root, Ledger& ledger, std::string& error) {
    ledger.root = scan_root.lexically_normal().generic_u8string();
    const auto now = std::chrono::system_clock::now().time_since_epoch();
    ledger.scanned_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(now).count();

    std::vector<fs::path> paths;
    if (!collect_regular_files(scan_root, paths, error)) {
        return false;
    }

    std::map<std::string, LedgerHunk> pool;
    for (const auto& path : paths) {
        std::vector<HunkRecord> records;
        std::string whole;
        std::uint64_t bytes = 0;
        std::string file_error;
        if (!hunk_file(path, records, whole, bytes, file_error)) {
            ++ledger.skipped;
            continue;
        }
        const std::uint32_t id = static_cast<std::uint32_t>(ledger.files.size());
        LedgerFile file;
        file.rel = path.lexically_relative(scan_root).lexically_normal().generic_u8string();
        file.bytes = bytes;
        file.whole = whole;
        ledger.files.push_back(std::move(file));
        for (auto& record : records) {
            LedgerHunk& slot = pool[record.hash];
            if (slot.sites.empty()) {
                slot.hash = record.hash;
                slot.length = record.length;
            } else if (slot.length != record.length) {
                error = "two hunks share a SHA-256 but differ in length; ledger aborted";
                return false;
            }
            slot.sites.push_back({id, record.offset});
        }
    }
    ledger.hunks.reserve(pool.size());
    for (auto& pair : pool) {
        ledger.hunks.push_back(std::move(pair.second));
    }
    return true;
}

// ---------------------------------------------------------------------------
// Ledger serialization. The emitter and the parser ship together and agree on
// an exact shape; anything else is rejected with a request to rescan.
// ---------------------------------------------------------------------------

std::string escape(const std::string& value) {
    std::ostringstream out;
    for (unsigned char c : value) {
        switch (c) {
            case '\\': out << "\\\\"; break;
            case '"': out << "\\\""; break;
            case '\n': out << "\\n"; break;
            case '\r': out << "\\r"; break;
            case '\t': out << "\\t"; break;
            default:
                if (c < 0x20) {
                    static const char* alphabet = "0123456789abcdef";
                    out << "\\u00" << alphabet[c >> 4U] << alphabet[c & 0x0FU];
                } else {
                    out << static_cast<char>(c);
                }
        }
    }
    return out.str();
}

std::string emit_ledger(const Ledger& ledger) {
    std::ostringstream out;
    out << "{\n"
        << "  \"schema\": " << ledger.schema << ",\n"
        << "  \"algo\": \"sha256\",\n"
        << "  \"cdc_min\": " << kMinHunk << ",\n"
        << "  \"cdc_mask_bits\": " << kMaskBits << ",\n"
        << "  \"cdc_max\": " << kMaxHunk << ",\n"
        << "  \"scanned_ns\": " << ledger.scanned_ns << ",\n"
        << "  \"skipped\": " << ledger.skipped << ",\n"
        << "  \"root\": \"" << escape(ledger.root) << "\",\n"
        << "  \"files\": [";
    for (std::size_t i = 0; i < ledger.files.size(); ++i) {
        const LedgerFile& file = ledger.files[i];
        out << (i == 0 ? "" : ",") << "\n    [\"" << escape(file.rel) << "\", "
            << file.bytes << ", \"" << file.whole << "\"]";
    }
    out << (ledger.files.empty() ? "" : "\n  ") << "],\n  \"hunks\": [";
    for (std::size_t i = 0; i < ledger.hunks.size(); ++i) {
        const LedgerHunk& hunk = ledger.hunks[i];
        out << (i == 0 ? "" : ",") << "\n    [\"" << hunk.hash << "\", " << hunk.length
            << ", [";
        for (std::size_t j = 0; j < hunk.sites.size(); ++j) {
            out << (j == 0 ? "" : ",") << "[" << hunk.sites[j].file << ","
                << hunk.sites[j].offset << "]";
        }
        out << "]]";
    }
    out << (ledger.hunks.empty() ? "" : "\n  ") << "]\n}\n";
    return out.str();
}

struct Scanner {
    const std::string& text;
    std::size_t pos = 0;

    explicit Scanner(const std::string& source) : text(source) {}

    void skip_ws() {
        while (pos < text.size() &&
               (text[pos] == ' ' || text[pos] == '\n' || text[pos] == '\r' ||
                text[pos] == '\t')) {
            ++pos;
        }
    }

    bool eat(char wanted) {
        skip_ws();
        if (pos < text.size() && text[pos] == wanted) {
            ++pos;
            return true;
        }
        return false;
    }

    bool peek(char wanted) {
        skip_ws();
        return pos < text.size() && text[pos] == wanted;
    }

    bool string_value(std::string& out) {
        skip_ws();
        if (pos >= text.size() || text[pos] != '"') {
            return false;
        }
        ++pos;
        out.clear();
        while (pos < text.size()) {
            const char c = text[pos++];
            if (c == '"') {
                return true;
            }
            if (c != '\\') {
                out.push_back(c);
                continue;
            }
            if (pos >= text.size()) {
                return false;
            }
            const char escaped = text[pos++];
            switch (escaped) {
                case '\\': out.push_back('\\'); break;
                case '"': out.push_back('"'); break;
                case 'n': out.push_back('\n'); break;
                case 'r': out.push_back('\r'); break;
                case 't': out.push_back('\t'); break;
                case 'u': {
                    if (pos + 4 > text.size()) {
                        return false;
                    }
                    unsigned value = 0;
                    for (int i = 0; i < 4; ++i) {
                        const char h = text[pos++];
                        value <<= 4U;
                        if (h >= '0' && h <= '9') {
                            value |= static_cast<unsigned>(h - '0');
                        } else if (h >= 'a' && h <= 'f') {
                            value |= static_cast<unsigned>(h - 'a' + 10);
                        } else if (h >= 'A' && h <= 'F') {
                            value |= static_cast<unsigned>(h - 'A' + 10);
                        } else {
                            return false;
                        }
                    }
                    if (value < 0x80U) {
                        out.push_back(static_cast<char>(value));
                    } else if (value < 0x800U) {
                        out.push_back(static_cast<char>(0xC0U | (value >> 6U)));
                        out.push_back(static_cast<char>(0x80U | (value & 0x3FU)));
                    } else {
                        out.push_back(static_cast<char>(0xE0U | (value >> 12U)));
                        out.push_back(static_cast<char>(0x80U | ((value >> 6U) & 0x3FU)));
                        out.push_back(static_cast<char>(0x80U | (value & 0x3FU)));
                    }
                    break;
                }
                default:
                    return false;
            }
        }
        return false;
    }

    bool u64_value(std::uint64_t& out) {
        skip_ws();
        const std::size_t start = pos;
        while (pos < text.size() && text[pos] >= '0' && text[pos] <= '9') {
            ++pos;
        }
        if (pos == start) {
            return false;
        }
        try {
            out = std::stoull(text.substr(start, pos - start));
        } catch (...) {
            return false;
        }
        return true;
    }

    bool i64_value(std::int64_t& out) {
        skip_ws();
        const std::size_t start = pos;
        if (pos < text.size() && text[pos] == '-') {
            ++pos;
        }
        const std::size_t digits = pos;
        while (pos < text.size() && text[pos] >= '0' && text[pos] <= '9') {
            ++pos;
        }
        if (pos == digits) {
            return false;
        }
        try {
            out = std::stoll(text.substr(start, pos - start));
        } catch (...) {
            return false;
        }
        return true;
    }

    bool key(const char* name) {
        std::string parsed;
        return string_value(parsed) && parsed == name && eat(':');
    }
};

bool parse_ledger(const std::string& text, Ledger& ledger, std::string& error) {
    Scanner scanner(text);
    const auto fail = [&error](const char* what) {
        error = what;
        return false;
    };
    std::uint64_t schema = 0;
    std::uint64_t cdc_min = 0;
    std::uint64_t cdc_bits = 0;
    std::uint64_t cdc_max = 0;
    std::uint64_t skipped = 0;
    std::int64_t scanned = 0;
    std::string algo;
    if (!scanner.eat('{')) return fail("ledger is not an object");
    if (!scanner.key("schema") || !scanner.u64_value(schema) || !scanner.eat(','))
        return fail("bad schema field");
    if (schema != static_cast<std::uint64_t>(kLedgerSchema)) return fail("unsupported schema");
    if (!scanner.key("algo") || !scanner.string_value(algo) || !scanner.eat(','))
        return fail("bad algo field");
    if (algo != "sha256") return fail("unsupported hash algorithm");
    if (!scanner.key("cdc_min") || !scanner.u64_value(cdc_min) || !scanner.eat(','))
        return fail("bad cdc_min field");
    if (!scanner.key("cdc_mask_bits") || !scanner.u64_value(cdc_bits) || !scanner.eat(','))
        return fail("bad cdc_mask_bits field");
    if (!scanner.key("cdc_max") || !scanner.u64_value(cdc_max) || !scanner.eat(','))
        return fail("bad cdc_max field");
    if (!scanner.key("scanned_ns") || !scanner.i64_value(scanned) || !scanner.eat(','))
        return fail("bad scanned_ns field");
    if (!scanner.key("skipped") || !scanner.u64_value(skipped) || !scanner.eat(','))
        return fail("bad skipped field");
    if (!scanner.key("root") || !scanner.string_value(ledger.root) || !scanner.eat(','))
        return fail("bad root field");
    if (!scanner.key("files") || !scanner.eat('[')) return fail("bad files field");
    if (!scanner.peek(']')) {
        do {
            LedgerFile file;
            if (!scanner.eat('[') || !scanner.string_value(file.rel) || !scanner.eat(',') ||
                !scanner.u64_value(file.bytes) || !scanner.eat(',') ||
                !scanner.string_value(file.whole) || !scanner.eat(']')) {
                return fail("bad file entry");
            }
            ledger.files.push_back(std::move(file));
        } while (scanner.eat(','));
    }
    if (!scanner.eat(']') || !scanner.eat(',')) return fail("unterminated files array");
    if (!scanner.key("hunks") || !scanner.eat('[')) return fail("bad hunks field");
    if (!scanner.peek(']')) {
        do {
            LedgerHunk hunk;
            std::uint64_t length = 0;
            if (!scanner.eat('[') || !scanner.string_value(hunk.hash) || !scanner.eat(',') ||
                !scanner.u64_value(length) || !scanner.eat(',') || !scanner.eat('[')) {
                return fail("bad hunk entry");
            }
            hunk.length = static_cast<std::uint32_t>(length);
            if (!scanner.peek(']')) {
                do {
                    std::uint64_t file_id = 0;
                    std::uint64_t offset = 0;
                    if (!scanner.eat('[') || !scanner.u64_value(file_id) || !scanner.eat(',') ||
                        !scanner.u64_value(offset) || !scanner.eat(']')) {
                        return fail("bad site entry");
                    }
                    if (file_id >= ledger.files.size()) {
                        return fail("site references a file that is not in the ledger");
                    }
                    hunk.sites.push_back({static_cast<std::uint32_t>(file_id), offset});
                } while (scanner.eat(','));
            }
            if (!scanner.eat(']') || !scanner.eat(']')) return fail("unterminated hunk entry");
            ledger.hunks.push_back(std::move(hunk));
        } while (scanner.eat(','));
    }
    if (!scanner.eat(']') || !scanner.eat('}')) return fail("unterminated hunks array");
    ledger.schema = static_cast<int>(schema);
    ledger.scanned_ns = scanned;
    ledger.skipped = skipped;
    (void)cdc_min;
    (void)cdc_bits;
    (void)cdc_max;
    return true;
}

bool read_file_text(const fs::path& path, std::string& text) {
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        return false;
    }
    std::ostringstream buffer;
    buffer << input.rdbuf();
    if (!input.good() && !input.eof()) {
        return false;
    }
    text = buffer.str();
    return true;
}

// ---------------------------------------------------------------------------
// Echo analysis: everything below is arithmetic over the ledger.
// ---------------------------------------------------------------------------

fs::path ledger_path_for(const fs::path& root) {
    return root / ".fweddle" / "hunks" / "ledger.json";
}

std::string format_percent(std::uint64_t part, std::uint64_t whole) {
    char buffer[32];
    const double percent = whole == 0 ? 0.0
                                      : 100.0 * static_cast<double>(part) /
                                            static_cast<double>(whole);
    std::snprintf(buffer, sizeof buffer, "%.1f", percent);
    return buffer;
}

std::string negator(std::uint64_t magnitude) {
    return magnitude == 0 ? "0" : "-" + std::to_string(magnitude);
}

// Per-hunk tally of how many sites each file contributes.
std::map<std::uint32_t, std::uint32_t> file_counts(const LedgerHunk& hunk) {
    std::map<std::uint32_t, std::uint32_t> counts;
    for (const HunkSite& site : hunk.sites) {
        ++counts[site.file];
    }
    return counts;
}

void append_top(std::ostringstream& out,
                std::vector<std::pair<std::uint64_t, std::string>>& entries) {
    std::sort(entries.begin(), entries.end(),
              [](const auto& left, const auto& right) {
                  if (left.first != right.first) return left.first > right.first;
                  return left.second < right.second;
              });
    const std::size_t shown = entries.size() < kTopList ? entries.size() : kTopList;
    for (std::size_t i = 0; i < shown; ++i) {
        out << "     -" << entries[i].first << "   " << entries[i].second << "\n";
    }
    if (entries.size() > shown) {
        out << "     … and " << (entries.size() - shown) << " more\n";
    }
}

std::string global_report(const Ledger& ledger) {
    std::uint64_t total_bytes = 0;
    for (const LedgerFile& file : ledger.files) {
        total_bytes += file.bytes;
    }
    std::uint64_t sites = 0;
    std::uint64_t redundant = 0;
    std::vector<std::pair<std::uint64_t, std::string>> pairs;
    std::map<std::pair<std::uint32_t, std::uint32_t>, std::pair<std::uint64_t, std::uint64_t>>
        pair_bytes;  // (bytes, hunk count)
    for (const LedgerHunk& hunk : ledger.hunks) {
        sites += hunk.sites.size();
        const std::uint64_t occurrences = hunk.sites.size();
        if (occurrences >= 2) {
            redundant += static_cast<std::uint64_t>(hunk.length) * (occurrences - 1);
            const auto counts = file_counts(hunk);
            for (auto left = counts.begin(); left != counts.end(); ++left) {
                if (left->second >= 2) {
                    auto& slot = pair_bytes[{left->first, left->first}];
                    slot.first += static_cast<std::uint64_t>(hunk.length) * (left->second - 1);
                    ++slot.second;
                }
                auto right = left;
                for (++right; right != counts.end(); ++right) {
                    const std::uint32_t overlap =
                        left->second < right->second ? left->second : right->second;
                    auto& slot = pair_bytes[{left->first, right->first}];
                    slot.first += static_cast<std::uint64_t>(hunk.length) * overlap;
                    ++slot.second;
                }
            }
        }
    }

    std::ostringstream out;
    out << "🍀 hunk ledger for " << ledger.root << "\n";
    out << "   files: " << ledger.files.size() << "   hunk sites: " << sites
        << "   distinct hunks: " << ledger.hunks.size();
    if (ledger.skipped > 0) {
        out << "   skipped: " << ledger.skipped;
    }
    out << "\n";
    out << "   physical_bytes:      " << total_bytes << "\n";
    out << "   redundancy_negator:  " << negator(redundant)
        << "   (bytes carried more than once)\n";
    if (redundant == 0) {
        out << "   every hunk is one of a kind — no echoes.\n";
        return out.str();
    }

    std::map<std::string, std::vector<std::uint32_t>> twins;
    for (std::uint32_t id = 0; id < ledger.files.size(); ++id) {
        if (ledger.files[id].bytes > 0) {
            twins[ledger.files[id].whole].push_back(id);
        }
    }
    bool titled = false;
    for (const auto& group : twins) {
        if (group.second.size() < 2) {
            continue;
        }
        if (!titled) {
            out << "\n   perfect doppelgängers:\n";
            titled = true;
        }
        out << "     ";
        for (std::size_t i = 0; i < group.second.size(); ++i) {
            out << (i == 0 ? "" : "  ≡  ") << ledger.files[group.second[i]].rel;
        }
        out << "   (" << ledger.files[group.second.front()].bytes << " bytes)\n";
    }

    out << "\n   loudest echoes:\n";
    for (const auto& entry : pair_bytes) {
        const std::uint32_t left = entry.first.first;
        const std::uint32_t right = entry.first.second;
        const std::string label =
            left == right
                ? ledger.files[left].rel + "  ↔  (itself)   (" +
                      std::to_string(entry.second.second) + " hunks)"
                : ledger.files[left].rel + "  ↔  " + ledger.files[right].rel + "   (" +
                      std::to_string(entry.second.second) + " hunks)";
        pairs.emplace_back(entry.second.first, label);
    }
    append_top(out, pairs);
    return out.str();
}

std::string file_report(const Ledger& ledger, std::uint32_t target) {
    const LedgerFile& file = ledger.files[target];
    std::uint64_t echoed = 0;
    std::uint64_t self_echo = 0;
    std::map<std::uint32_t, std::pair<std::uint64_t, std::uint64_t>> partners;  // bytes, hunks
    for (const LedgerHunk& hunk : ledger.hunks) {
        if (hunk.sites.size() < 2) {
            continue;
        }
        const auto counts = file_counts(hunk);
        const auto mine = counts.find(target);
        if (mine == counts.end()) {
            continue;
        }
        echoed += static_cast<std::uint64_t>(hunk.length) * mine->second;
        if (mine->second >= 2) {
            self_echo += static_cast<std::uint64_t>(hunk.length) * (mine->second - 1);
        }
        for (const auto& other : counts) {
            if (other.first == target) {
                continue;
            }
            const std::uint32_t overlap =
                mine->second < other.second ? mine->second : other.second;
            auto& slot = partners[other.first];
            slot.first += static_cast<std::uint64_t>(hunk.length) * overlap;
            ++slot.second;
        }
    }

    std::ostringstream out;
    out << "🍀 echoes for " << file.rel << "\n";
    out << "   physical_bytes:  " << file.bytes << "\n";
    out << "   echo_negator:    " << negator(echoed) << "   ("
        << format_percent(echoed, file.bytes) << "% of this raster recurs)\n";
    out << "   self_echo:       " << negator(self_echo) << "\n";
    if (echoed == 0) {
        out << "   this raster is one of a kind — no echoes.\n";
        return out.str();
    }
    bool titled = false;
    for (std::uint32_t id = 0; id < ledger.files.size(); ++id) {
        if (id != target && ledger.files[id].bytes > 0 &&
            ledger.files[id].whole == file.whole) {
            if (!titled) {
                out << "   perfect doppelgänger of:";
                titled = true;
            }
            out << " " << ledger.files[id].rel;
        }
    }
    if (titled) {
        out << "\n";
    }
    if (!partners.empty()) {
        out << "   shared with:\n";
        std::vector<std::pair<std::uint64_t, std::string>> entries;
        for (const auto& partner : partners) {
            entries.emplace_back(partner.second.first,
                                 ledger.files[partner.first].rel + "   (" +
                                     std::to_string(partner.second.second) + " hunks)");
        }
        append_top(out, entries);
    }
    return out.str();
}

std::optional<std::uint32_t> find_file(const Ledger& ledger, const fs::path& given) {
    std::map<std::string, std::uint32_t> index;
    for (std::uint32_t id = 0; id < ledger.files.size(); ++id) {
        index.emplace(ledger.files[id].rel, id);
    }
    std::vector<std::string> candidates;
    candidates.push_back(given.lexically_normal().generic_u8string());
    std::error_code ec;
    const fs::path absolute = fs::absolute(given, ec);
    if (!ec) {
        const fs::path root = fs::u8path(ledger.root);
        candidates.push_back(
            absolute.lexically_relative(root).lexically_normal().generic_u8string());
    }
    for (const std::string& candidate : candidates) {
        const auto found = index.find(candidate);
        if (found != index.end()) {
            return found->second;
        }
    }
    return std::nullopt;
}

}  // namespace

extern "C" {

int fw_hunk_scan(const char* search_root, char* out_path, std::size_t out_capacity) {
    auto lock = fweddle_detail::lock_runtime();
    try {
        const fs::path root = fweddle_detail::runtime_root_locked();
        std::error_code ec;
        const fs::path scan_root =
            search_root == nullptr ? root : fs::absolute(fs::u8path(search_root), ec);
        if (ec || !fs::is_directory(scan_root, ec)) {
            fweddle_detail::set_last_error("scan root is not a readable directory");
            return FW_INVALID_ARGUMENT;
        }
        Ledger ledger;
        std::string error;
        if (!build_ledger(scan_root, ledger, error)) {
            fweddle_detail::set_last_error(error);
            return FW_IO_ERROR;
        }
        const fs::path target = ledger_path_for(root);
        if (!fweddle_detail::atomic_write_file(target, emit_ledger(ledger), error)) {
            fweddle_detail::set_last_error("cannot commit hunk ledger: " + error);
            return FW_IO_ERROR;
        }
        fweddle_detail::clear_last_error();
        return fweddle_detail::copy_result_buffer(target.u8string(), out_path, out_capacity);
    } catch (const std::exception& failure) {
        fweddle_detail::set_last_error(failure.what());
        return FW_IO_ERROR;
    }
}

int fw_hunk_echoes(const char* target, char* out_report, std::size_t out_capacity) {
    auto lock = fweddle_detail::lock_runtime();
    try {
        const fs::path root = fweddle_detail::runtime_root_locked();
        const fs::path source = ledger_path_for(root);
        std::string text;
        if (!read_file_text(source, text)) {
            fweddle_detail::set_last_error("no hunk ledger at " + source.string() +
                                           "; run a scan first");
            return FW_NOT_FOUND;
        }
        Ledger ledger;
        std::string error;
        if (!parse_ledger(text, ledger, error)) {
            fweddle_detail::set_last_error("hunk ledger is unreadable (" + error +
                                           "); re-run the scan");
            return FW_BAD_METADATA;
        }
        std::string report;
        if (target == nullptr || *target == '\0') {
            report = global_report(ledger);
        } else {
            const auto id = find_file(ledger, fs::u8path(target));
            if (!id) {
                fweddle_detail::set_last_error(std::string(target) +
                                               " is not in the hunk ledger; "
                                               "re-run the scan or check the path");
                return FW_NOT_FOUND;
            }
            report = file_report(ledger, *id);
        }
        fweddle_detail::clear_last_error();
        return fweddle_detail::copy_result_buffer(report, out_report, out_capacity);
    } catch (const std::exception& failure) {
        fweddle_detail::set_last_error(failure.what());
        return FW_IO_ERROR;
    }
}

}  // extern "C"
