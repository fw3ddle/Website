// The emotes module: user-facing restyling of the emoji lexicon.
//
// The user lexicon is the fwemotes file, which lives in the root in one of
// two states: mortal (`fwemotes.json`) or sealed (`fwemotes.json.fweddle`).
// Because sealing never rewrites bytes, the sealed capsule is still the same
// JSON raster, so projections honor it in either state.
//
// `fw_emote_set` upserts or removes a single mapping. Mutating a sealed
// lexicon would rewrite a capsule's raster — forbidden — so the operation
// breaks the seal, edits the mortal file, and seals a fresh capsule. That is
// a compound operation: each step is individually atomic and serialized, but
// another fweddle process interleaving between steps can observe the mortal
// intermediate state.

#include "fweddle/fweddle.hpp"

#include "internal.hpp"

#include <algorithm>
#include <array>
#include <cctype>
#include <filesystem>
#include <fstream>
#include <map>
#include <regex>
#include <sstream>
#include <string>

namespace fs = std::filesystem;

namespace {

constexpr const char* kFwemotesName = "fwemotes.json";
constexpr const char* kCapsuleSuffix = ".fweddle";
constexpr std::size_t kPathBuffer = 32768;

std::string lower_ascii(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return value;
}

// Same normalization the lexicon loader applies, plus safety checks so a
// mapping key can never smuggle path syntax or quoting into the file.
bool normalize_extension(const char* raw, std::string& out, std::string& error) {
    if (raw == nullptr || *raw == '\0') {
        error = "extension is empty";
        return false;
    }
    std::string value = lower_ascii(raw);
    if (value.front() != '.') {
        value.insert(value.begin(), '.');
    }
    if (value == ".") {
        error = "extension is empty";
        return false;
    }
    for (unsigned char c : value) {
        if (c == '/' || c == '\\' || c == '"' || c < 0x21) {
            error = "extension may not contain separators, quotes, or whitespace";
            return false;
        }
    }
    out = value;
    return true;
}

std::string escape(const std::string& value) {
    std::ostringstream out;
    for (unsigned char c : value) {
        switch (c) {
            case '\\': out << "\\\\"; break;
            case '"': out << "\\\""; break;
            case '\n': out << "\\n"; break;
            case '\r': out << "\\r"; break;
            case '\t': out << "\\t"; break;
            default:
                if (c < 0x20) {
                    static const char* alphabet = "0123456789abcdef";
                    out << "\\u00" << alphabet[c >> 4U] << alphabet[c & 0x0FU];
                } else {
                    out << static_cast<char>(c);
                }
        }
    }
    return out.str();
}

std::string unescape(const std::string& value) {
    std::string out;
    out.reserve(value.size());
    for (std::size_t i = 0; i < value.size(); ++i) {
        if (value[i] != '\\' || i + 1 >= value.size()) {
            out.push_back(value[i]);
            continue;
        }
        const char next = value[++i];
        switch (next) {
            case '\\': out.push_back('\\'); break;
            case '"': out.push_back('"'); break;
            case 'n': out.push_back('\n'); break;
            case 'r': out.push_back('\r'); break;
            case 't': out.push_back('\t'); break;
            default:
                out.push_back('\\');
                out.push_back(next);
                break;
        }
    }
    return out;
}

bool read_file_text(const fs::path& path, std::string& text) {
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        return false;
    }
    std::ostringstream buffer;
    buffer << input.rdbuf();
    if (!input.good() && !input.eof()) {
        return false;
    }
    text = buffer.str();
    return true;
}

// Mirrors the tolerance of the core's lexicon loader: a JSON object of string
// pairs, keys normalized to lowercase dotted extensions.
bool load_pairs(const fs::path& path,
                std::map<std::string, std::string>& pairs,
                std::string& error) {
    std::string json;
    if (!read_file_text(path, json)) {
        error = "cannot read " + path.string();
        return false;
    }
    if (json.find('{') == std::string::npos || json.find('}') == std::string::npos) {
        error = path.string() + " is not a JSON object";
        return false;
    }
    const std::regex pair_pattern("\\\"((?:\\\\.|[^\\\"])*)\\\"\\s*:\\s*\\\"((?:\\\\.|[^\\\"])*)\\\"");
    std::size_t count = 0;
    for (std::sregex_iterator it(json.begin(), json.end(), pair_pattern), end; it != end;
         ++it) {
        std::string extension = lower_ascii(unescape((*it)[1].str()));
        if (!extension.empty() && extension.front() != '.') {
            extension.insert(extension.begin(), '.');
        }
        pairs[extension] = unescape((*it)[2].str());
        ++count;
    }
    if (count == 0 && json.find_first_not_of(" \t\r\n{}") != std::string::npos) {
        error = path.string() + " contains no valid string mappings";
        return false;
    }
    return true;
}

std::string emit_pairs(const std::map<std::string, std::string>& pairs) {
    if (pairs.empty()) {
        return "{}\n";
    }
    std::ostringstream out;
    out << "{\n";
    std::size_t index = 0;
    for (const auto& pair : pairs) {
        out << "  \"" << escape(pair.first) << "\": \"" << escape(pair.second) << "\""
            << (++index == pairs.size() ? "" : ",") << "\n";
    }
    out << "}\n";
    return out.str();
}

struct FwemotesState {
    fs::path mortal;
    fs::path sealed;
    bool mortal_exists = false;
    bool sealed_exists = false;
};

FwemotesState fwemotes_state(const fs::path& root) {
    FwemotesState state;
    state.mortal = root / kFwemotesName;
    state.sealed = root / (std::string(kFwemotesName) + kCapsuleSuffix);
    std::error_code ec;
    state.mortal_exists = fs::is_regular_file(state.mortal, ec);
    state.sealed_exists = fs::is_regular_file(state.sealed, ec);
    return state;
}

}  // namespace

extern "C" {

int fw_emote_set(const char* extension,
                 const char* emoji,
                 char* out_path,
                 std::size_t out_capacity) {
    try {
        std::string ext;
        std::string error;
        if (!normalize_extension(extension, ext, error)) {
            auto lock = fweddle_detail::lock_runtime();
            fweddle_detail::set_last_error(error);
            return FW_INVALID_ARGUMENT;
        }
        const bool removing = emoji == nullptr || *emoji == '\0';

        // Phase 1 (locked): learn where the fwemotes file is and what state
        // it is in.
        FwemotesState state;
        {
            auto lock = fweddle_detail::lock_runtime();
            const fs::path root = fweddle_detail::runtime_root_locked();
            state = fwemotes_state(root);
            if (state.mortal_exists && state.sealed_exists) {
                fweddle_detail::set_last_error(
                    "both " + state.mortal.string() + " and " + state.sealed.string() +
                    " exist; unseal or remove one before editing emotes");
                return FW_COLLISION;
            }
        }

        // Phase 2 (unlocked): a sealed lexicon cannot be rewritten in place —
        // the raster is sacred — so break the seal first. fw_exorcise takes
        // the runtime lock itself.
        fs::path mortal = state.mortal;
        if (state.sealed_exists) {
            std::array<char, kPathBuffer> restored{};
            const int status = fw_exorcise(state.sealed.u8string().c_str(),
                                           restored.data(), restored.size());
            if (status != FW_OK) {
                return status;
            }
            mortal = fs::u8path(restored.data());
        }

        // Phase 3 (locked): edit the mortal JSON and commit it atomically.
        {
            auto lock = fweddle_detail::lock_runtime();
            std::map<std::string, std::string> pairs;
            std::error_code ec;
            const bool present = fs::is_regular_file(mortal, ec);
            if (present && !load_pairs(mortal, pairs, error)) {
                fweddle_detail::set_last_error(error);
                return FW_BAD_METADATA;
            }
            if (removing) {
                if (!present) {
                    // Nothing to remove from: succeed without conjuring a file.
                    fweddle_detail::clear_last_error();
                    return fweddle_detail::copy_result_buffer(mortal.u8string(), out_path,
                                                              out_capacity);
                }
                pairs.erase(ext);
            } else {
                pairs[ext] = emoji;
            }
            if (!fweddle_detail::atomic_write_file(mortal, emit_pairs(pairs), error)) {
                fweddle_detail::set_last_error("cannot commit fwemotes: " + error);
                return FW_IO_ERROR;
            }
        }

        // Phase 4 (unlocked): restore the seal if there was one. The mapping
        // is already committed, so a reseal failure leaves a valid mortal
        // lexicon behind and says so.
        fs::path final_path = mortal;
        if (state.sealed_exists) {
            std::array<char, kPathBuffer> capsule{};
            const int status = fw_capsule(mortal.u8string().c_str(), capsule.data(),
                                          capsule.size());
            if (status != FW_OK) {
                auto lock = fweddle_detail::lock_runtime();
                fweddle_detail::set_last_error(
                    std::string("mapping saved to ") + mortal.string() +
                    " but resealing failed: " + fw_last_error());
                return status;
            }
            final_path = fs::u8path(capsule.data());
        }

        auto lock = fweddle_detail::lock_runtime();
        fweddle_detail::clear_last_error();
        return fweddle_detail::copy_result_buffer(final_path.u8string(), out_path,
                                                  out_capacity);
    } catch (const std::exception& failure) {
        auto lock = fweddle_detail::lock_runtime();
        fweddle_detail::set_last_error(failure.what());
        return FW_IO_ERROR;
    }
}

int fw_emote_report(char* out_report, std::size_t out_capacity) {
    auto lock = fweddle_detail::lock_runtime();
    try {
        const fs::path root = fweddle_detail::runtime_root_locked();
        std::map<std::string, std::string> effective;
        try {
            effective = fweddle_detail::effective_lexicon_locked();
        } catch (const std::exception& failure) {
            fweddle_detail::set_last_error(failure.what());
            return FW_BAD_METADATA;
        }
        const std::map<std::string, std::string> builtin =
            fweddle_detail::builtin_lexicon_map();

        std::string source;
        if (fweddle_detail::lexicon_is_explicit_locked()) {
            source = fweddle_detail::explicit_lexicon_path_locked().string() +
                     " (explicit --lexicon)";
        } else {
            const fs::path found = fweddle_detail::implicit_lexicon_source_locked();
            const FwemotesState state = fwemotes_state(root);
            if (found.empty()) {
                source = "built-in defaults only";
            } else if (found == state.mortal) {
                source = std::string(kFwemotesName) + " (mortal)";
            } else if (found == state.sealed) {
                source = std::string(kFwemotesName) + kCapsuleSuffix + " (sealed)";
            } else {
                source = ".fweddle/lexicon.json (legacy)";
            }
        }

        std::size_t width = 0;
        for (const auto& pair : effective) {
            width = pair.first.size() > width ? pair.first.size() : width;
        }
        std::ostringstream out;
        out << "🍀 emote lexicon — source: " << source << "\n";
        for (const auto& pair : effective) {
            const auto base = builtin.find(pair.first);
            const bool user = base == builtin.end() || base->second != pair.second;
            out << "   " << pair.first << std::string(width - pair.first.size() + 2, ' ')
                << pair.second << (user ? "   (user)" : "") << "\n";
        }
        const std::string label = "fallback";
        out << "   " << label
            << std::string(width > label.size() ? width - label.size() + 2 : 2, ' ')
            << "📦\n";
        fweddle_detail::clear_last_error();
        return fweddle_detail::copy_result_buffer(out.str(), out_report, out_capacity);
    } catch (const std::exception& failure) {
        fweddle_detail::set_last_error(failure.what());
        return FW_IO_ERROR;
    }
}

}  // extern "C"
